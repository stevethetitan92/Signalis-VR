$ErrorActionPreference='Stop'
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
 $t=$a.MainModule.Types|Where-Object Name -eq Tracking
 function Calls($name) { @(($t.Methods|Where-Object Name -eq $name).Body.Instructions|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference]}|ForEach-Object {$_.Operand.Name}) }
 foreach($name in 'PollQuestControllers','QuestAvailableNow') {
  if((Calls $name) -notcontains 'QuestHasSceneFocus'){throw "Missing scene ownership check: $name"}
 }
 if((Calls 'EnsureQuestMenuScene') -contains 'FindGameplayCamera'){throw 'Main menu requires gameplay camera'}
 foreach($name in 'ScreenCapture','RenderPuzzle') {} # Capture is checked by method name below.
 foreach($name in 'CaptureScreenshotIntoRenderTexture','ReadPose','RenderPuzzle') {
  if((Calls 'RenderQuestMenuScene') -notcontains $name){throw "Menu render missing $name"}
 }
 if((Calls 'SetupStereo') -contains 'Destroy'){throw 'Setup releases retained resources'}
 $src=Get-Content (Join-Path $PSScriptRoot 'QuestMenuScene.cs') -Raw
 $policy=$src.Substring($src.IndexOf(' public static class QuestScenePolicy'))
 Add-Type ('namespace SignalisVrTracking {'+$policy)
 foreach($case in @(@(0,0,$false),@(0,42,$false),@(41,42,$false),@(42,42,$true),@(42,0,$false))) {
  if([SignalisVrTracking.QuestScenePolicy]::OwnsScene($case[0],$case[1]) -ne $case[2]){throw 'Ownership policy failure'}
 }
 $main=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
 foreach($guard in 'if (questMenuScene || !active || diagnostic.Stage < 2) return;', 'if (!diagnostic.CanSubmit && !questMenuScene) return;', 'if (!stereo) EnableStereoSettings();', 'if (!active || !stereo || camera == null || !camera.isActiveAndEnabled) return;') {
  if(-not $main.Contains($guard)){throw "Missing transition guard: $guard"}
 }
 'PASS: scene PID policy; compiled focus gates and game-only capture/render calls; transition guards. No runtime/headset validation.'
} finally {$a.Dispose()}

