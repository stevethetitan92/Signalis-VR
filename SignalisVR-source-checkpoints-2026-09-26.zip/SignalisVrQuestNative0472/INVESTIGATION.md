# 0.4.72 candidate — main-menu VR scene

Goal: finish input coverage before stick response/performance tuning, per user.
No stick mapping, sensitivity, native input getter bridge or marker changes.

Starts a live game-only screen after window dimensions remain stable two seconds,
using the existing retained eye textures, puzzle screen and native render-thread
bridge. Does not require a gameplay camera. Quest routing requires SIGNALIS's
process to own the compositor scene, desktop focus, and a closed dashboard.
F6/F9 prepare immersive gameplay; F10 switches from the live screen. F9 cannot
advance without a valid gameplay camera. F12 stops. Failed automatic setup does
not retry allocations. Do not change game resolution during this test.

Changed: QuestMenuScene.cs (new), SignalisVrTracking.cs, PuzzleScreen.cs,
QuestControllers.cs, QuestFirstPerson.cs, build.ps1; test-menu-scene.ps1 added.
QuestInputPolicy.cs and QuestNativeReads.cs are byte-identical to 0471.
Shared GetInputState native detour remains removed.

Build succeeds (existing CS1701 reference warnings). Thirteen existing suites
and new menu-scene checks pass, covering input routing, button edges, independent
hand arming, native ABI, shared-getter regression, heading, overlays, markers,
recovery and diagnostic state. DiagnosticFlow tests describe immersive stages;
menu-scene submission is an explicit separate path. Evidence retained.
The inherited portability test failed because this incremental package has no
UserLibs payload. Loader/native dependencies are unchanged; portability was not
revalidated. This package contains only Mods/SignalisVrTracking.dll.

No game launched or installed by assistant. Installed DLL remains verified0471.
Compilation/static tests do not verify main-menu display, graphics stability,
scene ownership, UI navigation, or stereo handoff. These require headset testing.
No forced dashboard closure or SteamVR Home modification. Aim/fire/reload remain
untested until a weapon is available. Stick tuning explicitly deferred.

DLL SHA256: 4064AC16FFB79977797CF1BF674D394934BDB809D80B83C17D0E2F8E5247B529
Rollback0471.zip SHA256: 5A35982F389431E31988B3FF00DFD50EAD30A6295C6D60EDD406A580A6C50823
Candidate ZIP SHA256: FBBF3EE2FFD22D89BA8BC8C277ED50E4307550C67E9DC8F40F6F140563C51914
Installed0471 SHA256: EE6FF2CDB5468BCF3EAF374C476CABB69D005FCB4258F5631B22FDF6133A1321

Reference: https://github.com/ValveSoftware/openvr/wiki/IVRCompositor_Overview
WaitGetPoses establishes compositor focus; continuing submitted frames avoids
return to the grid. Actual ownership is checked by process ID at runtime.

Manual sequence (give user one step at a time): copy DLL while closed; launch
manually with SteamVR connected and stop at main menu; verify live headset screen;
verify navigation and A/B separately; load room then F6/F9/F10 handoff; recheck
movement, menu, inventory, book. F12 stops if needed. Restore0471 if regression.
