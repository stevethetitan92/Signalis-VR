using System;
using UnityEngine;
namespace SignalisVrTracking
{
    public sealed partial class Tracking
    {
        private Color[] markerColors = new Color[0];
        private bool[] markerRenderVetoes = new bool[0];
        private float nextObjectHighlightLog;
        private float nextBookGateLog;

        private void ShowObjectBracketForVr(SpriteRenderer sr, int index)
        {
            if (sr == null || sr.sprite == null || !HighlightPolicy.IsBracket(sr.sprite.name)) return;
            var popup = sr.GetComponentInParent<global::interactionPopup>();
            if (popup == null || popup.inter == null) return;
            var interaction = popup.inter;
            // Do not turn travel prompts into new object brackets.
            bool travel = interaction.GetComponentInParent<global::Ladder>() != null
                || interaction.GetComponentInParent<global::Doorway_Double>() != null
                || interaction.GetComponentInParent<global::InteractiveLockSingle>() != null
                || interaction.GetComponentInParent<global::InteractiveLock>() != null
                || interaction.GetComponentInParent<global::LoadLevelInteraction>() != null
                || interaction.GetComponentInParent<global::DoorLockEventInteraction>() != null;
            var book = interaction.GetComponent<global::BookScreen>();
            var pickup = interaction.GetComponent<global::ItemPickup>();
            var room = interaction.GetComponentInParent<global::Room>();
            bool sameRoom = room == null || global::PlayerState.currentRoom == null || room == global::PlayerState.currentRoom;
            bool consumed = pickup != null && (pickup.triggered || pickup.fadingOut);
            bool reading = book != null && (book.open || book.opening);
            bool cryoKeycard = pickup != null && interaction.gameObject.name == "ItemPickup_BrokenKey"
                && interaction.GetComponentInParent<global::PEN_Cryo>() != null;
            var bookBracket = book != null || cryoKeycard ? FindBookBracket(sr, interaction) : FindCryoKeypadBracket(sr, interaction);
            Vector3 rangeOrigin = bookBracket != null ? BracketOrigin(bookBracket) : markerPositions[index];
            Vector3 delta = rangeOrigin - camera.transform.position;
            bool visible = HighlightPolicy.Visible(interaction.gameObject.activeInHierarchy && sr.gameObject.activeInHierarchy,
                interaction.enabled, consumed, reading, sameRoom, travel, delta.x * delta.x + delta.y * delta.y, delta.z);
            if (book != null && Time.realtimeSinceStartup >= nextBookGateLog)
            {
                nextBookGateLog = Time.realtimeSinceStartup + 5f;
                MelonLoader.MelonLogger.Msg("BOOK VISIBILITY: object=" + interaction.gameObject.name
                    + " visible=" + visible + " active=" + interaction.gameObject.activeInHierarchy
                    + " spriteActive=" + sr.gameObject.activeInHierarchy + " enabled=" + interaction.enabled
                    + " consumed=" + consumed + " reading=" + reading + " sameRoom=" + sameRoom + " travel=" + travel
                    + " origin=" + FormatMarkerVector(rangeOrigin) + " camera=" + FormatMarkerVector(camera.transform.position)
                    + " model=" + (bookBracket == null ? "none" : bookBracket.model.name)
                    + " worldSize=" + (bookBracket == null ? "none" : FormatMarkerVector(bookBracket.model.GetComponent<MeshRenderer>().bounds.size)));
            }
            if (!visible || interaction.gameObject.name == "StompZone") return;
            // The game's popup animation can collapse its Y scale, fade alpha and
            // disable SR based on the flat-camera/player-facing interaction state.
            // Override only while each VR eye renders; restore ALL fields in finally.
            sr.enabled = true;
            sr.forceRenderingOff = false;
            var tint = markerColors[index];
            // An invisible/black animation sample is not the desired white artwork.
            if (tint.a < 0.1f || Math.Max(tint.r, Math.Max(tint.g, tint.b)) < 0.1f) tint = Color.white;
            tint.a = 1f;
            sr.color = tint;
            var scale = markerScales[index];
            scale.y = 1f;
            sr.transform.localScale = scale;
            if (bookBracket != null) PlaceBookBracket(bookBracket);
            if (Time.realtimeSinceStartup >= nextObjectHighlightLog)
            {
                nextObjectHighlightLog = Time.realtimeSinceStartup + 5f;
                MelonLoader.MelonLogger.Msg("HEADSET OBJECT BRACKET: object=" + interaction.gameObject.name
                    + " sprite=" + sr.sprite.name + " originalEnabled=" + markerEnabled[index]
                    + " originalAlpha=" + markerColors[index].a + " originalScaleY=" + markerScales[index].y
                    + " position=" + FormatMarkerVector(markerPositions[index])
                    + " bookAnchor=" + (bookBracket == null ? "none" : FormatMarkerVector(bookBracket.proxy.transform.position)));
            }
        }
    }
}
