using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking
{
    public sealed partial class Tracking
    {
        private sealed class BookBracket
        {
            internal SpriteRenderer source, proxy;
            internal MeshFilter model;
            internal Transform keypadRoot;
        }
        private readonly Dictionary<int, BookBracket> bookBrackets = new Dictionary<int, BookBracket>();

        private BookBracket FindCryoKeypadBracket(SpriteRenderer source, global::Interaction interaction)
        {
            var cryo = interaction.GetComponentInParent<global::PEN_Cryo>();
            if (cryo == null || cryo.interaction != interaction) return null;
            int id = source.GetInstanceID();
            BookBracket entry;
            if (bookBrackets.TryGetValue(id, out entry) && entry.source == source && entry.keypadRoot != null) return entry;
            entry = new BookBracket { source = source, keypadRoot = cryo.transform };
            bookBrackets[id] = entry;
            MelonLoader.MelonLogger.Msg("CRYO KEYPAD: selected controller interaction; anchor=" + FormatMarkerVector(BracketOrigin(entry)));
            return entry;
        }

        private static Vector3 BracketOrigin(BookBracket entry)
        {
            // Six-square panel UV center (84,210)/256 maps to Cryo-local
            // (-3.1,-3.8,-1.6). Clearance is 0.065 local Z toward world up.
            return entry.keypadRoot != null
                ? entry.keypadRoot.TransformPoint(new Vector3(-3.1f, -3.8f, -1.665f))
                : entry.model.GetComponent<MeshRenderer>().bounds.center;
        }

        private BookBracket FindBookBracket(SpriteRenderer source, global::Interaction interaction)
        {
            int id = source.GetInstanceID();
            BookBracket entry;
            if (bookBrackets.TryGetValue(id, out entry) && entry.source == source && entry.model != null) return entry;
            var models = interaction.GetComponentsInChildren<MeshFilter>(true);
            MeshFilter selected = null;
            foreach (var model in models)
            {
                if (model == null || model.sharedMesh == null || !model.gameObject.activeInHierarchy
                    || model.GetComponent<MeshRenderer>() == null) continue;
                if (selected != null) return null; // Ambiguous multi-model books keep the original path.
                selected = model;
            }
            if (selected == null) return null;
            entry = new BookBracket { source = source, model = selected };
            bookBrackets[id] = entry;
            return entry;
        }

        private void PlaceBookBracket(BookBracket entry)
        {
            if (entry.proxy == null)
            {
                var go = new GameObject("SignalisVR_BookBrackets_" + entry.source.GetInstanceID());
                go.layer = 23;
                entry.proxy = go.AddComponent<SpriteRenderer>();
                entry.proxy.enabled = false;
            }
            var source = entry.source;
            var proxy = entry.proxy;
            float width, height;
            if (entry.keypadRoot != null)
            {
                proxy.transform.position = BracketOrigin(entry);
                proxy.transform.rotation = entry.keypadRoot.rotation;
                width = 1.1f * entry.keypadRoot.TransformVector(Vector3.right).magnitude;
                height = 0.7f * entry.keypadRoot.TransformVector(Vector3.up).magnitude;
            }
            else
            {
            var model = entry.model;
            // Shared meshes may contain statically batched scene geometry. Renderer
            // bounds are already world-space: never transform their center again.
            var bounds = model.GetComponent<MeshRenderer>().bounds;
            proxy.transform.position = new Vector3(bounds.center.x, bounds.center.y, bounds.min.z - 0.08f);
            proxy.transform.rotation = Quaternion.identity;
            width = bounds.size.x;
            height = bounds.size.y;
            }
            proxy.sprite = source.sprite;
            proxy.sharedMaterial = source.sharedMaterial;
            proxy.color = source.color;
            proxy.sortingLayerID = source.sortingLayerID;
            proxy.sortingOrder = source.sortingOrder;
            var spriteSize = source.sprite.bounds.size;
            proxy.transform.localScale = new Vector3(Math.Max(0.5f, width) * 1.15f / Math.Max(0.01f, spriteSize.x),
                Math.Max(0.5f, height) * 1.15f / Math.Max(0.01f, spriteSize.y), 1f);
            // Independent root avoids the original popup's animated scale/nonuniform parent.
            proxy.enabled = true;
            source.enabled = false;
        }

        private void HideBookBrackets()
        { foreach (var e in bookBrackets.Values) if (e.proxy != null) e.proxy.enabled = false; }

        private void ClearBookBrackets()
        {
            foreach (var e in bookBrackets.Values) if (e.proxy != null) UnityEngine.Object.Destroy(e.proxy.gameObject);
            bookBrackets.Clear();
        }
    }
}
