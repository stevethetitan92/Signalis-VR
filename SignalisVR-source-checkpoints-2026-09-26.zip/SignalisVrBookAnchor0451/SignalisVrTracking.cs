using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Globalization;
using System.Collections;
using MelonLoader;
using UnityEngine;
using Valve.VR;

[assembly: MelonInfo(typeof(SignalisVrTracking.Tracking), "SIGNALIS VR Object Highlights", "0.4.51", "Local development")]
[assembly: MelonGame("rose-engine", "SIGNALIS")]
namespace SignalisVrTracking
{
    public sealed partial class Tracking : MelonMod
    {
        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int key);
        private readonly HotkeyEdge diagnosticConnect = new HotkeyEdge();
        private readonly HotkeyEdge diagnosticRender = new HotkeyEdge();
        private readonly HotkeyEdge diagnosticSubmit = new HotkeyEdge();
        private readonly HotkeyEdge diagnosticStop = new HotkeyEdge();
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int ConfigureBridgeDelegate(IntPtr submit, IntPtr wait, IntPtr left, IntPtr right);
        private static ConfigureBridgeDelegate ConfigureBridgeBound;
        private static int ConfigureBridge(IntPtr submit, IntPtr wait, IntPtr left, IntPtr right)
        {
            if (ConfigureBridgeBound == null) ConfigureBridgeBound = SignalisVrTracking.NativeLibraries.Bind<ConfigureBridgeDelegate>(true, "ConfigureBridge");
            return ConfigureBridgeBound(submit, wait, left, right);
        }
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int QueueFrameDelegate(int eventId, int flip);
        private static QueueFrameDelegate QueueFrameBound;
        private static int QueueFrame(int eventId, int flip)
        {
            if (QueueFrameBound == null) QueueFrameBound = SignalisVrTracking.NativeLibraries.Bind<QueueFrameDelegate>(true, "QueueFrame");
            return QueueFrameBound(eventId, flip);
        }
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int QueuePoseDelegate(int eventId);
        private static QueuePoseDelegate QueuePoseBound;
        private static int QueuePose(int eventId)
        {
            if (QueuePoseBound == null) QueuePoseBound = SignalisVrTracking.NativeLibraries.Bind<QueuePoseDelegate>(true, "QueuePose");
            return QueuePoseBound(eventId);
        }
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int GetPreparedPoseDelegate([Out] float[] matrix, out int valid);
        private static GetPreparedPoseDelegate GetPreparedPoseBound;
        private static int GetPreparedPose([Out] float[] matrix, out int valid)
        {
            if (GetPreparedPoseBound == null) GetPreparedPoseBound = SignalisVrTracking.NativeLibraries.Bind<GetPreparedPoseDelegate>(true, "GetPreparedPose");
            return GetPreparedPoseBound(matrix, out valid);
        }
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int CancelPreparedPoseDelegate();
        private static CancelPreparedPoseDelegate CancelPreparedPoseBound;
        private static int CancelPreparedPose()
        {
            if (CancelPreparedPoseBound == null) CancelPreparedPoseBound = SignalisVrTracking.NativeLibraries.Bind<CancelPreparedPoseDelegate>(true, "CancelPreparedPose");
            return CancelPreparedPoseBound();
        }
        private readonly float[] preparedMatrix = new float[12];
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate IntPtr GetRenderEventFuncDelegate();
        private static GetRenderEventFuncDelegate GetRenderEventFuncBound;
        private static IntPtr GetRenderEventFunc()
        {
            if (GetRenderEventFuncBound == null) GetRenderEventFuncBound = SignalisVrTracking.NativeLibraries.Bind<GetRenderEventFuncDelegate>(true, "GetRenderEventFunc");
            return GetRenderEventFuncBound();
        }
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int GetBridgeVersionDelegate();
        private static GetBridgeVersionDelegate GetBridgeVersionBound;
        private static int GetBridgeVersion()
        {
            if (GetBridgeVersionBound == null) GetBridgeVersionBound = SignalisVrTracking.NativeLibraries.Bind<GetBridgeVersionDelegate>(true, "GetBridgeVersion");
            return GetBridgeVersionBound();
        }
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void GetBridgeStatusDelegate(out int state, out int leftError, out int rightError, out int frames, out uint renderThread);
        private static GetBridgeStatusDelegate GetBridgeStatusBound;
        private static void GetBridgeStatus(out int state, out int leftError, out int rightError, out int frames, out uint renderThread)
        {
            if (GetBridgeStatusBound == null) GetBridgeStatusBound = SignalisVrTracking.NativeLibraries.Bind<GetBridgeStatusDelegate>(true, "GetBridgeStatus");
            GetBridgeStatusBound(out state, out leftError, out rightError, out frames, out renderThread);
        }
        private CVRSystem system;
        private readonly TrackedDevicePose_t[] poses = new TrackedDevicePose_t[OpenVR.k_unMaxTrackedDeviceCount];
        private Camera camera;
        private Quaternion originalRotation, neutral;
        private Quaternion stereoRotation;
        private bool recenterPending;
        private float nextPoseLog, nextFrameLog;
        private bool active;
        private bool waitingForGameplay;
        private float nextCameraCheck;
        private bool wasTracked;
        private bool stereo;
        private CVRCompositor compositor;
        private readonly Camera[] eyes = new Camera[2];
        private readonly RenderTexture[] textures = new RenderTexture[2];
        private readonly IntPtr[] textureHandles = new IntPtr[2];
        private readonly TrackedDevicePose_t[] gamePoses = new TrackedDevicePose_t[0];
        private bool submitted;
        private bool flipVertical = true;
        private bool originalBackground;
        private int oldVsync, oldFrameRate;
        private bool bridgeConfigured, stopping;
        private bool allocationAttempted;
        private int resumeFrame;
        private IntPtr renderCallback;
        private int eventId = 1000;
        // Initial estimate from the first-person camera height; needs headset calibration.
        private const float UnitsPerMetre = 5f;
        private readonly DiagnosticFlow diagnostic = new DiagnosticFlow();
        private readonly CameraRecovery recovery = new CameraRecovery();
        private bool menuCaptureReady;
        private bool pauseMenuVisible;
        private bool bookScreenVisible;
        private bool dialogueScreenVisible;
        private readonly HotkeyEdge menuFlip = new HotkeyEdge();
        private float nextFocusLog;
        private int diagnosticFrames;
        private bool traceFrame;
        public override void OnApplicationStart()
        {
            try
            {
                NativeLibraries.Initialize();
                if (GetBridgeVersion() != 400) throw new InvalidOperationException("Render bridge ABI mismatch: expected 400.");
                MelonLogger.Msg("VR dependencies verified: " + NativeLibraries.LibraryDirectory);
            }
            catch (Exception ex) { MelonLogger.Warning("VR startup check failed: " + ex.Message); }
            MarkerSuppression.Install();
            MelonCoroutines.Start(PuzzleFrames());
            MelonLogger.Msg("HEADSET BOOK ANCHOR 0.4.51: F6 connect; F9 render locally; F10 start continuous submission; F12 stop. These keys work without game keyboard focus. F1 still enables first person.");
        }
        public override void OnSceneWasLoaded(int index, string name)
        {
            Stop();
            doorMarkerAnchors.Clear();
            MarkerSuppression.Reset();
            ClearBookBrackets();
        }
        public override void OnApplicationQuit()
        {
            Stop();
            MelonLogger.Msg("Exit: VR resources are retained for process cleanup; no explicit compositor teardown.");
        }
        private Camera passiveCamera; private float nextPassiveSearch; private bool? lastCameraEnabled;
        private int observedCameraId;
        private string lastCameraCheckpoint = "none";
        private void ObserveCamera(string checkpoint)
        {
            try
            {
                if (passiveCamera == null && Time.realtimeSinceStartup >= nextPassiveSearch)
                {
                    nextPassiveSearch = Time.realtimeSinceStartup + 0.5f;
                    var go = GameObject.Find("__Prerequisites__/Character Origin/Character Root/Main Camera");
                    if (go != null) passiveCamera = go.GetComponent<Camera>();
                }
                var observed = camera != null ? camera : passiveCamera;
                if (observed == null) return;
                int id = observed.GetInstanceID();
                bool enabled = observed.enabled;
                if (id != observedCameraId || !lastCameraEnabled.HasValue || lastCameraEnabled.Value != enabled)
                    MelonLogger.Msg("CAMERA TRANSITION: checkpoint=" + checkpoint + " previousCheckpoint=" + lastCameraCheckpoint
                        + " frame=" + Time.frameCount + " id=" + id + " enabled=" + enabled + " stage=" + diagnostic.Stage);
                observedCameraId = id;
                lastCameraEnabled = enabled;
                lastCameraCheckpoint = checkpoint;
            }
            catch (Exception ex) { MelonLogger.Warning("Camera observation failed: " + ex.Message); }
        }
        private global::BookScreen[] cachedBookReaders = new global::BookScreen[0];
        private float nextBookObservation;
        private string lastBookObservation;
        private void ObserveBookReaders()
        {
            if (Time.realtimeSinceStartup < nextBookObservation) return;
            nextBookObservation = Time.realtimeSinceStartup + 1f;
            try
            {
                var manager = global::BookManager.instance;
                var selectedScreen = manager != null ? manager.screen : null;
                string report = "manager=" + (manager == null ? "null" : manager.GetInstanceID().ToString())
                    + " managerScreen=" + (selectedScreen == null ? "null" : selectedScreen.GetInstanceID().ToString());
                var readers = Resources.FindObjectsOfTypeAll<global::BookScreen>();
                cachedBookReaders = new global::BookScreen[readers.Length];
                for (int r = 0; r < readers.Length; r++) cachedBookReaders[r] = readers[r];
                report += " readers=" + readers.Length;
                for (int i = 0; i < readers.Length && i < 32; i++)
                {
                    var reader = readers[i];
                    if (reader == null) continue;
                    var go = reader.gameObject;
                    report += " | id=" + reader.GetInstanceID() + " name=" + go.name
                        + " active=" + go.activeInHierarchy + " enabled=" + reader.enabled
                        + " open=" + reader.open + " opening=" + reader.opening
                        + " page=" + reader.pageToDisplay;
                }
                if (report != lastBookObservation)
                {
                    MelonLogger.Msg("BOOK DIAGNOSTIC: " + report);
                    lastBookObservation = report;
                }
            }
            catch (Exception ex)
            {
                string error = "error=" + ex.GetType().Name + ": " + ex.Message;
                if (error != lastBookObservation) MelonLogger.Warning("BOOK DIAGNOSTIC: " + error);
                lastBookObservation = error;
            }
        }
        private float nextDialogueObservation;
        private string lastDialogueObservation;
        private static string DescribeUiObject(UnityEngine.Object value)
        {
            if (value == null) return "null";
            var go = value.TryCast<GameObject>();
            if (go == null)
            {
                var component = value.TryCast<Component>();
                if (component != null) go = component.gameObject;
            }
            return value.name + "#" + value.GetInstanceID()
                + (go == null ? "" : ":active=" + go.activeInHierarchy);
        }
        private void ObserveDialogueUi()
        {
            if (Time.realtimeSinceStartup < nextDialogueObservation) return;
            nextDialogueObservation = Time.realtimeSinceStartup + 0.5f;
            try
            {
                var ui = global::BlackSleekGuiSubs.instance;
                string report = ui == null ? "controller=null" :
                    "id=" + ui.GetInstanceID() + " show=" + ui._showDialogueBox
                    + " ending=" + ui._ending + " talking=" + global::BlackSleekGuiSubs.talking
                    + " itemView=" + global::BlackSleekGuiSubs.itemView + " ready=" + ui._windowReady
                    + " textBox=" + DescribeUiObject(ui.TextBox)
                    + " canvas=" + DescribeUiObject(ui.DialogueCanvas)
                    + " holder=" + DescribeUiObject(ui.DialogueHolder)
                    + " itemBox=" + DescribeUiObject(ui._ItemViewBox)
                    + " choices=" + DescribeUiObject(ui.choiceHolder);
                if (report != lastDialogueObservation)
                {
                    MelonLogger.Msg("DIALOGUE DIAGNOSTIC: " + report);
                    lastDialogueObservation = report;
                }
            }
            catch (Exception ex)
            {
                string error = "error=" + ex.GetType().Name + ": " + ex.Message;
                if (error != lastDialogueObservation) MelonLogger.Warning("DIALOGUE DIAGNOSTIC: " + error);
                lastDialogueObservation = error;
            }
        }
        private float nextMarkerCameraScan;
        private float nextIndicatorObservation;
        private string lastIndicatorError;
        private void ObserveInteractionIndicators()
        {
            if (!active || Time.realtimeSinceStartup < nextIndicatorObservation) return;
            nextIndicatorObservation = Time.realtimeSinceStartup + 2f;
            try
            {
                var markers = Resources.FindObjectsOfTypeAll<global::interactionPopup>();
                MelonLogger.Msg("INDICATOR SNAPSHOT: count=" + markers.Length + " stage=" + diagnostic.Stage
                    + " source=" + DescribeIndicatorCamera(camera)
                    + " left=" + DescribeIndicatorCamera(eyes[0]) + " right=" + DescribeIndicatorCamera(eyes[1]));
                int reported = 0;
                for (int i = 0; i < markers.Length && reported < 24; i++)
                {
                    var marker = markers[i];
                    if (marker == null || !marker.gameObject.activeInHierarchy) continue;
                    var sr = marker.SR;
                    if (camera != null && Vector3.Distance(camera.transform.position, marker.transform.position) > 40f) continue;
                    reported++;
                    string report = "id=" + marker.GetInstanceID() + " name=" + marker.gameObject.name
                        + " flickerTime=" + marker.flickerTime + " flickerTimer=" + marker.flickerTimer + " enabled=" + marker.enabled + " triggered=" + marker.wasTriggered + " forceOn=" + global::interactionPopup.forceOn
                        + " position=" + FormatMarkerVector(marker.transform.position);
                    if (sr == null) report += " SR=null";
                    else
                    {
                        int layer = sr.gameObject.layer;
                        report += " sprite=" + (sr.sprite == null ? "null" : sr.sprite.name)
                            + " active=" + sr.gameObject.activeInHierarchy + " rendererEnabled=" + sr.enabled
                            + " alpha=" + sr.color.a + " layer=" + layer + " position=" + FormatMarkerVector(sr.transform.position)
                            + " forward=" + FormatMarkerVector(sr.transform.forward) + " scale=" + FormatMarkerVector(sr.transform.lossyScale)
                            + " sourceIncludes=" + (camera != null && (camera.cullingMask & (1 << layer)) != 0)
                            + " leftIncludes=" + (eyes[0] != null && (eyes[0].cullingMask & (1 << layer)) != 0)
                            + " rightIncludes=" + (eyes[1] != null && (eyes[1].cullingMask & (1 << layer)) != 0)
                            + " shader=" + (sr.sharedMaterial == null || sr.sharedMaterial.shader == null ? "null" : sr.sharedMaterial.shader.name);
                    }
                    MelonLogger.Msg("INDICATOR: " + report);
                }
                var doors = Resources.FindObjectsOfTypeAll<global::DoorInteractionPopup>();
                int doorCount = 0;
                for (int i = 0; i < doors.Length && doorCount < 24; i++)
                {
                    var door = doors[i];
                    if (door == null || !door.gameObject.activeInHierarchy) continue;
                    if (camera != null && Vector3.Distance(camera.transform.position, door.transform.position) > 40f) continue;
                    doorCount++;
                    MelonLogger.Msg("DOOR MARKER: name=" + door.gameObject.name + " enabled=" + door.enabled
                        + " triggered=" + door.wasTriggered + " flickerTime=" + door.flickerTime
                        + " flickerTimer=" + door.flickerTimer + " position=" + FormatMarkerVector(door.transform.position));
                }
                if (Time.realtimeSinceStartup >= nextMarkerCameraScan)
                {
                    nextMarkerCameraScan = Time.realtimeSinceStartup + 10f;
                    var sprites = Resources.FindObjectsOfTypeAll<SpriteRenderer>();
                    int logged = 0;
                    for (int si = 0; si < sprites.Length && logged < 80; si++)
                    {
                        var sr = sprites[si];
                        if (sr == null || sr.gameObject.layer != 23 || !sr.gameObject.activeInHierarchy) continue;
                        if (camera != null && Vector3.Distance(camera.transform.position, sr.transform.position) > 45f) continue;
                        logged++;
                        string path = sr.gameObject.name;
                        var ancestor = sr.transform.parent;
                        for (int depth = 0; ancestor != null && depth < 5; depth++, ancestor = ancestor.parent)
                            path = ancestor.name + "/" + path;
                        var popup = sr.GetComponentInParent<global::DoorInteractionPopup>();
                        if (popup != null && popup.door != null && sr.gameObject.name.StartsWith("Door Icon", StringComparison.Ordinal)
                            && (popup.gameObject.name == "Door Icon E" || popup.gameObject.name == "Door Icon W"))
                        {
                            var root = popup.door.transform.parent != null ? popup.door.transform.parent : popup.door.transform;
                            var geometry = root.GetComponentsInChildren<Renderer>(true);
                            MelonLogger.Msg("SIDE GEOMETRY ROOT: name=" + root.name + " camera=" + (camera == null ? "null" : FormatMarkerVector(camera.transform.position)));
                            for (int gi = 0; gi < geometry.Length && gi < 32; gi++)
                            {
                                var r = geometry[gi];
                                if (r == null) continue;
                                MelonLogger.Msg("SIDE GEOMETRY: door=" + popup.gameObject.name + " name=" + r.gameObject.name
                                    + " layer=" + r.gameObject.layer + " enabled=" + r.enabled + " active=" + r.gameObject.activeInHierarchy
                                    + " center=" + FormatMarkerVector(r.bounds.center) + " size=" + FormatMarkerVector(r.bounds.size)
                                    + " position=" + FormatMarkerVector(r.transform.position));
                            }
                            DoorMarkerAnchor captured;
                            if (doorMarkerAnchors.TryGetValue(sr.GetInstanceID(), out captured))
                                MelonLogger.Msg("SIDE ANCHOR: door=" + popup.gameObject.name + " position=" + FormatMarkerVector(captured.position)
                                    + " rotation=" + FormatMarkerVector(captured.rotation.eulerAngles));
                        }
                        var obj = sr.GetComponentInParent<global::interactionPopup>();
                        MelonLogger.Msg("MARKER ART: path=" + path + " sprite=" + (sr.sprite == null ? "null" : sr.sprite.name)
                            + " enabled=" + sr.enabled + " flipX=" + sr.flipX + " flipY=" + sr.flipY
                            + " localRotation=" + FormatMarkerVector(sr.transform.localEulerAngles)
                            + " worldRotation=" + FormatMarkerVector(sr.transform.eulerAngles)
                            + " localScale=" + FormatMarkerVector(sr.transform.localScale)
                            + " worldScale=" + FormatMarkerVector(sr.transform.lossyScale)
                            + " pos=" + FormatMarkerVector(sr.transform.position)
                            + " doorPopup=" + (popup == null ? "null" : popup.gameObject.name)
                            + " objectPopup=" + (obj == null ? "null" : obj.gameObject.name)
                            + " doorPos=" + (popup == null || popup.door == null ? "null" : FormatMarkerVector(popup.door.transform.position)));
                    }
                    var cams = Resources.FindObjectsOfTypeAll<Camera>();
                    for (int i = 0; i < cams.Length; i++)
                    {
                        var c = cams[i];
                        if (c == null || !c.gameObject.activeInHierarchy || (c.cullingMask & (1 << 23)) == 0) continue;
                        string components = "";
                        var all = c.gameObject.GetComponents<Component>();
                        for (int j = 0; j < all.Length; j++) if (all[j] != null) components += all[j].GetIl2CppType().Name + ",";
                        MelonLogger.Msg("MARKER CAMERA: " + DescribeIndicatorCamera(c) + " depth=" + c.depth
                            + " ortho=" + c.orthographic + " target=" + (c.targetTexture == null ? "screen" : c.targetTexture.name)
                            + " components=" + components);
                    }
                }
                lastIndicatorError = null;
            }
            catch (Exception ex)
            {
                string error = ex.GetType().Name + ": " + ex.Message;
                if (lastIndicatorError != error) MelonLogger.Warning("INDICATOR observation failed: " + error);
                lastIndicatorError = error;
            }
        }
        private static string FormatMarkerVector(Vector3 v) { return string.Format(CultureInfo.InvariantCulture, "({0:F3},{1:F3},{2:F3})", v.x, v.y, v.z); }
        private string DescribeIndicatorCamera(Camera c)
        {
            return c == null ? "null" : c.name + ":enabled=" + c.enabled + ":mask=" + c.cullingMask
                + ":position=" + FormatMarkerVector(c.transform.position);
        }
        public override void OnUpdate()
        {
            try
            {
                ObserveInteractionIndicators();
                ObserveDialogueUi();
                ObserveBookReaders();
                ObserveCamera("Update entry"); // Direct Windows key edges do not depend on Unity keyboard focus.
                bool connectPressed = diagnosticConnect.Poll((GetAsyncKeyState(0x75) & 0x8000) != 0);
                bool renderPressed = diagnosticRender.Poll((GetAsyncKeyState(0x78) & 0x8000) != 0);
                bool submitPressed = diagnosticSubmit.Poll((GetAsyncKeyState(0x79) & 0x8000) != 0);
                bool stopPressed = diagnosticStop.Poll((GetAsyncKeyState(0x7B) & 0x8000) != 0);
                if (connectPressed || renderPressed || submitPressed || stopPressed)
                    MelonLogger.Msg("DIAG physical hotkey: " + (stopPressed ? "stop" : connectPressed ? "connect" : renderPressed ? "render" : "submit"));
                if (menuFlip.Poll((GetAsyncKeyState(0x7A) & 0x8000) != 0)) { puzzleContentFlip = !puzzleContentFlip; ApplyPuzzleUV(); MelonLogger.Msg("Inventory image flip=" + puzzleContentFlip); }
                if (stopping) { FinishStop(); return; }
                LogVrFocus();
                if (stopPressed) { MelonLogger.Msg("DIAG: manual stop."); Stop(); return; }
                if (bridgeConfigured && stereo) CheckRenderStatus();
                if (connectPressed)
                {
                    if (diagnostic.Stage != 0) { MelonLogger.Msg("DIAG: already connected. F9 is the next stage."); return; }
                    MelonLogger.Msg("DIAG A begin: OpenVR scene connection only; no eye allocation or submission.");
                    NativeLibraries.Initialize();
                    EVRInitError error = EVRInitError.None;
                    if (system == null) system = OpenVR.Init(ref error, EVRApplicationType.VRApplication_Scene);
                    if (error != EVRInitError.None || system == null) throw new InvalidOperationException("OpenVR connection: " + error);
                    diagnostic.Connected();
                    MelonLogger.Msg("DIAG A complete: connected. Observe dashboard, wait 20 seconds, then F9.");
                }
                if (renderPressed)
                {
                    if (diagnostic.Stage != 1) { MelonLogger.Msg("DIAG: F9 requires stage A first (F6). It does not toggle VR in this build."); return; }
                    MelonLogger.Msg("DIAG B begin: eye setup/render only; submission and WaitGetPoses disabled.");
                    Start(true);
                    if (!active || !stereo) return;
                    diagnostic.RenderReady();
                    diagnosticFrames = 0;
                    Application.targetFrameRate = 72;
                    MelonLogger.Msg("DIAG B active: images render locally only. Wait 20 seconds before F10.");
                }
                if (submitPressed)
                {
                    if (recovery.Paused || camera == null || !camera.isActiveAndEnabled) { MelonLogger.Msg("DIAG: F10 deferred; gameplay camera is unavailable."); return; }
                    if (!diagnostic.BeginSubmit(Time.realtimeSinceStartup)) { MelonLogger.Msg("DIAG: F10 requires stage B (F9) first."); return; }
                    recenterPending = true; // Center from first valid synchronized stereo pose, not the earlier F9 pose.
                    diagnosticFrames = 0;
                    MelonLogger.Msg("DIAG C begin: synchronized poses and native submission enabled continuously until manual stop or error.");
                }
                if (active && Input.GetKeyDown(KeyCode.F7))
                {
                    if (recovery.Paused || waitingForGameplay) puzzleAnchorPending = true;
                    else recenterPending = true;
                    MelonLogger.Msg("Recenter requested for next valid tracked frame.");
                }
            }
            catch (Exception ex) { MelonLogger.Warning("Tracking stopped: " + ex.Message); Stop(); }
        }
        public override void OnLateUpdate() { ObserveCamera("LateUpdate entry passive");
            if (!active || diagnostic.Stage < 2) return;
            try
            {
                if (waitingForGameplay)
                {
                    if (Time.realtimeSinceStartup < nextCameraCheck) return;
                    nextCameraCheck = Time.realtimeSinceStartup + 0.25f;
                    var restored = FindGameplayCamera();
                    if (restored == null) return;
                    camera = restored;
                    originalRotation = camera.transform.localRotation;
                    waitingForGameplay = false;
                    MelonLogger.Msg("Gameplay camera restored; stereo resumed automatically.");
                }
                ObserveCamera("LateUpdate guard"); if (camera == null || !camera.gameObject.activeInHierarchy || camera.orthographic || camera.transform.parent == null || camera.transform.parent.name != "Character Root")
                {
                    try
                    {
                        if (camera == null) MelonLogger.Msg("CAMERA GUARD: referenced camera is null or destroyed.");
                        else
                        {
                            var parent = camera.transform.parent;
                            MelonLogger.Msg("CAMERA GUARD: id=" + camera.GetInstanceID() + " name=" + camera.name
                                + " activeEnabled=" + camera.isActiveAndEnabled + " enabled=" + camera.enabled
                                + " activeHierarchy=" + camera.gameObject.activeInHierarchy + " orthographic=" + camera.orthographic
                                + " parent=" + (parent == null ? "<null>" : parent.name)
                                + " localPosition=" + camera.transform.localPosition);
                        }
                    }
                    catch (Exception ex) { MelonLogger.Warning("CAMERA GUARD snapshot failed: " + ex.Message); }
                    MelonLogger.Msg("DIAG: camera eligibility check failed; test stopped. See CAMERA GUARD above.");
                    Stop(); return;
                }
                bool wasPaused = recovery.Paused;
                var pauseMenu = global::PauseMenu.instance;
                var pauseObject = pauseMenu != null ? pauseMenu.MenuObject : null;
                bool pauseVisible = pauseObject != null && pauseObject.activeInHierarchy;
                if (pauseVisible != pauseMenuVisible)
                    MelonLogger.Msg("PAUSE MENU: visible=" + pauseVisible + ", gameplayCameraEnabled=" + camera.enabled);
                pauseMenuVisible = pauseVisible;
                bool bookVisible = false;
                for (int r = 0; r < cachedBookReaders.Length; r++)
                {
                    var reader = cachedBookReaders[r];
                    if (reader != null && reader.enabled && reader.gameObject.activeInHierarchy && reader.open)
                    {
                        bookVisible = true;
                        break;
                    }
                }
                if (bookVisible != bookScreenVisible)
                    MelonLogger.Msg("BOOK SCREEN: open=" + bookVisible + ", gameplayCameraEnabled=" + camera.enabled);
                bookScreenVisible = bookVisible;
                var dialogueUi = global::BlackSleekGuiSubs.instance;
                var dialogueHolder = dialogueUi != null ? dialogueUi.DialogueHolder : null;
                bool dialogueVisible = dialogueUi != null && dialogueHolder != null
                    && dialogueHolder.activeInHierarchy && (dialogueUi._showDialogueBox || dialogueUi._ending);
                if (dialogueVisible != dialogueScreenVisible)
                    MelonLogger.Msg("DIALOGUE SCREEN: visible=" + dialogueVisible + ", gameplayCameraEnabled=" + camera.enabled);
                dialogueScreenVisible = dialogueVisible;
                int recoveryAction = recovery.Observe(camera.enabled && !pauseMenuVisible && !bookScreenVisible && !dialogueScreenVisible, Time.realtimeSinceStartup);
                if (!wasPaused && recovery.Paused) { menuCaptureReady = false; puzzleAnchorPending = true; puzzleLogged = false; }
                if (!wasPaused && recovery.Paused)
                    MelonLogger.Msg("CAMERA RECOVERY: menu/camera suspended; displaying capture until the same camera returns. Native resources retained.");
                if (recovery.Paused)
                {
                    // Drain without blocking, discarding old prepared poses.
                    bool drained = menuCaptureReady && recoveryAction != 2;
                    if (!drained) drained = !bridgeConfigured || CancelPreparedPose() != 0;
                    if (drained) menuCaptureReady = true;
                    if (recoveryAction == 2 && drained)
                    {
                        menuCaptureReady = false;
                        recovery.Reset();
                        MelonLogger.Msg("CAMERA RECOVERY: camera stable; resuming next frame with fresh pose.");
                    }
                    return;
                }
                Quaternion pose;
                if (stereo && !CheckRenderStatus()) return;
                traceFrame = diagnosticFrames < 3;
                if (traceFrame) MelonLogger.Msg("DIAG stage " + diagnostic.Stage + " frame " + diagnosticFrames + ": pose call begin.");
                bool tracked = ReadPose(out pose, true);
                // A queued render-thread pose is asynchronous, not tracking loss.
                if (!tracked && diagnostic.CanSubmit) return;
                if (traceFrame) MelonLogger.Msg("DIAG: pose returned, valid=" + tracked);
                if (tracked != wasTracked) MelonLogger.Msg(tracked ? "Headset tracking acquired." : "Headset tracking lost; camera returned to neutral.");
                wasTracked = tracked;
                if (tracked && recenterPending)
                {
                    neutral = stereo ? Heading(pose) : pose;
                    recenterPending = false;
                    MelonLogger.Msg("Head tracking centered from current render pose.");
                }
                var baseRotation = stereo ? Heading(originalRotation) : originalRotation;
                var trackedLocal = tracked ? baseRotation * Quaternion.Inverse(neutral) * pose : baseRotation;
                if (stereo)
                {
                    // Keep headset rotation out of the camera controlled by FPv2.
                    // Otherwise other camera/control code can feed it back into the rig.
                    stereoRotation = camera.transform.parent.rotation * trackedLocal;
                }
                else camera.transform.localRotation = trackedLocal;
                if (tracked && Time.realtimeSinceStartup >= nextPoseLog)
                {
                    nextPoseLog = Time.realtimeSinceStartup + 2f;
                    var rig = camera.transform.parent.rotation.eulerAngles;
                    var local = originalRotation.eulerAngles;
                    var raw = pose.eulerAngles;
                    MelonLogger.Msg(string.Format(CultureInfo.InvariantCulture,
                        "Orientation inputs: rig=({0:F1},{1:F1},{2:F1}) initialLocal=({3:F1},{4:F1},{5:F1}) rawHead=({6:F1},{7:F1},{8:F1})",
                        rig.x, rig.y, rig.z, local.x, local.y, local.z, raw.x, raw.y, raw.z));
                    var head = (Quaternion.Inverse(neutral) * pose).eulerAngles;
                    var view = stereo ? stereoRotation.eulerAngles : camera.transform.rotation.eulerAngles;
                    MelonLogger.Msg(string.Format(CultureInfo.InvariantCulture, "Pose diagnostic: relative head=({0:F1},{1:F1},{2:F1}), view=({3:F1},{4:F1},{5:F1})", head.x, head.y, head.z, view.x, view.y, view.z));
                }
                if (stereo && tracked) { RenderStereo(); diagnosticFrames++; }
            }
            catch (Exception ex) { MelonLogger.Warning("Tracking stopped: " + ex.Message); Stop(); }
        }
        private void Start(bool wantStereo)
        {
            if (stopping) { MelonLogger.Warning("Previous render event is still finishing. Retry after it drains."); return; }
            var go = GameObject.Find("__Prerequisites__/Character Origin/Character Root/Main Camera");
            if (go == null) { MelonLogger.Warning("Load gameplay and press F1 before enabling head tracking."); return; }
            var candidate = go.GetComponent<Camera>();
            if (candidate == null || candidate.orthographic || !candidate.isActiveAndEnabled)
            { MelonLogger.Warning("First-person gameplay camera is not active."); return; }
                    NativeLibraries.Initialize();
            EVRInitError error = EVRInitError.None;
            // Keep one scene connection for the process. F9 is pause/resume,
            // never an OpenVR shutdown followed by immediate reinitialization.
            if (system == null) system = OpenVR.Init(ref error, EVRApplicationType.VRApplication_Scene);
            if (error != EVRInitError.None || system == null)
            { system = null; throw new InvalidOperationException("SteamVR connection failed: " + error + ". Connect Virtual Desktop and start SteamVR first."); }
            Quaternion pose;
            if (!ReadPose(out pose)) { Stop(); MelonLogger.Warning("No tracked headset. Put on the Quest, then press F6 to retry."); return; }
            camera = candidate;
            originalRotation = camera.transform.localRotation;
            neutral = wantStereo ? Heading(pose) : pose;
            recenterPending = true;
            nextPoseLog = nextFrameLog = 0f;
            active = true;
            wasTracked = true;
            if (wantStereo) SetupStereo();
            MelonLogger.Msg("DIAG: eye resources initialized; submission remains gated by stage C.");
        }
        private Camera FindGameplayCamera()
        {
            var go = GameObject.Find("__Prerequisites__/Character Origin/Character Root/Main Camera");
            if (go == null) return null;
            var found = go.GetComponent<Camera>();
            return found != null && found.isActiveAndEnabled && !found.orthographic ? found : null;
        }
        private void SuspendForGameplay()
        {
            if (!waitingForGameplay)
            {
                puzzleAnchorPending = true;
                puzzleLogged = false;
                MelonLogger.Msg("Gameplay camera unavailable; switching to live puzzle screen. F7 positions it ahead; F9 stops VR.");
            }
            waitingForGameplay = true;
            camera = null;
            nextCameraCheck = 0f;
        }
        private void SetupStereo()
        {
            if (bridgeConfigured)
            {
                if (eyes[0] == null || eyes[1] == null || textures[0] == null || textures[1] == null)
                    throw new InvalidOperationException("Retained VR resources were lost. Restart SIGNALIS before retrying.");
                EnableStereoSettings();
                MelonLogger.Msg("Stereo resumed using existing textures and SteamVR connection.");
                return;
            }
            if (allocationAttempted) throw new InvalidOperationException("A previous stereo setup failed. Restart SIGNALIS before retrying.");
            allocationAttempted = true;
            if (SystemInfo.graphicsDeviceType != UnityEngine.Rendering.GraphicsDeviceType.Direct3D11)
                throw new InvalidOperationException("This stereo prototype requires Direct3D 11.");
            compositor = OpenVR.Compositor;
            if (compositor == null) throw new InvalidOperationException("SteamVR compositor unavailable.");
            compositor.SetTrackingSpace(ETrackingUniverseOrigin.TrackingUniverseStanding);
            uint width = 0, height = 0;
            system.GetRecommendedRenderTargetSize(ref width, ref height);
            if (width == 0 || height == 0) throw new InvalidOperationException("SteamVR returned an invalid eye size.");
            float reduction = Math.Min(1f, 1600f / Math.Max(width, height));
            int w = Math.Max(64, (int)(width * reduction)), h = Math.Max(64, (int)(height * reduction));
            for (int i = 0; i < 2; i++)
            {
                var go = new GameObject("SignalisVR_Eye_" + i);
                eyes[i] = go.AddComponent<Camera>();
                eyes[i].enabled = false;
                UnityEngine.Object.DontDestroyOnLoad(go);
                textures[i] = new RenderTexture(w, h, 24, RenderTextureFormat.ARGB32);
                textures[i].name = "SignalisVR_Texture_" + i;
                textures[i].antiAliasing = 1;
                textures[i].useMipMap = false;
                if (!textures[i].Create()) throw new InvalidOperationException("Could not allocate eye texture.");
                textureHandles[i] = textures[i].GetNativeTexturePtr();
                if (textureHandles[i] == IntPtr.Zero) throw new InvalidOperationException("Eye texture has no native handle.");
            }
            NativeLibraries.Initialize();
            if (GetBridgeVersion() != 400) throw new InvalidOperationException("Render bridge ABI mismatch: expected 400. Restore the complete 0.4.16 candidate package and restart SIGNALIS.");
            EVRInitError tableError = EVRInitError.None;
            var table = OpenVR.GetGenericInterface("FnTable:" + OpenVR.IVRCompositor_Version, ref tableError);
            if (table == IntPtr.Zero || tableError != EVRInitError.None) throw new InvalidOperationException("Compositor function table: " + tableError);
            // Read actual native addresses, never managed delegate thunks on the render thread.
            var submitPointer = Marshal.ReadIntPtr(table, Marshal.OffsetOf(typeof(IVRCompositor), "Submit").ToInt32());
            var waitPointer = Marshal.ReadIntPtr(table, Marshal.OffsetOf(typeof(IVRCompositor), "WaitGetPoses").ToInt32());
            int configured = ConfigureBridge(submitPointer, waitPointer, textureHandles[0], textureHandles[1]);
            if (configured != 0) throw new InvalidOperationException("Render bridge rejected textures: " + configured);
            bridgeConfigured = true;
            renderCallback = GetRenderEventFunc();
            if (renderCallback == IntPtr.Zero) throw new InvalidOperationException("Render callback unavailable.");
            EnableStereoSettings();
            MelonLogger.Msg("Stereo eye textures: " + w + "x" + h + "; initial scale=" + UnitsPerMetre + " units/metre.");
        }
        private void EnableStereoSettings()
        {
            originalBackground = Application.runInBackground;
            oldVsync = QualitySettings.vSyncCount;
            oldFrameRate = Application.targetFrameRate;
            stereo = true;
            Application.runInBackground = true;
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = -1;
            submitted = false;
            int state, leftError, rightError; uint thread;
            GetBridgeStatus(out state, out leftError, out rightError, out resumeFrame, out thread);
        }
        private struct DoorMarkerAnchor
        {
            public SpriteRenderer renderer;
            public Vector3 position;
            public Quaternion rotation;
        }
        private readonly System.Collections.Generic.Dictionary<int, DoorMarkerAnchor> doorMarkerAnchors
            = new System.Collections.Generic.Dictionary<int, DoorMarkerAnchor>();
        private SpriteRenderer[] markerSprites = new SpriteRenderer[0];
        private Quaternion[] markerRotations = new Quaternion[0];
        private Vector3[] markerPositions = new Vector3[0];
        private Vector3[] markerScales = new Vector3[0];
        private bool[] doorMarkerSprites = new bool[0];
        private Sprite canonicalOpenDoorSprite;
        private Sprite canonicalBlockedDoorSprite;
        private Sprite[] savedMarkerArtwork = new Sprite[0];
        private bool[] markerEnabled = new bool[0];
        private int rotatedMarkerCount;
        private static bool IsLadderMarker(SpriteRenderer sr)
        {
            return sr.transform.parent != null && sr.transform.parent.name == "Ladder Icon";
        }
        private float nextMarkerSpriteSearch;
        private void FaceMarkersForVr()
        {
            MarkerSuppression.Apply();
            if (Time.realtimeSinceStartup >= nextMarkerSpriteSearch)
            {
                nextMarkerSpriteSearch = Time.realtimeSinceStartup + 1f;
                var found = Resources.FindObjectsOfTypeAll<SpriteRenderer>();
                var selected = new System.Collections.Generic.List<SpriteRenderer>();
                for (int i = 0; i < found.Length; i++)
                {
                    var sr = found[i];
                    if (sr == null || sr.gameObject.layer != 23) continue;
                    // Restrict facing changes to the game's object/door marker hierarchies.
                    if (sr.GetComponentInParent<global::interactionPopup>() == null
                        && sr.GetComponentInParent<global::DoorInteractionPopup>() == null && !IsLadderMarker(sr)) continue;
                    selected.Add(sr);
                }
                markerSprites = selected.ToArray();
                savedMarkerArtwork = new Sprite[markerSprites.Length];
                if (canonicalOpenDoorSprite == null || canonicalBlockedDoorSprite == null)
                {
                    var artwork = Resources.FindObjectsOfTypeAll<Sprite>();
                    for (int a = 0; a < artwork.Length; a++)
                        if (artwork[a] != null) { if (artwork[a].name == "Door_interactions_1") canonicalOpenDoorSprite = artwork[a]; if (artwork[a].name == "Door_interactions_0") canonicalBlockedDoorSprite = artwork[a]; }
                }
                markerEnabled = new bool[markerSprites.Length];
                markerColors = new Color[markerSprites.Length];
                markerRenderVetoes = new bool[markerSprites.Length];
                markerRotations = new Quaternion[markerSprites.Length];
                markerPositions = new Vector3[markerSprites.Length];
                markerScales = new Vector3[markerSprites.Length];
                doorMarkerSprites = new bool[markerSprites.Length];
                for (int i = 0; i < markerSprites.Length; i++)
                    doorMarkerSprites[i] = markerSprites[i].GetComponentInParent<global::DoorInteractionPopup>() != null;
            }
            rotatedMarkerCount = 0;
            for (int i = 0; i < markerSprites.Length; i++)
            {
                var sr = markerSprites[i];
                if (sr == null) { rotatedMarkerCount = i + 1; continue; }
                savedMarkerArtwork[i] = sr.sprite;
                markerEnabled[i] = sr.enabled;
                markerColors[i] = sr.color;
                markerRenderVetoes[i] = sr.forceRenderingOff;
                markerRotations[i] = sr.transform.rotation;
                markerPositions[i] = sr.transform.position;
                markerScales[i] = sr.transform.localScale;
                rotatedMarkerCount = i + 1;
                // Shared head orientation keeps both eyes consistent.
                sr.transform.rotation = stereoRotation;
                ShowObjectBracketForVr(sr, i);
                if (sr.sprite != null && sr.sprite.name == "Interaction_inspect"
                    && sr.GetComponentInParent<global::interactionPopup>() != null)
                {
                    // Reduce this large textual prompt without changing ordinary item markers.
                    // Trial console-edge placement for the reported Mess Hall prompt.
                    sr.transform.localScale = markerScales[i] * 0.2f;
                    int inspectId = sr.GetInstanceID();
                    DoorMarkerAnchor inspectAnchor;
                    if (!doorMarkerAnchors.TryGetValue(inspectId, out inspectAnchor) || inspectAnchor.renderer != sr)
                    {
                        if (sr.enabled && sr.gameObject.activeInHierarchy)
                        {
                            inspectAnchor = new DoorMarkerAnchor { renderer = sr,
                                position = markerPositions[i] + new Vector3(0f, 5f, 3f),
                                rotation = Quaternion.LookRotation(new Vector3(0f, 1f, 0f), new Vector3(0f, 0f, -1f)) };
                            doorMarkerAnchors[inspectId] = inspectAnchor;
                        }
                    }
                    if (inspectAnchor.renderer == sr)
                    {
                        sr.transform.position = inspectAnchor.position;
                        sr.transform.rotation = inspectAnchor.rotation;
                    }
                }
                if (IsLadderMarker(sr))
                {
                    // Ladder markers have no interactionPopup. Keep their position fixed;
                    // only the lower zero-scale marker needs a proximity visibility fallback.
                    bool lower = sr.sprite != null && (sr.sprite.name == "Door_interactions_15" || sr.sprite.name == "Door_interactions_14");
                    int ladderId = sr.GetInstanceID();
                    DoorMarkerAnchor ladderAnchor;
                    bool hasAnchor = doorMarkerAnchors.TryGetValue(ladderId, out ladderAnchor) && ladderAnchor.renderer == sr;
                    Vector3 delta = camera.transform.position - markerPositions[i];
                    delta.z = 0f;
                    if (!hasAnchor && delta.sqrMagnitude > 0.01f && delta.sqrMagnitude < 400f)
                    {
                        // World -Z is up. Capture approach once, never follow head movement.
                        ladderAnchor = new DoorMarkerAnchor { renderer = sr,
                            position = markerPositions[i],
                            rotation = Quaternion.LookRotation(-delta.normalized, new Vector3(0f, 0f, -1f)) };
                        doorMarkerAnchors[ladderId] = ladderAnchor;
                        hasAnchor = true;
                    }
                    if (hasAnchor)
                    {
                        sr.transform.position = ladderAnchor.position;
                        sr.transform.rotation = ladderAnchor.rotation * Quaternion.Euler(0f, 0f, markerRotations[i].eulerAngles.z);
                    }
                    float scale = lower ? 0.4f : 0.7f;
                    Vector3 original = markerScales[i];
                    sr.transform.localScale = new Vector3(original.x * scale, (lower && Math.Abs(original.y) < 0.001f ? 1f : original.y) * scale, original.z * scale);
                    if (lower && delta.sqrMagnitude < 144f && sr.gameObject.activeInHierarchy) sr.enabled = true;
                    continue;
                }
                if (doorMarkerSprites[i])
                {
                    var approachPopup = sr.GetComponentInParent<global::DoorInteractionPopup>();
                    bool earlyBlueDoor = approachPopup != null && approachPopup.gameObject.name == "Door Icon E"
                        && savedMarkerArtwork[i] != null && savedMarkerArtwork[i].name == "Door_interactions_9";
                    Vector3 rangeOrigin = earlyBlueDoor && approachPopup.door != null
                        ? approachPopup.door.transform.position : markerPositions[i];
                    Vector3 doorRange = camera.transform.position - rangeOrigin;
                    doorRange.z = 0f;
                    bool nearbyDoor = sr.gameObject.activeInHierarchy && doorRange.sqrMagnitude < (earlyBlueDoor ? 784f : 400f)
                        && Math.Abs(camera.transform.position.z - markerPositions[i].z) < 10f;
                    // Only revive the base icon. Optional lock bars retain game visibility.
                    bool baseDoorIcon = sr.gameObject.name.StartsWith("Door Icon", StringComparison.Ordinal);
                    if (nearbyDoor && baseDoorIcon && sr.sprite != null) sr.enabled = true;
                    // South open artwork points down even when its text is upright.
                    // Reuse the north open artwork; keep the same fixed door-relative geometry.
                    if (sr.sprite != null && (sr.sprite.name == "Door_interactions_4" || sr.sprite.name == "Door_interactions_9") && canonicalOpenDoorSprite != null)
                        sr.sprite = canonicalOpenDoorSprite;
                    if (sr.sprite != null && sr.sprite.name == "Door_interactions_6" && canonicalBlockedDoorSprite != null)
                        sr.sprite = canonicalBlockedDoorSprite;
                    // Starting-area evidence places eye/door markers at Z=-8.4 and floor props at Z=0.
                    // Trial offset toward the floor; validate in other rooms before generalizing.
                    int id = sr.GetInstanceID();
                    DoorMarkerAnchor anchor;
                    bool anchored = doorMarkerAnchors.TryGetValue(id, out anchor) && anchor.renderer == sr;
                    if (!anchored && sr.enabled && sr.gameObject.activeInHierarchy
                        && Vector3.Distance(camera.transform.position, markerPositions[i]) < 40f)
                    {
                        // Fixed door-relative facing, tilted 35 degrees with the doorward edge raised.
                        var popup = sr.GetComponentInParent<global::DoorInteractionPopup>();
                        var targetDoor = popup != null ? popup.door : null;
                        Vector3 facing = targetDoor != null
                            ? targetDoor.transform.position - markerPositions[i]
                            : markerRotations[i] * Vector3.up;
                        facing.z = 0f;
                        if (facing.sqrMagnitude <= 0.001f)
                        {
                            facing = markerRotations[i] * Vector3.up;
                            facing.z = 0f;
                        }
                        if (facing.sqrMagnitude > 0.001f)
                        {
                            anchor = new DoorMarkerAnchor { renderer = sr,
                                position = markerPositions[i] + new Vector3(0f, 0f, 4.6f) + facing.normalized * (savedMarkerArtwork[i] != null && savedMarkerArtwork[i].name == "Door_interactions_4" ? Math.Max(0f, facing.magnitude - 2f) : Math.Min(1.5f, facing.magnitude * 0.5f)),
                                rotation = Quaternion.LookRotation(new Vector3(0f, 0f, 1f), facing.normalized) * Quaternion.Euler(-35f, 0f, 0f) };
                            // Side-door sprite positions are offset from their door pivots.
                            // Anchor the entire popup at its doorway, facing along the room X axis.
                            bool east = popup != null && popup.gameObject.name == "Door Icon E";
                            bool west = popup != null && popup.gameObject.name == "Door Icon W";
                            if (targetDoor != null && (east || west))
                            {
                                Vector3 intoDoor = new Vector3(east ? 1f : -1f, 0f, 0f);
                                Vector3 atDoor = targetDoor.transform.position - intoDoor * 2f;
                                var doorRoot = targetDoor.transform.parent != null ? targetDoor.transform.parent : targetDoor.transform;
                                var doorMeshes = doorRoot.GetComponentsInChildren<MeshRenderer>(true);
                                for (int mi = 0; mi < doorMeshes.Length; mi++)
                                {
                                    var mesh = doorMeshes[mi];
                                    if (mesh == null || mesh.gameObject.name != "Mesh" || mesh.gameObject.layer != 22) continue;
                                    var bounds = mesh.bounds;
                                    if (bounds.size.x <= 0.01f) continue;
                                    atDoor.x = east ? bounds.min.x - 0.1f : bounds.max.x - 0.4f;
                                    atDoor.y = bounds.center.y;
                                    break;
                                }
                                atDoor.z = markerPositions[i].z + 4.6f;
                                anchor.position = atDoor;
                                anchor.rotation = Quaternion.LookRotation(new Vector3(0f, 0f, 1f), intoDoor) * Quaternion.Euler(-35f, 0f, 0f);
                            }
                            doorMarkerAnchors[id] = anchor;
                            anchored = true;
                        }
                    }
                    if (anchored)
                    {
                        sr.transform.position = anchor.position;
                        sr.transform.rotation = anchor.rotation * Quaternion.Euler(0f, 0f, markerRotations[i].eulerAngles.z);
                    }
                    else
                    {
                        sr.transform.position = markerPositions[i] + new Vector3(0f, 0f, 8.1f);
                        sr.transform.rotation = markerRotations[i];
                    }
                    sr.transform.localScale = new Vector3(markerScales[i].x * 0.46f, (nearbyDoor && sr.enabled && (earlyBlueDoor || Math.Abs(markerScales[i].y) < 0.001f) ? 1f : markerScales[i].y) * 0.4f, markerScales[i].z * 0.4f);
                    // Side-door parent scaling distorts the replacement north artwork.
                    // Match the north marker's world-space artwork-axis lengths.
                    if (savedMarkerArtwork[i] != null && (savedMarkerArtwork[i].name == "Door_interactions_9" || savedMarkerArtwork[i].name == "Door_interactions_6"))
                    {
                        float width = sr.transform.TransformVector(Vector3.right).magnitude;
                        float height = sr.transform.TransformVector(Vector3.up).magnitude;
                        Vector3 adjusted = sr.transform.localScale;
                        if (width > 0.0001f && height > 0.0001f)
                        {
                            adjusted.x *= 0.46f / width;
                            adjusted.y *= 0.694f / height;
                            sr.transform.localScale = adjusted;
                        }
                    }
                }
            }
        }
        private void RestoreMarkerRotations()
        {
            HideBookBrackets();
            for (int i = rotatedMarkerCount - 1; i >= 0; i--)
            {
                var sr = markerSprites[i];
                if (sr != null)
                {
                    sr.sprite = savedMarkerArtwork[i];
                    sr.enabled = markerEnabled[i];
                    sr.color = markerColors[i];
                    sr.forceRenderingOff = markerRenderVetoes[i];
                    sr.transform.rotation = markerRotations[i];
                    sr.transform.position = markerPositions[i];
                    sr.transform.localScale = markerScales[i];
                }
            }
            rotatedMarkerCount = 0;
        }
        private void RenderStereo()
        {
            for (int i = 0; i < 2; i++)
            {
                var eye = eyes[i];
                ObserveCamera("before CopyFrom"); eye.CopyFrom(camera); ObserveCamera("after CopyFrom");
                // Observed interaction sprites use layer 23, excluded by the gameplay camera.
                eye.cullingMask |= 1 << 23;
                eye.enabled = false;
                eye.stereoTargetEye = StereoTargetEyeMask.None;
                eye.targetTexture = textures[i];
                eye.rect = new Rect(0f, 0f, 1f, 1f);
                eye.clearFlags = CameraClearFlags.SolidColor;
                eye.backgroundColor = Color.black;
                var offset = system.GetEyeToHeadTransform((EVREye)i);
                eye.transform.position = camera.transform.position + stereoRotation * (new Vector3(offset.m3, offset.m7, -offset.m11) * UnitsPerMetre);
                var forward = new Vector3(-offset.m2, -offset.m6, offset.m10);
                var up = new Vector3(offset.m1, offset.m5, -offset.m9);
                eye.transform.rotation = stereoRotation * Quaternion.LookRotation(forward, up);
                float left = 0, right = 0, top = 0, bottom = 0;
                system.GetProjectionRaw((EVREye)i, ref left, ref right, ref top, ref bottom);
                if (traceFrame) MelonLogger.Msg(string.Format(CultureInfo.InvariantCulture,
                    "Eye geometry {0}: tangents=({1:F5},{2:F5},{3:F5},{4:F5}) offset=({5:F5},{6:F5},{7:F5})",
                    i, left, right, top, bottom, offset.m3, offset.m7, offset.m11));
                float near = Math.Max(0.01f, camera.nearClipPlane);
                // OpenVR's raw vertical tangents point down; Unity's frustum points up.
                eye.projectionMatrix = Matrix4x4.Frustum(left * near, right * near, -bottom * near, -top * near, near, camera.farClipPlane);
                eye.ResetWorldToCameraMatrix();
                if (traceFrame) MelonLogger.Msg("DIAG: render eye " + i + " begin.");
                ObserveCamera("before eye Render");
                try
                {
                    FaceMarkersForVr();
                    eye.Render();
                }
                finally { RestoreMarkerRotations(); }
                ObserveCamera("after eye Render");
                if (traceFrame) MelonLogger.Msg("DIAG: render eye " + i + " returned.");
            }
            SubmitEyes();
        }
        private void SubmitEyes()
        {
            if (!diagnostic.CanSubmit) return;
            if (traceFrame) MelonLogger.Msg("DIAG: queue native submission begin.");
            int nextEvent = ++eventId;
            if (QueueFrame(nextEvent, flipVertical ? 1 : 0) != 1) throw new InvalidOperationException("Previous frame has not drained.");
            // Ordered after Camera.Render on Unity's graphics command stream.
            // No compositor graphics calls run directly from this managed callback.
            GL.IssuePluginEvent(renderCallback, nextEvent);
            if (traceFrame) MelonLogger.Msg("DIAG: native event queued.");
        }
        private bool CheckRenderStatus()
        {
            int state, leftError, rightError, frames; uint thread;
            GetBridgeStatus(out state, out leftError, out rightError, out frames, out thread);
            if (Time.realtimeSinceStartup >= nextFrameLog)
            {
                nextFrameLog = Time.realtimeSinceStartup + 2f;
                MelonLogger.Msg("Frame diagnostic: completed=" + frames + ", state=" + state + ", left=" + leftError + ", right=" + rightError);
            }
            if (state == 2 || state == 3 || state == 4) return false;
            if (leftError != 0 || rightError != 0) throw new InvalidOperationException("Render-thread submission failed: left=" + leftError + ", right=" + rightError);
            if (!submitted && frames > resumeFrame)
            {
                submitted = true;
                MelonLogger.Msg("Both eye textures accepted on Unity render callback thread " + thread + ". Visual verification still required.");
            }
            return state == 1 || state == 5;
        }
        private bool ReadPose(out Quaternion rotation, bool synchronize = false)
        {
            rotation = Quaternion.identity;
            if (system == null) return false;
            if (stereo && synchronize && diagnostic.CanSubmit)
            {
                int valid;
                int result = GetPreparedPose(preparedMatrix, out valid);
                if (result < 0) throw new InvalidOperationException("Render-thread SteamVR poses: " + result);
                if (result == 0)
                {
                    int poseEvent = ++eventId;
                    if (QueuePose(poseEvent) == 1) GL.IssuePluginEvent(renderCallback, poseEvent);
                    return false;
                }
                if (valid == 0) return false;
                rotation = Quaternion.LookRotation(new Vector3(-preparedMatrix[2], -preparedMatrix[6], preparedMatrix[10]), new Vector3(preparedMatrix[1], preparedMatrix[5], -preparedMatrix[9]));
                return true;
            }
            else system.GetDeviceToAbsoluteTrackingPose(ETrackingUniverseOrigin.TrackingUniverseStanding, 0f, poses);
            var pose = poses[OpenVR.k_unTrackedDeviceIndex_Hmd];
            if (!pose.bDeviceIsConnected || !pose.bPoseIsValid) return false;
            var m = pose.mDeviceToAbsoluteTracking;
            // OpenVR uses right-handed coordinates; Unity uses left-handed coordinates.
            rotation = Quaternion.LookRotation(new Vector3(-m.m2, -m.m6, m.m10), new Vector3(m.m1, m.m5, -m.m9));
            return true;
        }
        // Recenter heading only: cancelling headset pitch/roll tilts the yaw axis.
        private static Quaternion Heading(Quaternion q)
        {
            double yaw = HeadingMath.Yaw(q.x, q.y, q.z, q.w);
            return new Quaternion(0f, (float)Math.Sin(yaw / 2), 0f, (float)Math.Cos(yaw / 2));
        }
        private void Stop()
        {
            pauseMenuVisible = false; bookScreenVisible = false; dialogueScreenVisible = false;
            menuCaptureReady = false;
            recovery.Reset();
            diagnostic.Stop();
            waitingForGameplay = false;
            if (puzzleRenderer != null) puzzleRenderer.enabled = false;
            if (stereo)
            {
                stereo = false;
                Application.runInBackground = originalBackground;
                QualitySettings.vSyncCount = oldVsync;
                Application.targetFrameRate = oldFrameRate;
            }
            if (active && camera != null && !camera.orthographic && camera.transform.parent != null && camera.transform.parent.name == "Character Root")
                camera.transform.localRotation = originalRotation;
            active = false;
            camera = null;
            stopping = true;
            FinishStop();
        }
        private void FinishStop()
        {
            if (bridgeConfigured)
            {
                int state, leftError, rightError, frames; uint thread;
                GetBridgeStatus(out state, out leftError, out rightError, out frames, out thread);
                if (state == 2 || state == 3 || state == 4) return;
                if (CancelPreparedPose() == 0) return;
            }
            // A completed Submit callback does not prove external driver/encoder
            // consumers have finished with a texture. Reuse the same bounded pair
            // until process exit instead of releasing/recreating on each toggle.
            stopping = false;
            MelonLogger.Msg("DIAG stopped; resources retained. Restart game for an independent test.");
        }
        private void LogVrFocus()
        {
            if (system == null || Time.realtimeSinceStartup < nextFocusLog) return;
            nextFocusLog = Time.realtimeSinceStartup + 2f;
            Quaternion pose;
            bool valid = ReadPose(out pose, false);
            bool dashboard = OpenVR.Overlay != null && OpenVR.Overlay.IsDashboardVisible();
            MelonLogger.Msg("DIAG status: stage=" + diagnostic.Stage + ", tracked=" + valid + ", dashboard=" + dashboard + ", inputAvailable=" + system.IsInputAvailable() + ", localFrames=" + diagnosticFrames);
        }
    }
}





















