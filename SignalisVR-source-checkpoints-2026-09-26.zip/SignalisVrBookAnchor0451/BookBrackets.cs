using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking
{
    public sealed partial class Tracking
    {
        private sealed class BookBracket
        {
            internal SpriteRenderer source, proxy;
            internal MeshFilter model;
        }
        private readonly Dictionary<int, BookBracket> bookBrackets = new Dictionary<int, BookBracket>();

        private BookBracket FindBookBracket(SpriteRenderer source, global::Interaction interaction)
        {
            int id = source.GetInstanceID();
            BookBracket entry;
            if (bookBrackets.TryGetValue(id, out entry) && entry.source == source && entry.model != null) return entry;
            var models = interaction.GetComponentsInChildren<MeshFilter>(true);
            MeshFilter selected = null;
            foreach (var model in models)
            {
                if (model == null || model.sharedMesh == null || !model.gameObject.activeInHierarchy
                    || model.GetComponent<MeshRenderer>() == null) continue;
                if (selected != null) return null; // Ambiguous multi-model books keep the original path.
                selected = model;
            }
            if (selected == null) return null;
            entry = new BookBracket { source = source, model = selected };
            bookBrackets[id] = entry;
            return entry;
        }

        private void PlaceBookBracket(BookBracket entry)
        {
            if (entry.proxy == null)
            {
                var go = new GameObject("SignalisVR_BookBrackets_" + entry.source.GetInstanceID());
                go.layer = 23;
                entry.proxy = go.AddComponent<SpriteRenderer>();
                entry.proxy.enabled = false;
            }
            var source = entry.source;
            var proxy = entry.proxy;
            var model = entry.model;
            var bounds = model.sharedMesh.bounds;
            var size = bounds.size;
            Vector3 right, up, normal;
            float width, height, depth;
            if (size.z <= size.x && size.z <= size.y)
            { right = Vector3.right; up = Vector3.up; normal = Vector3.forward; width = size.x; height = size.y; depth = size.z; }
            else if (size.y <= size.x)
            { right = Vector3.right; up = Vector3.forward; normal = Vector3.up; width = size.x; height = size.z; depth = size.y; }
            else
            { right = Vector3.forward; up = Vector3.up; normal = Vector3.right; width = size.z; height = size.y; depth = size.x; }
            right = model.transform.TransformVector(right);
            up = model.transform.TransformVector(up);
            normal = model.transform.TransformVector(normal);
            // SIGNALIS vertical is -Z. Choose the upper cover, independent of head/eye rotation.
            if (Vector3.Dot(normal, new Vector3(0f, 0f, -1f)) < 0f) normal = -normal;
            var center = model.transform.TransformPoint(bounds.center);
            proxy.transform.position = center + normal.normalized * (depth * normal.magnitude * 0.5f + 0.05f);
            proxy.transform.rotation = Quaternion.LookRotation(normal.normalized, up.normalized);
            proxy.sprite = source.sprite;
            proxy.sharedMaterial = source.sharedMaterial;
            proxy.color = source.color;
            proxy.sortingLayerID = source.sortingLayerID;
            proxy.sortingOrder = source.sortingOrder;
            var spriteSize = source.sprite.bounds.size;
            proxy.transform.localScale = new Vector3(width * right.magnitude * 1.15f / Math.Max(0.01f, spriteSize.x),
                height * up.magnitude * 1.15f / Math.Max(0.01f, spriteSize.y), 1f);
            // Independent root avoids the original popup's animated scale/nonuniform parent.
            proxy.enabled = true;
            source.enabled = false;
        }

        private void HideBookBrackets()
        { foreach (var e in bookBrackets.Values) if (e.proxy != null) e.proxy.enabled = false; }

        private void ClearBookBrackets()
        {
            foreach (var e in bookBrackets.Values) if (e.proxy != null) UnityEngine.Object.Destroy(e.proxy.gameObject);
            bookBrackets.Clear();
        }
    }
}
