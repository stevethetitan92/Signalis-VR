# Controller investigation, September 26

The user confirmed only right-stick up/down improved in 0467. Its successful
managed diagnostic reads did not establish that native gameplay consumed input.
0468 removes all Player query overrides so native readings cannot be artificially
supplied by those patches.

## Findings

Installed FPv2 IL shows OnLateUpdate writing Quaternion.y into
AlternatePlayerController.fAngle. The same mod compares fAngle against degree
thresholds such as 45, 135, 225 and 315. For Quest strafe, 0468 substitutes the
model's world heading in degrees. Physical keyboard behavior is preserved.

FPv2 also calls Rigidbody.AddForce once per rendered update. The Quest adapter
now scales its analog force by deltaTime/fixedDeltaTime, removing rendering rate
from accumulated force. A 50 ms hitch cap and zero force during paused scaled
time remain. This is a mathematical correction, not proof that all observed
movement jitter is resolved.

Static disassembly of the installed Rewired binary and matching Cpp2IL metadata
is saved in evidence. Binding constructors already default to enabled. Thus the
hypothesis that all bindings default to disabled is not supported. Native
CreateElementMap bakes elements and adds them to map lists; AddMap follows the
controller/player attachment path and applies the map enabler. This motivated
re-attaching completed maps and validating baked indices. It does NOT prove
stale map state caused the original failure. Runtime testing remains necessary.

0467 zeroed the custom horizontal movement axis during first-person play, while
sharing it with horizontal UI navigation. 0468 gives UI input independent axes.
It also stops treating an absent UI map category as a broken map: action
categories and map categories are different, and the observed Default map carries
the UI actions.

Diagnostics now include the actual player's input vector, raw Quest values,
custom-controller values, map ownership and native Player actions. There are no
Player.GetAxis/GetButton/GetButtonDown/GetButtonUp overrides in this candidate.

## Test limitations and user instruction

Before the user's instruction to stop launching SIGNALIS, an isolated workspace
copy was prepared to probe native Rewired mapping. It exited before Unity startup,
both with and without MelonLoader. No probe result was obtained. Normal attempts
exited 53; debugger attempts exited 84. The exact cause is unresolved. A .bind
section exists in the executable, but attributing the failure to it is speculation.

After the user said to stop launching the game, launch attempts ceased immediately.
Subsequent work used file/IL/native-binary inspection, compilation and software
checks only. Build/test scripts in this candidate do not launch SIGNALIS.
The installed DLL remains 0467, with its original SHA256 recorded in hashes.json.

## Remaining manual validation

- Confirm raw input reaches native actions AND gameplay consumers immediately.
- Confirm buttons/sticks remain responsive through menus and transitions.
- Check strafe under actual physics, animation and collision conditions.
- Solve/verify menu presentation and SteamVR focus before stereo. Scene
  initialization was previously observed with scene-focus PID zero; it does not
  establish exclusive Home ownership.
- Evaluate yaw feel once routing works. Head-tracking tuning remains deferred.

No assertion that all controls are fixed is supported yet.

## Primary references

[Rewired custom controllers](https://guavaman.com/projects/rewired/docs/CustomControllers.html)
documents manual assignment and InputSourceUpdateEvent.
[Rewired map methods](https://guavaman.com/projects/rewired/docs/api-reference/html/Methods_T_Rewired_Player_ControllerHelper_MapHelper.htm)
documents map attachment and lookup. Binary inspection checked the installed
implementation instead of assuming all current documentation applies unchanged.
