using System;
using Rewired;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private sealed class QuestMapBinding {
   public Player player;public CustomControllerMap map;public int category,layout;
  }
  private readonly System.Collections.Generic.List<QuestMapBinding> questMaps=new System.Collections.Generic.List<QuestMapBinding>();
  private float nextQuestMapAudit;
  private void MaintainQuestMaps() {
   if(UnityEngine.Time.realtimeSinceStartup<nextQuestMapAudit)return;
   nextQuestMapAudit=UnityEngine.Time.realtimeSinceStartup+1f;
   try {
    foreach(var binding in questMaps) {
     var player=binding.player;
     bool assigned=player.controllers.ContainsController(questController);
     var current=player.controllers.maps.GetMap(ControllerType.Custom,questController.id,binding.category,binding.layout);
     if(assigned&&current!=null&&current.elementMapCount==binding.map.elementMapCount)continue;
     // Restore only our missing controller/map, not maps intentionally disabled
     // by a game context, and never change keyboard or physical gamepad maps.
     if(!assigned)player.controllers.AddController(questController,false);
     player.controllers.maps.AddMap(ControllerType.Custom,questController.id,new CustomControllerMap(binding.map),true);
     var restored=player.controllers.maps.GetMap(ControllerType.Custom,questController.id,binding.category,binding.layout);
     ValidateQuestMap(player,restored,binding.map.elementMapCount);
     MelonLogger.Msg("QUEST MAP RECOVERED: "+player.name+" category="+binding.category);
    }
   }catch(Exception ex){questFailed=true;ReleaseQuestControls();MelonLogger.Warning("Quest map recovery stopped: "+ex.Message);}
  }
  private void CommitQuestMap(Player player,ControllerMap draft,int category,int layout,int expectedCount) {
   // Re-register a completed map through Rewired's native attachment path.
   // Merely observing map.enabled/count does not establish usable bindings.
   draft.SetAllElementMapsEnabled(true);
   var completed=new CustomControllerMap(draft.Cast<CustomControllerMap>());
   completed.enabled=true;
   player.controllers.maps.AddMap(ControllerType.Custom,questController.id,completed,true);
   var installed=player.controllers.maps.GetMap(ControllerType.Custom,questController.id,category,layout);
   ValidateQuestMap(player,installed,expectedCount);
   questMaps.Add(new QuestMapBinding{player=player,map=new CustomControllerMap(installed.Cast<CustomControllerMap>()),category=category,layout=layout});
  }
  private void ValidateQuestMap(Player player,ControllerMap installed,int expectedCount) {
   if(installed==null||!installed.enabled||installed.elementMapCount!=expectedCount||
      installed.playerId!=player.id||installed.controllerId!=questController.id||
      !player.controllers.ContainsController(questController))
    throw new InvalidOperationException("Quest map attachment failed for "+player.name);
   var elements=installed.GetElementMaps();
   for(int i=0;i<elements.Length;i++) {
    var element=elements[i];var action=ReInput.mapping.GetAction(element.actionId);
    string name=action==null?"<missing>":action.name;
    int expected=QuestMapPolicy.ElementIndex(name);
    bool axis=QuestMapPolicy.IsAxis(name);
    if(expected<0||!element.enabled||element.elementIndex!=expected||
       element.elementType!=(axis?ControllerElementType.Axis:ControllerElementType.Button))
     throw new InvalidOperationException("Quest binding invalid: "+player.name+"/"+name+" index="+element.elementIndex+" expected="+expected+" enabled="+element.enabled);
    MelonLogger.Msg("QUEST BINDING: player="+player.name+" action="+name+" identifier="+element.elementIdentifierId+" index="+element.elementIndex+" enabled="+element.enabled);
   }
  }
 }
 public static class QuestMapPolicy {
  public static bool IsAxis(string name) {
   return name=="Move Horizontal"||name=="Move Vertical"||name=="Aim Horizontal"||name=="Aim Vertical"||name=="UIHorizontal"||name=="UIVertical";
  }
  public static int ElementIndex(string name) {
   switch(name) {
    case "Move Horizontal":return 0;case "Move Vertical":return 1;
    case "Aim Horizontal":return 2;case "Aim Vertical":return 3;
    case "UIHorizontal":return 4;case "UIVertical":return 5;
    default:return QuestButtonEdges.ActionBit(name);
   }
  }
 }
}
