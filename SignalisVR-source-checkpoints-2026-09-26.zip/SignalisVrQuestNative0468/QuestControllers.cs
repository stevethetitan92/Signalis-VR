using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using MelonLoader;
using UnityEngine;
using Valve.VR;
using Rewired;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly QuestHandInputPolicy questPolicy=new QuestHandInputPolicy();
  private CustomController questController;
  private Il2CppSystem.Action questInputCallback;
  private QuestFrame questFrame;
  private bool questFailed;

  private bool questInputStopped;
  private float nextQuestConnect;
  private float nextQuestLog;
  private string lastQuestStatus;
  private float nextQuestRouteTrace;
  private string lastQuestRouteTrace;
  private void TraceQuestRouting() {
   if(questController==null||Time.realtimeSinceStartup<nextQuestRouteTrace)return;
   nextQuestRouteTrace=Time.realtimeSinceStartup+.25f;
   try {
    string report="sceneFocusPid="+(OpenVR.Compositor==null?0:OpenVR.Compositor.GetCurrentSceneFocusProcess())+" gamePid="+questProcessId+" armed="+questPolicy.Armed+" sourceButtons="+questFrame.buttons+" sourceMove="+questFrame.moveX.ToString("F2")+","+questFrame.moveY.ToString("F2")+" sourceLook="+questFrame.lookX.ToString("F2")+","+questFrame.lookY.ToString("F2")
     +" customEnabled="+questController.enabled+" axes="+questController.axisCount+" buttons="+questController.buttonCount
     +" customForward="+questController.GetAxis(1).ToString("F2")+" customA="+questController.GetButton(0)+" customX="+questController.GetButton(2)+" customY="+questController.GetButton(3);
    var players=ReInput.players.AllPlayers;
    if(questFpPlayer!=null&&questFpMod!=null) {
     var gamePlayer=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
     if(gamePlayer!=null)report+=" gameInput="+gamePlayer.input+" playing="+gamePlayer.playing+" traversing="+gamePlayer.traversing;
    }
    int count=players.Cast<Il2CppSystem.Collections.Generic.ICollection<Player>>().Count;
    foreach(string categoryName in new[]{"Default","UI"}) {
     int category=ReInput.mapping.GetMapCategoryId(categoryName),layout=ReInput.mapping.GetCustomControllerLayoutId("Default");
     if(category<0)continue; // UI is an action category, not necessarily a map category.
     for(int i=0;i<count;i++) {
      var player=players[i];
      var map=player.controllers.maps.GetMap(ControllerType.Custom,questController.id,category,layout);
      report+=" | "+player.name+"/"+categoryName+" assigned="+player.controllers.ContainsController(questController)+" map="+(map==null?"MISSING":map.enabled+"/"+map.elementMapCount+"/owner="+map.playerId+"/device="+map.controllerId)
       +" forward="+player.GetAxis("Move Vertical").ToString("F2")+" use="+player.GetButton("Use")+" inv="+player.GetButton("Inventory")+" pause="+player.GetButton("Pause")+" confirm="+player.GetButton("Confirm");
     }
    }
    if(report!=lastQuestRouteTrace){lastQuestRouteTrace=report;MelonLogger.Msg("QUEST ROUTE: "+report);}
   }catch(Exception ex){nextQuestRouteTrace=Time.realtimeSinceStartup+5f;MelonLogger.Warning("Quest route trace: "+ex.Message);}
  }
  private object questFpMod;
  private FieldInfo questFpYaw;
  private FieldInfo questFpPlayer;
  private readonly uint questProcessId=(uint)Process.GetCurrentProcess().Id;
  [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window,out uint processId);
  private void EnsureQuestConnection() {
   if(system!=null||questFailed||questInputStopped||stopping||Time.realtimeSinceStartup<nextQuestConnect)return;
   nextQuestConnect=Time.realtimeSinceStartup+5f;
   try {
    NativeLibraries.Initialize();
    if(!OpenVR.IsHmdPresent())return;
    EVRInitError error=EVRInitError.None;
    // Claim the VR scene at startup so SteamVR Home is not the active scene
    // while SIGNALIS is at a menu or still waiting for stereo setup.
    var connected=OpenVR.Init(ref error,EVRApplicationType.VRApplication_Scene);
    if(error!=EVRInitError.None||connected==null) {MelonLogger.Warning("Quest menu connection waiting: "+error);return;}
    system=connected;
    MelonLogger.Msg("QUEST MENU: SIGNALIS scene connection acquired; Home is no longer the intended active scene. Stereo rendering still requires F6/F9/F10.");
   }catch(Exception ex){MelonLogger.Warning("Quest menu connection waiting: "+ex.Message);}
  }
  private void PrepareQuestSceneConnection() { questInputStopped=false; }
  private void EnsureQuestControllers() {
   if(questFailed || system==null || !ReInput.isReady)return;
   if(questController!=null){MaintainQuestMaps();return;}
   try {
    // Validate every action before creating/attaching any controller or maps.
    string[] required={"Move Horizontal","Move Vertical","Aim Horizontal","Aim Vertical","UIHorizontal","UIVertical","Use","Confirm","Cancel","Inventory","Pause","Sprint","Aim Mode","Attack","Reload","TabLeft","TabRight"};
    foreach(string name in required) {
     int id=ReInput.mapping.GetActionId(name);
     if(id<0)throw new InvalidOperationException("Native action not found: "+name);
     MelonLogger.Msg("QUEST ACTION: "+name+"="+id);
    }
    var data=ReInput.UserData;
    var def=new Rewired.Data.CustomController_Editor();
    def.id=data.GetNewCustomControllerId(); def.name="SIGNALIS VR Quest"; def.descriptiveName="Quest sticks and buttons";
    def.typeGuidString="9b4cbf4c-d304-4d03-88c1-75e315354f6c";
    for(int i=0;i<6;i++)def.AddAxis();
    // The Quest policy already applies a dead zone. Keep a separate pair for UI
    // navigation so suppressing native FP strafe never suppresses menu input.
    for(int i=0;i<6;i++){var axis=def.axes[i];axis.range=AxisRange.Full;axis.min=-1f;axis.max=1f;axis.zero=0f;axis.deadZone=0f;axis.sensitivity=1f;axis.invert=false;}
    for(int i=0;i<10;i++)def.AddButton();
    data.customControllers.Add(def); // Session memory only; no saved bindings are overwritten.
    questController=ReInput.controllers.CreateCustomController(def.id);
    if(questController==null)throw new InvalidOperationException("Rewired did not create the Quest controller");
    int category=ReInput.mapping.GetMapCategoryId("Default"),layout=ReInput.mapping.GetCustomControllerLayoutId("Default");
    if(category<0||layout<0)throw new InvalidOperationException("Default controller category/layout missing");
    var axes=def.GetAxisElementIdentifierIds(); var buttons=def.GetButtonElementIdentifierIds();
    var players=ReInput.players.AllPlayers;
    int playerCount=players.Cast<Il2CppSystem.Collections.Generic.ICollection<Player>>().Count;
    for(int p=0;p<playerCount;p++) {
     var player=players[p];player.controllers.AddController(questController,false);
     player.controllers.maps.AddEmptyMap(ControllerType.Custom,questController.id,category,layout);
     var map=player.controllers.maps.GetMap(ControllerType.Custom,questController.id,category,layout);
     if(map==null)throw new InvalidOperationException("Custom map missing for "+player.name);
     string[] axisNames={"Move Horizontal","Move Vertical","Aim Horizontal","Aim Vertical"};
     for(int i=0;i<4;i++)AddQuestMap(map,axisNames[i],axes[i],true);
     AddQuestMap(map,"UIHorizontal",axes[4],true); AddQuestMap(map,"UIVertical",axes[5],true);
     string[] names={"Use","Cancel","Inventory","Pause","Sprint","Aim Mode","Attack","Reload","TabLeft","TabRight"};
     for(int i=0;i<names.Length;i++)AddQuestMap(map,names[i],buttons[i],false);
     AddQuestMap(map,"Confirm",buttons[0],false);
     CommitQuestMap(player,map,category,layout,17);
     // The game can select its UI category independently of its Default category.
     int uiCategory=ReInput.mapping.GetMapCategoryId("UI");
     if(uiCategory>=0&&uiCategory!=category) {
      player.controllers.maps.AddEmptyMap(ControllerType.Custom,questController.id,uiCategory,layout);
      var uiMap=player.controllers.maps.GetMap(ControllerType.Custom,questController.id,uiCategory,layout);
      if(uiMap==null)throw new InvalidOperationException("UI controller map missing for "+player.name);
      AddQuestMap(uiMap,"UIHorizontal",axes[4],true);AddQuestMap(uiMap,"UIVertical",axes[5],true);
      AddQuestMap(uiMap,"Confirm",buttons[0],false);AddQuestMap(uiMap,"Cancel",buttons[1],false);
      AddQuestMap(uiMap,"Pause",buttons[3],false);
      AddQuestMap(uiMap,"TabLeft",buttons[8],false);AddQuestMap(uiMap,"TabRight",buttons[9],false);
      CommitQuestMap(player,uiMap,uiCategory,layout,7);
     }
     MelonLogger.Msg("QUEST NATIVE MAP: player="+player.name+" controller="+questController.id);
    }
    foreach(var mod in MelonHandler.Mods) {
     if(mod.GetType().FullName!="FPv2_reworked.FPv2_rework")continue;
     questFpMod=mod;questFpYaw=mod.GetType().GetField("x",BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public);
     questFpPlayer=mod.GetType().GetField("player_control",BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public);
    }
    InstallQuestFirstPerson();
    questInputCallback=(Il2CppSystem.Action)(Action)PollQuestControllers;
    ReInput.add_InputSourceUpdateEvent(questInputCallback);
    MelonLogger.Msg("QUEST CONTROLLERS: bindings installed and indices checked; gameplay requires validation. Native Player query overrides DISABLED. FP turning="+(questFpYaw!=null));
   }catch(Exception ex){questFailed=true;ReleaseQuestControls();MelonLogger.Warning("Quest setup failed: "+ex.Message);}
  }
  private static void AddQuestMap(ControllerMap map,string name,int element,bool axis) {
   int action=ReInput.mapping.GetActionId(name);
   if(action<0)throw new InvalidOperationException("Native action not found: "+name);
   if(!map.CreateElementMap(action,Pole.Positive,element,axis?ControllerElementType.Axis:ControllerElementType.Button,AxisRange.Full,false))throw new InvalidOperationException("Could not map: "+name);
  }
  private bool ReadQuestHand(ETrackedControllerRole role,out QuestSample sample) {
   sample=new QuestSample();uint id=system.GetTrackedDeviceIndexForControllerRole(role);
   if(id==OpenVR.k_unTrackedDeviceIndexInvalid)return false;
   var state=new VRControllerState_t();
   if(!system.GetControllerState(id,ref state,(uint)Marshal.SizeOf(typeof(VRControllerState_t))))return false;
   sample=new QuestSample{x=state.rAxis0.x,y=state.rAxis0.y,trigger=state.rAxis1.x,grip=state.rAxis2.x,buttons=state.ulButtonPressed};return true;
  }
  private void PollQuestControllers() {
   try {
    uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
    bool ready=QuestInputPolicy.Ready(system!=null,stopping,questFailed,questInputStopped);
    // Foreground game and dashboard
    // checks complement SteamVR scene input availability.
    bool vrInput=ready&&system.IsInputAvailable()&&(OpenVR.Overlay==null||!OpenVR.Overlay.IsDashboardVisible());
    QuestSample left=new QuestSample(),right=new QuestSample();
    bool l=vrInput&&ReadQuestHand(ETrackedControllerRole.LeftHand,out left),r=vrInput&&ReadQuestHand(ETrackedControllerRole.RightHand,out right);
    questFrame=questPolicy.UpdateHands(ready&&foreground==questProcessId&&vrInput,l,r,left,right);
    RecordQuestActivity();ApplyQuestFrame();UpdateQuestInputMode();
    if(!ready)return;
    string status="focus="+(foreground==questProcessId)+" vrInput="+vrInput+" left="+l+" right="+r+" armed="+questPolicy.Armed+" leftArmed="+questPolicy.LeftArmed+" rightArmed="+questPolicy.RightArmed;
    if(status!=lastQuestStatus||Time.realtimeSinceStartup>=nextQuestLog) {
     lastQuestStatus=status;nextQuestLog=Time.realtimeSinceStartup+3f;
     MelonLogger.Msg("QUEST INPUT: "+status+" buttons="+questFrame.buttons+" move="+questFrame.moveX+","+questFrame.moveY+" look="+questFrame.lookX+","+questFrame.lookY);
    }
   }catch(Exception ex){questFailed=true;ReleaseQuestControls();MelonLogger.Warning("Quest input stopped: "+ex.Message);}
  }
  private void ApplyQuestFrame() {
   if(questController==null)return;
   questController.SetAxisValue(0,QuestFirstPersonReady()?0f:questFrame.moveX);questController.SetAxisValue(1,questFrame.moveY);
   questController.SetAxisValue(2,questFrame.lookX);questController.SetAxisValue(3,questFrame.lookY);
   questController.SetAxisValue(4,questFrame.moveX);questController.SetAxisValue(5,questFrame.moveY);
   for(int i=0;i<10;i++)questController.SetButtonValue(i,(questFrame.buttons&(1<<i))!=0);
  }
  private void ReleaseQuestControls() {
   questPolicy.Update(false,new QuestSample(),new QuestSample());questFrame=new QuestFrame();questLastActivity=-100f;
   try{ApplyQuestFrame();}catch(Exception ex){MelonLogger.Warning("Quest release failed: "+ex.Message);}
  }
 }
}
