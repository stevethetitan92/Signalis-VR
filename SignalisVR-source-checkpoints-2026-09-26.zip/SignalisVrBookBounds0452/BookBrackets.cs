using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking
{
    public sealed partial class Tracking
    {
        private sealed class BookBracket
        {
            internal SpriteRenderer source, proxy;
            internal MeshFilter model;
        }
        private readonly Dictionary<int, BookBracket> bookBrackets = new Dictionary<int, BookBracket>();

        private BookBracket FindBookBracket(SpriteRenderer source, global::Interaction interaction)
        {
            int id = source.GetInstanceID();
            BookBracket entry;
            if (bookBrackets.TryGetValue(id, out entry) && entry.source == source && entry.model != null) return entry;
            var models = interaction.GetComponentsInChildren<MeshFilter>(true);
            MeshFilter selected = null;
            foreach (var model in models)
            {
                if (model == null || model.sharedMesh == null || !model.gameObject.activeInHierarchy
                    || model.GetComponent<MeshRenderer>() == null) continue;
                if (selected != null) return null; // Ambiguous multi-model books keep the original path.
                selected = model;
            }
            if (selected == null) return null;
            entry = new BookBracket { source = source, model = selected };
            bookBrackets[id] = entry;
            return entry;
        }

        private void PlaceBookBracket(BookBracket entry)
        {
            if (entry.proxy == null)
            {
                var go = new GameObject("SignalisVR_BookBrackets_" + entry.source.GetInstanceID());
                go.layer = 23;
                entry.proxy = go.AddComponent<SpriteRenderer>();
                entry.proxy.enabled = false;
            }
            var source = entry.source;
            var proxy = entry.proxy;
            var model = entry.model;
            // Shared meshes may contain statically batched scene geometry. Renderer
            // bounds are already world-space: never transform their center again.
            var bounds = model.GetComponent<MeshRenderer>().bounds;
            proxy.transform.position = new Vector3(bounds.center.x, bounds.center.y, bounds.min.z - 0.08f);
            proxy.transform.rotation = Quaternion.identity;
            float width = bounds.size.x;
            float height = bounds.size.y;
            proxy.sprite = source.sprite;
            proxy.sharedMaterial = source.sharedMaterial;
            proxy.color = source.color;
            proxy.sortingLayerID = source.sortingLayerID;
            proxy.sortingOrder = source.sortingOrder;
            var spriteSize = source.sprite.bounds.size;
            proxy.transform.localScale = new Vector3(Math.Max(0.5f, width) * 1.15f / Math.Max(0.01f, spriteSize.x),
                Math.Max(0.5f, height) * 1.15f / Math.Max(0.01f, spriteSize.y), 1f);
            // Independent root avoids the original popup's animated scale/nonuniform parent.
            proxy.enabled = true;
            source.enabled = false;
        }

        private void HideBookBrackets()
        { foreach (var e in bookBrackets.Values) if (e.proxy != null) e.proxy.enabled = false; }

        private void ClearBookBrackets()
        {
            foreach (var e in bookBrackets.Values) if (e.proxy != null) UnityEngine.Object.Destroy(e.proxy.gameObject);
            bookBrackets.Clear();
        }
    }
}
