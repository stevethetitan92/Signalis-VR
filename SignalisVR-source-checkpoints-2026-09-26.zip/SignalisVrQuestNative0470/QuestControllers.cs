using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using MelonLoader;
using UnityEngine;
using Valve.VR;
using Rewired;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly QuestHandInputPolicy questPolicy=new QuestHandInputPolicy();


  private QuestFrame questFrame;
  private bool questFailed;

  private bool questInputStopped;
  private float nextQuestConnect;
  private float nextQuestLog;
  private string lastQuestStatus;
  private float nextQuestRouteTrace;
  private string lastQuestRouteTrace;
  private void TraceQuestRouting() {
   if(!questNativeInstalled||Time.realtimeSinceStartup<nextQuestRouteTrace)return;
   nextQuestRouteTrace=Time.realtimeSinceStartup+1f;
   try {
    string report="armed="+questPolicy.Armed+" sourceMove="+questFrame.moveX.ToString("F2")+","+questFrame.moveY.ToString("F2")+" sourceLook="+questFrame.lookX.ToString("F2")+","+questFrame.lookY.ToString("F2")+" buttons="+questFrame.buttons+QuestNativeReport();
    if(questFpPlayer!=null&&questFpMod!=null) {
     var gamePlayer=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
     if(gamePlayer!=null)report+=" gameInput="+gamePlayer.input.x.ToString("F2")+","+gamePlayer.input.y.ToString("F2")+" playing="+gamePlayer.playing+" traversing="+gamePlayer.traversing;
    }
    var actions=Resources.FindObjectsOfTypeAll<global::CharacterAction>();
    if(actions.Length>0&&actions[0]!=null)report+=" actionMove="+actions[0].Move.x.ToString("F2")+","+actions[0].Move.y.ToString("F2");
    if(report!=lastQuestRouteTrace){lastQuestRouteTrace=report;MelonLogger.Msg("QUEST ROUTE: "+report);}
   }catch(Exception ex){nextQuestRouteTrace=Time.realtimeSinceStartup+5f;MelonLogger.Warning("Quest route trace: "+ex.Message);}
  }
  private object questFpMod;
  private FieldInfo questFpYaw;
  private FieldInfo questFpPlayer;
  private readonly uint questProcessId=(uint)Process.GetCurrentProcess().Id;
  [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window,out uint processId);
  private void EnsureQuestConnection() {
   if(system!=null||questFailed||questInputStopped||stopping||Time.realtimeSinceStartup<nextQuestConnect)return;
   nextQuestConnect=Time.realtimeSinceStartup+5f;
   try {
    NativeLibraries.Initialize();
    if(!OpenVR.IsHmdPresent())return;
    EVRInitError error=EVRInitError.None;
    // Claim the VR scene at startup so SteamVR Home is not the active scene
    // while SIGNALIS is at a menu or still waiting for stereo setup.
    var connected=OpenVR.Init(ref error,EVRApplicationType.VRApplication_Scene);
    if(error!=EVRInitError.None||connected==null) {MelonLogger.Warning("Quest menu connection waiting: "+error);return;}
    system=connected;
    MelonLogger.Msg("QUEST MENU: SIGNALIS scene connection acquired; Home is no longer the intended active scene. Stereo rendering still requires F6/F9/F10.");
   }catch(Exception ex){MelonLogger.Warning("Quest menu connection waiting: "+ex.Message);}
  }
  private void PrepareQuestSceneConnection() { questInputStopped=false; }
  private void EnsureQuestControllers() {
   if(questFailed||system==null||!ReInput.isReady)return;
   if(questNativeInstalled){PollQuestControllers();return;}
   try {
    foreach(var mod in MelonHandler.Mods) {
     if(mod.GetType().FullName!="FPv2_reworked.FPv2_rework")continue;
     questFpMod=mod;questFpYaw=mod.GetType().GetField("x",BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public);
     questFpPlayer=mod.GetType().GetField("player_control",BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public);
    }
    InstallQuestFirstPerson();
    InstallQuestNativeReads();
    PollQuestControllers();
    MelonLogger.Msg("QUEST INPUT0470: no custom controller, no dynamic maps, no Rewired input event subscription. Native reads only; runtime unverified.");
   }catch(Exception ex){questFailed=true;ReleaseQuestControls();MelonLogger.Warning("Quest setup failed: "+ex.Message);}
  }
  private bool ReadQuestHand(ETrackedControllerRole role,out QuestSample sample) {
   sample=new QuestSample();uint id=system.GetTrackedDeviceIndexForControllerRole(role);
   if(id==OpenVR.k_unTrackedDeviceIndexInvalid)return false;
   var state=new VRControllerState_t();
   if(!system.GetControllerState(id,ref state,(uint)Marshal.SizeOf(typeof(VRControllerState_t))))return false;
   sample=new QuestSample{x=state.rAxis0.x,y=state.rAxis0.y,trigger=state.rAxis1.x,grip=state.rAxis2.x,buttons=state.ulButtonPressed};return true;
  }
  private void PollQuestControllers() {
   try {
    uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
    bool ready=QuestInputPolicy.Ready(system!=null,stopping,questFailed,questInputStopped);
    // Foreground game and dashboard
    // checks complement SteamVR scene input availability.
    bool vrInput=ready&&system.IsInputAvailable()&&(OpenVR.Overlay==null||!OpenVR.Overlay.IsDashboardVisible());
    QuestSample left=new QuestSample(),right=new QuestSample();
    bool l=vrInput&&ReadQuestHand(ETrackedControllerRole.LeftHand,out left),r=vrInput&&ReadQuestHand(ETrackedControllerRole.RightHand,out right);
    questFrame=questPolicy.UpdateHands(ready&&foreground==questProcessId&&vrInput,l,r,left,right);
    RecordQuestActivity();UpdateQuestInputMode();SnapshotQuestNative();
    if(!ready)return;
    string status="focus="+(foreground==questProcessId)+" vrInput="+vrInput+" left="+l+" right="+r+" armed="+questPolicy.Armed+" leftArmed="+questPolicy.LeftArmed+" rightArmed="+questPolicy.RightArmed;
    if(status!=lastQuestStatus||Time.realtimeSinceStartup>=nextQuestLog) {
     lastQuestStatus=status;nextQuestLog=Time.realtimeSinceStartup+3f;
     MelonLogger.Msg("QUEST INPUT: "+status+" buttons="+questFrame.buttons+" move="+questFrame.moveX+","+questFrame.moveY+" look="+questFrame.lookX+","+questFrame.lookY);
    }
   }catch(Exception ex){questFailed=true;ReleaseQuestControls();MelonLogger.Warning("Quest input stopped: "+ex.Message);}
  }
  private void ReleaseQuestControls() {
   questPolicy.Update(false,new QuestSample(),new QuestSample());questFrame=new QuestFrame();questLastActivity=-100f;questNativeAvailable=false;questNativeEdges.Reset();

  }
 }
}


