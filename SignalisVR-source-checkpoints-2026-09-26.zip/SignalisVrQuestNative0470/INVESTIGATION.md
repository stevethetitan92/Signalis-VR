# 0470 crash response

User reports0469 crashed when moving right. Installed hash confirms0469.
Saved Melon log, Unity crash Player.log, minidump and Windows event under
../SignalisVrQuestNative0469/evidence. Windows records c0000005 in Mono at2fdc28.
Unity log shows repeated out-of-range exceptions in Rewired update and
Player.ControllerHelper.GetLastActiveController -> CharacterAction.Update,
followed by synchronization/UI errors and eventual Mono crash. This establishes
controller-system exceptions, not the exact root cause of memory failure.
Native input callbacks did run while idle. Counts stopped increasing on stick
activity; original CharacterAction could throw before querying axes. Movement
was not established. The custom registration path is suspect, not proven cause.

0470 removes custom controller creation/assignment/maps/values and the Rewired
InputSourceUpdateEvent subscription completely. Quest input is sampled from the
existing managed OnUpdate. No native CharacterAction.Update detour remains:
the native game update and its exception handling run directly. Four native
integer axis/button getters remain, always calling originals. Existing metadata
target validation, delegate roots, physical input merge, focus/dashboard/arming
and F12 guards are retained. No OS input injection or automatic install/launch.
Diagnostics count getter callbacks without invoking getters for reporting, and
observe actual player input/CharacterAction.Move. These counts no longer assert
a specific native caller. Main-menu Home ownership remains unresolved.

Changes from0469: QuestControllers.cs rewritten without custom registration;
QuestNativeReads.cs removes Update hook/observer and uses four-target validation;
build.ps1 omits QuestNativeMap.cs, removed from this candidate; main version0470;
tests updated to reject controller mutation/event subscription/native Update hook.
Approved visual sources and QuestFirstPerson.cs hash-identical to0469.

Build passes with existingCS1701 warnings. Tests pass:80routing/edges/ABI/compiled,
20policy+11compiled,16turn+7FP,9hands,15button+3compiled,42strafe+8compiled,
16overlay restoration. These are software checks, not native or headset proof.
No game launched.0470 is not installed. Next manual test: movement before stereo.

0470 SHA256 652FA3BAA671601FFA33718E8286B57037B64EE4166B7244FE9363A598E0FF04
Installed0469 SHA256 B00E65A80C6E24E2BB7DF91FB119A173845F546156C6C249E0CF4C9F0565602F
