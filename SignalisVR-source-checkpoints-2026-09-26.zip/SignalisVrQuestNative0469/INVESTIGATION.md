# 0469 investigation

User confirms WASD works under0468 while left-stick forward/back does not.
Native movement remains functional. Why the dynamic Rewired map contributes
zero is not established.

Static native inspection: CharacterAction.Update RVA C67AC0 calls native
Player.GetAxis(int)1202670, GetButton(int)12058D0, GetButtonDown(int)12034F0,
GetButtonUp(int)1205710. AlternatePlayerController consumes CharacterAction.Move.
Earlier managed getter postfixes did not establish native game consumption.

0469 resolves pointers from generated IL2CPP MethodInfo metadata, validates all
five module-relative addresses against the inspected build, and uses MelonLoader
native hooks. Native originals are always called. Strongest-source axis merge
preserves physical input and avoids doubling custom input. Button masks merge
held/down/up with native results. Repeated polling preserves one-frame edges.
Simultaneous physical and Quest sources can independently generate button edges;
this remains a runtime limitation to test. No OS input injection.

CharacterAction.Update calls its original unchanged and observes resulting Move
and Use. Counters distinguish reads inside that native Update from diagnostics.
The native SuspendAll early-return path remains intact. No direct player action
or transform writes. Focus/dashboard/arming/F12 guards remain. Bool return is I1;
Cdecl delegates include self/action/MethodInfo. Delegates and slots are rooted for
process lifetime, including after F12, when they pass through.

New QuestNativeReads.cs; changed QuestControllers.cs, QuestInputPolicy.cs,
build.ps1, version in SignalisVrTracking.cs, test-quest-actions wording;
new test-quest-native-reads.ps1. Approved visuals and QuestFirstPerson.cs unchanged.

Build passes existing CS1701 warnings. Checks:73new routing/lifecycle/ABI/compiled,
20policy+11compiled,16turn+7FP,9hands,15button+3compiled,42strafe+12compiled,
16overlay restoration settings. No game/native runtime or headset validation.
Main-menu presentation/focus and SteamVR Home exclusivity remain unresolved.
Installed files unchanged. Rollback0468.zip contains the installed DLL.

Loader API declaration checked against installed binary and official source:
https://github.com/LavaGang/MelonLoader/blob/v0.5.7/MelonLoader/MelonUtils.cs
SteamVR Input can help configurable bindings but still needs the game bridge:
https://valvesoftware.github.io/steamvr_unity_plugin/articles/SteamVR-Input.html

DLL SHA256 B00E65A80C6E24E2BB7DF91FB119A173845F546156C6C249E0CF4C9F0565602F
Installed0468 SHA256 0E089415A1855840500A92F46F5175DB2751137BEAB06D7AA4FE13BA7A3378E9
GameAssembly SHA256 58174E0C941D00E49AC3796A6389E877773D0F6C7A0154C6A5881E53BBE73FC7
