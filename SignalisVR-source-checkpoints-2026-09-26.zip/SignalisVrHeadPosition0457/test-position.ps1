$ErrorActionPreference = 'Stop'
$source = Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
$match = [regex]::Match($source,'var trackingToWorld = camera.transform.parent.rotation \* baseRotation \* Quaternion.Inverse\(neutral\);\s*stereoPosition = camera.transform.position\s*\+ trackingToWorld \* \(\(trackedHeadPosition - neutralHeadPosition\) \* UnitsPerMetre\);')
if (-not $match.Success) { throw 'Production translation expression not found' }
$expression = $match.Value.Replace('stereoPosition =','return')
$code = @'
using System;
using N = System.Numerics;
public struct Vector3 {
 public N.Vector3 v;
 public Vector3(float x,float y,float z) { v=new N.Vector3(x,y,z); }
 public static Vector3 operator +(Vector3 a,Vector3 b) { return new Vector3 { v=a.v+b.v }; }
 public static Vector3 operator -(Vector3 a,Vector3 b) { return new Vector3 { v=a.v-b.v }; }
 public static Vector3 operator *(Vector3 a,float b) { return new Vector3 { v=a.v*b }; }
}
public struct Quaternion {
 public N.Quaternion q;
 public static Quaternion Inverse(Quaternion a) { return new Quaternion { q=N.Quaternion.Inverse(a.q) }; }
 public static Quaternion operator *(Quaternion a,Quaternion b) { return new Quaternion { q=a.q*b.q }; }
 public static Vector3 operator *(Quaternion a,Vector3 b) { return new Vector3 { v=N.Vector3.Transform(b.v,a.q) }; }
 public static Quaternion Euler(float yaw,float pitch,float roll) { return new Quaternion { q=N.Quaternion.CreateFromYawPitchRoll(yaw,pitch,roll) }; }
}
public class T { public T parent; public Quaternion rotation; public Vector3 position; }
public class C { public T transform; }
public static class PositionTests {
 static Vector3 Position(C camera, Quaternion baseRotation, Quaternion neutral, Vector3 trackedHeadPosition, Vector3 neutralHeadPosition) {
 const float UnitsPerMetre=5f;
 EXPRESSION
 }
 static void Check(Vector3 actual,Vector3 expected,string message) {
 if (N.Vector3.Distance(actual.v,expected.v)>0.0001f) throw new Exception(message+": "+actual.v+" != "+expected.v);
 }
 public static string Run() {
 var identity=Quaternion.Euler(0,0,0);
 var origin=new Vector3(10,-30,-8);
 var camera=new C {transform=new T {position=origin,parent=new T {rotation=identity}}};
 var neutral=new Vector3(2,1.7f,-4);
 Check(Position(camera,identity,identity,neutral,neutral),origin,"Standing height must cancel on recenter");
 foreach(var delta in new[]{new Vector3(.2f,0,0),new Vector3(0,.2f,0),new Vector3(0,0,.2f),new Vector3(-.2f,-.1f,-.3f)})
 Check(Position(camera,identity,identity,neutral+delta,neutral),origin+delta*5,"Metric translation scale/axis");
 var yaw=Quaternion.Euler((float)Math.PI/2,0,0);
 Check(Position(camera,identity,yaw,neutral+new Vector3(.2f,0,0),neutral),origin+new Vector3(0,0,1),"Recenter yaw must rotate translation axes");
 camera.transform.parent.rotation=Quaternion.Euler(0,(float)-Math.PI/2,0);
 Check(Position(camera,identity,identity,neutral+new Vector3(0,.2f,0),neutral),origin+new Vector3(0,0,-1),"Rig maps headset up to game up");
 var moved=neutral+new Vector3(.3f,.1f,-.2f);
 Check(Position(camera,identity,identity,moved,moved),origin,"F7 resets lean");
 return "PASS: 8 production-expression positional checks (recenter, axes, scale, yaw and game-up mapping).";
 }
}
'@
Add-Type -TypeDefinition $code.Replace('EXPRESSION',$expression)
[PositionTests]::Run()
foreach($text in @('trackedHeadPosition = new Vector3(preparedMatrix[3], preparedMatrix[7], -preparedMatrix[11]);','trackedHeadPosition = new Vector3(m.m3, m.m7, -m.m11);','neutralHeadPosition = trackedHeadPosition;','eye.transform.position = stereoPosition + stereoRotation')) {
 if (-not $source.Contains($text)) { throw "Missing pose integration: $text" }
}
'PASS: synchronized and local pose translation, recenter reference and stereo eye origin integration present.'
