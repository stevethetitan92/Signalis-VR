# 0471 shared native getter fix

User supplied0470 Player.log,31,711,857bytes, preserved in0470/user-diagnostics.
It contains repeated collection bounds/empty stack errors despite no custom
controller registration in0470. Custom registration was not the sole cause.

Confirmed static bug: InputControl.GetInputState is RVA299B70, four bytes:
mov eax,[rcx+18h]; ret. The compiler/linker shares this address with121 methods
across the inspected assemblies. This includes List<T>.Count, Stack<T>.Count,
Rewired.UpdateLoopDataSet<T>.Count and many other state/count getters.
QuestInputStatePrefix skipped the original and returned Controler (1) whenever
QuestOwnsInputMode became true, with no instance/type restriction. Consequently
the native detour could alter all these unrelated getter results after initial
Quest activity. This matches the idle-working/activity-breaks timing and the
collection errors. Static evidence establishes the unsafe patch; final crash
causality and the restoration of controls still need runtime verification.

0471 removes both the GetInputState patch registration and its prefix method.
Existing OnGUI instance-state assignment remains, so GetInputState can naturally
read m_State without a detour. The other InputControl targets and four Rewired
integer getter targets each have one address match in inspected metadata.
Evidence: shared-input-getter.txt, input-control-native.txt,
native-hook-address-audit.txt. No game executable was run for this inspection.

Changes: QuestFirstPerson.cs removes unsafe patch/prefix; SignalisVrTracking.cs
version0471; QuestControllers.cs diagnostic banner only; new collision regression
test. Native reads, axis policy and approved visuals unchanged from0470.
No custom controller registration or CharacterAction.Update detour restored.

Build passes existingCS1701 warnings. Regression test rejects shared getter patch
and checks remaining7addresses against audit. Existing80routing/edges/ABI,
20policy+11compiled,16turn+7FP,9hands,15button+3compiled,42strafe+8compiled,
16overlay settings checks pass. These do not establish headset stability.
Full user-controlled restart required. No install performed. SteamVR shared
control/pre-stereo display still unresolved and must be addressed separately.

0471 SHA256 EE6FF2CDB5468BCF3EAF374C476CABB69D005FCB4258F5631B22FDF6133A1321
Installed0470 SHA256652FA3BAA671601FFA33718E8286B57037B64EE4166B7244FE9363A598E0FF04
