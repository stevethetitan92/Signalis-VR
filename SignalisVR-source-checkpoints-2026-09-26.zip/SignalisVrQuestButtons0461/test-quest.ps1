$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
function Check($v,$message) {if(-not $v){throw $message}}
$p=[SignalisVrTracking.QuestInputPolicy]::new()
$l=[SignalisVrTracking.QuestSample]::new(); $r=[SignalisVrTracking.QuestSample]::new()
$r.trigger=1
Check ($p.Update($true,$l,$r).buttons -eq 0 -and -not $p.Armed) 'Held trigger armed at startup'
$r.trigger=0; $null=$p.Update($true,$l,$r)
Check $p.Armed 'Neutral did not arm'
$r.grip=1
Check ($p.Update($true,$l,$r).buttons -eq 32) 'Right grip must only aim'
$r.trigger=1
Check ($p.Update($true,$l,$r).buttons -eq 96) 'Aim and fire combination'
$r.grip=0; $r.trigger=0; $r.buttons=2
Check ($p.Update($true,$l,$r).buttons -eq 130) 'B must reload and provide contextual menu cancel'
$r.buttons=128
Check ($p.Update($true,$l,$r).buttons -eq 1) 'A must interact'
$r.buttons=0; $l.buttons=128
Check ($p.Update($true,$l,$r).buttons -eq 4) 'X inventory'
$l.buttons=2
Check ($p.Update($true,$l,$r).buttons -eq 8) 'Y pause'
$l.buttons=0; $l.grip=1
Check ($p.Update($true,$l,$r).buttons -eq 16) 'Left grip sprint'
$l.grip=0; $l.x=1; $r.x=-1
$f=$p.Update($true,$l,$r)
Check ($f.moveX -eq 1 -and $f.lookX -eq -1) 'Independent stick directions'
$f=$p.Update($false,$l,$r)
Check ($f.buttons -eq 0 -and $f.moveX -eq 0 -and $f.lookX -eq 0 -and -not $p.Armed) 'Focus/dashboard/disconnect release'
$null=$p.Update($true,$l,$r)
Check (-not $p.Armed) 'Held sticks rearmed after interruption'
$l.x=0; $r.x=0; $null=$p.Update($true,$l,$r)
Check $p.Armed 'Neutral reconnect failed'
Check ([SignalisVrTracking.QuestInputPolicy]::Stick(.1) -eq 0) 'Deadzone'
Check ([SignalisVrTracking.QuestInputPolicy]::Stick([float]::NaN) -eq 0) 'Invalid axis'
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
 $t=$a.MainModule.Types | Where-Object FullName -eq 'SignalisVrTracking.Tracking'
 foreach($pair in @(@('Stop','ReleaseQuestControls'),@('OnUpdate','EnsureQuestControllers'),@('OnUpdate','UpdateQuestTurning'),@('EnsureQuestControllers','add_InputSourceUpdateEvent'))) {
  $m=$t.Methods | Where-Object Name -eq $pair[0]
  Check (@($m.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.Name -eq $pair[1]}).Count -gt 0) ('Missing integration '+($pair -join ':'))
 }
}finally{$a.Dispose()}
'PASS: 15 controller policy checks and 4 compiled integration checks; headset behavior unverified.'
