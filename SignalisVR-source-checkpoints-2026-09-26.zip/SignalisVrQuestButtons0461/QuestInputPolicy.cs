using System;
namespace SignalisVrTracking {
 public struct QuestSample {
  public float x,y,trigger,grip; public ulong buttons;
  public bool Button(int bit) { return (buttons & (1UL<<bit))!=0; }
  public bool Neutral { get {return Math.Abs(x)<.2f && Math.Abs(y)<.2f && trigger<.2f && grip<.2f && buttons==0;} }
 }
 public struct QuestFrame {public float moveX,moveY,lookX,lookY; public int buttons;}
 public sealed class QuestInputPolicy {
  public bool Armed {get;private set;}
  public QuestFrame Update(bool available,QuestSample left,QuestSample right) {
   if(!available){Armed=false;return new QuestFrame();}
   if(!Armed){Armed=left.Neutral&&right.Neutral;return new QuestFrame();}
   int b=0;
   if(right.Button(7)) b|=1<<0;
   if(left.trigger>.55f || right.Button(1)) b|=1<<1;
   if(left.Button(7)) b|=1<<2;
   if(left.Button(1)) b|=1<<3;
   if(left.grip>.55f || left.Button(2)) b|=1<<4;
   if(right.grip>.55f || right.Button(2)) b|=1<<5;
   if(right.trigger>.55f) b|=1<<6;
   if(right.Button(1)) b|=1<<7;
   if(left.Button(32)) b|=1<<8;
   if(right.Button(32)) b|=1<<9;
   return new QuestFrame{moveX=Stick(left.x),moveY=Stick(left.y),lookX=Stick(right.x),lookY=Stick(right.y),buttons=b};
  }
  public static float Stick(float v) {
   if(float.IsNaN(v)||float.IsInfinity(v))return 0;
   return Math.Abs(v)<=.2f?0:Math.Sign(v)*Math.Min(1f,(Math.Abs(v)-.2f)/.8f);
  }
 }
}
