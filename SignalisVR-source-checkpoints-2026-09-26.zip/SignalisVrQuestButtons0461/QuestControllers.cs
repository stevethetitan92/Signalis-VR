using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using MelonLoader;
using UnityEngine;
using Valve.VR;
using Rewired;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly QuestInputPolicy questPolicy=new QuestInputPolicy();
  private CustomController questController;
  private Il2CppSystem.Action questInputCallback;
  private QuestFrame questFrame;
  private bool questFailed;
  private float nextQuestLog;
  private string lastQuestStatus;
  private object questFpMod;
  private FieldInfo questFpYaw;
  private FieldInfo questFpPlayer;
  private readonly uint questProcessId=(uint)Process.GetCurrentProcess().Id;
  [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window,out uint processId);
  private void EnsureQuestControllers() {
   if(questFailed || questController!=null || system==null || !ReInput.isReady)return;
   try {
    var data=ReInput.UserData;
    var def=new Rewired.Data.CustomController_Editor();
    def.id=data.GetNewCustomControllerId(); def.name="SIGNALIS VR Quest"; def.descriptiveName="Quest sticks and buttons";
    for(int i=0;i<4;i++)def.AddAxis();
    for(int i=0;i<10;i++)def.AddButton();
    data.customControllers.Add(def); // Session memory only; no saved bindings are overwritten.
    questController=ReInput.controllers.CreateCustomController(def.id);
    if(questController==null)throw new InvalidOperationException("Rewired did not create the Quest controller");
    int category=ReInput.mapping.GetMapCategoryId("Default"),layout=ReInput.mapping.GetCustomControllerLayoutId("Default");
    if(category<0||layout<0)throw new InvalidOperationException("Default controller category/layout missing");
    var axes=def.GetAxisElementIdentifierIds(); var buttons=def.GetButtonElementIdentifierIds();
    var players=ReInput.players.AllPlayers;
    int playerCount=players.Cast<Il2CppSystem.Collections.Generic.ICollection<Player>>().Count;
    for(int p=0;p<playerCount;p++) {
     var player=players[p]; player.controllers.AddController(questController,false);
     player.controllers.maps.AddEmptyMap(ControllerType.Custom,questController.id,category,layout);
     var map=player.controllers.maps.GetMap(ControllerType.Custom,questController.id,category,layout);
     if(map==null)throw new InvalidOperationException("Custom map missing for "+player.name);
     string[] axisNames={"Move Horizontal","Move Vertical","Aim Horizontal","Aim Vertical"};
     for(int i=0;i<4;i++)AddQuestMap(map,axisNames[i],axes[i],true);
     AddQuestMap(map,"UIHorizontal",axes[0],true); AddQuestMap(map,"UIVertical",axes[1],true);
     string[] names={"Interact","Cancel","Inventory","Pause","Sprint","Aim Mode","Attack","Reload","TabLeft","TabRight"};
     for(int i=0;i<names.Length;i++)AddQuestMap(map,names[i],buttons[i],false);
     AddQuestMap(map,"Confirm",buttons[0],false); map.enabled=true;
     MelonLogger.Msg("QUEST NATIVE MAP: player="+player.name+" controller="+questController.id);
    }
    foreach(var mod in MelonHandler.Mods) {
     if(mod.GetType().FullName!="FPv2_reworked.FPv2_rework")continue;
     questFpMod=mod;questFpYaw=mod.GetType().GetField("x",BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public);
     questFpPlayer=mod.GetType().GetField("player_control",BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public);
    }
    questInputCallback=(Il2CppSystem.Action)(Action)PollQuestControllers;
    ReInput.add_InputSourceUpdateEvent(questInputCallback);
    MelonLogger.Msg("QUEST CONTROLLERS: native Rewired input ready; right grip aims, right trigger fires, B reloads. FP turning="+(questFpYaw!=null));
   }catch(Exception ex){questFailed=true;ReleaseQuestControls();MelonLogger.Warning("Quest setup failed: "+ex.Message);}
  }
  private static void AddQuestMap(ControllerMap map,string name,int element,bool axis) {
   int action=ReInput.mapping.GetActionId(name);
   if(action<0)throw new InvalidOperationException("Native action not found: "+name);
   if(!map.CreateElementMap(action,Pole.Positive,element,axis?ControllerElementType.Axis:ControllerElementType.Button,AxisRange.Full,false))throw new InvalidOperationException("Could not map: "+name);
  }
  private bool ReadQuestHand(ETrackedControllerRole role,out QuestSample sample) {
   sample=new QuestSample();uint id=system.GetTrackedDeviceIndexForControllerRole(role);
   if(id==OpenVR.k_unTrackedDeviceIndexInvalid)return false;
   var state=new VRControllerState_t();
   if(!system.GetControllerState(id,ref state,(uint)Marshal.SizeOf(typeof(VRControllerState_t))))return false;
   sample=new QuestSample{x=state.rAxis0.x,y=state.rAxis0.y,trigger=state.rAxis1.x,grip=state.rAxis2.x,buttons=state.ulButtonPressed};return true;
  }
  private void PollQuestControllers() {
   try {
    uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
    bool ready=active&&stereo&&diagnostic.CanSubmit&&system!=null&&!stopping&&!questFailed;
    bool vrInput=ready&&system.IsInputAvailable()&&(OpenVR.Overlay==null||!OpenVR.Overlay.IsDashboardVisible());
    QuestSample left=new QuestSample(),right=new QuestSample();
    bool l=vrInput&&ReadQuestHand(ETrackedControllerRole.LeftHand,out left),r=vrInput&&ReadQuestHand(ETrackedControllerRole.RightHand,out right);
    questFrame=questPolicy.Update(ready&&foreground==questProcessId&&vrInput&&l&&r,left,right);ApplyQuestFrame();
    if(!ready)return;
    string status="focus="+(foreground==questProcessId)+" vrInput="+vrInput+" left="+l+" right="+r+" armed="+questPolicy.Armed;
    if(status!=lastQuestStatus||Time.realtimeSinceStartup>=nextQuestLog) {
     lastQuestStatus=status;nextQuestLog=Time.realtimeSinceStartup+3f;
     MelonLogger.Msg("QUEST INPUT: "+status+" buttons="+questFrame.buttons+" move="+questFrame.moveX+","+questFrame.moveY+" look="+questFrame.lookX+","+questFrame.lookY);
    }
   }catch(Exception ex){questFailed=true;ReleaseQuestControls();MelonLogger.Warning("Quest input stopped: "+ex.Message);}
  }
  private void ApplyQuestFrame() {
   if(questController==null)return;
   questController.SetAxisValue(0,questFrame.moveX);questController.SetAxisValue(1,questFrame.moveY);
   questController.SetAxisValue(2,questFrame.lookX);questController.SetAxisValue(3,questFrame.lookY);
   for(int i=0;i<10;i++)questController.SetButtonValue(i,(questFrame.buttons&(1<<i))!=0);
  }
  private void UpdateQuestTurning() {
   if(!questPolicy.Armed||questFailed||questFpYaw==null||questFpPlayer==null||camera==null||!camera.enabled||recovery.Paused||pauseMenuVisible||bookScreenVisible||dialogueScreenVisible)return;
   try {
    uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
    if(foreground!=questProcessId||system==null||!system.IsInputAvailable()||(OpenVR.Overlay!=null&&OpenVR.Overlay.IsDashboardVisible())) {ReleaseQuestControls();return;}
    var player=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
    if(player==null||!player.playing||player.traversing)return;
    float yaw=(float)questFpYaw.GetValue(questFpMod);
    questFpYaw.SetValue(questFpMod,Mathf.Repeat(yaw+questFrame.lookX*90f*Math.Min(.05f,Time.unscaledDeltaTime),360f));
   }catch(Exception ex){questFailed=true;ReleaseQuestControls();MelonLogger.Warning("Quest turning stopped: "+ex.Message);}
  }
  private void ReleaseQuestControls() {
   questPolicy.Update(false,new QuestSample(),new QuestSample());questFrame=new QuestFrame();
   try{ApplyQuestFrame();}catch(Exception ex){MelonLogger.Warning("Quest release failed: "+ex.Message);}
  }
 }
}
