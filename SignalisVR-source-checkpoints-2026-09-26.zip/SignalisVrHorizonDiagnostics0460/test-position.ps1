$ErrorActionPreference = 'Stop'
$source = Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
$match = [regex]::Match($source,'var levelRig = LevelTrackingRig\(camera.transform.parent.rotation \* baseRotation\);\s*var trackingToWorld = levelRig \* Quaternion.Inverse\(neutral\);[\s\S]*?stereoPosition = camera.transform.position\s*\+ trackingToWorld \* \(\(trackedHeadPosition - neutralHeadPosition\) \* UnitsPerMetre\);')
if (-not $match.Success) { throw 'Production translation expression not found' }
$expression = $match.Value.Replace('stereoPosition =','return').Replace('stereoRotation = trackingToWorld * pose;','')
$levelMethod = [regex]::Match($source,'private static Quaternion LevelTrackingRig\(Quaternion rig\)[\s\S]*?(?=private static Quaternion Heading)').Value
$levelMethod += [regex]::Match($source,'private static Quaternion StabilizeHorizon\(Quaternion rotation\)[\s\S]*?(?=private static Quaternion LevelTrackingRig)').Value
$code = @'
using System;
using N = System.Numerics;
public struct Vector3 {
 public N.Vector3 v;
 public static Vector3 forward { get { return new Vector3(0,0,1); } }
 public static Vector3 right { get { return new Vector3(1,0,0); } }
 public float sqrMagnitude { get { return v.LengthSquared(); } }
 public Vector3 normalized { get { return new Vector3 { v=N.Vector3.Normalize(v) }; } }
 public static float Dot(Vector3 a,Vector3 b) { return N.Vector3.Dot(a.v,b.v); }
 public static Vector3 Cross(Vector3 a,Vector3 b) { return new Vector3 {v=N.Vector3.Cross(a.v,b.v)}; }
 public Vector3(float x,float y,float z) { v=new N.Vector3(x,y,z); }
 public static Vector3 operator +(Vector3 a,Vector3 b) { return new Vector3 { v=a.v+b.v }; }
 public static Vector3 operator -(Vector3 a,Vector3 b) { return new Vector3 { v=a.v-b.v }; }
 public static Vector3 operator *(Vector3 a,float b) { return new Vector3 { v=a.v*b }; }
}
public struct Quaternion {
 public N.Quaternion q;
 public static Quaternion LookRotation(Vector3 f,Vector3 u) {
 var r=N.Vector3.Normalize(N.Vector3.Cross(u.v,f.v)); var up=N.Vector3.Cross(f.v,r);
 var m=new N.Matrix4x4(r.X,r.Y,r.Z,0,up.X,up.Y,up.Z,0,f.v.X,f.v.Y,f.v.Z,0,0,0,0,1);
 return new Quaternion {q=N.Quaternion.CreateFromRotationMatrix(m)};
 }
 public static Quaternion Inverse(Quaternion a) { return new Quaternion { q=N.Quaternion.Inverse(a.q) }; }
 public static Quaternion operator *(Quaternion a,Quaternion b) { return new Quaternion { q=a.q*b.q }; }
 public static Vector3 operator *(Quaternion a,Vector3 b) { return new Vector3 { v=N.Vector3.Transform(b.v,a.q) }; }
 public static Quaternion Euler(float yaw,float pitch,float roll) { return new Quaternion { q=N.Quaternion.CreateFromYawPitchRoll(yaw,pitch,roll) }; }
}
public class T { public T parent; public Quaternion rotation; public Vector3 position; }
public class C { public T transform; }
public static class PositionTests {
 LEVELMETHOD
 static Vector3 Position(C camera, Quaternion baseRotation, Quaternion neutral, Vector3 trackedHeadPosition, Vector3 neutralHeadPosition) {
 const float UnitsPerMetre=5f;
 EXPRESSION
 }
 static void Check(Vector3 actual,Vector3 expected,string message) {
 if (N.Vector3.Distance(actual.v,expected.v)>0.0001f) throw new Exception(message+": "+actual.v+" != "+expected.v);
 }
 public static string Run() {
 var identity=Quaternion.Euler(0,0,0);
 var origin=new Vector3(10,-30,-8);
 var gameRig=Quaternion.Euler(0,(float)-Math.PI/2,0);
 var camera=new C {transform=new T {position=origin,parent=new T {rotation=gameRig}}};
 var neutral=new Vector3(2,1.7f,-4);
 Check(Position(camera,identity,identity,neutral,neutral),origin,"Standing height must cancel on recenter");
 foreach(var delta in new[]{new Vector3(.2f,0,0),new Vector3(0,.2f,0),new Vector3(0,0,.2f),new Vector3(-.2f,-.1f,-.3f)})
 Check(Position(camera,identity,identity,neutral+delta,neutral),origin+gameRig*(delta*5),"Metric translation scale/axis");
 var yaw=Quaternion.Euler((float)Math.PI/2,0,0);
 Check(Position(camera,identity,yaw,neutral+new Vector3(.2f,0,0),neutral),origin+new Vector3(0,1,0),"Recenter yaw must rotate translation axes");
 camera.transform.parent.rotation=Quaternion.Euler(0,(float)-Math.PI/2,0);
 Check(Position(camera,identity,identity,neutral+new Vector3(0,.2f,0),neutral),origin+new Vector3(0,0,-1),"Rig maps headset up to game up");
 var moved=neutral+new Vector3(.3f,.1f,-.2f);
 Check(Position(camera,identity,identity,moved,moved),origin,"F7 resets lean");
 int count=0;
 foreach(float y in new[]{-2.5f,-1f,0f,1f,2.5f})
 foreach(float p in new[]{-1.3f,-.4f,0f,.4f,1.3f})
 foreach(float r in new[]{-.5f,0f,.5f}) {
 camera.transform.parent.rotation=gameRig*Quaternion.Euler(y,p,r);
 var stable=StabilizeHorizon(camera.transform.parent.rotation);
 Check(stable*Vector3.forward,camera.transform.parent.rotation*Vector3.forward,"Horizon test must preserve look direction");
 if (Math.Abs(Vector3.Dot(stable*Vector3.right,new Vector3(0,0,-1)))>.0001f) throw new Exception("Horizon has sideways tilt");
 var expected=gameRig*Quaternion.Euler(y,0,0);
 Check(Position(camera,identity,identity,neutral+new Vector3(0,.2f,0),neutral),origin+new Vector3(0,0,-1),"Tilt must not change physical up");
 Check(Position(camera,identity,identity,neutral+new Vector3(0,0,.2f),neutral),origin+expected*new Vector3(0,0,1),"Tilt must not change horizontal forward");
 Check(LevelTrackingRig(camera.transform.parent.rotation)*new Vector3(0,1,0),new Vector3(0,0,-1),"Rotation and position share room up");
 count++;
 }
 var vertical=gameRig*Quaternion.Euler(.5f,(float)Math.PI/2,.3f);
 Check(StabilizeHorizon(vertical)*Vector3.right,vertical*Vector3.right,"Vertical-gaze fallback");
 return "PASS: 8 positional checks and "+count+" tilted-rig/horizon cases: stable horizon preserves forward direction; vertical-gaze fallback passes.";
 }
}
'@
Add-Type -TypeDefinition $code.Replace('EXPRESSION',$expression).Replace('LEVELMETHOD',$levelMethod)
[PositionTests]::Run()
foreach($text in @('trackedHeadPosition = new Vector3(preparedMatrix[3], preparedMatrix[7], -preparedMatrix[11]);','trackedHeadPosition = new Vector3(m.m3, m.m7, -m.m11);','neutralHeadPosition = trackedHeadPosition;','eye.transform.position = stereoPosition + stereoRotation')) {
 if (-not $source.Contains($text)) { throw "Missing pose integration: $text" }
}
'PASS: synchronized and local pose translation, recenter reference and stereo eye origin integration present.'
