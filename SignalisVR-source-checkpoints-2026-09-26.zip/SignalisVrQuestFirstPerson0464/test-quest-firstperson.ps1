$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
function Check($value,$why){if(-not $value){throw $why}}
foreach($fps in 30,60,90,120) {
 foreach($sensitivity in .5,1,3) {
  $angle=[SignalisVrTracking.QuestInputPolicy]::LookAxis(1,(1.0/$fps),$sensitivity)*$sensitivity*$fps
  Check ([Math]::Abs($angle-90) -lt .001) 'Turn speed depends on frame rate/mouse sensitivity'
 }
}
Check ([SignalisVrTracking.QuestInputPolicy]::LookAxis(1,1,1) -eq 4.5) 'Long-frame turn clamp failed'
Check ([SignalisVrTracking.QuestInputPolicy]::LookAxis(1,.02,0) -eq 0) 'Zero sensitivity division'
Check ([SignalisVrTracking.QuestInputPolicy]::LookAxis(1,.02,[float]::NaN) -eq 0) 'Invalid sensitivity'
Check ([SignalisVrTracking.QuestInputPolicy]::LookAxis(-1,.02,1) -lt 0) 'Left turn direction'
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$fp=[Mono.Cecil.AssemblyDefinition]::ReadAssembly('E:/SteamLibrary/steamapps/common/SIGNALIS/Mods/FPv2_reworked.dll')
$mod=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
 $t=$fp.MainModule.Types | Where-Object Name -eq 'FPv2_rework'
 $update=$t.Methods | Where-Object Name -eq 'OnUpdate'
 $strafe=$t.Methods | Where-Object Name -eq 'x_movement'
 function CountCalls($m,$type,$name){@($m.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.DeclaringType.FullName -eq $type -and $_.Operand.Name -eq $name}).Count}
 Check ((CountCalls $update 'UnityEngine.Input' 'GetAxis') -eq 4) 'FP input layout changed'
 Check ((CountCalls $update 'UnityEngine.Input' 'GetKey') -eq 1) 'FP sprint layout changed'
 Check ((CountCalls $strafe 'UnityEngine.Input' 'GetKey') -eq 2) 'FP strafe key layout changed'
 Check ((CountCalls $strafe 'UnityEngine.Rigidbody' 'AddForce') -eq 2) 'FP strafe physics layout changed'
 $t=$mod.MainModule.Types | Where-Object Name -eq 'Tracking'
 foreach($name in 'QuestFirstPersonReady','QuestFpAxis','QuestFpKey','QuestFpForce') {
  $m=$t.Methods | Where-Object Name -eq $name
  Check (@($m.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.FieldReference] -and $_.Operand.Name -in 'active','stereo','diagnostic'}).Count -eq 0) 'First-person input gated on stereo'
 }
 foreach($pair in @(@('EnsureQuestControllers','InstallQuestFirstPerson'),@('PollQuestControllers','RecordQuestActivity'),@('QuestInputModePostfix','set_usingController'),@('QuestInputModePostfix','set_m_State'))) {
  $m=$t.Methods | Where-Object Name -eq $pair[0]
  Check ((CountCalls $m 'SignalisVrTracking.Tracking' $pair[1]) + (CountCalls $m 'InputControl' $pair[1]) -gt 0) ('Adapter integration missing '+($pair -join ':'))
 }
}finally{$fp.Dispose();$mod.Dispose()}
'PASS: 16 turn-math cases; installed FPv2 input/force layout and 8 compiled adapter checks. Runtime Harmony patching and headset behavior still require testing.'
