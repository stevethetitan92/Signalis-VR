using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using MelonLoader;
using UnityEngine;

namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static Tracking questOwner;
  private HarmonyLib.Harmony questHarmony;
  private FieldInfo questFpModel,questFpSensitivity;
  private float questLastActivity=-100f;
  private bool questFpPatched;
  private void InstallQuestFirstPerson() {
   questOwner=this;
   questHarmony=new HarmonyLib.Harmony("signalis.vr.quest.firstperson");
   if(questFpMod!=null) {
    var type=questFpMod.GetType();
    questFpModel=AccessTools.Field(type,"player_model");
    questFpSensitivity=AccessTools.Field(type,"mouse_sens");
    var update=AccessTools.Method(type,"OnUpdate");
    var strafe=AccessTools.Method(type,"x_movement");
    if(update==null||strafe==null||questFpModel==null||questFpSensitivity==null)throw new InvalidOperationException("FPv2 input adapter fields/methods missing");
    var transpiler=new HarmonyMethod(typeof(Tracking),nameof(QuestFpTranspiler));
    questHarmony.Patch(update,transpiler:transpiler);
    questHarmony.Patch(strafe,transpiler:transpiler);
    questFpPatched=true;
   }
   questHarmony.Patch(AccessTools.Method(typeof(global::InputControl),"OnGUI"),postfix:new HarmonyMethod(typeof(Tracking),nameof(QuestInputModePostfix)));
   MelonLogger.Msg("QUEST FP ADAPTER: keyboard/mouse reads bridged in FPv2 only; active before and during stereo; patched="+questFpPatched);
  }
  // Replace input reads only inside the existing managed FPv2 mod. No global
  // Unity input patch, synthetic OS keystrokes, or installed mod file changes.
  private static IEnumerable<CodeInstruction> QuestFpTranspiler(IEnumerable<CodeInstruction> code,MethodBase __originalMethod) {
   int axes=0,keys=0,forces=0;
   foreach(var instruction in code) {
    var method=instruction.operand as MethodInfo;
    if(method!=null&&method.DeclaringType==typeof(Input)) {
     if(method.Name=="GetAxis"&&method.GetParameters().Length==1) {
      instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpAxis));axes++;
     }else if(method.Name=="GetKey"&&method.GetParameters().Length==1&&method.GetParameters()[0].ParameterType==typeof(KeyCode)) {
      instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpKey));keys++;
     }
    }else if(method!=null&&method.DeclaringType==typeof(Rigidbody)&&method.Name=="AddForce"&&method.GetParameters().Length==1&&method.GetParameters()[0].ParameterType==typeof(Vector3)) {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpForce));forces++;
    }
    yield return instruction;
   }
   if(__originalMethod.Name=="OnUpdate"&&(axes!=4||keys!=1))throw new InvalidOperationException("Unexpected FPv2 update inputs");
   if(__originalMethod.Name=="x_movement"&&(keys!=2||forces!=2))throw new InvalidOperationException("Unexpected FPv2 strafe inputs");
   MelonLogger.Msg("QUEST FP PATCH: "+__originalMethod.Name+" axes="+axes+" keys="+keys+" forces="+forces);
  }
  private bool QuestAvailableNow() {
   if(!questPolicy.Armed||questFailed||questInputStopped||stopping||system==null)return false;
   uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
   return foreground==questProcessId&&(questBackgroundConnection||system.IsInputAvailable())&&(Valve.VR.OpenVR.Overlay==null||!Valve.VR.OpenVR.Overlay.IsDashboardVisible());
  }
  private bool QuestFirstPersonReady() {
   if(!questFpPatched||!QuestAvailableNow()||questFpPlayer==null||questFpModel==null||pauseMenuVisible||bookScreenVisible||dialogueScreenVisible)return false;
   var player=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
   var model=questFpModel.GetValue(questFpMod) as GameObject;
   // Same FPv2 model-layout/playing guard used by its own OnUpdate.
   return player!=null&&player.playing&&!player.traversing&&model!=null&&model.transform.childCount==5;
  }
  private void RecordQuestActivity() {
   if(!questPolicy.Armed){questLastActivity=-100f;return;}
   if(questFrame.buttons!=0||questFrame.moveX!=0||questFrame.moveY!=0||questFrame.lookX!=0||questFrame.lookY!=0)questLastActivity=Time.realtimeSinceStartup;
  }
  private bool QuestOwnsInputMode() {return QuestAvailableNow()&&Time.realtimeSinceStartup-questLastActivity<2f;}
  private void UpdateQuestInputMode() {
   if(QuestOwnsInputMode())global::InputControl.usingController=true;
  }
  private static void QuestInputModePostfix(global::InputControl __instance) {
   if(questOwner==null||!questOwner.QuestOwnsInputMode())return;
   global::InputControl.usingController=true;
   __instance.m_State=global::InputControl.eInputState.Controler;
  }
  private static float QuestFpAxis(string name) {
   var q=questOwner;
   if(q==null||!q.QuestFirstPersonReady())return Input.GetAxis(name);
   if(name=="Horizontal")return Mathf.Clamp(Input.GetAxis(name)+q.questFrame.moveX,-1f,1f);
   if(name=="Vertical")return Mathf.Clamp(Input.GetAxis(name)+q.questFrame.moveY,-1f,1f);
   if((name=="Mouse X"||name=="Mouse Y")&&q.QuestOwnsInputMode()) {
    float sensitivity=(float)q.questFpSensitivity.GetValue(q.questFpMod);
    return QuestInputPolicy.LookAxis(name=="Mouse X"?q.questFrame.lookX:q.questFrame.lookY,Time.unscaledDeltaTime,sensitivity);
   }
   return Input.GetAxis(name);
  }
  private static bool QuestFpKey(KeyCode key) {
   if(Input.GetKey(key))return true;
   var q=questOwner;if(q==null||!q.QuestFirstPersonReady())return false;
   if(key==KeyCode.A)return q.questFrame.moveX<0;
   if(key==KeyCode.D)return q.questFrame.moveX>0;
   if(key==KeyCode.LeftShift)return (q.questFrame.buttons&(1<<4))!=0;
   return false;
  }
  private static void QuestFpForce(Rigidbody body,Vector3 force) {
   var q=questOwner;
   if(q!=null&&q.QuestFirstPersonReady()&&!Input.GetKey(KeyCode.A)&&!Input.GetKey(KeyCode.D))force*=Math.Abs(q.questFrame.moveX);
   body.AddForce(force);
  }
 }
}
