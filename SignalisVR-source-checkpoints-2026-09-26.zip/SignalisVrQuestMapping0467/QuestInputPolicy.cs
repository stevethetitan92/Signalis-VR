using System;
namespace SignalisVrTracking {
 public sealed class QuestButtonEdges {
  private int previous,frame=-1;
  public int Down {get;private set;}
  public int Up {get;private set;}
  public void Sample(int value,int currentFrame) {
   if(frame!=currentFrame){Down=Up=0;frame=currentFrame;}
   Down|=value&~previous;Up|=previous&~value;previous=value;
  }
  public void Reset(){previous=Down=Up=0;frame=-1;}
  public static int ActionBit(string name) {
   switch(name){case "Use":case "Confirm":return 0;case "Cancel":return 1;case "Inventory":return 2;case "Pause":return 3;case "Sprint":return 4;case "Aim Mode":return 5;case "Attack":return 6;case "Reload":return 7;case "TabLeft":return 8;case "TabRight":return 9;default:return -1;}
  }
 }
 public sealed class QuestHandInputPolicy {
  private readonly QuestInputPolicy left=new QuestInputPolicy(),right=new QuestInputPolicy();
  public bool Armed {get{return left.Armed||right.Armed;}}
  public bool LeftArmed {get{return left.Armed;}}
  public bool RightArmed {get{return right.Armed;}}
  public QuestFrame UpdateHands(bool available,bool leftAvailable,bool rightAvailable,QuestSample l,QuestSample r) {
   var a=left.Update(available&&leftAvailable,l,new QuestSample());
   var b=right.Update(available&&rightAvailable,new QuestSample(),r);
   return new QuestFrame{moveX=a.moveX,moveY=a.moveY,lookX=b.lookX,lookY=b.lookY,buttons=a.buttons|b.buttons};
  }
  public QuestFrame Update(bool available,QuestSample l,QuestSample r) {return UpdateHands(available,available,available,l,r);}
 }
 public struct QuestSample {
  public float x,y,trigger,grip; public ulong buttons;
  public bool Button(int bit) { return (buttons & (1UL<<bit))!=0; }
  public bool Neutral { get {return Math.Abs(x)<.2f && Math.Abs(y)<.2f && trigger<.2f && grip<.2f && buttons==0;} }
 }
 public struct QuestFrame {public float moveX,moveY,lookX,lookY; public int buttons;}
 public sealed class QuestInputPolicy {
  public static float LookAxis(float stick,float delta,float sensitivity) {
   if(float.IsNaN(sensitivity)||float.IsInfinity(sensitivity)||Math.Abs(sensitivity)<.0001f)return 0;
   return stick*90f*Math.Min(.05f,Math.Max(0f,delta))/sensitivity;
  }
  public static bool Ready(bool connected,bool stopping,bool failed,bool manuallyStopped) {
   return connected&&!stopping&&!failed&&!manuallyStopped;
  }
  public bool Armed {get;private set;}
  public QuestFrame Update(bool available,QuestSample left,QuestSample right) {
   if(!available){Armed=false;return new QuestFrame();}
   if(!Armed){Armed=left.Neutral&&right.Neutral;return new QuestFrame();}
   int b=0;
   if(right.Button(7)) b|=1<<0;
   if(left.trigger>.55f || right.Button(1)) b|=1<<1;
   if(left.Button(7)) b|=1<<2;
   if(left.Button(1)) b|=1<<3;
   if(left.grip>.55f || left.Button(2)) b|=1<<4;
   if(right.grip>.55f || right.Button(2)) b|=1<<5;
   if(right.trigger>.55f) b|=1<<6;
   if(right.Button(1)) b|=1<<7;
   if(left.Button(32)) b|=1<<8;
   if(right.Button(32)) b|=1<<9;
   return new QuestFrame{moveX=Stick(left.x),moveY=Stick(left.y),lookX=Stick(right.x),lookY=Stick(right.y),buttons=b};
  }
  public static float Stick(float v) {
   if(float.IsNaN(v)||float.IsInfinity(v))return 0;
   return Math.Abs(v)<=.2f?0:Math.Sign(v)*Math.Min(1f,(Math.Abs(v)-.2f)/.8f);
  }
 }
}
