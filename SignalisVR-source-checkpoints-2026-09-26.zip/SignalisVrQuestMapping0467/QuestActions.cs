using System;
using System.Reflection;
using HarmonyLib;
using Rewired;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly QuestButtonEdges questEdges=new QuestButtonEdges();
  private readonly System.Collections.Generic.HashSet<int> questPlayerIds=new System.Collections.Generic.HashSet<int>();
  private void InstallQuestActionBridge() {
   foreach(string name in new[]{"GetAxis","GetAxisRaw","GetButton","GetButtonDown","GetButtonUp"}) {
    foreach(Type argument in new[]{typeof(int),typeof(string)}) {
     var method=AccessTools.Method(typeof(Player),name,new[]{argument});
     if(method==null)throw new InvalidOperationException("Missing native action query: "+name);
     questHarmony.Patch(method,postfix:new HarmonyMethod(typeof(Tracking),name.StartsWith("GetAxis")?nameof(QuestAxisResult):nameof(QuestButtonResult)));
    }
   }
   MelonLoader.MelonLogger.Msg("QUEST ACTION BRIDGE: native Player action queries connected; original input preserved.");
  }
  private static string QuestActionName(object value) {
   var name=value as string;if(name!=null)return name;
   var action=ReInput.mapping.GetAction((int)value);return action==null?"":action.name;
  }
  private static bool QuestActionAvailable(Player player) {
   var q=questOwner;return q!=null&&q.QuestAvailableNow()&&q.questPlayerIds.Contains(player.id);
  }
  private static void QuestAxisResult(Player __instance,object[] __args,ref float __result) {
   if(!QuestActionAvailable(__instance))return;
   var q=questOwner;float value=0;string name=QuestActionName(__args[0]);
   if(name=="Move Vertical")value=q.questFrame.moveY;
   else if(name=="Move Horizontal")value=q.QuestFirstPersonReady()?0:q.questFrame.moveX;
   else if(name=="UIHorizontal")value=q.questFrame.moveX;
   else if(name=="UIVertical")value=q.questFrame.moveY;
   else if(name=="Aim Horizontal")value=q.questFrame.lookX;
   else if(name=="Aim Vertical")value=q.questFrame.lookY;
   // Preserve stronger original input and avoid double-applying nested overloads.
   if(Math.Abs(value)>Math.Abs(__result))__result=value;
  }
  private static void QuestButtonResult(Player __instance,object[] __args,MethodBase __originalMethod,ref bool __result) {
   if(!QuestActionAvailable(__instance))return;
   var q=questOwner;int bit=QuestButtonEdges.ActionBit(QuestActionName(__args[0]));
   if(bit<0)return;
   int mask=__originalMethod.Name=="GetButtonDown"?q.questEdges.Down:__originalMethod.Name=="GetButtonUp"?q.questEdges.Up:q.questFrame.buttons;
   __result=__result||(mask&(1<<bit))!=0;
  }
 }
}
