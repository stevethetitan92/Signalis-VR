# 0.4.78 puzzle input candidate

User: left stick fails in all directions on six-button keypad.
Offline native inspection: EventScreen3DCam.Update and ROT_Cursor.Update select
mouse/controller paths using PlayerState.input.lastActiveController and consume
CharacterAction.Move. Existing bridge sets InputControl mode, but not this field;
first-person routing can also suppress horizontal Move. Runtime cause not proven.

Adds QuestPuzzleInput.cs: guarded prefix temporarily supplies stronger left UI
axes and controller device to these two consumers. Native cursor/selection/click
code remains original. Finalizer restores both fields, preserving exceptions.
Native addresses checked at startup; all-metadata audit finds both unique.
QuestFirstPerson installs hooks; build.ps1 includes file; tracking version0.4.78.
Based on0477, so retains its unverified cutscene screen-capture transition fix.
No further graphics, movement tuning, button, marker or right-stick changes.

Build and seven suites pass (puzzle harness, firstperson, native reads, shared
getter, action layout, menu scene, recovery). Initial shared-getter check lacked
its audit fixture; regenerated metadata audit and reran successfully. Original
failure retained. Harness runs actual scoped methods with stand-in game state;
it cannot prove native detour execution, graphics stability or headset behavior.
Native inspection excerpts and audit saved in evidence; game never launched.

DLL SHA256: 6F6015BE869A5219FBA04BAA253B4881AD8A269A34221FF0C7D6F4F65A219120
Installed remains0476: FB97B8A78F4F88C876A4E06478EEA985230855B918D1067370D4244FD5FB32F7
Not installed by assistant. Rollback0476.zip preserves installed DLL with correct
SignalisVrTracking.dll filename. Historical0475 remains verified input baseline.

Manual sequence (deliver one step at a time): close game; copy candidate DLL to
Mods; launch manually; enter six-button keypad; check left/right/up/down cursor;
then A selection, B exit, ordinary movement/menu controls. Test cutscene separately.
