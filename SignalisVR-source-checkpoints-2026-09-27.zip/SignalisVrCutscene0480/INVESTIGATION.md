# 0.4.80 cutscene candidate

Based on user-verified0479 inputs. Only production source changed versus0479 is
SignalisVrTracking.cs (including version): imports0477 scene-load/invalid-camera
handoff to existing live game-screen renderer. All0479 input files unchanged.

Intent: keep game-only flat-screen frames going to headset through cutscene rather
than Stop on scene load/camera removal. Does not make cutscene immersive stereo.
Blocking Unity loads may still briefly show Waiting. Central white rectangle
reported on0476 remains unexplained; no claim this patch removes it.
After transition, manually restore first person and F6/F9/F10 when appropriate.

Build and8 suites pass: puzzle input harness, firstperson, native reads, shared
getter, menu scene, recovery, diagnostic, dialogue overlay. No runtime/headset
verification. Compilation and stand-in tests cannot establish graphics stability.

DLL SHA256 AE82EDFF4A61B7EF0928E3A482D162885E129CEB5EEED412EB4BA12174CAA144
Installed0479 remains38E0F431770D41D39540C99FF243D74ADB37201A94178FE4BDDB7FE6064AC74D.
Historical0479 DLL had been moved out of workspace; restored from hash-verified
installed reference. Rollback0479.zip contains SignalisVrTracking.dll.
No automatic install/game launch. User manual copy and one-step tests only.
Next: close game/copy; then launch, enter stereo, reproduce EVA/airlock cutscene;
observe continued video vs Waiting, central rectangle, and next-area return.
