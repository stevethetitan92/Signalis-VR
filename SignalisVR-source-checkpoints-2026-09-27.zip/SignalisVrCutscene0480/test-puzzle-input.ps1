$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'QuestPuzzleInput.cs') -Raw
$body=$source.Substring($source.IndexOf('  private struct QuestPuzzleState'))
$harness=@"
using System;
using UnityEngine;
namespace UnityEngine { public struct Vector2 { public float x,y; public Vector2(float x,float y){this.x=x;this.y=y;} } }
public class CharacterAction { public enum inputDevice {Keyboard,Controller} public Vector2 Move; public inputDevice lastActiveController; }
public static class PlayerState { public static CharacterAction input; }
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static Tracking questOwner;
  private bool questNativeAvailable=true,owns=true;
  private int questNativeThread=System.Threading.Thread.CurrentThread.ManagedThreadId;
  private Frame questFrame;
  private struct Frame {public float uiX,uiY;}
  private bool QuestOwnsInputMode(){return owns;}
  private static void Check(bool b,string why){if(!b)throw new Exception(why);}
  public static void RunPuzzleChecks(){
   var q=new Tracking();questOwner=q;
   foreach(var v in new[]{new Vector2(-1,0),new Vector2(1,0),new Vector2(0,-1),new Vector2(0,1),new Vector2(0,0)}) {
    PlayerState.input=new CharacterAction();q.questFrame=new Frame{uiX=v.x,uiY=v.y};
    QuestPuzzleState s;QuestPuzzlePrefix(out s);
    Check(PlayerState.input.Move.x==v.x&&PlayerState.input.Move.y==v.y,"direction");
    Check(PlayerState.input.lastActiveController==CharacterAction.inputDevice.Controller,"native controller branch");
    var error=new Exception("original");Check(object.ReferenceEquals(error,QuestPuzzleFinalizer(error,s)),"exception preserved");
    Check(PlayerState.input.Move.x==0&&PlayerState.input.Move.y==0&&PlayerState.input.lastActiveController==CharacterAction.inputDevice.Keyboard,"restore");
   }
   PlayerState.input.Move=new Vector2(-1,.8f);q.questFrame=new Frame{uiX=.5f,uiY=.4f};
   QuestPuzzleState outer;QuestPuzzlePrefix(out outer);
   Check(PlayerState.input.Move.x==-1&&PlayerState.input.Move.y==.8f,"stronger physical input");
   QuestPuzzleState inner;QuestPuzzlePrefix(out inner);QuestPuzzleFinalizer(null,inner);
   Check(PlayerState.input.lastActiveController==CharacterAction.inputDevice.Controller,"nested restore");
   QuestPuzzleFinalizer(null,outer);
   Check(PlayerState.input.lastActiveController==CharacterAction.inputDevice.Keyboard,"outer restore");
   for(int i=0;i<3;i++){
    q.owns=i!=0;q.questNativeAvailable=i!=1;q.questNativeThread=i==2?-1:System.Threading.Thread.CurrentThread.ManagedThreadId;
    QuestPuzzleState s;QuestPuzzlePrefix(out s);Check(s.input==null,"unavailable/focus/thread guard");QuestPuzzleFinalizer(null,s);
   }
   q.owns=true;q.questNativeAvailable=true;q.questNativeThread=System.Threading.Thread.CurrentThread.ManagedThreadId;
   PlayerState.input=null;QuestPuzzleState none;QuestPuzzlePrefix(out none);QuestPuzzleFinalizer(null,none);
  }
"@
Add-Type -TypeDefinition ($harness+$body)
[SignalisVrTracking.Tracking]::RunPuzzleChecks()
'PASS actual scoped prefix/finalizer: four directions, neutral, physical precedence, nested restoration, original exception, focus/availability/thread/null guards. Harness does not exercise native detour or headset.'
