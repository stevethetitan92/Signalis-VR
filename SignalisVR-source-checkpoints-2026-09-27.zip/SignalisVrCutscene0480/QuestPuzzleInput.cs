using System;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private void InstallQuestPuzzleInput(IntPtr gameBase) {
   if(QuestNativeAddress(typeof(global::EventScreen3DCam),"NativeMethodInfoPtr_Update_Private_Void_0").ToInt64()-gameBase.ToInt64()!=0xB29D50 ||
      QuestNativeAddress(typeof(global::ROT_Cursor),"NativeMethodInfoPtr_Update_Private_Void_0").ToInt64()-gameBase.ToInt64()!=0x4B74A0)
    throw new InvalidOperationException("Puzzle cursor layout differs from inspected build");
   foreach(var type in new[]{typeof(global::EventScreen3DCam),typeof(global::ROT_Cursor)})
    questHarmony.Patch(AccessTools.Method(type,"Update"),prefix:new HarmonyMethod(typeof(Tracking),nameof(QuestPuzzlePrefix)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(QuestPuzzleFinalizer)));
  }
  // Scoped to native puzzle consumers: never change the global CharacterAction
  // update or shared getters. Keep native cursor movement, selection and clicks.
  private struct QuestPuzzleState {
   public global::CharacterAction input;
   public Vector2 move;
   public global::CharacterAction.inputDevice device;
  }
  private static void QuestPuzzlePrefix(out QuestPuzzleState __state) {
   __state=default(QuestPuzzleState);
   var q=questOwner;
   if(q==null || !q.questNativeAvailable || System.Threading.Thread.CurrentThread.ManagedThreadId!=q.questNativeThread || !q.QuestOwnsInputMode())return;
   var input=global::PlayerState.input;
   if(input==null)return;
   __state.input=input;__state.move=input.Move;__state.device=input.lastActiveController;
   // Use the left UI axes even when FP locomotion suppresses MoveHorizontal.
   // Stronger physical input still wins; Quest movement is never added twice.
   var move=input.Move;
   if(Math.Abs(q.questFrame.uiX)>Math.Abs(move.x))move.x=q.questFrame.uiX;
   if(Math.Abs(q.questFrame.uiY)>Math.Abs(move.y))move.y=q.questFrame.uiY;
   input.Move=move;
   input.lastActiveController=global::CharacterAction.inputDevice.Controller;
  }
  private static Exception QuestPuzzleFinalizer(Exception __exception,QuestPuzzleState __state) {
   // Restore even if the original throws; do not suppress its exception.
   if(__state.input!=null) {
    __state.input.Move=__state.move;
    __state.input.lastActiveController=__state.device;
   }
   return __exception;
  }
 }
}
