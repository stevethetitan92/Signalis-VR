# 0.4.76 stick comfort candidate

Prepared offline at user's request. NOT installed, launched, or headset tested.
0.4.75 remains the user-verified available-input baseline. Public licensing work
remains shelved; repository visibility unchanged. Head tracking untouched.

## Changes
- Left movement uses a circular 0.2 dead zone: direction preserved and input
  magnitude capped at1. The old independent-axis map distorted diagonals (a full
  circular diagonal produced about0.896 total input instead of1).
- UIHorizontal/UIVertical keep the original independent-axis thresholds via
  separate uiX/uiY values. Menus and book navigation need regression checking.
- Smooth turn uses 0.5*s + 0.5*s^3 after the existing stick dead zone. Full-stick
  speed remains90 degrees/sec; half of the mapped range turns28.125 rather than45
  degrees/sec. Turning is still continuous, not snap; vertical stick look stays0.
- No time-based smoothing, accumulated input or new delay on release. This is an
  input guarantee, not a claim that native physics instantly stops the character.
- Diagonal held-stick reconnect cannot arm inside the old square neutral region
  but outside the new circular dead zone. Invalid turn inputs return zero.

Changed production files: QuestInputPolicy.cs; SignalisVrTracking.cs version only.
Native hooks, render code, force compensation and camera/head tracking unchanged.
Test native-routing fixtures now specify independent UI axes.

## Checks and limits
Build succeeds with existing reference warnings. Eleven suites pass including
10863 geometric/frame-rate/invalid/release assertions plus two diagonal neutral
checks; native routing/ABI, button lifecycle, menu scene, shared-getter regression,
FP adapter layout, force scaling, overlay restoration and recovery checks.
The first geometric test run failed because PowerShell selected an integer Min
reference overload; the oracle now uses doubles and the final sweep passes.

Automated tests do not establish headset comfort, actual walking speed or graphics
stability. Forward/back and strafe still use different native/FP movement paths;
this build aligns input geometry but does not establish equal physical speeds.
No game process launched and no installed files changed. Source0475 DLL restored
locally from verified installed baseline because user had moved the delivered DLL.

DLL SHA256 FB97B8A78F4F88C876A4E06478EEA985230855B918D1067370D4244FD5FB32F7
ZIP SHA256 EDE367971BB16D4F4C0D509F71E34A53F8ED9D0179300082B0017BA8DEADBF2A
Rollback0475.zip SHA256 BC11ACA89E89F1B304342139CFD3A20763046BE95030BB7436D88DF112570EF2
Baseline DLL SHA256 2537A162E69B90C67BBEBC6AEFB9C0F9871897155857D04FDB5E6728586AEDD9

## Next-session manual test (deliver one step at a time)
1. Close game and copy candidate DLL to Mods. Rollback0475.zip is available.
2. Launch manually: A at title, main-menu navigation/Continue.
3. Enter room and stereo with F6/F9/F10.
4. Compare small versus full left-stick movement and cardinal/diagonal transitions.
5. Release stick: report drift/coasting, then check sprint toggle.
6. Compare small right-stick turns and full turn; release; verify no vertical look.
7. Inventory/pause/book navigation and dashboard-close neutral rearming.
Stop and restore0475 if movement/buttons regress. Do not tune head tracking yet.
