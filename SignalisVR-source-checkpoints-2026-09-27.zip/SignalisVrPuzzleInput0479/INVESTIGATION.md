# 0.4.79 inputs-only candidate

Supersedes undelivered0478 after user requested inputs before cutscene changes.
Based on0476 tracking/rendering; adds0478 scoped puzzle input fix, with0477 scene
transition changes excluded. Changes relative0476: QuestPuzzleInput.cs (new),
QuestFirstPerson.cs (hook installation), build.ps1 (new source), tracking version.
New test-puzzle-input harness; native evidence and read-only installed log saved.

Reported failures: six-keypad all directions; screenshots show terminal, keypad
and airlock interaction views. Screenshot keypad has nine visible buttons; do not
infer exact puzzle identity just from prior six-keypad description. Both native
EventScreen3DCam and ROT_Cursor consumers are covered, but runtime validation is
pending. Left UI axes temporarily supplied via PlayerState.input.Move, using
stronger-axis precedence; lastActiveController temporarily Controller. Finalizer
restores fields and preserves original exception. Native selection/click/rendering
remain original. Unique-address checks for both hook targets at startup.

F1 reported ineffective; whether it fails outside interactions is unknown (user
answered "i dont know"). Inspected CameraPerspectiveSolid.OnUpdate: F1 uses native
Unity GetKeyDown and relocates Main Camera, gated by prerequisites and scene. It
does not replace EventScreen3DCam interaction rendering. No F1 or camera change
made without reproduction. Current log also has foreground focus losses; cannot
attribute F1 failure or each screenshot to those without a synchronized test.

Build +7 suites pass: puzzle harness, firstperson, native reads, shared getter,
actions, menu scene, recovery. No game/native detour/headset execution performed.
Compilation and harness do not establish graphics stability or complete inputs.
Aim/fire/reload remain unverified until weapon available. All reported screens
need left-stick directions, A activation and B exit checked individually, followed
by ordinary room movement and F1 with game focused. Cutscene work remains deferred.

DLL SHA256:38E0F431770D41D39540C99FF243D74ADB37201A94178FE4BDDB7FE6064AC74D
Installed remains0476 hashFB97B8A78F4F88C876A4E06478EEA985230855B918D1067370D4244FD5FB32F7.
No assistant launch or install. Rollback0476.zip retained. User manual copy only.
First instruction: close game before copying candidate DLL. Test one step at a time.
