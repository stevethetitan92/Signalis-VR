$ErrorActionPreference = 'Stop'
Add-Type -Path @((Join-Path $PSScriptRoot 'MarkerSuppression.cs'), (Join-Path $PSScriptRoot 'MarkerSuppressionTests.cs'))
[SignalisVrTracking.MarkerSuppressionTests]::Run()
