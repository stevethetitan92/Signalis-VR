using System;
using System.Collections.Generic;
using UnityEngine;

namespace SignalisVrTracking
{
    // Camera-wide rendering veto: never change an interaction component, collider,
    // active state, Renderer.enabled, sprite, transform, or shared material.
    internal static class MarkerSuppression
    {
        private static readonly List<Renderer> targets = new List<Renderer>();
        private static readonly HashSet<int> targetIds = new HashSet<int>();
        private static int scannedFrame = -1;
        private static float nextWarning;
        private static Camera.CameraCallback preCull;

        internal static void Install()
        {
            if (preCull != null) return;
            preCull = (Action<Camera>)BeforeCamera;
            Camera.onPreCull += preCull;
        }

        internal static void Reset()
        {
            scannedFrame = -1;
            targets.Clear();
            targetIds.Clear();
        }

        private static void BeforeCamera(Camera unused) { Apply(); }

        internal static void Apply()
        {
            try
            {
                // Include inactive controllers, new scenes and newly spawned popups.
                // Scan once per frame, then enforce again for EVERY camera/eye.
                // No VR stage, proximity, sprite-name, layer or enabled-state gate.
                if (scannedFrame != Time.frameCount)
                {
                    targets.Clear();
                    targetIds.Clear();
                    var doors = Resources.FindObjectsOfTypeAll<global::DoorInteractionPopup>();
                    for (int i = 0; i < doors.Length; i++)
                    {
                        var door = doors[i];
                        if (door == null) continue;
                        Add(door.block);
                        Add(door.bar);
                        // This is the popup hierarchy, NOT door.door or door geometry.
                        AddArtwork(door.transform);
                    }
                    var ladders = Resources.FindObjectsOfTypeAll<global::Ladder>();
                    for (int i = 0; i < ladders.Length; i++)
                    {
                        var ladder = ladders[i];
                        if (ladder == null) continue;
                        // Game-owned icon/label references also cover renamed roots.
                        Add(ladder.block);
                        Add(ladder.bar);
                        var children = ladder.GetComponentsInChildren<Transform>(true);
                        for (int j = 0; j < children.Length; j++)
                            if (children[j] != null && children[j].name == "Ladder Icon")
                                AddArtwork(children[j]);
                    }
                    scannedFrame = Time.frameCount;
                }
                for (int i = 0; i < targets.Count; i++)
                    if (targets[i] != null) targets[i].forceRenderingOff = true;
            }
            catch (Exception ex)
            {
                if (Time.realtimeSinceStartup >= nextWarning)
                {
                    nextWarning = Time.realtimeSinceStartup + 10f;
                    MelonLoader.MelonLogger.Warning("Door/ladder artwork suppression failed: " + ex.Message);
                }
            }
        }

        private static void AddArtwork(Transform root)
        {
            var artwork = root.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < artwork.Length; i++) Add(artwork[i]);
        }

        private static void Add(Renderer renderer)
        {
            if (renderer != null && targetIds.Add(renderer.GetInstanceID())) targets.Add(renderer);
        }
    }
}
