$ErrorActionPreference = 'Stop'
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a = [Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
$t = $a.MainModule.Types | Where-Object FullName -eq 'SignalisVrTracking.Tracking'
$m = $t.Methods | Where-Object Name -eq 'RenderDialogueOverlay'
$handler = $m.Body.ExceptionHandlers | Where-Object HandlerType -eq 'Finally'
if (-not $handler) { throw 'Dialogue overlay lacks finally restoration' }
$calls = @()
for ($i = $handler.HandlerStart; $i -and $i -ne $handler.HandlerEnd; $i = $i.Next) {
if ($i.Operand -is [Mono.Cecil.MethodReference]) { $calls += $i.Operand.Name }
}
foreach ($name in 'set_cullingMask','set_clearFlags','set_layer','set_renderMode','set_worldCamera','set_overrideSorting','set_sortingOrder','set_anchorMin','set_anchorMax','set_pivot','set_sizeDelta','set_anchoredPosition3D','set_localPosition','set_localRotation','set_localScale','set_active') {
if ($calls -notcontains $name) { throw "Missing overlay restoration: $name" }
}
$render = $t.Methods | Where-Object Name -eq 'RenderStereo'
$renderCalls = @($render.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] } | ForEach-Object { $_.Operand.Name })
if ($renderCalls -notcontains 'RenderDialogueOverlay') { throw 'Stereo path lacks dialogue overlay' }
$source = Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
if ($source -notmatch 'recovery.Observe\(camera.enabled && !pauseMenuVisible && !bookScreenVisible,') { throw 'Recovery routing unexpectedly changed' }
'PASS: compiled overlay finally restores all 16 mutated settings; stereo calls overlay; dialogue no longer requests whole-screen capture. Headset rendering remains unverified.'
} finally { $a.Dispose() }
