$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'DiagnosticFlow.cs')
function Check($v,$message) { if (-not $v) { throw $message } }
$r = [SignalisVrTracking.CameraRecovery]::new()
Check ($r.Observe($true,0) -eq 0) 'Healthy camera paused'
Check ($r.Observe($false,1) -eq 1 -and $r.Paused) 'Disable did not pause'
Check ($r.Observe($false,4) -eq 1) 'Short interruption timed out'
Check ($r.Observe($true,5) -eq 1) 'Enabled camera skipped stabilization'
Check ($r.Observe($true,5.24) -eq 1) 'Stabilization ended early'
Check ($r.Observe($true,5.25) -eq 2 -and $r.Paused) 'Ready must remain paused until native drain'
Check ($r.Observe($false,5.3) -eq 1) 'Flapping not paused'
Check ($r.Observe($true,6) -eq 1) 'Flapping retained stale stable timestamp'
Check ($r.Observe($true,6.25) -eq 2) 'Second stabilization failed'
# Simulate native callback busy: readiness alone must not clear Paused.
Check ($r.Observe($true,120.99) -eq 2 -and $r.Paused) 'Busy native work resumed prematurely'
Check ($r.Observe($true,121) -eq 2 -and $r.Paused) 'Native drain must remain gated'
$r.Reset()
Check (-not $r.Paused -and $r.Observe($true,12) -eq 0) 'Stop did not reset recovery'
Check ($r.Observe($false,20) -eq 1) 'Second loss failed'
Check ($r.Observe($true,21) -eq 1) 'Second stabilization missing'
Check ($r.Observe($true,21.25) -eq 2) 'Second ready failed'
$r.Reset() # Represents successful nonblocking native drain.
Check ($r.Observe($true,21.3) -eq 0) 'Successful recovery cannot resume'
$f = [SignalisVrTracking.DiagnosticFlow]::new()
$f.Connected(); $f.RenderReady(); [void]$f.BeginSubmit(0)
[void]$r.Observe($false,899)
Check (-not $f.Expired(900) -and $f.CanSubmit) 'Recovery stopped session at old cutoff'
'PASS: 17 camera recovery and continuous submission checks'

$r.Reset()
Check ($r.Observe($false,0) -eq 1) 'Inventory did not pause'
Check ($r.Observe($false,60) -eq 1) 'One-minute inventory prematurely stopped'
Check ($r.Observe($true,61) -eq 1) 'Inventory return skipped stabilization'
Check ($r.Observe($true,61.25) -eq 2) 'Inventory return cannot recover'
$r.Reset()
[void]$r.Observe($false,0)
Check ($r.Observe($false,119.99) -eq 1) 'Timeout ended early'
Check ($r.Observe($false,120) -eq 1) 'Inventory stopped at old cutoff'
'PASS: long inventory suspension and former timeout boundaries'
Check ($r.Observe($false,3600) -eq 1) 'Long inventory stopped'
Check ($r.Observe($true,3601) -eq 1) 'Long inventory skipped stabilization'
Check ($r.Observe($true,3601.25) -eq 2 -and $r.Paused) 'Long inventory cannot recover through drain'
$r.Reset()
Check ($r.Observe($true,3602) -eq 0) 'Return did not restore gameplay'
