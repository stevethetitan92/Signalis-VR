$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
$checks=0
function Check($v,$why){if(!$v){throw $why};$script:checks++}
# Sweep directions/radii: direction preservation, magnitude bound and equal
# response at every heading, including diagonals and out-of-range samples.
foreach($radius in 0,.1,.19,.2,.201,.3,.5,.8,1,1.4){
 foreach($degrees in 0..359){
  $a=$degrees*[Math]::PI/180;$x=[float]($radius*[Math]::Cos($a));$y=[float]($radius*[Math]::Sin($a))
  [float]$mx=0;[float]$my=0
  [SignalisVrTracking.QuestInputPolicy]::Movement($x,$y,[ref]$mx,[ref]$my)
  $length=[Math]::Sqrt($mx*$mx+$my*$my)
  $expected=[Math]::Max(0.0,([Math]::Min(1.0,[double]$radius)-.2)/.8)
  Check ([Math]::Abs($length-$expected) -lt .00001) 'Directional magnitude distortion'
  Check ([Math]::Abs($mx*$y-$my*$x) -lt .00001) 'Direction changed'
  Check ($length -le 1.000001) 'Diagonal exceeded full input'
 }
}
foreach($bad in [float]::NaN,[float]::PositiveInfinity,[float]::NegativeInfinity){
 [float]$mx=0;[float]$my=0
 [SignalisVrTracking.QuestInputPolicy]::Movement($bad,1,[ref]$mx,[ref]$my)
 Check ($mx -eq 0 -and $my -eq 0) 'Invalid movement'
 Check ([SignalisVrTracking.QuestInputPolicy]::LookAxis($bad,.02,1) -eq 0) 'Invalid turn stick'
 Check ([SignalisVrTracking.QuestInputPolicy]::LookAxis(1,$bad,1) -eq 0) 'Invalid turn clock'
}
foreach($stick in -.75,-.5,-.1,0,.1,.5,.75,1){
 $expected=90*(.5*$stick+.5*$stick*$stick*$stick)
 foreach($fps in 30,60,72,90,120,144){
  $angle=[SignalisVrTracking.QuestInputPolicy]::LookAxis($stick,(1.0/$fps),2)*2*$fps
  Check ([Math]::Abs($angle-$expected) -lt .0001) 'Turn response depends on frame rate'
 }
}
$p=[SignalisVrTracking.QuestHandInputPolicy]::new()
$l=[SignalisVrTracking.QuestSample]::new();$r=[SignalisVrTracking.QuestSample]::new()
$null=$p.Update($true,$l,$r)
$l.x=.18;$l.y=.8;$r.x=.5;$r.y=1
$f=$p.Update($true,$l,$r)
Check ($f.moveX -gt 0 -and $f.uiX -eq 0) 'Gameplay radial/menu axial separation lost'
Check ([Math]::Abs($f.uiY-.75) -lt .00001) 'Menu threshold changed'
Check ($f.lookY -eq 0) 'Vertical look restored'
$l.x=$l.y=$r.x=$r.y=0
$f=$p.Update($true,$l,$r)
Check ($f.moveX -eq 0 -and $f.moveY -eq 0 -and $f.lookX -eq 0) 'Release retains motion'
$l.y=1;$r.x=1;$f=$p.Update($true,$l,$r)
$f=$p.UpdateHands($true,$false,$true,$l,$r)
Check ($f.moveY -eq 0 -and $f.uiY -eq 0 -and $f.lookX -eq 1) 'Independent disconnect failed'
$f=$p.Update($false,$l,$r)
Check ($f.moveY -eq 0 -and $f.lookX -eq 0 -and $f.buttons -eq 0) 'Focus loss retains input'
"PASS: $checks geometry, frame-rate, invalid-input, UI separation and release checks. Physics and headset comfort unverified."

$p2=[SignalisVrTracking.QuestInputPolicy]::new()
$l.x=.19;$l.y=.19;$r.x=$r.y=0
$f=$p2.Update($true,$l,$r)
Check (-not $p2.Armed -and $f.moveX -eq 0) 'Diagonal held stick falsely neutral on reconnect'
$l.x=$l.y=0;$null=$p2.Update($true,$l,$r)
Check $p2.Armed 'Centered reconnect blocked'
'PASS: diagonal reconnect neutral guard.'
