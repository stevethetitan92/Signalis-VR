$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
function Check($v,$m){if(-not $v){throw $m}}
$e=[SignalisVrTracking.QuestButtonEdges]::new()
$e.Sample(1,1);Check ($e.Down -eq 1 -and $e.Up -eq 0) 'A down missing'
$e.Sample(1,1);Check ($e.Down -eq 1) 'Multiple input loops erased down'
$e.Sample(1,2);Check ($e.Down -eq 0) 'Held A repeats down'
$e.Sample(0,3);Check ($e.Up -eq 1) 'A up missing'
$e.Sample(0,4);Check ($e.Up -eq 0) 'Up repeats'
$e.Sample(12,5);Check ($e.Down -eq 12) 'X/Y combination'
$e.Reset();Check ($e.Down -eq 0 -and $e.Up -eq 0) 'Stop leaves edges'
foreach($pair in @(@('Use',0),@('Confirm',0),@('Inventory',2),@('Pause',3),@('Aim Mode',5),@('Attack',6),@('Reload',7),@('unknown',-1))) {
 Check ([SignalisVrTracking.QuestButtonEdges]::ActionBit($pair[0]) -eq $pair[1]) ('Action mapping '+$pair[0])
}
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
 $t=$a.MainModule.Types | Where-Object Name -eq 'Tracking'
 $m=$t.Methods | Where-Object Name -eq 'EnsureQuestControllers'
 Check (@($t.Methods | Where-Object Name -in 'InstallQuestActionBridge','QuestAxisResult','QuestButtonResult').Count -eq 0) 'Diagnostic-masking Player getter overrides must be absent'
 Check (@($t.Methods | Where-Object Name -eq 'CommitQuestMap').Count -eq 0) 'Custom registration must be absent'
 $m=$t.Methods | Where-Object Name -eq 'OnLateUpdate'
 Check (@($m.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.FieldReference] -and $_.Operand.Name -eq 'questStereoPitch'}).Count -gt 0) 'Stereo ignores stick pitch'
}finally{$a.Dispose()}
'PASS: 15 button-layout/helper cases and 3 compiled checks; Managed getter patches are absent; native bridge tested separately and stereo pitch remains integrated. Gameplay unverified.'


