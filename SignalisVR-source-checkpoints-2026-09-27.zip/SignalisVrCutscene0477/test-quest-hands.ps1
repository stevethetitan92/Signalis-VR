$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
function Check($v,$s){if(-not $v){throw $s}}
$p=[SignalisVrTracking.QuestHandInputPolicy]::new()
$l=[SignalisVrTracking.QuestSample]::new();$r=[SignalisVrTracking.QuestSample]::new()
$null=$p.UpdateHands($true,$true,$false,$l,$r)
Check ($p.LeftArmed -and -not $p.RightArmed) 'Missing right blocks left'
$l.buttons=128;$l.x=1
$f=$p.UpdateHands($true,$true,$false,$l,$r)
Check ($f.buttons -eq 4 -and $f.moveX -eq 1) 'Left input unavailable with right missing'
$r.trigger=1
$f=$p.UpdateHands($true,$true,$true,$l,$r)
Check ($f.buttons -eq 4 -and -not $p.RightArmed) 'Held trigger fires during reconnect'
$r.trigger=0;$null=$p.UpdateHands($true,$true,$true,$l,$r)
Check $p.RightArmed 'Right neutral does not arm while left held'
$r.trigger=1;$f=$p.UpdateHands($true,$true,$true,$l,$r)
Check ($f.buttons -eq 68) 'Combined hand inputs lost'
$f=$p.UpdateHands($true,$false,$true,$l,$r)
Check ($f.buttons -eq 64 -and $f.moveX -eq 0 -and $p.RightArmed) 'Left disconnect blocks right or leaves motion'
$f=$p.UpdateHands($false,$true,$true,$l,$r)
Check (-not $p.Armed -and $f.buttons -eq 0) 'Focus/dashboard loss leaves input'
$null=$p.UpdateHands($true,$true,$true,$l,$r)
Check (-not $p.Armed) 'Held inputs rearm after focus loss'
$l.buttons=0;$l.x=0;$r.trigger=0;$null=$p.UpdateHands($true,$true,$true,$l,$r)
Check ($p.LeftArmed -and $p.RightArmed) 'Both fail neutral rearm'
'PASS: 9 independent-hand startup/disconnect/reconnect cases.'
