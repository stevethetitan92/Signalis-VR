using System;
namespace SignalisVrTracking
{
    internal static class HighlightPolicy
    {
        internal static bool IsBracket(string spriteName)
        { return spriteName == "interaction" || spriteName == "interactionScaleable"; }

        internal static bool Visible(bool active, bool enabled, bool consumed,
            bool reading, bool sameRoom, bool travel, float xyDistanceSquared, float heightDifference)
        {
            return active && enabled && !consumed && !reading && sameRoom && !travel
                && xyDistanceSquared <= 900f && Math.Abs(heightDifference) < 12f;
        }
    }
}
