using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using System.Threading;
using MelonLoader;
using Rewired;
using UnityEngine;

namespace SignalisVrTracking {
 public sealed partial class Tracking {
  // IL2CPP wrappers are not the game's native call sites. Detour the actual
  // entry points, retaining native originals and leaving game action processing intact.
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
  private delegate float QuestAxisNative(IntPtr self,int action,IntPtr method);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
  [return: MarshalAs(UnmanagedType.I1)]
  private delegate bool QuestButtonNative(IntPtr self,int action,IntPtr method);

  private sealed class QuestHook {
   public IntPtr slot,detour;
   public Delegate root;
  }
  // Hooks and their delegates remain rooted for process lifetime, including F12.
  // Stopping VR releases input; it does not invalidate callable trampolines.
  private static readonly List<QuestHook> questNativeHooks=new List<QuestHook>();
  private QuestAxisNative questAxisOriginal;
  private QuestButtonNative questHeldOriginal,questDownOriginal,questUpOriginal;

  private readonly HashSet<IntPtr> questNativePlayers=new HashSet<IntPtr>();
  private readonly Dictionary<int,string> questNativeActions=new Dictionary<int,string>();
  private readonly QuestButtonEdges questNativeEdges=new QuestButtonEdges();
  private int questNativeThread;
  private bool questNativeInstalled,questNativeAvailable,questNativeFp;
  private long questNativeAxisReads,questNativeButtonReads;
  private float questNativeForward;


  private static IntPtr QuestNativeAddress(Type type,string fieldName) {
   RuntimeHelpers.RunClassConstructor(type.TypeHandle);
   var field=type.GetField(fieldName,BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public);
   if(field==null)throw new InvalidOperationException("Missing native metadata: "+fieldName);
   var info=(IntPtr)field.GetValue(null);
   if(info==IntPtr.Zero)throw new InvalidOperationException("Empty native metadata: "+fieldName);
   var address=Marshal.ReadIntPtr(info);
   if(address==IntPtr.Zero)throw new InvalidOperationException("Empty native method: "+fieldName);
   return address;
  }
  private static T AttachQuestNative<T>(IntPtr address,Delegate callback) where T:class {
   var hook=new QuestHook{slot=Marshal.AllocHGlobal(IntPtr.Size),root=callback,detour=Marshal.GetFunctionPointerForDelegate(callback)};
   Marshal.WriteIntPtr(hook.slot,address);
   questNativeHooks.Add(hook); // Root before attaching; even a failed install stays safe.
   MelonUtils.NativeHookAttach(hook.slot,hook.detour);
   var trampoline=Marshal.ReadIntPtr(hook.slot);
   if(trampoline==IntPtr.Zero||trampoline==address)throw new InvalidOperationException("Native hook did not create a trampoline");
   return Marshal.GetDelegateForFunctionPointer(trampoline,typeof(T)) as T;
  }
  private void InstallQuestNativeReads() {
   questNativeThread=Thread.CurrentThread.ManagedThreadId;
   foreach(string name in new[]{"Move Horizontal","Move Vertical","Aim Horizontal","Aim Vertical","UIHorizontal","UIVertical","Use","Confirm","Cancel","Inventory","Pause","Sprint","Aim Mode","Attack","Reload","TabLeft","TabRight"})
    {int id=ReInput.mapping.GetActionId(name);if(id<0)throw new InvalidOperationException("Missing input action: "+name);questNativeActions.Add(id,name);}
   var players=ReInput.players.AllPlayers;
   int count=players.Cast<Il2CppSystem.Collections.Generic.ICollection<Player>>().Count;
   for(int i=0;i<count;i++)questNativePlayers.Add(players[i].Pointer);
   var axis=QuestNativeAddress(typeof(Player),"NativeMethodInfoPtr_GetAxis_Public_Single_Int32_0");
   var held=QuestNativeAddress(typeof(Player),"NativeMethodInfoPtr_GetButton_Public_Boolean_Int32_0");
   var down=QuestNativeAddress(typeof(Player),"NativeMethodInfoPtr_GetButtonDown_Public_Boolean_Int32_0");
   var up=QuestNativeAddress(typeof(Player),"NativeMethodInfoPtr_GetButtonUp_Public_Boolean_Int32_0");
   // Verify all metadata targets before any mutation. This candidate is for the
   // inspected game build only. Addresses are resolved from metadata, never guessed.
   IntPtr baseAddress=IntPtr.Zero;
   foreach(System.Diagnostics.ProcessModule module in System.Diagnostics.Process.GetCurrentProcess().Modules)
    if(string.Equals(module.ModuleName,"GameAssembly.dll",StringComparison.OrdinalIgnoreCase))baseAddress=module.BaseAddress;
   var addresses=new[]{axis,held,down,up};
   var offsets=new long[]{0x1202670,0x12058D0,0x12034F0,0x1205710};
   if(baseAddress==IntPtr.Zero)throw new InvalidOperationException("GameAssembly module missing");
   for(int i=0;i<addresses.Length;i++)if(addresses[i].ToInt64()-baseAddress.ToInt64()!=offsets[i])throw new InvalidOperationException("Native input layout differs from inspected build");
   questAxisOriginal=AttachQuestNative<QuestAxisNative>(axis,new QuestAxisNative(QuestNativeAxis));
   questHeldOriginal=AttachQuestNative<QuestButtonNative>(held,new QuestButtonNative(QuestNativeHeld));
   questDownOriginal=AttachQuestNative<QuestButtonNative>(down,new QuestButtonNative(QuestNativeDown));
   questUpOriginal=AttachQuestNative<QuestButtonNative>(up,new QuestButtonNative(QuestNativeUp));
   questNativeInstalled=true;
   MelonLogger.Msg("QUEST NATIVE BRIDGE: four native input reads attached; no CharacterAction.Update detour. No managed getter patches.");
  }
  private void SnapshotQuestNative() {
   questNativeAvailable=questNativeInstalled&&QuestAvailableNow();
   questNativeFp=questNativeAvailable&&QuestFirstPersonReady();
   if(!questNativeAvailable){questNativeEdges.Reset();return;}
   questNativeEdges.Sample(questFrame.buttons,Time.frameCount);
  }
  private bool QuestNativeCanRead(IntPtr self) {
   return questNativeAvailable&&!questFailed&&!questInputStopped&&!stopping&&Thread.CurrentThread.ManagedThreadId==questNativeThread&&questNativePlayers.Contains(self);
  }
  private float QuestNativeAxis(IntPtr self,int action,IntPtr method) {
   float native=questAxisOriginal(self,action,method);
   try {
    string name;
    if(!QuestNativeCanRead(self)||!questNativeActions.TryGetValue(action,out name))return native;
    float result=QuestNativeRouting.Axis(name,native,questFrame,questNativeFp);
    questNativeAxisReads++;if(name=="Move Vertical")questNativeForward=result;
    return result;
   }catch{return native;}
  }
  private bool QuestNativeButton(IntPtr self,int action,bool native,int mode) {
   try {
    string name;
    if(!QuestNativeCanRead(self)||!questNativeActions.TryGetValue(action,out name))return native;
    int bit=QuestButtonEdges.ActionBit(name);
    int mask=mode==0?questFrame.buttons:mode==1?questNativeEdges.Down:questNativeEdges.Up;
    bool result=native||(bit>=0&&(mask&(1<<bit))!=0);
    questNativeButtonReads++;
    return result;
   }catch{return native;}
  }
  private bool QuestNativeHeld(IntPtr self,int action,IntPtr method){return QuestNativeButton(self,action,questHeldOriginal(self,action,method),0);}
  private bool QuestNativeDown(IntPtr self,int action,IntPtr method){return QuestNativeButton(self,action,questDownOriginal(self,action,method),1);}
  private bool QuestNativeUp(IntPtr self,int action,IntPtr method){return QuestNativeButton(self,action,questUpOriginal(self,action,method),2);}
  private string QuestNativeReport() {
   return " nativeAxisReads="+questNativeAxisReads+" nativeButtonReads="+questNativeButtonReads
    +" nativeForward="+questNativeForward.ToString("F2");
  }
 }
}


