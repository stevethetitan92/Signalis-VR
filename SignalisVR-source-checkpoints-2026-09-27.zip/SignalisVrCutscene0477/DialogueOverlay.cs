using System;
using UnityEngine;

namespace SignalisVrTracking
{
    public sealed partial class Tracking
    {
        private void RenderDialogueOverlay(Camera eye)
        {
            if (!dialogueScreenVisible) return;
            var ui = global::BlackSleekGuiSubs.instance;
            var go = ui == null ? null : ui.DialogueCanvas;
            var canvas = go == null ? null : go.GetComponent<Canvas>();
            var rect = go == null ? null : go.GetComponent<RectTransform>();
            if (canvas == null || rect == null || !go.activeInHierarchy) return;

            // Borrow the live UI only for this eye render, then restore it before
            // the game updates input or renders the desktop. No cloned controllers.
            var mode = canvas.renderMode;
            var worldCamera = canvas.worldCamera;
            var sorting = canvas.overrideSorting;
            var order = canvas.sortingOrder;
            var anchorMin = rect.anchorMin;
            var anchorMax = rect.anchorMax;
            var pivot = rect.pivot;
            var sizeDelta = rect.sizeDelta;
            var anchored = rect.anchoredPosition3D;
            var localPosition = rect.localPosition;
            var localRotation = rect.localRotation;
            var localScale = rect.localScale;
            var dimensions = rect.rect.size;
            if (dimensions.x <= 0f || dimensions.y <= 0f) return;
            var transforms = go.GetComponentsInChildren<Transform>(true);
            var layers = new int[transforms.Length];
            for (int i = 0; i < transforms.Length; i++) layers[i] = transforms[i].gameObject.layer;
            int mask = eye.cullingMask;
            var clear = eye.clearFlags;
            var target = RenderTexture.active;
            try
            {
                canvas.renderMode = RenderMode.WorldSpace;
                canvas.worldCamera = eye;
                canvas.overrideSorting = true;
                canvas.sortingOrder = 32760;
                rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
                rect.pivot = new Vector2(0.5f, 0.5f);
                rect.sizeDelta = dimensions;
                rect.rotation = stereoRotation;
                rect.position = camera.transform.position + stereoRotation * new Vector3(0f, 0f, 2f * UnitsPerMetre);
                // Match a 2.4 metre wide UI plane, including nonuniform parent scale.
                rect.localScale = Vector3.one;
                var inherited = rect.lossyScale;
                float scale = 2.4f * UnitsPerMetre / dimensions.x;
                rect.localScale = new Vector3(scale / Math.Max(0.0001f, Math.Abs(inherited.x)),
                    scale / Math.Max(0.0001f, Math.Abs(inherited.y)),
                    scale / Math.Max(0.0001f, Math.Abs(inherited.z)));
                for (int i = 0; i < transforms.Length; i++) transforms[i].gameObject.layer = 31;
                Canvas.ForceUpdateCanvases();
                // Composite only dialogue UI over the already-rendered stereo room.
                eye.cullingMask = 1 << 31;
                eye.clearFlags = CameraClearFlags.Depth;
                eye.Render();
            }
            finally
            {
                eye.cullingMask = mask;
                eye.clearFlags = clear;
                for (int i = 0; i < transforms.Length; i++)
                    if (transforms[i] != null) transforms[i].gameObject.layer = layers[i];
                canvas.renderMode = mode;
                canvas.worldCamera = worldCamera;
                canvas.overrideSorting = sorting;
                canvas.sortingOrder = order;
                rect.anchorMin = anchorMin;
                rect.anchorMax = anchorMax;
                rect.pivot = pivot;
                rect.sizeDelta = sizeDelta;
                rect.anchoredPosition3D = anchored;
                rect.localPosition = localPosition;
                rect.localRotation = localRotation;
                rect.localScale = localScale;
                Canvas.ForceUpdateCanvases();
                RenderTexture.active = target;
            }
        }
    }
}
