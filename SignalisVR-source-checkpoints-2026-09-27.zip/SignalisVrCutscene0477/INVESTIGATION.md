# 0.4.77 cutscene screen candidate

User reprioritized first airlock/EVA cutscene because weekly budget is limited.
Symptom: headset shows Waiting. Stick tuning paused; 0476 movement feels same
speed at small/full forward and sideways inputs by user observation.

Changed SignalisVrTracking.cs only, including version. During active submitted
stereo, scene loads now enter the existing persistent game-screen renderer rather
than Stop. Invalid/destroyed gameplay camera uses the same transition path. Clears
scene-specific camera, recovery and input state while retaining render resources.
Menu/startup behavior preserved. F12 and errors still stop. Stick changes from0476
remain; no new input tuning. Capture is game-only, not desktop capture.

Cutscene is shown on a flat screen inside VR. After scene transition, immersive
stereo requires F6/F9/F10 again once a valid first-person camera is available.
This deliberate manual handoff avoids switching into cutscene cameras automatically.
Blocking Unity scene loads may still interrupt rendering; this patch does not
promise to eliminate every compositor Waiting interval. Current saved log was
not a reproduction of cutscene failure; causal finding is from code inspection.

Build and six focused suites pass: menu, recovery, diagnostic, shared-getter,
native reads, dialogue overlay. This does not prove cutscene visuals or stability.
No assistant game launch/install. Installed0476 verified unchanged.0475 remains
user-verified input fallback. New cutscene and next-area behavior require headset
validation. Preserve historical builds and evidence.

DLL SHA256 78BC6F41DE52BEA3F18101A3C05820C03502C40293199CD9B673275C4E7D9553
Installed0476 SHA256 FB97B8A78F4F88C876A4E06478EEA985230855B918D1067370D4244FD5FB32F7
