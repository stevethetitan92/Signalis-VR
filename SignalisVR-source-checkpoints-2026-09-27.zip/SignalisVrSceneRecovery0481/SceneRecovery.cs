using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private bool immersiveRequested,sceneRecoveryRequest,sceneRecoveryInstalled;
  private float sceneStableSince=-1f,nextSceneRecovery,nextSnowReport;
  private int sceneRecoveryAttempts,sceneCandidateId;
  private void InstallSceneRecovery() {
   foreach(var mod in MelonHandler.Mods) {
    if(mod.GetType().FullName!="Camera_Perspective_Mod.PerspectiveChange")continue;
    var update=AccessTools.Method(mod.GetType(),"OnUpdate");
    if(update==null)throw new InvalidOperationException("Perspective update missing");
    questHarmony.Patch(update,transpiler:new HarmonyMethod(typeof(Tracking),nameof(SceneRecoveryTranspiler)));
    sceneRecoveryInstalled=true;break;
   }
  }
  private static IEnumerable<CodeInstruction> SceneRecoveryTranspiler(IEnumerable<CodeInstruction> code) {
   int count=0;
   foreach(var instruction in code) {
    var method=instruction.operand as MethodInfo;
    if(method!=null&&method.DeclaringType==typeof(Input)&&method.Name=="GetKeyDown"&&method.GetParameters().Length==1&&method.GetParameters()[0].ParameterType==typeof(KeyCode)) {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(SceneRecoveryKey));count++;
    }
    yield return instruction;
   }
   if(count==0)throw new InvalidOperationException("Perspective keyboard reads missing");
  }
  private static bool SceneRecoveryKey(KeyCode key) {
   bool physical=Input.GetKeyDown(key);
   var q=questOwner;
   if(key!=KeyCode.F1||q==null||!q.sceneRecoveryRequest)return physical;
   q.sceneRecoveryRequest=false;
   return physical||q.CanRecoverScene();
  }
  private bool CanRecoverScene() {
   if(!immersiveRequested||!questMenuScene||!active||!stereo||stopping||questInputStopped||system==null)return false;
   if(SceneManager.GetActiveScene().name=="PEN_Hole")return false;
   if(global::PlayerState.gameState!=global::PlayerState.gameStates.play||global::PlayerState.cutscene||global::PlayerState.suspendInput)return false;
   var root=GameObject.Find("__Prerequisites__/Character Origin/Character Root");
   if(root==null)return false;
   var player=global::PlayerState.player;
   var control=player!=null?player.GetComponent<global::AlternatePlayerController>():null;
   return control!=null&&control.playing&&!control.traversing;
  }
  private void UpdateSceneRecovery() {
   if(!immersiveRequested||!questMenuScene)return;
   if(SceneManager.GetActiveScene().name=="PEN_Hole"&&Time.realtimeSinceStartup>=nextSnowReport) {
    nextSnowReport=Time.realtimeSinceStartup+10f;
    MelonLogger.Msg("SNOW CAMERA: state="+global::PlayerState.gameState+" cutscene="+global::PlayerState.cutscene);
    foreach(var c in Camera.allCameras) {
     if(c==null||c.name.StartsWith("SignalisVR_"))continue;
     MelonLogger.Msg("SNOW CAMERA: name="+c.name+" parent="+(c.transform.parent==null?"<none>":c.transform.parent.name)+" ortho="+c.orthographic+" target="+(c.targetTexture==null?"screen":c.targetTexture.name));
    }
   }
   if(!CanRecoverScene()){sceneStableSince=-1f;sceneRecoveryRequest=false;sceneCandidateId=0;return;}
   float now=Time.realtimeSinceStartup;
   var candidate=FindGameplayCamera();
   int id=candidate==null?0:candidate.GetInstanceID();
   if(sceneStableSince<0f||id!=sceneCandidateId){sceneStableSince=now;sceneCandidateId=id;return;}
   if(now-sceneStableSince<0.75f)return;
   if(candidate==null) {
    if(sceneRecoveryInstalled&&sceneRecoveryAttempts<3&&now>=nextSceneRecovery) {
     sceneRecoveryAttempts++;nextSceneRecovery=now+3f;sceneRecoveryRequest=true;
     MelonLogger.Msg("SCENE RECOVERY: requesting original first-person camera, attempt="+sceneRecoveryAttempts);
    }
    return;
   }
   // Drain the prior flat-screen pose before reusing the retained eye textures.
   if(bridgeConfigured&&CancelPreparedPose()==0)return;
   camera=candidate;originalRotation=camera.transform.localRotation;
   recovery.Reset();waitingForGameplay=false;menuCaptureReady=false;
   diagnostic.Connected();diagnostic.RenderReady();
   if(!diagnostic.CanSubmit&&!diagnostic.BeginSubmit(now))return;
   questMenuScene=false;sceneRecoveryRequest=false;recenterPending=true;diagnosticFrames=0;
   MelonLogger.Msg("SCENE RECOVERY: stable gameplay camera; first person/stereo resumed. Headset verification required.");
  }
  private readonly List<Renderer> cinematicBars=new List<Renderer>();
  private readonly List<Renderer> hiddenCinematicBars=new List<Renderer>();
  private float nextBarSearch;
  private void PrepareCinematicBars() {
   RestoreCinematicBars();
   if(!immersiveRequested||!questMenuScene||!active||stopping)return;
   // These named graphics are authored cinematic masks, not game/UI containers.
   if(Time.realtimeSinceStartup>=nextBarSearch) {
    nextBarSearch=Time.realtimeSinceStartup+1f;cinematicBars.Clear();
    foreach(var r in Resources.FindObjectsOfTypeAll<Renderer>()) {
     if(r==null||(r.name!="TopBar"&&r.name!="BottomBar"))continue;
     var p=r.transform.parent;
     if(p==null||p.name!="Bars"||p.parent==null||p.parent.name!="Effects Camera")continue;
     cinematicBars.Add(r);
    }
   }
   foreach(var r in cinematicBars)if(r!=null&&r.gameObject.activeInHierarchy&&r.enabled){hiddenCinematicBars.Add(r);r.enabled=false;}
  }
  private void RestoreCinematicBars() {
   foreach(var r in hiddenCinematicBars)if(r!=null)r.enabled=true;
   hiddenCinematicBars.Clear();
  }
 }
}
