param([Parameter(Mandatory=$true)][string]$GamePath)
$ErrorActionPreference = 'Stop'
$managed = Join-Path $GamePath 'MelonLoader\Managed'
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$references = @(
    (Join-Path $managed 'Assembly-CSharp.dll'),
    (Join-Path $managed 'Rewired_Core.dll'),
    (Join-Path $managed 'UnityEngine.PhysicsModule.dll'),
    (Join-Path $managed 'UnityEngine.IMGUIModule.dll'),
    (Join-Path $GamePath 'MelonLoader\0Harmony.dll'),
    (Join-Path $managed 'UnityEngine.UI.dll'),
    (Join-Path $managed 'UnityEngine.UIModule.dll'),
    (Join-Path $GamePath 'MelonLoader\MelonLoader.dll'),
    (Join-Path $managed 'UnityEngine.CoreModule.dll'),
    (Join-Path $managed 'UnityEngine.InputLegacyModule.dll'),
    (Join-Path $managed 'UnityEngine.ScreenCaptureModule.dll'),
    (Join-Path $managed 'UnhollowerBaseLib.dll'),
    (Join-Path $managed 'Il2Cppmscorlib.dll'),
    (Join-Path $framework 'mscorlib.dll'),
    (Join-Path $framework 'System.dll'),
    (Join-Path $framework 'System.Core.dll')
)
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.dll')) | Out-Null
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.CSharp.dll')) | Out-Null
$metadata = [System.Collections.Generic.List[Microsoft.CodeAnalysis.MetadataReference]]::new()
foreach ($reference in $references) {
    $metadata.Add([Microsoft.CodeAnalysis.MetadataReference]::CreateFromFile($reference))
}
$source = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'SignalisVrTracking.cs'))
$tree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($source)
$options = [Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions]::new([Microsoft.CodeAnalysis.OutputKind]::DynamicallyLinkedLibrary)
# NativeLibraries resolves all VR exports from verified absolute runtime paths.
$bindings = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'vendor\openvr_api.cs'))
$bindingTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($bindings)
$mathTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'HeadingMath.cs')))
$puzzleTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'PuzzleScreen.cs')))
$flowTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'DiagnosticFlow.cs')))
$keyTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'HotkeyEdge.cs')))
$nativeTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'NativeLibraries.cs')))
$suppressionTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'MarkerSuppression.cs')))
$highlightTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'HeadsetObjectHighlights.cs')))
$policyTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'HighlightPolicy.cs')))
$bookTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'BookBrackets.cs')))
$dialogueTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'DialogueOverlay.cs')))
$questTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'QuestControllers.cs')))
$questPolicyTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'QuestInputPolicy.cs')))
$fpTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'QuestFirstPerson.cs')))
$nativeReadsTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'QuestNativeReads.cs')))
$menuSceneTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'QuestMenuScene.cs')))
$puzzleInputTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'QuestPuzzleInput.cs')))
$sceneTree = [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'SceneRecovery.cs')))
$compilation = [Microsoft.CodeAnalysis.CSharp.CSharpCompilation]::Create('SignalisVrTracking', [Microsoft.CodeAnalysis.SyntaxTree[]]@($tree, $bindingTree, $mathTree, $puzzleTree, $flowTree, $keyTree, $nativeTree, $suppressionTree, $highlightTree, $policyTree, $bookTree, $dialogueTree, $questTree, $questPolicyTree, $fpTree, $nativeReadsTree, $menuSceneTree, $puzzleInputTree, $sceneTree), $metadata, $options)
$stream = [IO.File]::Create((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try { $result = $compilation.Emit($stream) } finally { $stream.Dispose() }
$result.Diagnostics | ForEach-Object { $_.ToString() }
if (-not $result.Success) { throw 'VR probe compilation failed.' }
Write-Output 'Built SignalisVrTracking.dll'




