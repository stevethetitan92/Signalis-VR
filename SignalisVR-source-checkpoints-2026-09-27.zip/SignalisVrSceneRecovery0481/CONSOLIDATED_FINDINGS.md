# Consolidated cutscene findings and build0481

## Verified baseline
0479: user confirms available inputs including puzzle sticks/A/B, ordinary
movement/turning, inventory, pause and sprint. F1 requires desktop game focus.
Weapon actions pending.0480: user reaches next area through cutscene with controls
working. It retains flat game-screen submission across scene changes; no automatic
return to first person/stereo existed. Installed0480 verified and backed up.

## Visual evidence
Review source and timeline: evidence/REVIEW.md; full evidence work/cutscene0480.
Full239.68s video reviewed via1fps frames, plus4fps title segment and full-resolution
face frame. Not continuous audiovisual playback. Snow and next-area gameplay remain
flat. Wide letterboxing varies. Face close-up has separate short central black
notches. Rose-engine card size is user-reported; exact logo not identified in
reviewed frames. No Waiting panel in sampled frames, not proof of no short flash.

## Code evidence
0480 scene handler clears gameplay camera and stops diagnostic immersive state,
while continuing flat-screen capture. Perspective mod's F1 excludes PEN_Hole.
EnhancedResolution setDimUI explicitly scales Bars/TopBar and Bars/BottomBar on
copied Effects Camera hierarchy. This is a plausible contributor to notches,
not runtime proof of sole cause. Do not globally crop dark image pixels or scale
all UI/title text to address an unidentified logo.

##0481 implementation
Keeps0480 cutscene playback and0479 input mapping. New SceneRecovery.cs:
- Remembers immersive intent only after user enters stereo; Stop clears it.
- Requires normal play state, no cutscene/suspended input, active playing controller,
  no traversal, valid Character Root and0.75s stable camera identity/state.
- Requests original perspective mod's F1 logic through managed input-read wrapper
  (no OS key injection/global Unity hook). Up to3requests spaced3seconds apart.
- Restores stereo with existing eye textures after native pose drain. Recenter on
  first synchronized pose. Does not allocate new graphics resources at handoff.
- Explicitly excludes PEN_Hole pending native snow-camera investigation; logs
  active camera names/parents/targets/state at10second intervals there.
- During immersive-session flat-screen capture, temporarily hides enabled renderers
  named TopBar/BottomBar under Bars under Effects Camera. Restores after capture,
  on stop and scene change; preserves original game objects/animation/state.
  Does not crop baked-in movie bars or enlarge the unidentified logo.

Production changes: SceneRecovery.cs(new), QuestFirstPerson.cs(installs managed
patch), QuestMenuScene.cs(capture-finally restoration), SignalisVrTracking.cs
(intent/recovery/lifecycle/bar integration/version), build.ps1(source inclusion).
Input policy/native read/puzzle input/controllers/puzzle screen/book/dialogue
sources hash-equal0480. Consolidated findings: this document.

## Checks and limits
Build and9suites pass: scene eligibility (actual method with stand-in game state),
puzzle scope, firstperson, native reads, shared getter, menu scene, recovery,
diagnostic, dialogue. No game launched and no runtime detour or headset proof.
Automatic standard-area restoration and bar removal are candidates for testing;
snow stereo and logo scaling remain outstanding. Bars embedded in video may remain.
Asset reader attempt failed due unavailable usable UnityPy; no game assets edited.

DLL SHA256 C8CBAF3554892DA4551635D20D80FCA287D5C6C2D53BA23F83592C0D3019E0E9
Installed0480 SHA256 AE82EDFF4A61B7EF0928E3A482D162885E129CEB5EEED412EB4BA12174CAA144
Restored missing historical0480 DLL from verified installed copy. Rollback0480.zip
contains correctly named DLL. No automatic installation. No GitHub update.

Manual test sequence, one step at a time: close game/copy; start immersive in
starting room; trigger EVA/airlock; check bars/cutscene progression; snow still
flat while collecting diagnostics; see whether next normal gameplay automatically
returns to first person/stereo; check controls and stop key. Retain0480 fallback.
