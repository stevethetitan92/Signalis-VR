$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'SceneRecovery.cs') -Raw
$start=$s.IndexOf('  private bool CanRecoverScene()')
$end=$s.IndexOf('  private void UpdateSceneRecovery()')
$method=$s.Substring($start,$end-$start).Replace('private bool CanRecoverScene','public bool CanRecoverScene')
$stub=@'
using System;
class Scene {public string name="LOV_Reeducation";}
static class SceneManager {public static Scene scene=new Scene();public static Scene GetActiveScene(){return scene;}}
class GameObject {public static GameObject root=new GameObject();public static GameObject Find(string path){return root;}public AlternatePlayerController control=new AlternatePlayerController();public T GetComponent<T>() where T:class{return control as T;}}
class AlternatePlayerController {public bool playing=true,traversing;}
static class PlayerState {public enum gameStates {play,menu,paused,inventory,cutscene,traversing,dialogue,eventScreen,book,loading}public static gameStates gameState;public static bool cutscene,suspendInput;public static GameObject player=new GameObject();}
public class Gate {public bool immersiveRequested=true,questMenuScene=true,active=true,stereo=true,stopping,questInputStopped;public object system=new object();
'@
$tail=@'
public static void Test(){
var g=new Gate();if(!g.CanRecoverScene())throw new Exception("eligible");
foreach(PlayerState.gameStates state in Enum.GetValues(typeof(PlayerState.gameStates))){PlayerState.gameState=state;if(g.CanRecoverScene()!=(state==PlayerState.gameStates.play))throw new Exception("state "+state);}
PlayerState.gameState=PlayerState.gameStates.play;
SceneManager.scene.name="PEN_Hole";if(g.CanRecoverScene())throw new Exception("snow");SceneManager.scene.name="LOV_Reeducation";
foreach(var name in new[]{"immersiveRequested","questMenuScene","active","stereo","stopping","questInputStopped"}){var f=typeof(Gate).GetField(name);bool old=(bool)f.GetValue(g);f.SetValue(g,!old);if(g.CanRecoverScene())throw new Exception(name);f.SetValue(g,old);}
PlayerState.cutscene=true;if(g.CanRecoverScene())throw new Exception("cutscene");PlayerState.cutscene=false;
PlayerState.suspendInput=true;if(g.CanRecoverScene())throw new Exception("suspend");PlayerState.suspendInput=false;
PlayerState.player.control.playing=false;if(g.CanRecoverScene())throw new Exception("playing");PlayerState.player.control.playing=true;
PlayerState.player.control.traversing=true;if(g.CanRecoverScene())throw new Exception("traversing");PlayerState.player.control.traversing=false;
GameObject.root=null;if(g.CanRecoverScene())throw new Exception("root");GameObject.root=new GameObject();
PlayerState.player=null;if(g.CanRecoverScene())throw new Exception("player");
}}
'@
Add-Type -TypeDefinition ($stub+$method+$tail)
[Gate]::Test()
'PASS actual eligibility method: ten states, lifecycle guards, snow exclusion, cutscene/suspension/player/traversal/null guards. Native/graphics runtime unverified.'
