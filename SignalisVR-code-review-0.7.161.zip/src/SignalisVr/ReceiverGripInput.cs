using System;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed class ReceiverGripRepeat {
  private bool armed;
  private int direction;
  private float next;
  public int Update(bool available,bool left,bool right,float now) {
   if(!available){armed=false;direction=0;return 0;}
   if(!armed){armed=!left&&!right;return 0;}
   int d=left==right?0:left?-1:1;
   if(d==0){direction=0;return 0;}
   if(d!=direction){direction=d;next=now+.2f;return d;}
   if(now<next)return 0;
   // Keep the initial tap/delay precise; held receiver controls repeat every 20ms after a 200ms delay.
   next=now+.02f;return d;
  }
 }
 public sealed partial class Tracking {
  private readonly ReceiverGripRepeat receiverGripRepeat=new ReceiverGripRepeat();
  private global::RadioManager receiverMenuRadio;
  private float receiverMenuSeen=-100f,nextReceiverGripReport;
  // Inventory views can carry a different manager from the global singleton.
  // Bind to the actual visible receiver panel, without scanning each frame.
  private static void ReceiverMenuObserved(global::RadioUI __instance){
   var q=questOwner;if(q==null||__instance==null||!__instance.isActiveAndEnabled)return;
   q.UpdateReceiverFooter(__instance);var radio=__instance.radioManager;
   if(radio!=null&&radio.selected){q.receiverMenuRadio=radio;q.receiverMenuSeen=Time.realtimeSinceStartup;}
  }
  private void PollReceiverGrips(bool available,QuestSample left,QuestSample right) {
   var radio=Time.realtimeSinceStartup-receiverMenuSeen<.25f&&receiverMenuRadio!=null?receiverMenuRadio:global::RadioManager.instance;
   bool menu=global::PlayerState.gameState==global::PlayerState.gameStates.inventory&&radio!=null&&radio.selected;
   bool active=available&&questPolicy.LeftArmed&&questPolicy.RightArmed&&radio!=null&&global::RadioManager.moduleInstalled&&!modMenuOpen&&!global::PlayerState.pauseMenu&&menu;
   bool l=left.grip>.55f||left.Button(2),r=right.grip>.55f||right.Button(2);
   int step=receiverGripRepeat.Update(active,l,r,Time.realtimeSinceStartup);
   if((l||r)&&global::PlayerState.gameState==global::PlayerState.gameStates.inventory&&Time.realtimeSinceStartup>=nextReceiverGripReport){nextReceiverGripReport=Time.realtimeSinceStartup+2;MelonLoader.MelonLogger.Msg("RECEIVER GRIP: active="+active+" selected="+(radio!=null&&radio.selected)+" visiblePanel="+(Time.realtimeSinceStartup-receiverMenuSeen<.25f)+" step="+step+" frequency="+(radio==null?0:radio._frequency));}
   if(!active)return;
   // Consume page/aim grips only in the receiver context; native stick tuning remains available.
   questFrame.buttons&=~((1<<5)|(1<<8)|(1<<9));manualLeftGrip=false;
   if(step==0)return;
   radio._frequency=ReceiverTuning.Turn(radio._frequency,step*1.5f,radio.range.x,radio.range.y);
   receiverArrowDirection=step;receiverPressTime=Time.realtimeSinceStartup;
  }
 }
}


