using System;
using HarmonyLib;
using MelonLoader;
namespace SignalisVrTracking {
 public static class QuickSlotDefaults {
  public static void Clear(string[] slots){for(int i=0;i<slots.Length;i++)slots[i]="None";}
  public static bool ShowCount(string id){return id=="Health25"||id=="Health50"||id=="Health100"||id=="HealthFast"||id=="Taser"||id=="SignalFlare";}
  public static string Caption(string name,int count,bool showCount){return name=="NO ITEM"?"NO ITEM":showCount?name+" "+count:name;}
 }
 public sealed partial class Tracking {
  private static Tracking quickSettingsOwner;
  private void InstallQuickNewGame() {
   try {
    quickSettingsOwner=this;
    new HarmonyLib.Harmony("SignalisVR.NoMarkers.NewGameWheel").Patch(AccessTools.DeclaredMethod(typeof(global::SaveManager),"NewGame",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(QuickNewGameFinished)));
   }catch(Exception ex){MelonLogger.Warning("New-game wheel reset unavailable: "+ex.Message);}
  }
  private static void QuickNewGameFinished() {
   var q=quickSettingsOwner;if(q==null)return;
   try {
    QuickSlotDefaults.Clear(q.quickSlots);q.quickSelect.Reset();q.quickLast=-1;q.quickFlashUntil=0;
    q.ClearHeldModules();q.healthUsed=false;
    q.heldQuickHealth=null;q.quickPreviousWeapon=null;q.HideQuickSelect();q.HideQuickHealth();
    Array.Clear(q.quickCaptions,0,q.quickCaptions.Length);q.wheelPickSlot=-1;q.wheelPendingChoice=-1;
    q.SaveModSettings();
    MelonLogger.Msg("ITEM WHEEL: new game started; all four slots cleared and saved.");
   }catch(Exception ex){MelonLogger.Warning("New-game wheel reset/save failed: "+ex.Message);}
  }
 }
}


