using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly CylinderFlickPolicy cylinderFlick=new CylinderFlickPolicy();
  private Quaternion flickPrevious=Quaternion.identity;private float flickTime=-1,hingeOpened=-100;
  private const string RifleSpentKey="SignalisVR.ManualRifle.Spent.v1";
  private readonly Vector3[] rifleCaseOrigins=new Vector3[2];
  private int rifleCaseCount;private float rifleCaseTime=-100;private Vector3 rifleCaseOrigin;private Quaternion rifleCaseRotation;
  private readonly MeshRenderer[] rifleCases=new MeshRenderer[2];
  private Mesh rifleCaseMesh;private Material rifleCaseMaterial;
  private Mesh smgRoundsMesh;private MeshRenderer smgRounds;
  private static Mesh ReloadCylinderMesh(){
   const int sides=12;var v=new Vector3[sides*2+2];var t=new int[sides*12];
   for(int i=0;i<sides;i++){float a=i*(float)Math.PI*2/sides;v[i]=new Vector3(Mathf.Cos(a)*.5f,-.5f,Mathf.Sin(a)*.5f);v[i+sides]=new Vector3(v[i].x,.5f,v[i].z);int n=(i+1)%sides,k=i*12;int[] face={i,n,i+sides,n,n+sides,i+sides,sides*2,n,i,sides*2+1,i+sides,n+sides};for(int j=0;j<12;j++)t[k+j]=face[j];}
   v[sides*2]=new Vector3(0,-.5f,0);v[sides*2+1]=new Vector3(0,.5f,0);var mesh=new Mesh();mesh.vertices=v;mesh.triangles=t;mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
  }
  private void RecordManualRifleShot(){try{var w=global::InventoryManager.EquippedWeapon;if(!manualReloadEnabled||w==null||w.parentItem==null||w.parentItem._item!=global::Items.itemlist.Rifle)return;global::SProgress.SetInt(RifleSpentKey,RifleCases.Fired(global::SProgress.GetInt(RifleSpentKey,0),w.MagSize));}catch(Exception ex){MelonLoader.MelonLogger.Warning("Rifle case tracking unavailable: "+ex.Message);}}
  private void EjectManualRifleCases(){
   int recorded=RifleCases.Eject(global::SProgress.GetInt(RifleSpentKey,0));int mask=rifleChambers.Spent;
   if(mask==0&&recorded>0){for(int c=0;c<2&&recorded>0;c++)if(rifleChambers.Empty(c)){mask|=1<<c;recorded--;}}
   rifleSmokeMask=mask;ResetRifleCaseContacts();rifleCaseCount=0;for(int c=0;c<2;c++)if((mask&(1<<c))!=0){rifleCaseChambers[rifleCaseCount]=c;rifleCaseOrigins[rifleCaseCount++]=rifleChamberWorld[c];}
   rifleChambers.Ejected();global::SProgress.SetInt(RifleSpentKey,0);rifleCaseTime=Time.realtimeSinceStartup;rifleCaseOrigin=additionalChamber;rifleCaseRotation=rightWeaponRotation*Quaternion.AngleAxis(RifleHingePolicy.MaxAngle*additionalOpen,Vector3.right);
  }
  private bool RevolverFlickClose(float now){
   var current=rightWeaponRotation;if(flickTime<0||now-flickTime>.2f){flickPrevious=current;flickTime=now;cylinderFlick.Reset();return false;}
   var delta=Quaternion.Inverse(flickPrevious)*current;float angle;Vector3 axis;delta.ToAngleAxis(out angle,out axis);if(angle>180)angle-=360;flickPrevious=current;flickTime=now;
   return cylinderFlick.Tick(now,angle*axis.z,hingedReload.Stage==HingedReloadPolicy.Step.Open&&additionalOpen>.95f&&now-hingeOpened>.25f);
  }
  private void AddSmgRounds(int count){
   if(additionalAmmo==null||additionalVisualKind!="SMG"||smgRounds!=null||IsXiphias())return;
   var go=new GameObject("SMGMagazineRounds");go.layer=30;go.transform.SetParent(additionalRoot.transform,false);var vertices=new List<Vector3>();var cases=new List<int>();var tips=new List<int>();var b=additionalMesh.bounds;var scale=additionalAmmo.transform.lossyScale/UnitsPerMetre;
   float sx=Math.Max(.001f,Math.Abs(scale.x)),sy=Math.Max(.001f,Math.Abs(scale.y)),sz=Math.Max(.001f,Math.Abs(scale.z));float radius=.004f;int rows=(Math.Max(0,count)+1)/2;
   for(int round=0;round<count;round++){
    float x=(round%2==0?-1:1)*.0038f/sx;float y=b.max.y+.001f/sy-(round/2)*Math.Min(.0075f/sy,b.size.y/Math.Max(1,rows));
    Cartridge(vertices,cases,new Vector3(x,y,b.center.z-.010f/sz),new Vector3(x,y,b.center.z+.010f/sz),radius/sx,radius/sy);
    Cartridge(vertices,tips,new Vector3(x,y,b.center.z+.010f/sz),new Vector3(x,y,b.center.z+.016f/sz),radius/sx,radius/sy,.1f);
   }
   smgRoundsMesh=new Mesh();smgRoundsMesh.vertices=vertices.ToArray();smgRoundsMesh.subMeshCount=2;smgRoundsMesh.SetTriangles(cases.ToArray(),0);smgRoundsMesh.SetTriangles(tips.ToArray(),1);smgRoundsMesh.RecalculateNormals();smgRoundsMesh.RecalculateBounds();go.AddComponent<MeshFilter>().sharedMesh=smgRoundsMesh;smgRounds=go.AddComponent<MeshRenderer>();smgRounds.sharedMaterials=new[]{additionalBrass,additionalCopper};smgRounds.enabled=false;
  }
  private static void Cartridge(List<Vector3> v,List<int> t,Vector3 rear,Vector3 front,float rx,float ry,float taper=1){
   for(int i=0;i<8;i++){float a=i*(float)Math.PI/4,b=(i+1)*(float)Math.PI/4;var p=new Vector3(Mathf.Cos(a)*rx,Mathf.Sin(a)*ry,0);var q=new Vector3(Mathf.Cos(b)*rx,Mathf.Sin(b)*ry,0);MagazineQuad(v,t,rear+p,rear+q,front+q*taper,front+p*taper);int n=v.Count;v.Add(rear);v.Add(rear+q);v.Add(rear+p);t.Add(n);t.Add(n+1);t.Add(n+2);n=v.Count;v.Add(front);v.Add(front+p*taper);v.Add(front+q*taper);t.Add(n);t.Add(n+1);t.Add(n+2);}
  }
  private void ShowReloadAmmoDetails(){
   if(smgRounds!=null&&additionalAmmo!=null){smgRounds.transform.position=additionalAmmo.transform.position;smgRounds.transform.rotation=additionalAmmo.transform.rotation;smgRounds.transform.localScale=additionalAmmo.transform.localScale;smgRounds.enabled=additionalAmmo.enabled&&AdditionalHoldingAmmo();}
   float age=Time.realtimeSinceStartup-rifleCaseTime;ShowRifleSmoke(age);if(rifleCaseCount<=0||age<0||age>1.5f)return;
   EnsureHdRifleCase();
   for(int i=0;i<rifleCaseCount;i++){if(rifleCases[i]==null){var go=new GameObject("SpentRifleCase_"+i);go.layer=30;UnityEngine.Object.DontDestroyOnLoad(go);go.AddComponent<MeshFilter>().sharedMesh=rifleCaseMesh;rifleCases[i]=go.AddComponent<MeshRenderer>();rifleCases[i].sharedMaterial=rifleCaseMaterial;}
    var r=rifleCases[i];r.transform.localScale=Vector3.one*UnitsPerMetre;MoveRifleCase(i,age);r.enabled=true;
   }
  }
  private void HideReloadAmmoDetails(){HideRifleSmoke();if(smgRounds!=null)smgRounds.enabled=false;foreach(var r in rifleCases)if(r!=null)r.enabled=false;}
  private void DestroyMagazineRounds(){if(smgRoundsMesh!=null)UnityEngine.Object.Destroy(smgRoundsMesh);if(smgRounds!=null)UnityEngine.Object.Destroy(smgRounds.gameObject);smgRoundsMesh=null;smgRounds=null;}
  private void DestroyReloadAmmoDetails(){DestroyRifleSmoke();DestroyMagazineRounds();foreach(var r in rifleCases)if(r!=null)UnityEngine.Object.Destroy(r.gameObject);for(int i=0;i<2;i++){rifleCases[i]=null;rifleCaseContacts[i]=null;}DestroyRifleContactMeshes();if(rifleCaseMesh!=null)UnityEngine.Object.Destroy(rifleCaseMesh);if(rifleCaseMaterial!=null)UnityEngine.Object.Destroy(rifleCaseMaterial);rifleCaseMesh=null;rifleCaseMaterial=null;rifleCaseCount=0;}
 }
}

