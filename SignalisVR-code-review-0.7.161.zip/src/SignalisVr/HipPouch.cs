using System;
using System.IO;
using UnityEngine;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private Mesh hipPouchMesh;private Material hipPouchMaterial;private Texture2D hipPouchTexture;private MeshRenderer hipPouchRenderer;
 private void EnsureHipPouch(){
  if(hipPouchRenderer!=null)return;
  using(var r=new BinaryReader(new MemoryStream(HipPouchData.Geometry))){
   int nv=r.ReadInt32(),nt=r.ReadInt32();var v=new Vector3[nv];var uv=new Vector2[nv];var t=new int[nt];
   for(int i=0;i<nv;i++)v[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
   for(int i=0;i<nv;i++)uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());for(int i=0;i<nt;i++)t[i]=r.ReadInt32();
   hipPouchMesh=new Mesh();hipPouchMesh.vertices=v;hipPouchMesh.uv=uv;hipPouchMesh.triangles=t;hipPouchMesh.RecalculateNormals();hipPouchMesh.RecalculateBounds();
  }
  var shader=Shader.Find("Unlit/Texture");if(shader==null)throw new InvalidOperationException("Hip pouch shader unavailable");
  hipPouchTexture=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(hipPouchTexture,HipPouchData.Texture,true))throw new InvalidOperationException("Hip pouch texture unavailable");
  hipPouchTexture.filterMode=FilterMode.Bilinear;hipPouchMaterial=new Material(shader);hipPouchMaterial.mainTexture=hipPouchTexture;
  hipPouchRenderer=CreateControllerPart(hipAmmoRoot,hipPouchMesh,hipPouchMaterial,"LeftHipAmmoPouch",new Vector3(.01f,-.10f,0),Vector3.one);
  hipPouchRenderer.transform.localRotation=Quaternion.Euler(0,-90,0);hipAmmoParts.Add(hipPouchRenderer);
 }
 private void DestroyHipPouch(){
  hipPouchRenderer=null;if(hipPouchMesh!=null)UnityEngine.Object.Destroy(hipPouchMesh);hipPouchMesh=null;
  if(hipPouchMaterial!=null)UnityEngine.Object.Destroy(hipPouchMaterial);hipPouchMaterial=null;if(hipPouchTexture!=null)UnityEngine.Object.Destroy(hipPouchTexture);hipPouchTexture=null;
 }
} }
