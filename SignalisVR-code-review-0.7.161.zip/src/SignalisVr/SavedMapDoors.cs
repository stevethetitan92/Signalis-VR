namespace SignalisVrTracking {public sealed partial class Tracking {
 // Use the native save address: floor LIST index + RoomID name + sorted door
 // index. Unlike a live scene hierarchy, this also exists during event handoffs.
 private static string SavedMapRoomKey(global::PersistentMinimapManager manager,global::PersistentMinimapRoom room){
  if(manager==null||manager.FloorManagers==null||room==null||room.RoomID==null)return null;
  for(int i=0;i<manager.FloorManagers.Count;i++){
   var floor=manager.FloorManagers[i];
   if(floor!=null&&floor.Rooms!=null&&floor.Rooms.Contains(room))return "F"+i+"R "+room.RoomID.name;
  }return null;
 }
 private static string SavedMapDoorKey(string roomKey,int count,int index){
  return roomKey==null||index<0||index>=count?null:"SignalisVR.Map.DoorObserved.v4:"+roomKey+":"+count+":"+index;
 }
 private static bool PreferMapDoorObservation(int current,int currentRevision,int next,int nextRevision){return ValidObservedDoorState(next)&&(!ValidObservedDoorState(current)||nextRevision>currentRevision);}
 private static bool ValidObservedDoorState(int state){return state==1||state==2||state==4;}
 private static int DecodeSavedMapDoor(string record,int count,int index){
  // PersistentMinimapManager.Save/Load: U=unknown, O=open, L=locked,
  // X=dead/broken. Read serialized history, NEVER the live marker.state/tried.
  if(record==null||record.Length!=count||index<0||index>=count)return 0;
  foreach(char c in record)if(c!='U'&&c!='O'&&c!='L'&&c!='X')return 0;
  return record[index]=='O'?1:record[index]=='L'?4:record[index]=='X'?2:0;
 }
 private static int RestoreSavedMapDoor(global::MinimapDoor marker,global::PersistentMinimapRoom room,string roomKey,string saved){
  int index=room==null||room.Doors==null?-1:room.Doors.IndexOf(marker);
  var key=SavedMapDoorKey(roomKey,room==null||room.Doors==null?0:room.Doors.Count,index);
  int state=key==null?0:global::SProgress.GetInt(key,0);
  var legacy=marker==null?null:MapDoorHistory(marker.door);
  int recent=LiveMapDoorState(marker);
  int revision=legacy==null?0:global::SProgress.GetInt(legacy+":revision",0);
  if(ValidObservedDoorState(recent)&&(key==null||!ValidObservedDoorState(state)||revision>global::SProgress.GetInt(key+":revision",-1))){
   if(key!=null){global::SProgress.SetInt(key,recent);global::SProgress.SetInt(key+":revision",revision);if(recent==4&&legacy!=null)global::SProgress.SetString(key+":keyName",global::SProgress.GetString(legacy+":keyName",""));}
   return recent;
  }
  if(ValidObservedDoorState(state))return state;
  // Native saved map states and v3 aliases can contain scripted reveals or
  // observations copied from a different, identically named physical door.
  // Only this door's explicit observation may reveal its status.
  return 0;
 }
 private static void RememberSavedMapDoor(global::AutoTraverseDoor door,int state,int revision){
  if(door==null||!ValidObservedDoorState(state))return;
  var manager=global::PersistentMinimapManager.instance;
  if(manager==null||manager.FloorManagers==null)return;
  foreach(var floor in manager.FloorManagers){if(floor==null||floor.Rooms==null)continue;
   foreach(var room in floor.Rooms){if(room==null||room.Doors==null)continue;
    for(int i=0;i<room.Doors.Count;i++){
     var marker=room.Doors[i];if(marker==null||marker.door!=door)continue;
     var key=SavedMapDoorKey(SavedMapRoomKey(manager,room),room.Doors.Count,i);
     if(key!=null){global::SProgress.SetInt(key,state);global::SProgress.SetInt(key+":revision",revision);string label=MapDoorRequiredKey(door);if(state==4&&!string.IsNullOrEmpty(label))global::SProgress.SetString(key+":keyName",label);}
    }
   }
  }
 }
 private static void RestoreRootIndependentDoor(string key,string oldPrefix,string slots){
  if(global::SProgress.GetInt(key+":observedState",0)!=0)return;
  var progress=global::SProgress.progress;if(progress==null||progress.intKeys==null)return;
  int best=0,revision=-1;
  // Migration runs once per physical door/load (MapDoorHistory caches keys).
  // Only the scene-root index is ignored; all authored child indices still match.
  foreach(var entry in progress.intKeys){
   const string suffix=":observedState";
   if(entry==null||!entry.StartsWith(oldPrefix,System.StringComparison.Ordinal)||!entry.EndsWith(suffix,System.StringComparison.Ordinal))continue;
   string tail=entry.Substring(oldPrefix.Length,entry.Length-oldPrefix.Length-suffix.Length);
   int slash=tail.IndexOf('/');if(slash<0||tail.Substring(slash+1)!=slots)continue;
   int state=global::SProgress.GetInt(entry,0);string prior=entry.Substring(0,entry.Length-suffix.Length);
   int rev=global::SProgress.GetInt(prior+":revision",0);
   if(ValidObservedDoorState(state)&&rev>revision){best=state;revision=rev;}
  }
  if(ValidObservedDoorState(best)){global::SProgress.SetInt(key,1);global::SProgress.SetInt(key+":observedState",best);global::SProgress.SetInt(key+":revision",revision);}
 }
 private static void SavedMapLoaded(){
  // No process-global history cache: loading another slot/profile must replace
  // observations, not merge them with the previous playthrough.
  mapDoorKeyCache.Clear();var q=questOwner;if(q!=null)q.nextModMapRefresh=0;
 }
}}


