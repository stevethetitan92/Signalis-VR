namespace SignalisVrTracking {
 public sealed class ModMenuInput {
  private bool chordLatched,confirmHeld,cancelHeld;
  private int direction;
  private float repeat;
  private int adjustDirection;
  private float adjustRepeat;
  public int Adjust(float axis,float now) {
   int d=axis>.5f?1:axis<-.5f?-1:0;
   if(d==0){adjustDirection=0;return 0;}
   if(d!=adjustDirection){adjustDirection=d;adjustRepeat=now+.4f;return d;}
   if(now<adjustRepeat)return 0;
   adjustRepeat=now+.18f;return d;
  }
  private bool sectionLeft,sectionRight;
  public int Section(bool available,bool left,bool right) {
   bool l=left&&!sectionLeft,r=right&&!sectionRight;
   sectionLeft=left;sectionRight=right;
   if(!available||left&&right)return 0;
   return r?1:l?-1:0;
  }
  public bool Toggle(bool available,bool left,bool right) {
   if(!available){chordLatched=true;return false;}
   if(!left&&!right)chordLatched=false;
   if(left&&right&&!chordLatched){chordLatched=true;return true;}
   return false;
  }
  public int Navigate(float axis,float now) {
   int d=axis>.5f?-1:axis<-.5f?1:0;
   if(d==0){direction=0;return 0;}
   if(d!=direction){direction=d;repeat=now+.4f;return d;}
   if(now<repeat)return 0;
   repeat=now+.18f;return d;
  }
  public bool Confirm(bool held){bool down=held&&!confirmHeld;confirmHeld=held;return down;}
  public bool Cancel(bool held){bool down=held&&!cancelHeld;cancelHeld=held;return down;}
 }
}
