using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class StarAxeState {public SkinnedMeshRenderer Renderer;public Mesh Original,Replacement;public Material Native,Owned;public Bounds Bounds;}
 private readonly Dictionary<int,StarAxeState> starAxes=new Dictionary<int,StarAxeState>();
 private readonly HashSet<global::EnemyController> pendingStarAxes=new HashSet<global::EnemyController>();
 private readonly List<int> staleStarAxes=new List<int>();
 private bool starAxeInitialScan=true,starAxeFailed;
 private Texture2D starAxeTexture;
 private Vector3[] starAxeVertices;private Vector2[] starAxeUv;private int[] starAxeTriangles;
 private void LoadStarAxeAsset(){
  if(starAxeVertices!=null)return;
  using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(HdAsset.Read("STAR-fire-axe.bin"))))){
   int nv=r.ReadInt32(),nt=r.ReadInt32();if(nv!=186||nt!=300)throw new InvalidDataException("Unexpected STAR axe geometry");
   var v=new Vector3[nv];var uv=new Vector2[nv];var t=new int[nt];
   for(int i=0;i<nv;i++)v[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
   for(int i=0;i<nv;i++)uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());
   for(int i=0;i<nt;i++){t[i]=r.ReadInt32();if(t[i]<0||t[i]>=nv)throw new InvalidDataException("STAR axe index");}
   var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);
   if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(HdAsset.Read("STAR-fire-axe.png")))){UnityEngine.Object.Destroy(tex);throw new InvalidDataException("STAR axe texture");}
   tex.name="STAR axe original texture";tex.filterMode=FilterMode.Point;tex.wrapMode=TextureWrapMode.Clamp;
   starAxeTexture=tex;starAxeVertices=v;starAxeUv=uv;starAxeTriangles=t;
  }
 }
 private static bool IsStarBaton(SkinnedMeshRenderer r){
  return r!=null&&r.name=="STARBaton"&&r.sharedMesh!=null&&r.sharedMesh.name=="STARBaton"&&r.sharedMesh.vertexCount==128;
 }
 private void AttachStarAxe(global::EnemyController enemy){
  if(enemy==null||!enemy.gameObject.scene.IsValid()||OwnsTestEnemy(enemy))return;
  foreach(var r in enemy.GetComponentsInChildren<SkinnedMeshRenderer>(true)){
   if(r==null||starAxes.ContainsKey(r.GetInstanceID())||!IsStarBaton(r))continue;
   var original=r.sharedMesh;var bones=r.bones;var binds=original.bindposes;int hand=-1;
   for(int i=0;i<bones.Length;i++)if(bones[i]!=null&&bones[i].name=="hand_R"){hand=i;break;}
   var native=r.sharedMaterial;if(hand<0||hand>=binds.Length||native==null||native.mainTexture==null)continue;
   LoadStarAxeAsset();
   var mesh=new Mesh();mesh.name="SignalisVR_STAR_FireAxe";mesh.vertices=starAxeVertices;mesh.uv=starAxeUv;mesh.triangles=starAxeTriangles;mesh.bindposes=binds;
   var weights=new BoneWeight[starAxeVertices.Length];for(int i=0;i<weights.Length;i++)weights[i]=new BoneWeight{boneIndex0=hand,weight0=1f};mesh.boneWeights=weights;mesh.RecalculateNormals();mesh.RecalculateBounds();
   var state=new StarAxeState{Renderer=r,Original=original,Replacement=mesh,Native=native,Owned=new Material(native),Bounds=r.localBounds};
   UpdateStarAxeMaterial(state);starAxes.Add(r.GetInstanceID(),state);r.sharedMesh=mesh;r.sharedMaterial=state.Owned;
   // Keep the original animation culling envelope, enlarged for the axe head.
   var bounds=state.Bounds;bounds.Expand(3f);r.localBounds=bounds;
   MelonLoader.MelonLogger.Msg("STAR AXE: replaced baton visual; original hand bones, attacks and collisions retained.");
  }
 }
 private void UpdateStarAxeMaterial(StarAxeState s){
  if(s.Native==null||s.Owned==null)return;
  s.Owned.shader=s.Native.shader;s.Owned.CopyPropertiesFromMaterial(s.Native);
  s.Owned.mainTexture=starAxeTexture;s.Owned.mainTextureScale=Vector2.one;s.Owned.mainTextureOffset=Vector2.zero;
  if(s.Owned.HasProperty("_EmitTex"))s.Owned.SetTexture("_EmitTex",Texture2D.blackTexture);
  if(s.Owned.HasProperty("_Glossiness"))s.Owned.SetFloat("_Glossiness",0f);
  if(s.Owned.HasProperty("_Metallic"))s.Owned.SetFloat("_Metallic",0f);
 }
 private void UpdateStarAxes(){
  if(starAxeFailed)return;
  try{
   if(starAxeInitialScan){starAxeInitialScan=false;foreach(var enemy in Resources.FindObjectsOfTypeAll<global::EnemyController>())pendingStarAxes.Add(enemy);}
   foreach(var enemy in pendingStarAxes)AttachStarAxe(enemy);pendingStarAxes.Clear();
   staleStarAxes.Clear();
   foreach(var pair in starAxes){var s=pair.Value;var r=s.Renderer;
    if(r==null||r.sharedMesh!=s.Replacement){staleStarAxes.Add(pair.Key);continue;}
    // Native burn/death may replace the material. Preserve that state and shader.
    var current=r.sharedMaterial;if(current!=s.Owned){s.Native=current;if(current==null)continue;r.sharedMaterial=s.Owned;}
    if(r.gameObject.activeInHierarchy)UpdateStarAxeMaterial(s);
   }
   foreach(int id in staleStarAxes){RestoreStarAxe(starAxes[id]);starAxes.Remove(id);}
  }catch(Exception ex){ClearStarAxes();starAxeFailed=true;MelonLoader.MelonLogger.Warning("STAR axe fallback to native baton: "+ex.Message);}
 }
 private static void RestoreStarAxe(StarAxeState s){
  if(s.Renderer!=null){if(s.Renderer.sharedMesh==s.Replacement){s.Renderer.sharedMesh=s.Original;s.Renderer.localBounds=s.Bounds;}if(s.Renderer.sharedMaterial==s.Owned)s.Renderer.sharedMaterial=s.Native;}
  if(s.Replacement!=null)UnityEngine.Object.Destroy(s.Replacement);if(s.Owned!=null)UnityEngine.Object.Destroy(s.Owned);
 }
 private void ClearStarAxes(){
  foreach(var s in starAxes.Values)RestoreStarAxe(s);starAxes.Clear();pendingStarAxes.Clear();staleStarAxes.Clear();
  if(starAxeTexture!=null)UnityEngine.Object.Destroy(starAxeTexture);starAxeTexture=null;starAxeVertices=null;starAxeUv=null;starAxeTriangles=null;starAxeInitialScan=true;starAxeFailed=false;
 }
}}
