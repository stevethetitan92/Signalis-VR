namespace SignalisVrTracking
{
    public sealed class DiagnosticFlow
    {
        public int Stage { get; private set; }

        public bool CanSubmit { get { return Stage == 3; } }
        public void Connected() { if (Stage == 0) Stage = 1; }
        public void RenderReady() { if (Stage == 1) Stage = 2; }
        public bool BeginSubmit(float now)
        {
            if (Stage != 2) return false;
            Stage = 3; return true;
        }
        public bool Expired(float now) { return false; }
        public void Stop() { Stage = 0; }
    }
}

namespace SignalisVrTracking
{
    // 0 normal, 1 menu/camera suspended, 2 ready after native drain.
    public sealed class CameraRecovery
    {
        public bool Paused { get; private set; }

        private float stableSince = -1f;
        public int Observe(bool enabled, float now)
        { return Observe(enabled,now,false); }
        public int Observe(bool enabled, float now, bool sameCameraReturn)
        {
            if (!Paused)
            {
                if (enabled) return 0;
                Paused = true; stableSince = -1f;
            }

            if (!enabled) { stableSince = -1f; return 1; }
            if (stableSince < 0f) stableSince = now;
            return 2; // Native eligibility and pose drain gate the handoff; no artificial dwell.
        }
        public void Reset() { Paused = false; stableSince = -1f; }
    }
}


