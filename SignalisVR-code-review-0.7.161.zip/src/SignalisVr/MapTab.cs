using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool mapDoorLocks;
 private int mapSizePercent,mapTextSizePercent;
 private bool mapHints=true;
 private float nextManualMapRefresh,manualMapRefreshStatusUntil;
 private bool manualMapRefreshPending;
 private void CompleteManualMapRefresh(){if(!manualMapRefreshPending)return;manualMapRefreshPending=false;manualMapRefreshStatusUntil=Time.realtimeSinceStartup+3;nextModMapRefresh=0;MelonLoader.MelonLogger.Msg("MAP REFRESH: rescan complete; projection, known ladders, key hints and solved puzzles rebuild on next display.");}
 private float MapTextSizeFactor(){return 1f+Math.Max(0,Math.Min(100,mapTextSizePercent))/100f;}
 private void RequestManualMapRefresh(){
  // Coalesce repeated presses. Recreate derived identities and positions from
  // live objects; preserve native progress and checked door observations.
  if(Time.realtimeSinceStartup<nextManualMapRefresh)return;
  nextManualMapRefresh=Time.realtimeSinceStartup+1f;manualMapRefreshPending=true;
  MelonLoader.MelonLogger.Msg("MAP REFRESH: requested; preserving checked door observations and save data.");
  boundsRoom=null;cachedRoomBoundsValid=false;modRoomBoundsValid=false;modRoomProjectionValid=false;
  mapDoorKeyCache.Clear();nextMapScan=0;nextMapDiscovery=0;nextModMapRefresh=0;
  mapObjects.Clear();ReindexMapPoints();rejectedMapIds.Clear();
  mapSymbolsDirty=true;mapLabelsDirty=true;
 }
 private void SetMapHints(bool on){if(mapHints==on)return;mapHints=on;nextModMapRefresh=0;mapLabelsDirty=true;}
 private void SetMapDoorDesign(bool locks){if(mapDoorLocks==locks)return;mapDoorLocks=locks;mapSymbolsDirty=true;}
 private float MapSizeFactor(){return 1f+Math.Max(0,Math.Min(100,mapSizePercent))/100f;}
 private void ActivateMapMenu(int index){
  if(index==0){modMiniMap=!modMiniMap;nextModMapRefresh=0;}
  else if(index==1)AdjustMapMenu(index,1);
  else if(index==2){mapComplete=!mapComplete;if(mapComplete)CompleteAllMaps();nextModMapRefresh=0;}
  else if(index==3)SetMapDoorDesign(!mapDoorLocks);
  else if(index==4)AdjustMapMenu(index,1);
  else if(index==5)RequestManualMapRefresh();
  else if(index==6)SetMapHints(!mapHints);

 }
 private void AdjustMapMenu(int index,int direction){
  if(index==4){mapTextSizePercent=Math.Max(0,Math.Min(100,mapTextSizePercent+direction*5));nextModMapRefresh=0;mapLabelsDirty=true;}
  else if(index==6)SetMapHints(direction>0);
  else if(index==3)SetMapDoorDesign(direction>0);
  else if(index==1)mapSizePercent=Math.Max(0,Math.Min(100,mapSizePercent+direction*5));
  else if(index==0&&modMiniMap!=(direction>0))ActivateMapMenu(index);
  else if(index==2&&mapComplete!=(direction>0))ActivateMapMenu(index);
 }
 private void DrawMapTab(float x,float y,float width,float s){
  string[] labels={"MINI MAP","MAP SIZE","MAP COMPLETE","MAP DESIGN","MAP TEXT SIZE","MAP REFRESH","MAP HINTS"};
  string[] values={modMiniMap?"ON":"OFF",mapSizePercent+"%",mapComplete?"ON":"OFF",mapDoorLocks?"LOCKS":"FLAT DOORS",mapTextSizePercent+"%",manualMapRefreshPending?"REFRESHING":Time.realtimeSinceStartup<manualMapRefreshStatusUntil?"REFRESHED":"PRESS A",mapHints?"ON":"OFF"};
  string[] help={"VR: hold your left hand forward, palm down, to reveal the map. Desktop: show the map.","0% is the current default size. 100% doubles its width and height. Adjust with LEFT / RIGHT or the arrows. Changes the displayed map size in VR and on desktop.","Reveal all map layouts and points of interest. Revealed layouts remain explored when turned OFF; special icons return to discovery requirements.","Switch instantly between lock symbols and flat door symbols. Only the artwork changes; discovered rooms, door states and map positions stay intact.","0% is the current text size. 100% is twice as large. Room names wrap and fit inside their rooms. Applies to desktop and VR.","Select and press A to rebuild positions, projection and completed-puzzle visibility. Rescans in stages. Door colors use your saved interactions; recheck a door to record a changed lock.","Show yellow required-key names beside checked gold locks. Turning hints OFF hides only these names."};
  for(int i=0;i<labels.Length;i++){
   float row=y+(130+i*80)*s;
   PaintMenuRect(new Rect(x,row,870*s,65*s),modMenuSelection==i?new Color(.12f,.22f,.22f):Color.black);
   MenuText(new Rect(x,row,450*s,65*s),labels[i],Color.white,modMenuStyle);
   var left=new Rect(x+470*s,row,60*s,65*s);var right=new Rect(x+790*s,row,60*s,65*s);
   MenuText(left,i!=5?"<":"",Color.cyan,modMenuStyle);MenuText(right,i!=5?">":"",Color.cyan,modMenuStyle);
   MenuText(new Rect(x+540*s,row,240*s,65*s),values[i],Color.cyan,modMenuStyle);
   if(i!=5&&MenuClicked(left)){modMenuSelection=i;AdjustMapMenu(i,-1);return;}
   if(i!=5&&MenuClicked(right)){modMenuSelection=i;AdjustMapMenu(i,1);return;}
   if(MenuClicked(new Rect(x,row,870*s,65*s))){modMenuSelection=i;ActivateMapMenu(i);return;}
  }
  MenuText(new Rect(x+930*s,y+140*s,530*s,250*s),help[modMenuSelection],Color.white,modMenuHelp);
  DrawModMapLegend(x+930*s,y+430*s,s);
  MenuText(new Rect(x,y+710*s,width,60*s),"LEFT STICK: SELECT / CHANGE   A: ACTIVATE   GRIPS: SWITCH TABS",Color.white,modMenuHelp);
  if(modSettingsError!=null)MenuText(new Rect(x,y+818*s,width,36*s),modSettingsError,Color.white,modMenuHelp);
 }
}}





