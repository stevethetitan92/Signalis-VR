namespace SignalisVrTracking {
 public sealed class ShotgunReloadPolicy {
  public enum Step { Idle, Holding, AwaitingInsert, PumpReady, Pumping }
  public Step Stage {get;private set;}
  public bool Active {get{return Stage!=Step.Idle;}}
  public bool BlocksAttack {get{return needsPump||Stage==Step.Holding||Stage==Step.AwaitingInsert||Stage==Step.Pumping&&Pull>.01f;}}
  private bool lastPump,lastGrip,lastPouch,needsPump,pulled,spent,strokeLive;
  public int EjectionCount {get;private set;}
  public bool LastEjectionLive {get;private set;}
  private float origin,lastPosition;
  private bool hasSample;
  public float Pull {get;private set;}
  public bool NeedsPump {get{return needsPump;}}
  // Interrupting a gesture must not chamber a round (menus, tracking or swaps).
  public void Interrupt(){needsPump=needsPump||Pull>.01f;Stage=needsPump?Step.PumpReady:Step.Idle;lastGrip=lastPump=lastPouch=hasSample=false;}
  public void Fired(){bool held=lastGrip&&lastPump&&hasSample;needsPump=true;spent=true;strokeLive=false;Stage=held?Step.Pumping:Step.PumpReady;pulled=false;Pull=0;if(held)origin=lastPosition;}
  public void Cancel(){Stage=Step.Idle;lastGrip=lastPump=lastPouch=hasSample=false;needsPump=spent=strokeLive=false;pulled=false;Pull=0;}
  // Return true exactly once for a held-shell insertion. Ammo transfer is owned by Update.
  public bool Tick(float now,bool grip,bool pouch,bool port,bool pump,float position,int loaded,int capacity,int reserve){
   bool down=grip&&!lastGrip;bool arrived=pump&&!lastPump;bool pouchArrival=pouch&&!lastPouch;lastGrip=grip;lastPump=pump;lastPouch=pouch;
   lastPosition=position;hasSample=!float.IsNaN(position)&&!float.IsInfinity(position);
   if((Stage==Step.Idle||Stage==Step.PumpReady)&&(down||pouchArrival)&&grip&&pouch&&!pump&&reserve>0){needsPump=needsPump||loaded==0;Stage=Step.Holding;}
   else if(Stage==Step.Holding){
    if(port&&CanTransfer(loaded,capacity,reserve)){Stage=Step.AwaitingInsert;return true;}
    if(!grip){Stage=needsPump?Step.PumpReady:Step.Idle;}
   }else if((Stage==Step.PumpReady||Stage==Step.Idle&&(down||arrived))&&grip&&pump){bool resume=Stage==Step.PumpReady&&Pull>0;if(!resume){strokeLive=!needsPump&&loaded>0;pulled=false;Pull=0;}Stage=Step.Pumping;if(!resume)origin=position;}
   else if(Stage==Step.Pumping){
    if(float.IsNaN(position)||float.IsInfinity(position)||System.Math.Abs(position-origin)>.35f){Interrupt();return false;}
    Pull=System.Math.Min(.1f,System.Math.Max(0,position-origin));
    if(Pull>=.06f&&!pulled){
     pulled=true;
     if(strokeLive||spent){LastEjectionLive=strokeLive;EjectionCount++;}
     spent=strokeLive=false;needsPump=true;
    }
    if(!grip){Stage=needsPump||Pull>.01f?Step.PumpReady:Step.Idle;needsPump=Stage==Step.PumpReady;}
    else if(pulled&&Pull<=.02f){needsPump=loaded==0;Stage=needsPump?Step.PumpReady:Step.Idle;Pull=0;}
   }
   return false;
  }
  public void Inserted(int loaded,int capacity,int reserve){Stage=needsPump?Step.PumpReady:Step.Idle;}
  public static bool CanTransfer(int loaded,int capacity,int reserve){return loaded>=0&&capacity>0&&loaded<capacity&&reserve>0;}
 }
}




