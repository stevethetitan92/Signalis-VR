using System;
using System.Collections.Generic;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly ProdContactPolicy prodContact=new ProdContactPolicy();
  private BoxCollider prodProbe;
  private static readonly Vector3 ProdGripPalm=new Vector3(.032f,-.004f,-.170f);
  private Vector3 prodResolved;
  private Quaternion prodResolvedRotation;
  private bool prodPoseValid;
  private global::Room prodPoseRoom;
  private class ProdFrozen {
   public global::EnemyController enemy;public float until,animSpeed;
   public StunVisual Visual;public bool enabled,agentEnabled,agentStopped,weapon,weaponAlt;
  }
  private readonly List<ProdFrozen> prodFrozen=new List<ProdFrozen>();
  private bool ProdPowered(){return !prodFailed&&prodHooksReady&&ProdVrMode()&&ProdSelected()&&!ProdHandOccupied()
   &&controllerMarkers[1]!=null&&questAvailabilityValue&&questPolicy.RightArmed&&(controllerVisibility&2)!=0
   &&global::PlayerState.hp>0&&global::InventoryManager.hasItem(global::InventoryManager.EquippedTool);}
  private bool ProdObstacle(Collider c){
   if(c==null||!c.enabled||c==prodProbe||c.transform.IsChildOf(prodRoot.transform))return false;
   if(global::PlayerState.player!=null&&c.transform.IsChildOf(global::PlayerState.player.transform))return false;
   return c.GetComponentInParent<global::EnemyController>()==null&&(!c.isTrigger&&((1<<c.gameObject.layer)&(int)global::PlayerAttack.instance.WallMask)!=0);
  }
  private bool ProdResolve(ref Vector3 position,Quaternion rotation){
   var centre=rotation*new Vector3(0,0,.0084f)*UnitsPerMetre;
   for(int pass=0;pass<8;pass++){
    bool clear=true;
    foreach(var c in Physics.OverlapBox(position+centre,new Vector3(.045f,.013f,.267f)*UnitsPerMetre,rotation,-1,QueryTriggerInteraction.Collide)){
     if(!ProdObstacle(c))continue;Vector3 direction;float depth;
     if(Physics.ComputePenetration(prodProbe,position,rotation,c,c.transform.position,c.transform.rotation,out direction,out depth)){
      position+=direction*(depth+.0008f*UnitsPerMetre);clear=false;
     }
    }
    if(clear)return true;
   }
   return false;
  }
  private void SolveProdPose(){
   EnsureProdVisual();
   if(prodProbe==null){prodProbe=prodRoot.AddComponent<BoxCollider>();prodProbe.center=new Vector3(0,0,.0084f);prodProbe.size=new Vector3(.088f,.024f,.534f);prodProbe.enabled=false;}
   prodRoot.transform.localScale=Vector3.one*UnitsPerMetre;
   var hand=controllerMarkers[1].transform;var desired=HandPlacement.TrackedPalm(hand.position,hand.rotation,UnitsPerMetre);
   var rotation=WeaponAimPolicy.ControllerRotation(hand.rotation)*Quaternion.Euler(-8f,0,0);
   // Imported handle spans Z=-.258 to -.08; the origin is the housing.
   var gripPalm=ProdGripPalm;var saved=SavedGripData.Get("StunProd",1);
   // Aim the prod along the controller/forearm. The saved hand pose wraps the
   // handle in ResolveSavedGrip; undoing it here tilted the entire weapon to
   // preserve a firearm-style wrist, defeating the forward stabbing pose.
   if(saved!=null)gripPalm=saved.Palm;
   desired-=rotation*(gripPalm*UnitsPerMetre);
   var position=desired;GatherProdSurfaces(desired,rotation);
   bool continuous=prodPoseValid&&prodPoseRoom==global::PlayerState.currentRoom&&(desired-prodResolved).magnitude<.6f*UnitsPerMetre;
   if(continuous){
    position=prodResolved;
    int steps=Math.Max(1,Math.Min(12,(int)Math.Ceiling(Math.Max((desired-prodResolved).magnitude/(.04f*UnitsPerMetre),Quaternion.Angle(prodResolvedRotation,rotation)/10f))));
    for(int step=1;step<=steps;step++){
     var next=Vector3.Lerp(prodResolved,desired,step/(float)steps);var r=Quaternion.Slerp(prodResolvedRotation,rotation,step/(float)steps);
     var delta=next-position;
     if(delta.sqrMagnitude>1e-10f){float fraction=1;
      foreach(var hit in Physics.BoxCastAll(position+r*new Vector3(0,0,.0084f)*UnitsPerMetre,new Vector3(.044f,.012f,.267f)*UnitsPerMetre,delta.normalized,r,delta.magnitude,-1,QueryTriggerInteraction.Collide))
       if(ProdObstacle(hit.collider))fraction=Math.Min(fraction,Math.Max(0,(hit.distance-.0008f*UnitsPerMetre)/delta.magnitude));
      next=position+delta*fraction;
     }
     if(!ProdResolve(ref next,r))break;ResolveProdSurface(ref next,r);position=next;
    }
   }
   if(!ProdResolve(ref position,rotation)){prodPoseValid=false;prodContact.Reset();return;}
   ResolveProdSurface(ref position,rotation);
   prodResolved=position;prodResolvedRotation=rotation;prodPoseValid=true;prodPoseRoom=global::PlayerState.currentRoom;
   prodRoot.transform.SetPositionAndRotation(position,rotation);
  }
  private bool ProdIsFrozen(global::EnemyController e){foreach(var f in prodFrozen)if(f.enemy==e)return true;return false;}
  private void FreezeProdEnemy(global::EnemyController e){
   var f=new ProdFrozen{enemy=e,until=Time.time+4f,enabled=e.enabled,agentEnabled=e.agent!=null&&e.agent.enabled,agentStopped=e.agent!=null&&e.agent.enabled&&e.agent.isStopped,animSpeed=e.animator==null?1:e.animator.speed,
    weapon=e.WeaponHurtboxObject!=null&&e.WeaponHurtboxObject.activeSelf,weaponAlt=e.WeaponHurtboxAltObject!=null&&e.WeaponHurtboxAltObject.activeSelf};
   prodFrozen.Add(f);HoldProdEnemy(f);try{BeginStunVisual(f);}catch(Exception ex){EndStunVisual(f);MelonLogger.Warning("Stun visuals unavailable: "+ex.Message);}
  }
  private void HoldProdEnemy(ProdFrozen f){var e=f.enemy;if(e.agent!=null&&e.agent.enabled)e.agent.isStopped=true;if(e.animator!=null)e.animator.speed=0;
   if(e.WeaponHurtboxObject!=null)e.WeaponHurtboxObject.SetActive(false);if(e.WeaponHurtboxAltObject!=null)e.WeaponHurtboxAltObject.SetActive(false);}
  private void RestoreProdEnemy(ProdFrozen f){EndStunVisual(f);var e=f.enemy;if(e==null)return;
   e.enabled=f.enabled;if(e.animator!=null)e.animator.speed=f.animSpeed;
   if(e.agent!=null&&ProdEnemyValid(e)&&f.agentEnabled&&e.agent.enabled)e.agent.isStopped=false;
   if(ProdEnemyValid(e)&&f.enabled&&!OwnsTestEnemy(e)){e.CheckStateChange();MelonLogger.Msg("STUN RECOVERY: native AI resumed; state="+e.state);}
   if(ProdEnemyValid(e)){if(e.WeaponHurtboxObject!=null)e.WeaponHurtboxObject.SetActive(f.weapon);if(e.WeaponHurtboxAltObject!=null)e.WeaponHurtboxAltObject.SetActive(f.weaponAlt);}}
  private void PollProdFrozen(){for(int i=prodFrozen.Count-1;i>=0;i--){var f=prodFrozen[i];if(!ProdEnemyValid(f.enemy)||Time.time>=f.until){RestoreProdEnemy(f);prodFrozen.RemoveAt(i);}else {HoldProdEnemy(f);AnimateStunVisual(f);}}}
  private void ClearProdFrozen(){foreach(var f in prodFrozen)RestoreProdEnemy(f);prodFrozen.Clear();}
  private void PollProdContact(){
   PollProdFrozen();PollProdDebris();
   if(!ProdPowered()){SetProdContactAudio(false);prodPoseValid=false;prodContact.Reset();return;}
   // Consume the most recent render-pose contact; do not solve against stale
   // controller markers here and then display it with a newer body/head pose.
   if(!ProdEligible()||!prodPoseValid||global::PlayerState.paused){SetProdContactAudio(false);return;}
   Vector3 left=prodResolved+prodResolvedRotation*new Vector3(-.0175f,0,.27438f)*UnitsPerMetre;
   Vector3 right=prodResolved+prodResolvedRotation*new Vector3(.0175f,0,.27438f)*UnitsPerMetre;
   global::EnemyController target=null;bool touching=false;
   var checkedEnemies=new HashSet<IntPtr>();
   foreach(var face in prodFaces){
    var e=face.enemy;if(!ProdEnemyValid(e)||!checkedEnemies.Add(e.Pointer))continue;
    if(!ProdSurfaceTouch(e,left)&&!ProdSurfaceTouch(e,right))continue;
    touching=true;if(!ProdIsFrozen(e)){target=e;break;}
   }
   SetProdContactAudio(touching);
   if(!prodContact.Touch(touching,target!=null,Time.time))return;
   FreezeProdEnemy(target);
   int remaining=ProdDurability.Hit(ProdUses()); // Each confirmed stun always spends one charge.
   global::SProgress.SetInt(ProdDurabilityKey,remaining==0?ProdDurability.Capacity:remaining);
   if(remaining==0){
    var item=global::InventoryManager.EquippedTool;global::InventoryManager.RemoveItem(item);global::InventoryManager.EquippedTool=null;
    for(int i=0;i<quickSlots.Length;i++)if(quickSlots[i]=="Taser")quickSlots[i]="None";
    try{SaveModSettings();}catch(Exception ex){MelonLogger.Warning("Spent prod wheel save: "+ex.Message);}
    SetProdContactAudio(false);BeginProdBreakup();HideSwingProd();prodPoseValid=false;ResetRightHandAfterProd();
   }
   ProdReport("Prong contact: four-second stun, "+remaining+"/3 charges; no HP damage.");
  }
 }
}




