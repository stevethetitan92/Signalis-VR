using System;
namespace SignalisVrTracking {
 public static class RifleBarrelMotion {
  public const float OpenSeconds=.20f,CloseSeconds=.24f;
  public static float Advance(float phase,bool open,float dt){
   phase=Math.Max(0,Math.Min(1,phase));
   if(float.IsNaN(dt)||float.IsInfinity(dt)||dt<=0)return phase;
   float step=dt/(open?OpenSeconds:CloseSeconds);
   return open?Math.Min(1,phase+step):Math.Max(0,phase-step);
  }
  // Zero velocity and acceleration at each end; no bounce through the breech.
  public static float Ease(float phase){
   float t=Math.Max(0,Math.Min(1,phase));return t*t*t*(t*(t*6-15)+10);
  }
 }
}
