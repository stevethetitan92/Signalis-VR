using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Camera computerGuiCamera;
 private Transform computerGuiEventRoot;
 private int computerGuiFrame=-1;
 private bool computerGuiPresented;
 private int computerGuiReports;
 // Observe completed native renders. Never render a second camera or change
 // the desktop targets, program state, cursor, or interaction routing.
 private void ObserveComputerGui(Camera view){
  if(!active||!stereo||desktopMouseOnly||stopping||!nativeEventContext||
   view==null||view==eyes[0]||view==eyes[1])return;
  var root=ComputerContentRoot(view);
  if(root==null)return;
  if(ComputerSurfaceName(root.name)=="ROT_PC")computerGuiEventRoot=root;
  try{ObserveComputerStage(view,root);}catch(System.Exception ex){computerStageFrame=-1;if(computerStageReports++<4)MelonLoader.MelonLogger.Warning("Computer drive capture fallback: "+ex.Message);}
  if(ComputerSurfaceName(view.name)=="PC Camera"&&view.transform.Find("PC_content")!=null&&
   view.targetTexture!=null&&view.targetTexture.name=="PCGUI"){
   computerGuiCamera=view;computerGuiFrame=Time.frameCount;
  }
 }
 private bool PresentComputerGui(){
  bool use=active&&stereo&&!desktopMouseOnly&&!stopping&&nativeEventContext&&
   !pauseMenuVisible&&!bookScreenVisible&&!modMenuOpen&&
   (global::PlayerState.gameState==global::PlayerState.gameStates.eventScreen||
    global::PlayerState.gameState==global::PlayerState.gameStates.dialogue)&&
   computerGuiEventRoot!=null&&computerGuiEventRoot.gameObject.activeInHierarchy&&
   computerGuiCamera!=null&&computerGuiCamera.isActiveAndEnabled&&computerGuiFrame==Time.frameCount;
  var source=use?computerGuiCamera.targetTexture:null;
  use=use&&source!=null&&source.name=="PCGUI"&&source.IsCreated()&&source.width>0&&source.height>0;
  computerStagePresented=use&&ComputerStageReady()&&(ComputerDesktopIdle()||global::PlayerState.gameState==global::PlayerState.gameStates.dialogue);
  if(computerStagePresented){source=computerStageCapture;if(computerStageReports++<4)MelonLoader.MelonLogger.Msg("COMPUTER DRIVES IMAGE: completed native computer stage including disk drives; frame="+computerStageFrame);}
  if(computerGuiPresented!=use){computerGuiPresented=use;ApplyPuzzleUV();}
  puzzleMaterial.mainTexture=use?source:puzzleCapture;
  int width=use?source.width:Screen.width,height=use?source.height:Screen.height;
  puzzleScreen.transform.localScale=new Vector3(2.4f,2.4f*height/Mathf.Max(1,width),1f);
  if(use&&computerGuiReports++<4)MelonLoader.MelonLogger.Msg("COMPUTER HEADSET IMAGE: "+source.name+" "+source.width+"x"+source.height+" freshFrame="+computerGuiFrame+"; desktop capture bypassed, native cursor/control unchanged.");
  return use;
 }
 private void ClearComputerGui(){ClearComputerCursor();ClearComputerStage();ClearComputerHint();computerGuiCamera=null;computerGuiEventRoot=null;computerGuiFrame=-1;computerGuiPresented=false;ApplyPuzzleUV();if(puzzleMaterial!=null)puzzleMaterial.mainTexture=puzzleCapture;}
}}

