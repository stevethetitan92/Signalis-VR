using System;
using System.IO;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Diagnostics;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking { public sealed partial class Tracking {
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int DrainFrameTraceDelegate([Out, MarshalAs(UnmanagedType.LPArray, SizeConst=10240)] double[] rows,int capacity,out double dropped);
    private DrainFrameTraceDelegate drainFrameTrace;
    private bool nativeTraceUnavailable;
    private readonly double[] nativeTraceRows=new double[512*20],managedTraceRows=new double[2048*20];
    private int managedTraceCount;
    private long managedTraceDropped;
    private TraceFileSink frameTraceWriter;
    private bool frameTraceDisabled;
    private float nextFrameTrace;
    private long tracePairs,traceLeftCalls,traceRightCalls,traceErrors;
    [DllImport("kernel32.dll")] private static extern uint GetCurrentThreadId();
    [DllImport("kernel32.dll")] private static extern bool QueryPerformanceCounter(out long value);
    private static long NativeTraceClock(){long value;QueryPerformanceCounter(out value);return value;}
    private static long stereoTraceId;
    private static long TraceClock() {return Stopwatch.GetTimestamp();}
    // No strings, allocations or file writes in the per-eye/maintenance hooks.
    private void TraceOperation(int kind,long start,int token=0) {
        if(frameTraceDisabled)return;
        if(managedTraceCount==2048){managedTraceDropped++;return;}
        int n=managedTraceCount++*20;
        managedTraceRows[n]=kind;managedTraceRows[n+1]=token;managedTraceRows[n+2]=Time.frameCount;
        managedTraceRows[n+3]=start;managedTraceRows[n+4]=TraceClock();
        managedTraceRows[n+18]=GetCurrentThreadId();managedTraceRows[n+19]=kind>=40?0:stereoTraceId;
    }
    private void ObserveFrameTrace() {
        if(frameTraceDisabled||Time.realtimeSinceStartup<nextFrameTrace)return;
        nextFrameTrace=Time.realtimeSinceStartup+0.73f; // Avoid aliasing the 1-second maintenance cadence.
        long started=TraceClock();
        try {
            if(frameTraceWriter==null) {
                var directory=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"UserData","SignalisVrDiagnostics");
                string path=Path.Combine(Path.Combine(directory,"session-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")),"frames.csv");
                frameTraceWriter=new TraceFileSink(path,"# UTC="+DateTime.UtcNow.ToString("o")+",qpc="+TraceClock()+",nativeQpc="+NativeTraceClock()+",frequency="+Stopwatch.Frequency+",version="+DiagnosticVersion);
                MarkerSuppression.TimingObserver=(kind,start)=>TraceOperation(kind,start);
                MelonLogger.Msg("VR FRAME TRACE: "+path+" (four rolling 8 MiB segments; whole session; F8 reports a problem).");
            }
            if(frameTraceWriter.Error!=null)throw new IOException(frameTraceWriter.Error);
            double dropped=0;int count=0;
            if(bridgeConfigured&&!nativeTraceUnavailable){try{if(drainFrameTrace==null)drainFrameTrace=NativeLibraries.Bind<DrainFrameTraceDelegate>(true,"DrainFrameTrace");count=drainFrameTrace(nativeTraceRows,512,out dropped);}catch(Exception ex){nativeTraceUnavailable=true;MelonLogger.Warning("Native timing unavailable; managed recorder continues: "+ex.Message);}}
            for(int i=0;i<count;i++) {
                int n=i*20;
                if(nativeTraceRows[n]==2) {
                    tracePairs++;int attempts=(int)nativeTraceRows[n+17];
                    if(attempts>0)traceLeftCalls++;if(attempts>1)traceRightCalls++;
                    if(nativeTraceRows[n+10]!=0||nativeTraceRows[n+11]!=0)traceErrors++;
                }

            }
            string status="# status qpc="+TraceClock()+" unityFrame="+Time.frameCount+" cap="+Application.targetFrameRate+" vsync="+QualitySettings.vSyncCount
                +" nativeDrain="+count+" nativeDropped="+(count<0?"unknown":dropped.ToString(CultureInfo.InvariantCulture))+" managedDropped="+managedTraceDropped
                +" nativeTraceUnavailable="+nativeTraceUnavailable+" gc0="+GC.CollectionCount(0)+" gc1="+GC.CollectionCount(1)+" gc2="+GC.CollectionCount(2)
                +" observedPairs="+tracePairs+" leftCalls="+traceLeftCalls+" rightCalls="+traceRightCalls+" pairErrors="+traceErrors
                +" left="+(textures[0]==null?"null":textures[0].width+"x"+textures[0].height)+" right="+(textures[1]==null?"null":textures[1].width+"x"+textures[1].height);
            frameTraceWriter.Enqueue(nativeTraceRows,count,managedTraceRows,managedTraceCount,status+"\n"+DiagnosticSnapshot(false));
            managedTraceCount=0;
            TraceOperation(29,started);
        }catch(Exception ex) {
            frameTraceDisabled=true;
            MarkerSuppression.TimingObserver=null;
            try {if(frameTraceWriter!=null)frameTraceWriter.Complete();}catch{}
            frameTraceWriter=null;
            MelonLogger.Warning("VR FRAME TRACE disabled: "+ex.Message);
        }
    }
    private void TraceEyeRender(Camera eye,int index) {
        long started=TraceClock();
        try {eye.Render();}finally {TraceOperation(10+index,started);}
    }
    private void TraceCaptureScreen(RenderTexture target) {
        long started=TraceClock();
        try {ScreenCapture.CaptureScreenshotIntoRenderTexture(target);}finally {TraceOperation(16,started);}
    }
}}















































