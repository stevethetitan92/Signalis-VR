using System;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  // Once per newly created hand, not per frame. Measure the actual skinned palm
  // surface in renderer-local coordinates, including bind-pose/bone effects.
  private void CalibrateRenderedPalm(int hand,Vector3 trackedPalm) {
   if(handPalmCalibrated[hand])return;
   var sample=new Mesh();
   try {
    handsRenderers[hand].BakeMesh(sample);
    var vertices=sample.vertices;var indices=handPalmVertices[hand];
    if(indices==null||indices.Length<3)throw new InvalidOperationException("Palm sample unavailable");
    Vector3 center=Vector3.zero;
    foreach(int index in indices){if(index<0||index>=vertices.Length)throw new InvalidOperationException("Palm sample topology changed");center+=vertices[index];}
    center/=indices.Length;
    if(float.IsNaN(center.x)||float.IsNaN(center.y)||float.IsNaN(center.z)||float.IsInfinity(center.x)||float.IsInfinity(center.y)||float.IsInfinity(center.z))throw new InvalidOperationException("Invalid skinned palm sample");
    var t=handsObjects[hand].transform;
    var before=t.TransformPoint(center)-trackedPalm;
    handPalmCenters[hand]=center;
    t.position=HandPlacement.PalmAnchor(trackedPalm,t.rotation,center,t.localScale);
    handPalmCalibrated[hand]=true;
    MelonLogger.Msg("HAND SKIN ANCHOR: hand="+hand+" oldSurfaceDelta="+WeaponVector(before)+" newSurfaceDelta="+WeaponVector(t.TransformPoint(center)-trackedPalm)+" localPalm="+WeaponVector(center));
   }finally {UnityEngine.Object.Destroy(sample);}
  }
 }
}
