using System;using System.Collections.Generic;using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool minesMapActive;private MinesMapLayout.Cell minesCurrent;
 private readonly List<Vector2[]> minesMapEdges=new List<Vector2[]>();private readonly List<Color> minesMapEdgeColors=new List<Color>();
 private static string MineVisit(string name){return "SignalisVR.Map.MinesVisited.v1:"+name;}
 private static MinesMapLayout.Cell MineCell(global::Room room){return room==null?null:MinesMapLayout.Find(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name,(int)room.floor,room.name);}
 private void MarkMineVisited(){var room=global::PlayerState.currentRoom;var c=MineCell(room);if(c!=null&&global::SProgress.GetInt(MineVisit(c.Name),0)==0){global::SProgress.SetInt(MineVisit(c.Name),1);nextModMapRefresh=0;}}
 private void MineEdge(Vector2 a,Vector2 b,Color color,float width=0){minesMapEdges.Add(new[]{a,b});minesMapEdgeColors.Add(color);VrMapStroke((a-modMapCenter)*modMapScale,(b-modMapCenter)*modMapScale,color,width>0?width:.075f*modMapScale,0,0);}
 private void MinePolygon(MinesMapLayout.Cell cell,bool current){
  var edge=current?new Color(1,.12f,.12f,.9f):new Color(.35f,.85f,1,.8f);var fill=edge;fill.r*=.12f;fill.g*=.12f;fill.b*=.12f;fill.a=.6f;
  // Scanline quads exactly cover convex and concave outlines; shared desktop/VR fill.
  float step=.2f;for(float y=cell.Low.y;y<cell.High.y;y+=step){float high=Math.Min(y+step,cell.High.y),sample=(y+high)*.5f;var cuts=new List<float>();
   for(int i=0;i<cell.Polygon.Length;i++){var a=cell.Polygon[i];var b=cell.Polygon[(i+1)%cell.Polygon.Length];if((a.y>sample)!=(b.y>sample))cuts.Add(a.x+(sample-a.y)*(b.x-a.x)/(b.y-a.y));}cuts.Sort();for(int i=0;i+1<cuts.Count;i+=2)MapRoomQuad(new Vector2(cuts[i],y),new Vector2(cuts[i+1],high),fill);
  }
  for(int i=0;i<cell.Polygon.Length;i++)MineEdge(cell.Polygon[i],cell.Polygon[(i+1)%cell.Polygon.Length],edge);
  // Small native-style dots only inside this polygon, not in the slope's empty corner.
  for(float x=cell.Low.x+.35f;x<cell.High.x;x+=.55f)for(float y=cell.Low.y+.35f;y<cell.High.y;y+=.55f)if(MinesMapLayout.Contains(cell.Polygon,new Vector2(x,y)))MapRoomQuad(new Vector2(x-.025f,y-.025f),new Vector2(x+.025f,y+.025f),new Color(edge.r*.2f,edge.g*.2f,edge.b*.2f,.6f));
 }
 private bool RefreshMinesMap(){
  var live=global::PlayerState.currentRoom;minesCurrent=MineCell(live);if(minesCurrent==null)return false;
  minesMapActive=true;MarkMineVisited();modMappedRoom=live;modMapCenter=MinesMapLayout.P(414,397.5f);modMapScale=.25f*UnitsPerMetre/49f;
  modCurrentLow=minesCurrent.Low;modCurrentHigh=minesCurrent.High;
  BeginMapStrokeMesh();minesMapEdges.Clear();minesMapEdgeColors.Clear();
  var revisions=new List<int>();var captions=new List<UniformRoomCaption>();foreach(var c in MinesMapLayout.Cells){Vector2 low,high;MinesMapLayout.CaptionBounds(c,out low,out high);captions.Add(new UniformRoomCaption{Low=low,High=high,Text=c.Label,Visible=mapComplete||c==minesCurrent||global::SProgress.GetInt(MineVisit(c.Name),0)!=0});}AddUniformRoomCaptions(captions);
  foreach(var cell in MinesMapLayout.Cells){bool current=cell==minesCurrent;if(!mapComplete&&!current&&global::SProgress.GetInt(MineVisit(cell.Name),0)==0)continue;MinePolygon(cell,current);
   // Captions are generated above with one common size for the entire map.
   global::Room room=null;foreach(var candidate in mapRooms)if(MineCell(candidate)==cell){room=candidate;break;}if(room==null&&current)room=live;
   if(room==null)continue;
   if(room.Doors!=null)for(int n=0;n<room.Doors.Count&&n<cell.Doors.Length;n++){
    var door=room.Doors[n];if(door==null)continue;var at=cell.Doors[n];string key=MapDoorHistory(door);int state=key==null?0:global::SProgress.GetInt(key+":observedState",0);if(!ValidObservedDoorState(state))state=0;
    int slot=-1;for(int j=0;j<modDoorPoints.Count;j++)if((modDoorPoints[j]-at).sqrMagnitude<.00001f){slot=j;break;}
    int revision=key==null?0:global::SProgress.GetInt(key+":revision",0);string label=state==4?(MapDoorRequiredKey(door)??global::SProgress.GetString(key+":keyName","")):null;
    if(slot<0){modDoorPoints.Add(at);modDoorStates.Add(state);modDoorKeyLabels.Add(label);modDoorRotations.Add(MinesMapLayout.DoorAngle(cell,at));revisions.Add(revision);}
    else if(PreferMapDoorObservation(modDoorStates[slot],revisions[slot],state,revision)){modDoorStates[slot]=state;modDoorKeyLabels[slot]=label;revisions[slot]=revision;}
    if(current){var w=door.transform.position;modDoorWorld.Add(new Vector2(w.x,w.y));modDoorMap.Add(at);}
   }
   // Allowed services only. Loot/enemy annotations in the reference are not map POIs.
   foreach(var point in mapObjects)if(point.Room==room&&point.Source!=null&&(point.Kind==1||point.Kind==2)&&!MapPuzzleGone(point)&&(mapComplete||global::SProgress.GetInt(point.Id,0)!=0)){
    var p=cell.Caption+new Vector2(point.Kind==1?-1.35f:1.35f,2.3f);p=MinesMapLayout.Clamp(cell,p);mapPointPositions.Add((p-modMapCenter)*modMapScale);mapPointKinds.Add(point.Kind);
   }
  }
  if(mapComplete||(global::SProgress.GetInt(MineVisit("Hatch Room"),0)!=0&&global::SProgress.GetInt(MineVisit("The Hole"),0)!=0)){
   var red=new Color(1,.12f,.12f,.95f);MineEdge(MinesMapLayout.P(222,494),MinesMapLayout.P(383,494),red);AddMapLabel((MinesMapLayout.P(300,482)-modMapCenter)*modMapScale,"DROP",.13f);
  }
  FinishMapStrokeMesh(ref joinedRoomMesh,ref joinedRoomRenderer,"JoinedMapRooms");joinedRoomRenderer.sortingOrder=0;
  ConfigureMineNavigation(live);
  var geometry=live.chunk;modRoomBoundsValid=false;modRoomBounds=new Bounds();
  // Native mesh combining can remove renderers or give them scene-wide
  // bounds. Room-owned solid colliders remain reliable geometry references.
  if(geometry!=null){int count=0;foreach(var collider in geometry.GetComponentsInChildren<Collider>(true)){if(collider==null||collider.isTrigger||count++>=1024)continue;var bounds=collider.bounds;if(bounds.size.sqrMagnitude<.0001f)continue;if(!modRoomBoundsValid){modRoomBounds=bounds;modRoomBoundsValid=true;}else modRoomBounds.Encapsulate(bounds);}}
  // Two threshold anchors plus independent room width retain motion on both
  // axes. Decorative centre offsets must not create a nearly singular fit.
  var pairs=new double[modDoorWorld.Count,4];for(int i=0;i<modDoorWorld.Count;i++){pairs[i,0]=modDoorWorld[i].x;pairs[i,1]=modDoorWorld[i].y;pairs[i,2]=modDoorMap[i].x;pairs[i,3]=modDoorMap[i].y;}
  if(modRoomBoundsValid)pairs=RoomMapProjection.MinePairs(pairs,modRoomBounds.min.x,modRoomBounds.min.y,modRoomBounds.size.x,modRoomBounds.size.y,minesCurrent.Low.x,minesCurrent.Low.y,minesCurrent.High.x-minesCurrent.Low.x,minesCurrent.High.y-minesCurrent.Low.y);
  modRoomProjectionValid=modRoomProjection.Fit(pairs);for(int i=0;i<modDoorPoints.Count;i++)if(mapHints&&modDoorStates[i]==4&&!string.IsNullOrWhiteSpace(modDoorKeyLabels[i]))AddMapKeyHint((modDoorPoints[i]-modMapCenter)*modMapScale,modDoorKeyLabels[i]);ReportModMap("");return true;
 }
 private void DrawMineMapDesktop(Vector2 center,float factor){for(int i=0;i<minesMapEdges.Count;i++){var a=(minesMapEdges[i][0]-modMapCenter)*modMapScale;var b=(minesMapEdges[i][1]-modMapCenter)*modMapScale;DrawMapLine(new Vector2(center.x+a.x*factor,center.y-a.y*factor),new Vector2(center.x+b.x*factor,center.y-b.y*factor),.075f*modMapScale*factor,minesMapEdgeColors[i]);}}
}}



