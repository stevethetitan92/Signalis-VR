using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool pauseControlsFailed;
 private void DestroyPauseControlsImage(){pauseControlsFailed=false;}
 private void UpdatePauseControlsImage(global::PauseMenuShowControls legend){}
 private void DrawPauseControlsImage(){
  if(pauseControlsFailed||modMenuOpen||Event.current.type!=EventType.Repaint)return;
  var pause=global::PauseMenu.instance;
  bool show=pause!=null&&pause.MenuObject!=null&&pause.MenuObject.activeInHierarchy&&pause.BaseMenu!=null&&pause.BaseMenu.activeInHierarchy&&!pause.cutscenePause&&(pause.OptionsMenu==null||!pause.OptionsMenu.activeInHierarchy)&&(pause.manual==null||!pause.manual.activeInHierarchy)&&(pause.areYouSure==null||!pause.areYouSure.activeInHierarchy);
  if(!show)return;
  var oldColor=GUI.color;int oldDepth=GUI.depth;
  try{
   if(controlsDiagram==null){controlsDiagram=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(controlsDiagram,Convert.FromBase64String(ControlsArtwork.Png),true))throw new InvalidOperationException("Controls artwork decode failed");controlsDiagram.filterMode=FilterMode.Point;controlsDiagram.wrapMode=TextureWrapMode.Clamp;}
   // Composite after all native/EnhancedResolution cameras, before the same
   // end-of-frame capture used for the headset pause screen. No camera guess.
   float w=Math.Min(Screen.width*.65f,Screen.height*.4f*(1644f/806f));float h=w*806f/1644f;
   GUI.depth=-9999;GUI.color=Color.white;
   var image=new Rect(Screen.width*.505f-w/2,Screen.height*.765f-h/2,w,h);GUI.DrawTextureWithTexCoords(image,controlsDiagram,new Rect(14f/1672f,127f/941f,1644f/1672f,806f/941f),true);DrawControlsBindings(image,true);
  }catch(Exception ex){pauseControlsFailed=true;MelonLoader.MelonLogger.Warning("Pause controls image unavailable: "+ex.Message);}
  finally{GUI.color=oldColor;GUI.depth=oldDepth;}
 }
}}


