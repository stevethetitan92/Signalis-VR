﻿using System;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private bool quickNonFirearmAudio;
  private PackAudio quickItemEquipSound;
  private void PlayWheelItemEquip(string id){
   if(QuickFirearm(id))return;
   try{if(quickItemEquipSound==null)quickItemEquipSound=new PackAudio(Convert.FromBase64String(HdAsset.Read("item-wheel-equip.pcm")),44100);quickItemEquipSound.Play(1f,false);}
   catch(Exception ex){MelonLoader.MelonLogger.Warning("Item wheel equip audio: "+ex.Message);}
  }
  internal static bool QuickFirearm(string id){id=WeaponFamily(id);return id=="Pistol"||id=="Revolver"||id=="Shotgun"||id=="Rifle"||id=="FlareGun"||id=="SMG";}
  private static bool AllowWheelEquipAudio(string __0){
   var q=weaponOwner;
   if(q==null||!q.quickNonFirearmAudio||!q.ProdVrMode()||string.IsNullOrEmpty(__0))return true;
   // Match only the native equip/draw event, leaving item-specific audio intact.
   if(q.quickInventory!=null&&__0==q.quickInventory.equipSound)return false;
   var attack=global::PlayerAttack.instance;
   return attack==null||__0!=attack.drawSound;
  }
  private bool playingOwnedFlareSound;
  private PackAudio userFlareShot;
  private Vector3 userFlareShotPosition;
  private Transform userFlareShotFollow;
  private global::Room userFlareShotRoom;
  private float userFlareShotAge;
  private bool userFlareShotActive;
  private void DestroyUserFlareSound(){userFlareShotActive=false;userFlareShotRoom=null;userFlareShotFollow=null;if(userFlareShot!=null)userFlareShot.Dispose();userFlareShot=null;}
  private void PlayOwnedFlareSound(Vector3 muzzlePosition,Transform follow=null){
   try{
    playingOwnedFlareSound=true;
    if(userFlareShot==null)userFlareShot=new PackAudio(Convert.FromBase64String(HdAsset.Read("flare-user-shot.pcm")),44100);
    userFlareShot.Stop();userFlareShotFollow=follow;userFlareShotPosition=muzzlePosition;userFlareShotRoom=global::PlayerState.currentRoom;userFlareShotAge=0;userFlareShotActive=true;
    userFlareShot.SpatialOnce(Quaternion.Inverse(stereoRotation)*(muzzlePosition-stereoPosition)/UnitsPerMetre,.5f);
   }catch(Exception ex){DestroyUserFlareSound();MelonLoader.MelonLogger.Warning("Flare shot audio failed: "+ex.Message);}finally{playingOwnedFlareSound=false;}
  }
  private void PollUserFlareSound(){
   if(!userFlareShotActive||userFlareShot==null)return;
   try{
    if(userFlareShotRoom!=global::PlayerState.currentRoom||!ProdVrMode()||userFlareShotAge>=2.404f){userFlareShot.Stop();userFlareShotActive=false;return;}
    if(global::PlayerState.paused||!WeaponGameplayReady()||pauseMenuVisible||modMenuOpen){userFlareShot.PauseLoop();return;}
    userFlareShotAge+=Mathf.Max(0,Time.deltaTime);
    // Follow the flight root; a landed projectile keeps its impact position.
    if(userFlareShotFollow!=null)userFlareShotPosition=userFlareShotFollow.position;
    userFlareShot.SpatialOnce(Quaternion.Inverse(stereoRotation)*(userFlareShotPosition-stereoPosition)/UnitsPerMetre,.5f);
   }catch(Exception ex){DestroyUserFlareSound();MelonLoader.MelonLogger.Warning("Flare spatial audio ended: "+ex.Message);}
  }
  private static bool CorrectNativeFlareShot(string __0){
   var q=weaponOwner;var w=global::InventoryManager.EquippedWeapon;
   if(q==null||q.playingOwnedFlareSound||!q.ProdVrMode()||w==null||w.parentItem==null||w.parentItem._item!=global::Items.itemlist.FlareGun)return true;
   // Both events belong to the base game. Correct only the player's pistol-shot
   // event while the flare is equipped; reloads and other sounds are untouched.
   return __0!=w.shotMod&&__0!="event:/Elster/Weapons/Pistol/Shot"&&__0!="event:/Elster/Weapons/FlareGun/Shot";
  }
  private void InstallQuickEquipAudio(HarmonyLib.Harmony h){
   h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"ReadyForAttack",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(FlareSoundScope),nameof(FlareSoundScope.Begin)),finalizer:new HarmonyMethod(typeof(FlareSoundScope),nameof(FlareSoundScope.End)));
   var flare=new HarmonyMethod(typeof(Tracking),nameof(CorrectNativeFlareShot));flare.priority=HarmonyLib.Priority.First;
   h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.RuntimeManager),"PlayOneShot",new[]{typeof(string),typeof(Vector3)}),prefix:flare);
   h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.RuntimeManager),"PlayOneShotAttached",new[]{typeof(string),typeof(GameObject)}),prefix:flare);
   var prefix=new HarmonyMethod(typeof(Tracking),nameof(AllowWheelEquipAudio));
   h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.RuntimeManager),"PlayOneShot",new[]{typeof(string),typeof(Vector3)}),prefix:prefix);
   h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.RuntimeManager),"PlayOneShotAttached",new[]{typeof(string),typeof(GameObject)}),prefix:prefix);
  }
  private static class FlareSoundScope {
   internal sealed class State {internal global::AnWeapon Weapon;internal string Sound;}
   internal static void Begin(out State __state){
    __state=null;var q=weaponOwner;var w=global::InventoryManager.EquippedWeapon;
    if(q==null||!q.ProdVrMode()||w==null||w.parentItem==null||w.parentItem._item!=global::Items.itemlist.FlareGun)return;
    __state=new State{Weapon=w,Sound=w.shotMod};w.shotMod=""; // The authorized projectile owns the one user-supplied flare sound.
   }
   internal static Exception End(Exception __exception,State __state){if(__state!=null&&__state.Weapon!=null)__state.Weapon.shotMod=__state.Sound;return __exception;}
  }
 }
}







