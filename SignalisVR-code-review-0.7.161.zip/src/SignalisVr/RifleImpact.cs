using System;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly GameObject[] rifleImpacts=new GameObject[128];
  private readonly MeshRenderer[] rifleImpactRenderers=new MeshRenderer[128];
  private readonly float[] rifleImpactExpiry=new float[128];
  private readonly MaterialPropertyBlock[] rifleImpactColors=new MaterialPropertyBlock[128];
  private Mesh rifleImpactMesh,enemyWoundMesh;
  private readonly bool[] rifleImpactEnemy=new bool[128];
  private readonly Transform[] rifleImpactAnchor=new Transform[128];
  private readonly Vector3[] rifleImpactLocalPoint=new Vector3[128],rifleImpactLocalNormal=new Vector3[128];
  private Material rifleImpactMaterial;
  private int rifleImpactNext,rifleImpactLogs;
  private bool rifleImpactFailed;
  private void RecordRifleImpact(WeaponPoseScope shot) { /* Custom enemy wounds and orange rings disabled by request. */ }
  private bool RecordShotgunPelletRings() {
   var attack=global::PlayerAttack.instance;if(attack==null)return false;var owner=FindRifleOwner(attack);var gun=EquippedControllerGun(owner);if(gun==null)return false;
   var pellets=gun.GetComponentsInChildren<global::AimLaser>(true);if(pellets.Length<2)return false;
   // These are the game's authored BUCK spread rays, including their individual
   // rotations and native hit positions. Do not invent a cone or apply damage.
   foreach(var pellet in pellets)if(pellet!=null&&pellet.gameObject.activeInHierarchy){pellet.Update();if(pellet.hitSomething){RaycastHit surface;Collider collider=null;if(Physics.Raycast(pellet.hitPos+pellet.hitNorm*(.015f*UnitsPerMetre),-pellet.hitNorm,out surface,.03f*UnitsPerMetre,pellet.mask))collider=surface.collider;AddWeaponImpact(pellet.hitPos,pellet.hitNorm,collider);}}
   return true;
  }
  private void AddWeaponImpact(Vector3 point,Vector3 normal,Collider collider) {
   if(normal.sqrMagnitude<1e-8f||float.IsNaN(point.x)||float.IsNaN(point.y)||float.IsNaN(point.z))return;
   var enemy=collider==null?null:collider.GetComponentInParent<global::EnemyController>();
   bool bloody=enemy!=null;int slot=rifleImpactNext;
   EnsureRifleImpact(slot);
   rifleImpactEnemy[slot]=bloody;
   rifleImpacts[slot].GetComponent<MeshFilter>().sharedMesh=bloody?EnemyWoundMesh():rifleImpactMesh;
   rifleImpactAnchor[slot]=bloody?EnemyImpactAnchor(enemy,point):null;
   if(rifleImpactAnchor[slot]!=null){rifleImpactLocalPoint[slot]=rifleImpactAnchor[slot].InverseTransformPoint(point);rifleImpactLocalNormal[slot]=rifleImpactAnchor[slot].InverseTransformDirection(normal);}
   var t=rifleImpacts[rifleImpactNext].transform;t.position=point+normal.normalized*(.002f*UnitsPerMetre);t.rotation=Quaternion.LookRotation(normal);t.localScale=Vector3.one*((bloody?.018f:.012f)*UnitsPerMetre);
   rifleImpactExpiry[rifleImpactNext]=Time.realtimeSinceStartup+2f;rifleImpactNext=(rifleImpactNext+1)%rifleImpacts.Length;
  }
  private void EnsureRifleImpact(int slot) {
   if(rifleImpacts[slot]!=null)return;
   if(rifleImpactMesh==null) {
    const int count=24;var vertices=new Vector3[count*2];var triangles=new int[count*6];
    for(int i=0;i<count;i++) {
     float a=i*(float)Math.PI*2f/count;var v=new Vector3(Mathf.Cos(a),Mathf.Sin(a),0f);
     vertices[i*2]=v;vertices[i*2+1]=v*.55f;
     int n=((i+1)%count)*2,k=i*6;
     triangles[k]=i*2;triangles[k+1]=n;triangles[k+2]=i*2+1;
     triangles[k+3]=n;triangles[k+4]=n+1;triangles[k+5]=i*2+1;
    }
    rifleImpactMesh=new Mesh();rifleImpactMesh.name="SignalisVR_RifleImpactRing";
    rifleImpactMesh.vertices=vertices;rifleImpactMesh.triangles=triangles;rifleImpactMesh.RecalculateBounds();
    var shader=Shader.Find("Sprites/Default");
    if(shader==null)throw new InvalidOperationException("Impact shader unavailable");
    rifleImpactMaterial=new Material(shader);rifleImpactMaterial.mainTexture=Texture2D.whiteTexture;rifleImpactMaterial.color=Color.white;
   }
   var go=new GameObject("SignalisVR_RifleImpact_"+slot);go.layer=30;UnityEngine.Object.DontDestroyOnLoad(go);
   go.AddComponent<MeshFilter>().sharedMesh=rifleImpactMesh;
   var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=rifleImpactMaterial;
   renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;renderer.receiveShadows=false;renderer.enabled=false;
   rifleImpactColors[slot]=new MaterialPropertyBlock();rifleImpacts[slot]=go;rifleImpactRenderers[slot]=renderer;
  }
  private Transform EnemyImpactAnchor(global::EnemyController enemy,Vector3 point) {
   Transform closest=enemy.transform;float distance=float.MaxValue;
   foreach(var skin in enemy.GetComponentsInChildren<SkinnedMeshRenderer>(true))
    foreach(var bone in skin.bones){if(bone==null)continue;float d=(bone.position-point).sqrMagnitude;if(d<distance){distance=d;closest=bone;}}
   return closest;
  }
  private Mesh EnemyWoundMesh() {
   if(enemyWoundMesh!=null)return enemyWoundMesh;
   // Filled dark puncture, irregular red tissue and a broken translucent blood edge.
   const int n=24;var v=new Vector3[1+n*3];var colors=new Color[v.Length];var triangles=new int[n*15];
   colors[0]=new Color(.025f,.004f,.006f,1);
   for(int i=0;i<n;i++){
    float a=i*(float)Math.PI*2/n;float irregular=1f+.16f*Mathf.Sin(i*2.7f)+.1f*Mathf.Cos(i*4.3f);
    var axis=new Vector3(Mathf.Cos(a),Mathf.Sin(a),0);
    v[1+i]=axis*(.25f*irregular);colors[1+i]=new Color(.07f,.005f,.009f,1);
    v[1+n+i]=axis*(.55f*irregular);colors[1+n+i]=new Color(.38f+.08f*Mathf.Sin(i),.015f,.023f,.95f);
    v[1+2*n+i]=axis*irregular;colors[1+2*n+i]=new Color(.25f,.005f,.013f,0);
    int j=(i+1)%n,k=i*15;triangles[k]=0;triangles[k+1]=1+i;triangles[k+2]=1+j;
    for(int band=0;band<2;band++){int x=1+band*n+i,y=1+band*n+j;k=i*15+3+band*6;triangles[k]=x;triangles[k+1]=x+n;triangles[k+2]=y;triangles[k+3]=y;triangles[k+4]=x+n;triangles[k+5]=y+n;}
   }
   enemyWoundMesh=new Mesh();enemyWoundMesh.name="SignalisVR_BloodyBulletHole";enemyWoundMesh.vertices=v;enemyWoundMesh.colors=colors;enemyWoundMesh.triangles=triangles;enemyWoundMesh.RecalculateBounds();return enemyWoundMesh;
  }
  private void ShowRifleImpacts() {
   if(mouseWeaponTest? !MouseWeaponReady():(!QuestUnifiedReady()||pauseMenuVisible||bookScreenVisible||dialogueScreenVisible))return;
   for(int i=0;i<rifleImpacts.Length;i++)if(rifleImpactRenderers[i]!=null)
    {float alpha=RingFade.Alpha(Time.realtimeSinceStartup-(rifleImpactExpiry[i]-2f));bool visible=Time.realtimeSinceStartup<rifleImpactExpiry[i];
     if(rifleImpactEnemy[i]){var anchor=rifleImpactAnchor[i];if(anchor==null)visible=false;else {var n=anchor.TransformDirection(rifleImpactLocalNormal[i]).normalized;rifleImpacts[i].transform.SetPositionAndRotation(anchor.TransformPoint(rifleImpactLocalPoint[i])+n*(.002f*UnitsPerMetre),Quaternion.LookRotation(n));}}
     rifleImpactRenderers[i].enabled=visible;rifleImpactColors[i].SetColor("_Color",rifleImpactEnemy[i]?new Color(1,1,1,alpha):new Color(1f,.7f,.15f,alpha));rifleImpactRenderers[i].SetPropertyBlock(rifleImpactColors[i]);}
  }
  private void HideRifleImpacts(bool clear=false) {
   for(int i=0;i<rifleImpacts.Length;i++) {
    if(rifleImpactRenderers[i]!=null)rifleImpactRenderers[i].enabled=false;
    if(clear){rifleImpactExpiry[i]=0f;rifleImpactAnchor[i]=null;rifleImpactEnemy[i]=false;}
   }
  }
 }
}

