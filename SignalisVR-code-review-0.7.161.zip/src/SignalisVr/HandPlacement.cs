using UnityEngine;
namespace SignalisVrTracking {
 internal static class HandPlacement {
  // Runtime-reported device-local handgrip translation, in metres. Convert once
  // with the raw controller rotation. No empirical world/local height offset.
  internal static Vector3 CalibrateGrip(Vector3 world,Quaternion controllerRotation,float unitsPerMetre,Vector3 localGrip) {
   return world+controllerRotation*new Vector3(localGrip.x*unitsPerMetre,localGrip.y*unitsPerMetre,localGrip.z*unitsPerMetre);
  }
  // Use the tracked origin directly. A screenshot cannot establish a physical
  // centimetre correction; fix mesh/grip anchoring instead of guessing one.
  internal static Vector3 TrackedPalm(Vector3 tracked,Quaternion rotation,float unitsPerMetre) {
   return tracked;
  }
  internal static Vector3 WeaponAnchor(Vector3 palm,Quaternion delta,Vector3 nativePalm,Vector3 nativeModel) {
   return palm-delta*(nativePalm-nativeModel);
  }
  // Controller position belongs at the palm, rather than at the wrist seam.
  internal static Vector3 PalmAnchor(Vector3 controller,Quaternion rotation,Vector3 localPalm,Vector3 scale) {
   return controller-rotation*Vector3.Scale(localPalm,scale);
  }
 }
}



