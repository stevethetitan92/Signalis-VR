﻿using UnityEngine;
namespace SignalisVrTracking {
 internal enum ElsterGripKind { Open, Fist, Handle, Trigger, Magazine, Round, Loader, Slide, ForeEnd, ShellPinch }
 public sealed partial class Tracking {
  // These poses are authored on Elster's bind skeleton. No legacy hand geometry,
  // copied bone rotations, legacy pose bounds, or hand scale enters this path.
  private void ResolveElsterGrip(int hand,out Vector3 palm,out Quaternion basis,out ElsterGripKind pose){
   var tracked=controllerMarkers[hand].transform;
   palm=tracked.position;
   basis=WeaponAimPolicy.ControllerRotation(tracked.rotation)*Quaternion.Euler(0,0,hand==0?90:-90);
   pose=(hand==0?manualLeftGrip:modMenuRightGrip)?ElsterGripKind.Fist:ElsterGripKind.Open;
   if(eventWalkStereo){pose=ElsterGripKind.Open;return;}
   if(hand==0){
    if(shotgunPumpHeld&&SelectedActive("Shotgun")&&selectedMoving!=null){
     var b=selectedMoving.GetComponent<MeshFilter>().sharedMesh.bounds;
     palm=selectedMoving.transform.TransformPoint(new Vector3(b.center.x,b.min.y-.014f,b.center.z));
     basis=rightWeaponRotation*Quaternion.LookRotation(Vector3.right,Vector3.down);pose=ElsterGripKind.ForeEnd;return;
    }
    if(revolverRod.Held&&SelectedActive("Revolver")){palm=revolverRodContact+rightWeaponRotation*new Vector3(.0296f,.0293f,.103f)*UnitsPerMetre;basis=rightWeaponRotation*Quaternion.LookRotation(Vector3.back,Vector3.up);pose=ElsterGripKind.Slide;return;}
    if(hdSupportHeld){
     bool underneath=hdSupportKind=="Rifle"||hdSupportKind=="Shotgun"||hdSupportKind=="SMG";
     var support=new Vector3(-.029f,-.027f,.008f);
     if(hdSupportKind=="SMG")support=new Vector3(0,.0435f,.24f);
     if(hdSupportKind=="Rifle")support=new Vector3(hdSupportLocal.x,-.0162f,hdSupportLocal.z);
     if(hdSupportKind=="Shotgun"&&selectedMoving!=null){var b=selectedMoving.GetComponent<MeshFilter>().sharedMesh.bounds;support=new Vector3(b.center.x,b.min.y-.014f,b.center.z)+selectedMoving.transform.localPosition;}
     palm=rightWeaponPosition+rightWeaponRotation*support*UnitsPerMetre;
     basis=rightWeaponRotation*(underneath?Quaternion.LookRotation(Vector3.right,Vector3.down):Quaternion.Euler(hdSupportKind=="Revolver"?15:0,0,0)*Quaternion.Euler(0,0,90));pose=ElsterGripKind.ForeEnd;return;
    }
    if(manualMagazine!=null&&manualMagazine.enabled&&manualReload.Active){ElsterObjectGrip(manualMagazine.transform,hand,ElsterGripKind.Magazine,out palm,out basis,out pose);return;}
    if(AdditionalHoldingAmmo()&&additionalAmmo!=null){
     string kind=additionalVisualKind;
     if(ElsterAmmoGripData.Has(kind)){
      var item=additionalAmmo.transform;
      palm=item.position+item.rotation*(ElsterAmmoGripData.Palm(kind))*UnitsPerMetre;
      basis=item.rotation*(ElsterAmmoGripData.Basis(kind));
      pose=kind=="Revolver"?ElsterGripKind.Loader:ElsterGripKind.Round;return;
     }
     ElsterObjectGrip(additionalAmmo.transform,hand,kind=="SMG"?ElsterGripKind.Magazine:kind=="Revolver"?ElsterGripKind.Loader:ElsterGripKind.Round,out palm,out basis,out pose);return;
    }
    if(shotgunShell!=null&&shotgunShell.enabled){pose=ElsterGripKind.ShellPinch;return;}
    if(manualReload.Stage==ManualReloadPolicy.Step.RackHolding&&SelectedActive("Pistol")){
     var slideBounds=selectedMoving.GetComponent<MeshFilter>().sharedMesh.bounds;
     palm=selectedMoving.transform.TransformPoint(new Vector3(0,slideBounds.max.y+.014f,slideBounds.min.z+.025f));basis=rightWeaponRotation*Quaternion.LookRotation(Vector3.left,Vector3.up);pose=ElsterGripKind.Slide;return;
    }
    if(smgHandleStroke.Held){palm=additionalBolt+rightWeaponRotation*new Vector3(-.035f,.014f,-.03f)*UnitsPerMetre;basis=rightWeaponRotation;pose=ElsterGripKind.Slide;return;}
    if(rifleBarrelHeld){palm=RiflePalmWorld();basis=RifleBarrelRotation()*Quaternion.LookRotation(Vector3.right,Vector3.down);pose=ElsterGripKind.ForeEnd;return;}
   }else{
    if(ProdEligible()&&prodPoseValid){palm=prodResolved+prodResolvedRotation*ProdGripPalm*UnitsPerMetre;basis=prodResolvedRotation*Quaternion.Euler(90,0,0)*Quaternion.Euler(0,0,-90);pose=ElsterGripKind.Handle;return;}
    var w=global::InventoryManager.EquippedWeapon;
    if(w!=null&&w.parentItem!=null&&QuickFirearm(WeaponFamily(w.parentItem._item.ToString()))){
     string kind=WeaponFamily(w.parentItem._item.ToString());
     // Authored trigger-grip transforms, converted through the model importer.
     // Rifle's grip is X=-55.82 degrees, revolver's X=-75, versus pistol X=-90.
     float tilt=kind=="Rifle"?34.18f:kind=="Revolver"?15f:0;
     var grip=Quaternion.Euler(tilt,0,0);var origin=kind=="FlareGun"?new Vector3(.002f,.003f,0):kind=="SMG"?new Vector3(0,-.012f,0):Vector3.zero;
     palm=rightWeaponPosition+rightWeaponRotation*(origin+grip*new Vector3(.025f,0,0))*UnitsPerMetre;
     if(kind!="Rifle")palm+=rightWeaponRotation*new Vector3(-.003f,-.013f,.010f)*UnitsPerMetre;
     basis=rightWeaponRotation*grip*Quaternion.Euler(0,0,-90);pose=ElsterGripKind.Trigger;return;
    }
    if(heldQuickHealth!=null){palm=tracked.position;basis=WeaponAimPolicy.ControllerRotation(tracked.rotation)*Quaternion.Euler(0,0,-90);pose=heldQuickHealth._item==global::Items.itemlist.Health25?ElsterGripKind.Round:ElsterGripKind.Trigger;}
    if(ThermiteEligible()&&thermiteHand!=null){palm=tracked.position;basis=WeaponAimPolicy.ControllerRotation(tracked.rotation)*Quaternion.Euler(0,0,-90);pose=ElsterGripKind.Handle;}
   }
  }
  private void ElsterObjectGrip(Transform item,int hand,ElsterGripKind kind,out Vector3 palm,out Quaternion basis,out ElsterGripKind pose){
   pose=kind;float radius=kind==ElsterGripKind.Magazine?.025f:kind==ElsterGripKind.Loader?.019f:.018f;
   // Item local +Y is the cartridge axis; preserve its actual guided rotation.
   palm=item.position+item.rotation*new Vector3(hand==0?-radius:radius,kind==ElsterGripKind.Loader?-.035f:0,0)*UnitsPerMetre;
   basis=item.rotation*Quaternion.Euler(0,0,hand==0?90:-90);
  }
  private void PoseElsterDigits(int hand,ElsterGripKind pose,float amount){
   string side=hand==0?".l":".r";string[] names={"thumb","index","middle","ring","little"};
   var values=pose==ElsterGripKind.Fist?(hand==0?ElsterFistData.Left:ElsterFistData.Right):ElsterGripPoseData.Get(hand,pose);
   if(hand==1&&heldQuickHealth!=null&&heldQuickHealth._item==global::Items.itemlist.Health25)values=ElsterPatchGripData.Pose;
   else if(hand==1&&heldQuickHealth!=null)values=ElsterGripPoseData.SprayRight;
   if(hand==0&&pose==ElsterGripKind.Slide&&(smgHandleStroke.Held||SelectedActive("Pistol")))values=ElsterGripPoseData.SlideOverLeft;
   if(hand==0&&pose==ElsterGripKind.Slide&&revolverRod.Held&&SelectedActive("Revolver"))values=ElsterGripPoseData.EjectorLeft;
   if(hand==0&&pose==ElsterGripKind.ShellPinch)values=ElsterShellPinchData.Pose;
   if(hand==0&&pose==ElsterGripKind.ForeEnd){
    if(rifleBarrelHeld||SelectedActive("Shotgun")||SelectedActive("Rifle")||IsXiphias())values=ElsterGripPoseData.UnderBarrelLeft;
    else if(hdSupportHeld)values=ElsterGripPoseData.SharedSupportLeft;
   }
   if(hand==0&&AdditionalHoldingAmmo()){
    if(ElsterAmmoGripData.Has(additionalVisualKind))values=ElsterAmmoGripData.Pose(additionalVisualKind);
   }
   if(hand==1&&pose==ElsterGripKind.Trigger&&heldQuickHealth==null){
    values=SelectedActive("Rifle")?ElsterGripPoseData.RifleRight:ElsterGripPoseData.SharedPrimaryRight;
   }
   if(hand==1&&pose==ElsterGripKind.Handle){if(ProdEligible()&&prodPoseValid)values=ElsterGripPoseData.ProdRight;else if(ThermiteEligible()&&thermiteHand!=null)values=ElsterGripPoseData.ThermiteRight;}
   for(int f=0;f<5;f++)for(int j=1;j<=3;j++){
    int k=(f*3+j-1)*4;var q=values==null?Quaternion.identity:new Quaternion(values[k],values[k+1],values[k+2],values[k+3]);
    if(activeSavedGrip[hand]!=null)q=activeSavedGrip[hand].Fingers[f*3+j-1];
    // Firearm index motion is solved once from the moving trigger after the resting pose.
    if(hand==1&&heldQuickHealth!=null&&healthUsed){
     if(heldQuickHealth._item==global::Items.itemlist.Health25){float use=RepairPatchMotion.Amount(Time.realtimeSinceStartup-healthSqueezeTime);var fist=ElsterFistData.Right;q=Quaternion.Slerp(q,new Quaternion(fist[k],fist[k+1],fist[k+2],fist[k+3]),use);}
     else if(f==1){float use=RepairSprayUseMotion.Amount(Time.realtimeSinceStartup-healthSqueezeTime);var curl=(elsterRest[EB("little1.r")]-elsterRest[EB("index1.r")]).normalized;q=Quaternion.AngleAxis(use*12,curl)*q;}
    }
    elsterBones[EB(names[f]+j+side)].localRotation=Quaternion.Slerp(Quaternion.identity,q,amount);
   }
  }
  private void FitElsterTriggerContact(int hand,ElsterGripKind pose){
   if(hand!=1||pose!=ElsterGripKind.Trigger||heldQuickHealth!=null||GunSqueeze()<=.0001f||elsterCurl[hand]<.999f)return;
   MeshRenderer trigger=null;
   if(IsXiphias()&&xiphiasTrigger!=null)trigger=xiphiasTrigger;
   else if(SelectedActive(selectedKind)){for(int i=0;i<selectedParts.Count;i++)if(selectedRoles[i]==4){trigger=selectedParts[i];break;}}
   if(trigger==null||trigger.transform.parent==null)return;
   int tip=EB("index3.r"),parent=EB("index2.r");
   var endOffset=(elsterRest[tip]-elsterRest[parent])*.8f;
   var restingPoint=elsterBones[tip].TransformPoint(endOffset);
   // Imported trigger meshes have identity local transform at rest. Carry the
   // authored finger-to-trigger offset through the actual live trigger transform.
   // This follows each trigger pivot without snapping the resting grip to a box center.
   var contact=trigger.transform.TransformPoint(trigger.transform.parent.InverseTransformPoint(restingPoint));
   var joints=new Transform[]{elsterBones[EB("index1.r")],elsterBones[EB("index2.r")],elsterBones[tip]};
   var rest=new Quaternion[]{joints[0].localRotation,joints[1].localRotation,joints[2].localRotation};
   for(int pass=0;pass<12;pass++){
    if((elsterBones[tip].TransformPoint(endOffset)-contact).sqrMagnitude<.00000025f*UnitsPerMetre*UnitsPerMetre)break;
    for(int joint=2;joint>=0;joint--){
     var bone=joints[joint];var from=elsterBones[tip].TransformPoint(endOffset)-bone.position;var to=contact-bone.position;
     if(from.sqrMagnitude<1e-10f||to.sqrMagnitude<1e-10f)continue;
     var delta=Quaternion.FromToRotation(from,to);float angle=Quaternion.Angle(Quaternion.identity,delta);
     bone.rotation=Quaternion.Slerp(Quaternion.identity,delta,angle>2?2/angle:1)*bone.rotation;
     bone.localRotation=Quaternion.RotateTowards(rest[joint],bone.localRotation,18);
    }
   }
  }
 }
}
