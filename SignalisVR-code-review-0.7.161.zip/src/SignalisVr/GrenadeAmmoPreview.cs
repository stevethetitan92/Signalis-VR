using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private readonly Dictionary<Transform,GameObject> grenadeInventory=new Dictionary<Transform,GameObject>();
 private readonly Dictionary<Renderer,bool> grenadeInventoryOriginals=new Dictionary<Renderer,bool>();
 private void ShowGrenadeInventory(Transform root){
  if(root==null)return;if(grenadeInventory.Count>16)ClearGrenadeInventory();
  if(grenadeInventory.ContainsKey(root))return;
  var native=root.GetComponentsInChildren<Renderer>(true);if(native.Length==0)return;
  var bounds=native[0].bounds;foreach(var r in native)bounds.Encapsulate(r.bounds);
  var model=GetHdRound("Grenade");var obj=new GameObject("SignalisVR_GrenadeAmmoInspect");obj.layer=native[0].gameObject.layer;obj.transform.SetParent(root,false);
  obj.transform.position=bounds.center;float height=Mathf.Max(.0001f,bounds.size.y);float scale=height/Mathf.Max(.0001f,model.Mesh.bounds.size.y*Mathf.Abs(root.lossyScale.y));obj.transform.localScale=Vector3.one*scale;
  obj.AddComponent<MeshFilter>().sharedMesh=model.Mesh;obj.AddComponent<MeshRenderer>().sharedMaterials=model.Materials;
  foreach(var r in native){grenadeInventoryOriginals[r]=r.forceRenderingOff;r.forceRenderingOff=true;}grenadeInventory[root]=obj;
 }
 private void ClearGrenadeInventory(){foreach(var p in grenadeInventoryOriginals)if(p.Key!=null)p.Key.forceRenderingOff=p.Value;grenadeInventoryOriginals.Clear();foreach(var o in grenadeInventory.Values)if(o!=null)UnityEngine.Object.Destroy(o);grenadeInventory.Clear();}
}}
