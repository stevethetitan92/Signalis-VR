namespace SignalisVrTracking {
 public static class ProdDurability {
  public const int Capacity=3;
  public static int Normalize(int uses){return uses<1||uses>Capacity?Capacity:uses;}
  // Zero means this rod is spent. The next rod starts at Capacity.
  public static int Hit(int uses){return Hit(uses,false);}
  public static int Hit(int uses,bool infinite){return infinite?Normalize(uses):Normalize(uses)-1;}
 }
}

