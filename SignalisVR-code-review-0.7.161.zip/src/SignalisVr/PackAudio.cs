using System;
using System.IO;
namespace SignalisVrTracking {
 // Use the game's FMOD system after runtime AudioClip population failed in
 // the headset log. Load a cached WAV by filename to avoid interop struct layout.
 internal sealed class PackAudio : IDisposable {
  internal readonly float Duration;
  private FMOD.Sound sound;private FMOD.Channel loopChannel;private bool disposed,loopStarted;
  internal PackAudio(byte[] pcm,int rate){
   if(pcm==null||pcm.Length==0||(pcm.Length&1)!=0||rate<8000||rate>192000)throw new ArgumentException("Invalid mono PCM audio");
   Duration=pcm.Length/(rate*2f);
   byte[] wave;using(var stream=new MemoryStream())using(var w=new BinaryWriter(stream)){
    w.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));w.Write(36+pcm.Length);w.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));
    w.Write(16);w.Write((short)1);w.Write((short)1);w.Write(rate);w.Write(rate*2);w.Write((short)2);w.Write((short)16);
    w.Write(System.Text.Encoding.ASCII.GetBytes("data"));w.Write(pcm.Length);w.Write(pcm);wave=stream.ToArray();
   }
   // Use FMOD's filename overload: the generated IL2CPP extended-info layout
   // was rejected with ERR_INVALID_PARAM on the headset. PCM stays embedded;
   // a content-addressed WAV cache avoids passing any managed native struct.
   string hash;using(var sha=System.Security.Cryptography.SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(wave)).Replace("-","");
   var directory=Path.Combine(Path.GetTempPath(),"SignalisVrAudio");Directory.CreateDirectory(directory);
   var path=Path.Combine(directory,hash+".wav");
   if(!File.Exists(path)||new FileInfo(path).Length!=wave.Length)File.WriteAllBytes(path,wave);
   Check(FMODUnity.RuntimeManager.CoreSystem.createSound(path,FMOD.MODE._2D,out sound));
  }
  private static void Check(FMOD.RESULT r){if(r!=FMOD.RESULT.OK)throw new InvalidOperationException("Pack FMOD audio: "+r);}
  internal void Play(float volume,bool loop){
   if(disposed)return;bool playing=false;if(loop&&loopStarted)loopChannel.isPlaying(out playing);if(loop&&playing){Check(loopChannel.setPaused(false));Check(loopChannel.setVolume(volume));return;}
   FMOD.ChannelGroup group;Check(FMODUnity.RuntimeManager.CoreSystem.getMasterChannelGroup(out group));FMOD.Channel channel;
   Check(FMODUnity.RuntimeManager.CoreSystem.playSound(sound,group,true,out channel));
   try{Check(channel.setMode(loop?FMOD.MODE.LOOP_NORMAL:FMOD.MODE.LOOP_OFF));Check(channel.setVolume(volume));Check(channel.setPaused(false));if(loop){loopChannel=channel;loopStarted=true;}}
   catch{channel.stop();throw;}
  }
  internal void Stop(){if(!disposed&&loopStarted)loopChannel.stop();loopStarted=false;}
  internal void PauseLoop(){if(!disposed&&loopStarted)Check(loopChannel.setPaused(true));}
  internal void SpatialLoop(UnityEngine.Vector3 relative,float volume){
   Spatial(relative,volume,true);
  }
  internal void SpatialOnce(UnityEngine.Vector3 relative,float volume){Spatial(relative,volume,false);}
  private void Spatial(UnityEngine.Vector3 relative,float volume,bool repeat){
   if(disposed)return;bool playing=false;if(loopStarted)loopChannel.isPlaying(out playing);
   if(!repeat&&loopStarted&&!playing)return;
   if(!playing){FMOD.ChannelGroup group;Check(FMODUnity.RuntimeManager.CoreSystem.getMasterChannelGroup(out group));Check(FMODUnity.RuntimeManager.CoreSystem.playSound(sound,group,true,out loopChannel));loopStarted=true;}
   Check(loopChannel.setMode((repeat?FMOD.MODE.LOOP_NORMAL:FMOD.MODE.LOOP_OFF)|FMOD.MODE._2D));
   Check(loopChannel.setPan(0));Check(loopChannel.setVolume(volume));Check(loopChannel.setPaused(false));
  }  public void Dispose(){if(disposed)return;Stop();sound.release();disposed=true;}
 }
}


