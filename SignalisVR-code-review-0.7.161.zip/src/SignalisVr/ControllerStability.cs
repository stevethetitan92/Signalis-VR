using System;
namespace SignalisVrTracking {
 // Tracking-space filter: player locomotion, world origin and head pose never
 // enter this history. Fast deliberate motion bypasses the resting smoothing.
 internal sealed class ControllerStability {
  private bool ready;
  private uint device;
  private long frame;
  private float time;
  internal float Weight(uint currentDevice,long currentFrame,float now,float distanceMetres,float angleDegrees,bool reacquired) {
   float dt=now-time;
   if(ready&&!reacquired&&device==currentDevice&&frame==currentFrame)return 0f;
   if(!ready||reacquired||device!=currentDevice||dt<=0f||dt>.1f||distanceMetres>.35f||angleDegrees>70f) {
    ready=true;device=currentDevice;frame=currentFrame;time=now;return 1f;
   }
   frame=currentFrame;time=now;
   float speed=Math.Max(distanceMetres/(dt*.8f),angleDegrees/(dt*180f));
   double tau=.018/(1.0+20.0*speed*speed);
   return (float)(1.0-Math.Exp(-dt/tau));
  }
 }
}
