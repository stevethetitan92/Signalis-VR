using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static float ProdFractureHeight(Vector3 p){return p.z+.006f*Mathf.Sin(p.x*410f)+.003f*Mathf.Sin(p.y*530f+p.x*150f);}
 private static List<Vector3> ClipProdFace(List<Vector3> face,float plane,bool above,List<Vector3> cuts){
  var output=new List<Vector3>();if(face.Count==0)return output;
  var a=face[face.Count-1];float da=ProdFractureHeight(a)-plane;bool insideA=above?da>=0:da<=0;
  foreach(var b in face){float db=ProdFractureHeight(b)-plane;bool insideB=above?db>=0:db<=0;
   if(insideA!=insideB){var v=Vector3.Lerp(a,b,da/(da-db));output.Add(v);cuts.Add(v);}
   if(insideB)output.Add(b);a=b;da=db;insideA=insideB;
  }return output;
 }
 private static void ProdTriangle(List<Vector3> v,List<int> t,Vector3 a,Vector3 b,Vector3 c){int n=v.Count;v.Add(a);v.Add(b);v.Add(c);t.Add(n);t.Add(n+1);t.Add(n+2);}
 private Mesh FractureProdMesh(float low,float high){
  var vertices=new List<Vector3>();var triangles=new List<int>();
  foreach(var part in prodParts){
   var mesh=part.GetComponent<MeshFilter>().sharedMesh;var source=mesh.vertices;var indices=mesh.triangles;
   var lower=new List<Vector3>();var upper=new List<Vector3>();
   for(int i=0;i<source.Length;i++)source[i]=part.transform.localPosition+part.transform.localRotation*Vector3.Scale(source[i],part.transform.localScale);
   for(int i=0;i<indices.Length;i+=3){var face=new List<Vector3>{source[indices[i]],source[indices[i+1]],source[indices[i+2]]};face=ClipProdFace(face,low,true,lower);face=ClipProdFace(face,high,false,upper);for(int j=1;j+1<face.Count;j++)ProdTriangle(vertices,triangles,face[0],face[j],face[j+1]);}
   // Close fracture surfaces; duplicated opposite faces are safe for unlit dark debris.
   foreach(var ring in new[]{lower,upper}){if(ring.Count<2)continue;var centre=Vector3.zero;foreach(var point in ring)centre+=point;centre/=ring.Count;for(int j=0;j+1<ring.Count;j+=2)ProdTriangle(vertices,triangles,centre,ring[j],ring[j+1]);}
  }
  if(vertices.Count==0)return null;
  var result=new Mesh();result.name="Jagged spent prod";result.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;result.vertices=vertices.ToArray();result.triangles=HandSurfaceTopology.DoubleSided(triangles.ToArray());result.RecalculateNormals();result.RecalculateBounds();return result;
 }
}}
