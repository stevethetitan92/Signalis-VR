using System;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static int smgReadyDepth;
  private static bool smgAudioWarning;
  private static void SmgReadyAudioBegin(){smgReadyDepth++;}
  private static Exception SmgReadyAudioEnd(Exception __exception){smgReadyDepth=Math.Max(0,smgReadyDepth-1);return __exception;}
  // Harmony keys __state by declaring type. The existing Tracking shot hook
  // owns a WeaponPoseScope; audio must have a different declaring type.
  private static class SmgAudioPatch {
  internal static void SmgShotAudioBegin(global::PlayerAttack __instance,out int __state){
   __state=-1;var q=weaponOwner;var w=__instance.weapon;
   if(q!=null&&smgReadyDepth==0&&w!=null&&w.parentItem!=null&&w.parentItem._item==global::Items.itemlist.SMG)__state=w.magAmmo;
  }
  internal static void SmgShotAudioEnd(global::PlayerAttack __instance,int __state){
   var w=__instance.weapon;if(__state<=0||w==null||w.magAmmo>=__state)return;
   try{if(!string.IsNullOrEmpty(w.shotMod))FMODUnity.RuntimeManager.PlayOneShot(w.shotMod,Vector3.zero);}
   catch(Exception e){if(!smgAudioWarning){smgAudioWarning=true;MelonLoader.MelonLogger.Warning("SMG continuing-shot sound unavailable: "+e.Message);}}
  }
  }
  // Observe the native ammo decrement before the optional infinite-ammo postfix refills it.
  private void InstallSmgShotAudio(HarmonyLib.Harmony h){
   h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"ReadyForAttack",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(SmgReadyAudioBegin)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(SmgReadyAudioEnd)));
   h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"RaycastShot",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(SmgAudioPatch),nameof(SmgAudioPatch.SmgShotAudioBegin)),postfix:new HarmonyMethod(typeof(SmgAudioPatch),nameof(SmgAudioPatch.SmgShotAudioEnd)){before=new[]{"signalis.vr.nomarkers.lifeammo"}});
  }
 }
}

