using System;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private global::PEN_Awakening cryoOpening;
 private Camera cryoStereoCamera,cryoSource;
 private Camera cryoRoomCamera;
 private float nextCryoLookup;
 private bool cryoRoomWasDisabled;
 private static float CryoFramingDistance(float size,float fov){
  return Mathf.Max(.01f,size)/Mathf.Tan(Mathf.Clamp(fov,20f,100f)*0.01745329252f*.5f);
 }
 private Camera OpeningCryoCamera(){
  if(SceneManager.GetActiveScene().name!="PEN_Wreck"||stopping||!immersiveRequested)return null;
  var state=global::PlayerState.gameState;
  if(state!=global::PlayerState.gameStates.cutscene&&state!=global::PlayerState.gameStates.play&&state!=global::PlayerState.gameStates.eventScreen)return null;
  if(cryoOpening==null&&Time.realtimeSinceStartup>=nextCryoLookup){
   nextCryoLookup=Time.realtimeSinceStartup+.5f;
   var root=GameObject.Find("Cutscenes/IntroCutscene");
   if(root!=null)cryoOpening=root.GetComponent<global::PEN_Awakening>();
  }
  // Native intro reports play with cutscene=false. Its room camera is disabled
  // for the 2D shots and enabled at the pod cut, before pod motion starts.
  if(cryoOpening==null||!cryoOpening.isActiveAndEnabled||cryoOpening.pod==null||
   cryoOpening.gameElster==null||cryoOpening.gameElster.activeInHierarchy)return null;
  Camera source=nativeCutsceneHome==null?null:nativeCutsceneHome.Camera;
  if(source==null){
   if(cryoRoomCamera==null){var room=GameObject.Find("__Prerequisites__/Angled Camera Rig/LocalSpace/Main Camera");if(room!=null)cryoRoomCamera=room.GetComponent<Camera>();}
   source=cryoRoomCamera;
  }
  if(source==null)return null;
  if(!source.enabled)cryoRoomWasDisabled=true;
  if(!source.isActiveAndEnabled||(!cryoRoomWasDisabled&&cryoOpening.pod.progress<=0f))return null;
  if(cryoStereoCamera==null){var go=new GameObject("SignalisVR_OpeningCryoStereo");cryoStereoCamera=go.AddComponent<Camera>();cryoStereoCamera.enabled=false;go.transform.SetParent(cryoOpening.transform,false);}
  // Copy camera settings only. The native animated cameras and their scripts
  // remain untouched and continue to own progression, fades and cut timing.
  cryoStereoCamera.CopyFrom(source);cryoStereoCamera.enabled=false;cryoStereoCamera.targetTexture=null;
  cryoStereoCamera.orthographic=false;cryoStereoCamera.fieldOfView=Mathf.Clamp(source.fieldOfView,20f,100f);
  var position=source.transform.position;
  if(source.orthographic){
   var actor=cryoOpening.cutsceneElster;
   if(actor==null||!actor.activeInHierarchy)actor=cryoOpening.pod.StaticElster;
   var subject=actor!=null?actor.transform:cryoOpening.Elster;
   if(subject==null)return null;
   float depth=Vector3.Dot(subject.position-position,source.transform.forward);
   float distance=CryoFramingDistance(source.orthographicSize,cryoStereoCamera.fieldOfView);
   position+=source.transform.forward*(depth-distance);
   cryoStereoCamera.nearClipPlane=.01f;
   cryoStereoCamera.farClipPlane=Mathf.Max(source.farClipPlane,distance*4f);
  }
  cryoStereoCamera.transform.SetPositionAndRotation(position,source.transform.rotation);
  if(cryoSource!=source){cryoSource=source;MelonLoader.MelonLogger.Msg("CRYO STEREO: pod emergence camera="+source.name+"; native sequence retained, headset framing requires verification.");}
  return cryoStereoCamera;
 }
 private bool CryoStereoSelected(){return cryoStereoCamera!=null&&camera==cryoStereoCamera&&OpeningCryoCamera()==cryoStereoCamera;}
 private void ClearOpeningCryo(){
  if(cryoStereoCamera!=null)UnityEngine.Object.Destroy(cryoStereoCamera.gameObject);
  cryoStereoCamera=null;cryoSource=null;cryoOpening=null;cryoRoomCamera=null;nextCryoLookup=0;cryoRoomWasDisabled=false;
 }
}}

