using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class ManualFlare {
  internal ThermiteFlight Visual;internal GameObject Root;internal Vector3 Position,Velocity;internal float Age,Hurt,Critical;internal int Damage;
  internal int Mask;internal bool Landed;internal global::Room Room;
  internal readonly List<Material> Materials=new List<Material>();
 }
 private readonly List<ManualFlare> manualFlares=new List<ManualFlare>();
 private bool flareProjectileWarning;
 private float manualFlareShotTime=-100;
 private static class FlareProjectilePatch {
  internal static bool Fire(global::PlayerAttack __instance){
   var q=weaponOwner;var w=global::InventoryManager.EquippedWeapon;
   // Native firing is already authorized here. Do not reject its delayed shot
   // because the sampled trigger bit was released or attack.weapon is stale.
   if(q==null||!q.ProdVrMode()||w==null||w.parentItem==null||w.parentItem._item!=global::Items.itemlist.FlareGun)return true;
   if(w.magAmmo<=0)return false;
   q.LaunchManualFlare(__instance,w);return false;
  }
  internal static bool NativeCasing(){var q=weaponOwner;return q==null||!q.ProdVrMode()||!q.SelectedActive("FlareGun")||!q.manualReloadEnabled;}
  internal static bool NativeFlight(global::FlareShotMissed __instance){
   var q=weaponOwner;if(q==null||!q.ProdVrMode())return true;
   // This component exists only on the old flaregun projectile, never a held
   // thermite flare or an enemy burn. Stop its light/halo coroutine at creation.
   __instance.gameObject.SetActive(false);UnityEngine.Object.Destroy(__instance.gameObject);return false;
  }
  internal static bool NativeMiss(global::AimLaser __instance){
   var q=weaponOwner;var w=global::InventoryManager.EquippedWeapon;
   if(q==null||!q.ProdVrMode()||w==null||w.parentItem==null||w.parentItem._item!=global::Items.itemlist.FlareGun)return true;
   // Native miss can be invoked before RaycastShot or by a delayed animation event.
   // Its flare flag identifies the native projectile route without a timing window.
   var attack=global::PlayerAttack.instance;var owner=attack==null?null:q.FindRifleOwner(attack);
   return !__instance.flare&&(owner==null||owner.FlareGun==null||!__instance.transform.IsChildOf(owner.FlareGun.transform));
  }
 }
 private void InstallFlareProjectile(HarmonyLib.Harmony h){
  h.Patch(AccessTools.DeclaredMethod(typeof(global::FlareGunShellEject),"load",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(FlareProjectilePatch),nameof(FlareProjectilePatch.NativeCasing)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::FlareShotMissed),"Start",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(FlareProjectilePatch),nameof(FlareProjectilePatch.NativeFlight)));
  // Own only the flare's raycast replacement. The existing scoped muzzle hook
  // runs first; other weapons retain their native firing path.
  var prefix=new HarmonyMethod(typeof(FlareProjectilePatch),nameof(FlareProjectilePatch.Fire));prefix.priority=HarmonyLib.Priority.Last;
  h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"RaycastShot",Type.EmptyTypes),prefix:prefix);
  h.Patch(AccessTools.DeclaredMethod(typeof(global::AimLaser),"miss",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(FlareProjectilePatch),nameof(FlareProjectilePatch.NativeMiss)));
 }
 private bool LaunchManualFlare(global::PlayerAttack attack,global::AnWeapon weapon){
  GameObject created=null;ManualFlare flight=null;
  try{
   var muzzle=global::PlayerAttack.muzzle;if(muzzle==null)throw new InvalidOperationException("Flare muzzle unavailable");
   var position=muzzle.position;var rotation=muzzle.rotation;
   // Script-free projectile: native prefab Awake/OnEnable must never spawn a second shot.
   created=new GameObject("SignalisVR_ArcingFlare");created.transform.SetPositionAndRotation(position,rotation);created.transform.localScale=Vector3.one*UnitsPerMetre;
   flight=new ManualFlare{Root=created,Position=position,Velocity=rotation*Vector3.forward*(12f*UnitsPerMetre),Mask=(int)attack.TargetMask|(int)attack.WallMask|(int)attack.BurnMask,Room=global::PlayerState.currentRoom};
   flight.Visual=new ThermiteFlight{Root=created,Projectile=true};AddThermiteFlame(flight.Visual);flight.Visual.Bounds=new Bounds(Vector3.zero,Vector3.zero);
   AnimateThermiteFlame(flight.Visual,Time.time);
   manualFlares.Add(flight);
   try{weapon.magAmmo--;}
   catch{manualFlares.Remove(flight);throw;}
   // Own the projectile, casing request and original flare sound exactly once.
   MelonLoader.MelonLogger.Msg("VR FLARE: one owned projectile; native projectile suppressed.");manualFlareShotTime=Time.realtimeSinceStartup;flareShotAppearance=RoundAppearance("FlareGun");flareCasePending=true;PlayOwnedFlareSound(position,created.transform);return true;
  }catch(Exception ex){if(flight!=null)DisposeManualFlare(flight);else if(created!=null)UnityEngine.Object.Destroy(created);if(!flareProjectileWarning){flareProjectileWarning=true;MelonLoader.MelonLogger.Warning("Arcing flare cancelled without consuming ammunition: "+ex.Message);}return false;}
 }
 private void PollManualFlares(){
  PollUserFlareSound();PollEnemyFire();PollFireHitAudio();
  if(global::PlayerState.paused||!WeaponGameplayReady()||modMenuOpen||pauseMenuVisible)return;
  float dt=Mathf.Clamp(Time.deltaTime,0,.05f);var gravity=(calibrationRoot!=null?calibrationRoot.transform.up:controllerTrackingToWorld*Vector3.up)*(-9.81f*UnitsPerMetre);
  for(int i=manualFlares.Count-1;i>=0;i--){var f=manualFlares[i];
   try{
   if(f.Root==null||f.Room!=global::PlayerState.currentRoom||f.Age>=6){DisposeManualFlare(f);manualFlares.RemoveAt(i);continue;}
   f.Age+=Mathf.Max(0,Time.deltaTime);
   if(f.Age>=6){DisposeManualFlare(f);manualFlares.RemoveAt(i);continue;}
   f.Visual.Expires=Time.time+Mathf.Max(0,6-f.Age);if(f.Landed){AnimateThermiteFlame(f.Visual,Time.time);continue;}
   var delta=f.Velocity*dt+gravity*(.5f*dt*dt);f.Velocity+=gravity*dt;
   RaycastHit closest=new RaycastHit();bool hitAny=false;float distance=delta.magnitude;
   foreach(var hit in Physics.SphereCastAll(f.Position,.006f*UnitsPerMetre,delta.normalized,distance,f.Mask,QueryTriggerInteraction.Collide)){
    var c=hit.collider;if(c==null||(global::PlayerState.player!=null&&c.transform.IsChildOf(global::PlayerState.player.transform)))continue;
    if(c.isTrigger&&c.GetComponentInParent<global::EnemyController>()==null)continue;
    if(c.GetComponentInParent<global::EnemyController>()!=null)continue;
    if(!hitAny||hit.distance<closest.distance){closest=hit;hitAny=true;}
   }
   global::EnemyController bodyEnemy=null;Vector3 bodyPoint=Vector3.zero;
   float bodyDistance=FindFlareBodyContact(f.Position,f.Position+delta,f.Mask,out bodyEnemy,out bodyPoint);
   if(bodyEnemy!=null&&(!hitAny||bodyDistance<=closest.distance)){
    f.Position=bodyPoint;f.Landed=true;BeginNativeEnemyFire(bodyEnemy,2);PlayFireHit(bodyPoint,bodyEnemy);f.Root.SetActive(false);
   }else if(hitAny){
    f.Position=closest.point+closest.normal*(.006f*UnitsPerMetre);f.Landed=true;
    var enemy=closest.collider.GetComponentInParent<global::EnemyController>();
    if(FireEnemyValid(enemy)){BeginNativeEnemyFire(enemy,2);PlayFireHit(closest.point,enemy);f.Root.SetActive(false);}
   }else f.Position+=delta;
   f.Root.transform.position=f.Position;
   if(!f.Landed&&f.Velocity.sqrMagnitude>.001f)f.Root.transform.rotation=Quaternion.LookRotation(f.Velocity,Vector3.up);
   AnimateThermiteFlame(f.Visual,Time.time);
   }catch(Exception ex){
    DisposeManualFlare(f);manualFlares.RemoveAt(i);
    if(!flareProjectileWarning){flareProjectileWarning=true;MelonLoader.MelonLogger.Warning("Flare flight ended safely: "+ex.Message);}
   }
  }
 }
 private void DisposeManualFlare(ManualFlare f){if(f.Root!=null)UnityEngine.Object.Destroy(f.Root);foreach(var m in f.Materials)if(m!=null)UnityEngine.Object.Destroy(m);f.Materials.Clear();}
 private void DestroyManualFlares(){DestroyUserFlareSound();DestroyEnemyFire();DestroyFireHitAudio();foreach(var f in manualFlares)DisposeManualFlare(f);manualFlares.Clear();}
}}






