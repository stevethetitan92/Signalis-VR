using System;
using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed class FlareThrowPolicy {
  private bool held,blocked=true;
  public bool Release(bool ready,bool grip){if(!ready){held=false;blocked=true;return false;}if(blocked){if(!grip)blocked=false;return false;}bool release=held&&!grip;held=grip;return release;}
  public static float Speed(float speed){if(float.IsNaN(speed)||float.IsInfinity(speed))return 1.5f;return Math.Max(1.5f,Math.Min(8f,speed));}
 }
 public sealed partial class Tracking {
  private GameObject thermiteHand;
  private readonly List<MeshRenderer> thermiteHandParts=new List<MeshRenderer>();
  private readonly List<Material> thermiteMaterials=new List<Material>();
  private readonly List<ThermiteFlight> thermiteFlights=new List<ThermiteFlight>();
  private readonly FlareThrowPolicy thermiteThrow=new FlareThrowPolicy();
  private bool thermiteFailed,thermiteSampled;
  private Vector3 thermiteRawLast,thermiteVelocity;
  private float thermiteSampleTime,thermiteLastUpdate;
  private sealed class ThermiteFlight {public bool NativeBodyBurn;public global::EnemyController BurnTarget;public bool Projectile;public PackAudio Sound;public bool AudioFailed;public readonly List<Material> OwnMaterials=new List<Material>();public readonly List<float> MaterialAlpha=new List<float>();public MaterialPropertyBlock EffectFade;public GameObject Root;public Bounds Bounds;public MeshRenderer[] Flames;public Vector3 Velocity,Spin;public BoxCollider Probe;public GameObject Fire;public ParticleSystem[] Particles;public Renderer[] Renderers;public MaterialPropertyBlock Fade;public float Expires;public global::Room Room;public readonly HashSet<IntPtr> Burned=new HashSet<IntPtr>();}
  private static bool ThermiteSelected(){var t=global::InventoryManager.EquippedTool;return t!=null&&t._item==global::Items.itemlist.SignalFlare;}
  private bool ThermiteEligible(){return !thermiteFailed&&ProdVrMode()&&ThermiteSelected()&&!ProdHandOccupied()&&ControllerWeaponVisualReady()&&questPolicy.RightArmed&&!quickSelect.Open&&!modMenuOpen&&!global::PlayerState.paused&&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput&&!global::PlayerState.animating&&!global::PlayerState.reloading&&!global::PlayerState.grappled&&!global::PlayerState.hurt&&global::PlayerState.hp>0&&global::InventoryManager.hasItem(global::InventoryManager.EquippedTool);}
  private static bool ThermiteEquipGuard(global::InventoryBase __instance,global::AnItem __0){if(weaponOwner==null||!weaponOwner.ProdVrMode()||__0==null||__0._item!=global::Items.itemlist.SignalFlare||weaponOwner.thermiteFailed)return true;if(global::InventoryManager.EquippedTool==__0)return true;try{return weaponOwner.PrepareProdHand(__instance);}catch(Exception ex){MelonLogger.Warning("Thermite equip blocked: "+ex.Message);return false;}}
  private static bool ThermiteNativeGuard(ref bool __result){if(weaponOwner==null||!weaponOwner.ProdVrMode()||!ThermiteSelected()||weaponOwner.thermiteFailed)return true;__result=false;return false;}
  private void InstallThermite(HarmonyLib.Harmony h){h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"EquipTool",new[]{typeof(global::AnItem)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(ThermiteEquipGuard)));foreach(string method in new[]{"useFusee","Fusee"})h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),method,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(ThermiteNativeGuard)));}
  private void PollThermite(){
   try {
    var all=global::InventoryManager.allItems;if(all!=null&&all.ContainsKey(global::Items.itemlist.SignalFlare))all[global::Items.itemlist.SignalFlare].maxNumber=3;
    bool eligible=ThermiteEligible();if(ProdVrMode()&&ThermiteSelected()&&!thermiteFailed)questFrame.buttons&=~((1<<5)|(1<<6));
    float now=Time.time;
    if(eligible){float dt=now-thermiteSampleTime;var raw=rawControllerPositions[1];if(thermiteSampled&&dt>0&&dt<.1f){var velocity=(raw-thermiteRawLast)/dt;thermiteVelocity=Vector3.Lerp(thermiteVelocity,velocity,.6f);}else thermiteVelocity=Vector3.zero;thermiteRawLast=raw;thermiteSampleTime=now;thermiteSampled=true;}else thermiteSampled=false;
    if(thermiteThrow.Release(eligible,modMenuRightGrip))ThrowThermite();
    float elapsed=Math.Max(0,Math.Min(.1f,now-thermiteLastUpdate));thermiteLastUpdate=now;
    bool audioReady=ProdVrMode()&&!modMenuOpen&&!global::PlayerState.paused&&WeaponGameplayReady()&&!pauseMenuVisible;
    if(heldThermiteFire!=null)UpdateThermiteAudio(heldThermiteFire,now,audioReady&&ThermiteEligible());
    foreach(var f in thermiteFlights)UpdateThermiteAudio(f,now,audioReady);
    if(!audioReady)return;
    for(int i=thermiteFlights.Count-1;i>=0;i--){var flight=thermiteFlights[i];try{if(flight.Root==null||flight.Room!=global::PlayerState.currentRoom||now>=flight.Expires){DisposeThermiteFlight(flight);thermiteFlights.RemoveAt(i);continue;}
     var attack=global::PlayerAttack.instance;if(attack==null)continue;
     for(float remaining=elapsed;remaining>0;){float step=Math.Min(.02f,remaining);remaining-=step;var from=flight.Root.transform.position;
      StepThermite(flight,step,now);AnimateThermiteFlame(flight,now);
      // Burn across the flight segment as well as the resting contact zone.
      int mask=attack.MeleeMask.value|attack.BurnMask.value;
      foreach(var c in Physics.OverlapCapsule(from,flight.Root.transform.position,.11f*UnitsPerMetre,mask,QueryTriggerInteraction.Collide).ToArray()){if(c==null)continue;var enemy=c.GetComponentInParent<global::EnemyController>();if(enemy==null||!enemy.gameObject.activeInHierarchy||flight.Burned.Contains(enemy.Pointer))continue;if(Physics.Linecast(flight.Root.transform.position,c.ClosestPoint(flight.Root.transform.position),attack.WallMask,QueryTriggerInteraction.Ignore))continue;
       if(!FireEnemyValid(enemy))continue;
       var fireHitPoint=c.ClosestPoint(flight.Root.transform.position);BeginEnemyFire(enemy);flight.BurnTarget=enemy;flight.NativeBodyBurn|=!ProdEnemyValid(enemy);AnimateThermiteFlame(flight,now);
       flight.Burned.Add(enemy.Pointer);PlayFireHit(fireHitPoint,enemy);
       MelonLogger.Msg("VR THERMITE: fire contact applied (living burn or corpse incineration).");
      }
     }
     }catch(Exception ex){thermiteFlights.RemoveAt(i);try{DisposeThermiteFlight(flight);}catch{}MelonLogger.Warning("Thrown thermite retired; held flare remains available: "+ex);}
    }
   }catch(Exception ex){thermiteFailed=true;HideThermite();MelonLogger.Warning("Throwable thermite disabled: "+ex.Message);}
  }
  private void ThrowThermite(){
   if(controllerMarkers[1]==null)return;EnsureThermiteVisual();var item=global::InventoryManager.EquippedTool;if(item==null||QuickCount(item)<=0)return;
   var hand=controllerMarkers[1].transform;var root=new GameObject("SignalisVR_ThrownThermite");BuildThermite(root,new List<MeshRenderer>());root.transform.position=HandPlacement.TrackedPalm(hand.position,hand.rotation,UnitsPerMetre);root.transform.rotation=thermiteHand.transform.rotation;root.transform.localScale=Vector3.one*UnitsPerMetre;root.transform.position=thermiteHand.transform.position;
   var glow=root.AddComponent<Light>();glow.color=new Color(1f,.22f,.025f);glow.range=.8f*UnitsPerMetre;glow.intensity=1.5f;
   float speed=FlareThrowPolicy.Speed(thermiteVelocity.magnitude);var direction=thermiteVelocity.magnitude>.3f?(controllerTrackingToWorld*thermiteVelocity).normalized:hand.forward;
   var flight=new ThermiteFlight{Root=root,Velocity=direction*speed*UnitsPerMetre,Spin=new Vector3(130,65,90),Expires=Time.time+6f,Room=global::PlayerState.currentRoom};
   try{AddThermiteFlame(flight);PrepareThermiteCollision(flight);global::InventoryManager.RemoveItem(item);}
   catch{DisposeThermiteFlight(flight);throw;}
   if(heldThermiteFire!=null){flight.Sound=heldThermiteFire.Sound;heldThermiteFire.Sound=null;}
   global::InventoryManager.EquippedTool=null;thermiteFlights.Add(flight);thermiteSampled=false;thermiteThrow.Release(false,false);HideThermite();
  }
  private ThermiteFlight heldThermiteFire;
  private void EnsureThermiteVisual(){if(thermiteHand!=null)return;LoadThermiteAsset();thermiteHand=new GameObject("SignalisVR_HeldThermite");UnityEngine.Object.DontDestroyOnLoad(thermiteHand);BuildThermite(thermiteHand,thermiteHandParts);heldThermiteFire=new ThermiteFlight{Root=thermiteHand};AddThermiteFlame(heldThermiteFire);}
  private void BuildThermite(GameObject root,List<MeshRenderer> parts){for(int i=0;i<thermiteMeshes.Count;i++)parts.Add(CreateControllerPart(root,thermiteMeshes[i],thermiteMaterials[i],"ThermiteFlare",Vector3.zero,Vector3.one));foreach(var part in parts)part.enabled=true;}
  private void PrepareThermite(){HideThermite();if(!ThermiteEligible()||!handsScoped||controllerMarkers[1]==null||(controllerVisibility&2)==0)return;EnsureThermiteVisual();var hand=controllerMarkers[1].transform;thermiteHand.transform.position=HandPlacement.TrackedPalm(hand.position,hand.rotation,UnitsPerMetre);thermiteHand.transform.rotation=hand.rotation;thermiteHand.transform.localScale=Vector3.one*UnitsPerMetre;AlignImportedThermite();if(heldThermiteFire!=null){if(heldThermiteFire.Renderers!=null)foreach(var r in heldThermiteFire.Renderers)if(r!=null)r.enabled=true;AnimateThermiteFlame(heldThermiteFire,Time.time);}foreach(var part in thermiteHandParts)part.enabled=true;}
  private void HideThermite(){if(heldThermiteFire!=null){if(heldThermiteFire.Renderers!=null)foreach(var r in heldThermiteFire.Renderers)if(r!=null)r.enabled=false;if(heldThermiteFire.Flames!=null)foreach(var flame in heldThermiteFire.Flames)if(flame!=null)flame.enabled=false;}foreach(var part in thermiteHandParts)if(part!=null)part.enabled=false;}
  private void DestroyThermite(){HideThermite();if(heldThermiteFire!=null&&heldThermiteFire.Sound!=null)heldThermiteFire.Sound.Dispose();DestroyThermiteFlame();if(thermiteHand!=null)UnityEngine.Object.Destroy(thermiteHand);foreach(var f in thermiteFlights)DisposeThermiteFlight(f);foreach(var m in thermiteMaterials)if(m!=null)UnityEngine.Object.Destroy(m);DestroyThermiteAsset();thermiteHand=null;heldThermiteFire=null;thermiteFlights.Clear();thermiteHandParts.Clear();thermiteMaterials.Clear();thermiteSampled=false;thermiteThrow.Release(false,false);thermiteFailed=false;}
 }
}


