using System;
namespace SignalisVrTracking {
 public static class MovementMath {
  // Preserve analog magnitude and angle; modest walk/sprint tuning over 0508.
  public const float QuestForceGain=1.5f;
  public static float ForceGain(bool sprint){return QuestForceGain*(sprint?1.15f:1.10f);}
  // Project the view into the player's floor plane. Both stick axes share
  // this basis; world Y is not assumed to be up in SIGNALIS.
  public static bool Direction(double ux,double uy,double uz,double fx,double fy,double fz,
      double x,double y,out float dx,out float dy,out float dz) {
   dx=dy=dz=0;
   double ul=Math.Sqrt(ux*ux+uy*uy+uz*uz);
   if(double.IsNaN(ul)||double.IsInfinity(ul)||ul<1e-6)return false;
   ux/=ul;uy/=ul;uz/=ul;
   double dot=ux*fx+uy*fy+uz*fz;fx-=ux*dot;fy-=uy*dot;fz-=uz*dot;
   double fl=Math.Sqrt(fx*fx+fy*fy+fz*fz);
   if(double.IsNaN(fl)||double.IsInfinity(fl)||fl<1e-4||double.IsNaN(x)||double.IsNaN(y)||double.IsInfinity(x)||double.IsInfinity(y))return false;
   fx/=fl;fy/=fl;fz/=fl;
   double length=Math.Sqrt(x*x+y*y);if(length>1){x/=length;y/=length;}
   dx=(float)((uy*fz-uz*fy)*x+fx*y);
   dy=(float)((uz*fx-ux*fz)*x+fy*y);
   dz=(float)((ux*fy-uy*fx)*x+fz*y);
   return true;
  }
  // Convert a floor-projected world direction to the game's own forward/right
  // basis, so native forward motion and camera-mod strafing do not fight.
  public static bool Split(double ux,double uy,double uz,double fx,double fy,double fz,
      double dx,double dy,double dz,out float forward,out float side) {
   forward=side=0f;float ax,ay,az,bx,by,bz;
   if(!Direction(ux,uy,uz,fx,fy,fz,0,1,out ax,out ay,out az)
      ||!Direction(ux,uy,uz,fx,fy,fz,1,0,out bx,out by,out bz))return false;
   forward=(float)(dx*ax+dy*ay+dz*az);side=(float)(dx*bx+dy*by+dz*bz);
   return !(float.IsNaN(forward)||float.IsInfinity(forward)||float.IsNaN(side)||float.IsInfinity(side));
  }
 }
}
