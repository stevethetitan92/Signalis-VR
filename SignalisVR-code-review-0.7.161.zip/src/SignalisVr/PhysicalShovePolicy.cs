using System;
namespace SignalisVrTracking {
 internal sealed class PhysicalShovePolicy {
  private float travel,clearTime;private bool latched;
  internal void Reset(){travel=clearTime=0;latched=false;}
  internal bool Step(float dt,float distance,float approach,bool contact){
   if(dt<=0||dt>.1f||distance<0||distance>.35f||float.IsNaN(dt)||float.IsNaN(distance)||float.IsInfinity(distance)||float.IsNaN(approach)||float.IsInfinity(approach)){Reset();return false;}
   if(!contact){clearTime+=dt;if(clearTime>=.025f)latched=false;}else clearTime=0;
   float speed=distance/dt;
   if(speed<.2f)travel=0;else travel=Math.Min(.25f,travel+distance);
   if(!contact||latched||speed<.55f||approach<.25f||travel<.035f)return false;
   latched=true;travel=0;return true;
  }
 }
}

