using System;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private IntPtr screenCursorPoint, closeupAnchorPoint;
 private global::EventScreen3DCam screenCursorControl;
 private int screenCursorFrame=-1;
 private Vector2 screenCursorPosition=new Vector2(.5f,.5f);
 private void UpdateEventScreenCursorState(){
  if(screenCursorControl!=null&&(!JoystickCursorPoint(screenCursorControl)||
   (global::PlayerState.gameState!=global::PlayerState.gameStates.eventScreen&&global::PlayerState.gameState!=global::PlayerState.gameStates.dialogue))){
   screenCursorControl=null;screenCursorPoint=IntPtr.Zero;screenCursorFrame=-1;
  }
 }
 private static bool JoystickCursorPoint(global::EventScreen3DCam control){
  if(control==null||!control.isActiveAndEnabled||control.path==null||control.depth<0||control.depth>=control.path.Count)return false;
  var point=control.path[control.depth];if(point==null||!point._active)return false;
  string owner=null;for(var t=point.transform;t!=null;t=t.parent){if(t.name=="ROT_RadioStation"||t.name=="MED_TrainEvent"||t.name=="ROT_School"){owner=t.name;break;}}
  return (owner=="ROT_RadioStation"&&point.name=="BuildingTablePointTOP")||(owner=="MED_TrainEvent"&&point.name=="CardPoint")||(owner=="ROT_School"&&point.name=="Cam PoitraitPoint");
 }
 private bool ScreenCursorInputReady(){return immersiveRequested&&QuestOwnsInputMode()&&QuestAvailableNow()&&questPolicy.LeftArmed&&
  global::PlayerState.gameState==global::PlayerState.gameStates.eventScreen&&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput&&
  !global::PlayerState.paused&&!modMenuOpen&&!pauseMenuVisible;}
 private static Vector2 MoveScreenCursor(Vector2 position,float x,float y,float seconds){
  float dt=Mathf.Clamp(seconds,0f,.05f);
  return new Vector2(Mathf.Clamp(position.x+x*.6f*dt,.02f,.98f),Mathf.Clamp(position.y+y*.6f*dt,.02f,.98f));
 }
 private void PrepareScreenCursor(global::EventScreen3DCam control,ref QuestPuzzleState state){
  if(control!=null&&control.isActiveAndEnabled&&control.path!=null&&control.depth>=0&&control.depth<control.path.Count){
   var anchor=control.path[control.depth];if(anchor!=null&&anchor._active&&anchor.Pointer!=closeupAnchorPoint){closeupAnchorPoint=anchor.Pointer;puzzleAnchorPending=true;}
  }
  if(!JoystickCursorPoint(control)){if(control==screenCursorControl){screenCursorPoint=IntPtr.Zero;screenCursorFrame=-1;screenCursorControl=null;}return;}
  if(!ScreenCursorInputReady())return;
  var point=control.path[control.depth];
  screenCursorControl=control;
  if(screenCursorPoint!=point.Pointer){screenCursorPoint=point.Pointer;screenCursorPosition=new Vector2(.5f,.5f);screenCursorFrame=Time.frameCount;}
  else if(screenCursorFrame!=Time.frameCount){screenCursorFrame=Time.frameCount;screenCursorPosition=MoveScreenCursor(screenCursorPosition,questFrame.uiX,questFrame.uiY,Time.unscaledDeltaTime);}
  global::EventScreen3DCam.cursorPosition=screenCursorPosition;
  state.restoreCursorMode=true;state.cursorUnlocked=global::EventScreen3DCam.unlockedCursor;
  global::EventScreen3DCam.unlockedCursor=true;
  // The scoped input snapshot is restored by the existing exception finalizer.
  // This cursor consumes the left stick; do not rotate the close-up as well.
  if(state.input!=null){state.input.Move=Vector2.zero;if(state.restorePeek)state.input.Peek=Vector2.zero;}
 }
}}


