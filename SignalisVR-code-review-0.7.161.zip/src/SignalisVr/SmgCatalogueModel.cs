using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static GameObject smgCatalogueModel;
 private static void BindSmgCatalogueModel(global::AnItem item){
  if(smgCatalogueModel==null){
   if(item.Image3D==null)return;
   EnsureInventorySmgAssets();
   var original=item.Image3D.transform;
   var bounds=new Bounds();bool first=true;
   foreach(var renderer in original.GetComponentsInChildren<Renderer>(true)){
    Bounds b;if(!InventorySmgLocalBounds(renderer,out b))continue;
    for(int corner=0;corner<8;corner++){
     var vertex=b.center+Vector3.Scale(b.extents,new Vector3((corner&1)==0?-1:1,(corner&2)==0?-1:1,(corner&4)==0?-1:1));
     var p=original.InverseTransformPoint(InventorySmgBoundsFrame(renderer).TransformPoint(vertex));
     if(first){bounds=new Bounds(p,Vector3.zero);first=false;}else bounds.Encapsulate(p);
    }
   }
   if(first)return;
   var rotation=bounds.size.x>bounds.size.z?Quaternion.Euler(0,90,0):Quaternion.identity;
   var fit=new Bounds();first=true;
   foreach(var mesh in inventorySmgMeshes)foreach(var vertex in mesh.vertices){var p=rotation*vertex;if(first){fit=new Bounds(p,Vector3.zero);first=false;}else fit.Encapsulate(p);}
   float scale=Mathf.Max(bounds.size.x,Mathf.Max(bounds.size.y,bounds.size.z))/Mathf.Max(fit.size.x,Mathf.Max(fit.size.y,fit.size.z));
   if(scale<=0||float.IsNaN(scale)||float.IsInfinity(scale))return;
   // Keep activeSelf true for native Instantiate, but park the template below
   // an inactive parent so it never renders as a floating world gun.
   var holder=new GameObject("SignalisVR_SmgTemplates");holder.SetActive(false);UnityEngine.Object.DontDestroyOnLoad(holder);
   var root=new GameObject("SignalisVR_SmgCatalogue");root.transform.SetParent(holder.transform,false);
   root.transform.localScale=original.localScale;root.transform.localRotation=original.localRotation;
   // Native previews clone this geometry-only template. No firing controllers,
   // inventory scripts, interaction handlers or colliders are copied.
   for(int i=0;i<inventorySmgMeshes.Count;i++){
    var part=new GameObject("Xiphias part");part.layer=5;part.transform.SetParent(root.transform,false);
    part.transform.localRotation=rotation;part.transform.localScale=Vector3.one*scale;
    part.transform.localPosition=bounds.center-fit.center*scale;
    part.AddComponent<MeshFilter>().sharedMesh=inventorySmgMeshes[i];part.AddComponent<MeshRenderer>().sharedMaterial=inventorySmgMaterials[inventorySmgSlots[i]];
   }
   smgCatalogueModel=root;
  }
  item.Image3D=smgCatalogueModel;
 }
}}
