using System;
using HarmonyLib;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool enhancedResolutionRequested=true,flashlightModRequested=true;
 private static bool enhancedResolutionActive=true,flashlightModActive=true;
 private bool enhancedResolutionAvailable,flashlightModAvailable;
 private static string OptionalModValue(bool available,bool requested,bool active){return !available?"UNAVAILABLE":(requested?"ON":"OFF")+(requested!=active?" (RESTART)":"");}
 private void InstallOptionalModSwitches(){
  enhancedResolutionActive=enhancedResolutionRequested;flashlightModActive=flashlightModRequested;
  enhancedResolutionAvailable=PatchOptionalMod("Enhanced_Resolution.EnhancedResolution",nameof(EnhancedResolutionAllowed),new[]{"OnUpdate"});
  flashlightModAvailable=PatchOptionalMod("MyFlashlightModTest.FlashlightModTest",nameof(FlashlightModAllowed),new[]{"OnUpdate","OnSceneWasLoaded"});
 }
 private static bool EnhancedResolutionAllowed(){return enhancedResolutionActive;}
 private static bool FlashlightModAllowed(){return flashlightModActive;}
 private static bool PatchOptionalMod(string typeName,string prefix,string[] callbacks){
  var h=new HarmonyLib.Harmony("signalis.vr.optional."+typeName);
  try {
   var t=AccessTools.TypeByName(typeName);if(t==null)return false;
   var methods=new System.Collections.Generic.List<System.Reflection.MethodInfo>();
   foreach(var callback in callbacks){var m=AccessTools.DeclaredMethod(t,callback);if(m==null)throw new MissingMethodException(typeName,callback);methods.Add(m);}
   foreach(var m in methods)h.Patch(m,prefix:new HarmonyMethod(typeof(Tracking),prefix));
   MelonLoader.MelonLogger.Msg("OPTIONAL MOD: "+typeName+" startup switch installed; changes require restart.");return true;
  }catch(Exception ex){h.UnpatchSelf();MelonLoader.MelonLogger.Warning("Optional mod switch unavailable: "+typeName+": "+ex.Message);return false;}
 }
}}
