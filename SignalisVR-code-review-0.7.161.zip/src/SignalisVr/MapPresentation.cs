using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private const string MapDiscoveryPrefix="SignalisVR.Map.Discovered.v2:";
 private readonly List<Vector2> mapLabelPoints=new List<Vector2>();
 private readonly List<string> mapLabelTexts=new List<string>();
 private readonly List<bool> mapLabelGold=new List<bool>(),mapLabelLayoutGold=new List<bool>();
 private readonly List<float> mapLabelScales=new List<float>();
 private readonly List<Mesh> mapLabelMeshes=new List<Mesh>();
 private readonly List<Transform> mapLabelTransforms=new List<Transform>();
 private readonly List<string> mapLabelPrevious=new List<string>();
 private readonly List<Renderer[]> mapLabelRenderers=new List<Renderer[]>();
 private static bool MapSameRoom(global::Room a,global::Room b){return a!=null&&b!=null&&(a==b||(a.minimapRoom!=null&&a.minimapRoom==b.minimapRoom));}
 private string MapCanonicalId(string live,int kind,global::Room room,string path=null){
  string selected=null;int count=0;
  foreach(var e in mapCatalogue)if(e.Kind==kind&&e.Floor==(int)room.floor&&MapIdentityPolicy.Matches(e.Id,live)){selected=e.Id;count++;}
  foreach(var e in mapLadderCatalogue)if(e.Kind==kind&&e.Floor==(int)room.floor&&MapIdentityPolicy.Matches(e.Id,live)){selected=e.Id;count++;}
  // Services and ladders have authored coordinates indexed by hierarchy.
  // Runtime UniqueId components must not send them through player projection.
  if(count==0&&path!=null&&(kind==1||kind==2||kind==11)){
   foreach(var e in mapCatalogue)if(e.Kind==kind&&e.Floor==(int)room.floor&&MapIdentityPolicy.Matches(e.Id,path)){selected=e.Id;count++;}
   foreach(var e in mapLadderCatalogue)if(e.Kind==kind&&e.Floor==(int)room.floor&&MapIdentityPolicy.Matches(e.Id,path)){selected=e.Id;count++;}
   // Exactly one service of this category in the same authored room is safe.
   // Never apply this fallback to ladders, pickups or puzzles.
   if(count==0&&(kind==1||kind==2)&&room.minimapRoom!=null)
    foreach(var e in mapCatalogue)if(e.Kind==kind&&e.Floor==(int)room.floor&&e.Room==room.minimapRoom.name){selected=e.Id;count++;}
  }
  string id=MapDiscoveryPrefix+(count==1?selected:live),old=MapDiscoveryPrefix+live;
  if(id!=old&&global::SProgress.GetInt(old,0)!=0&&global::SProgress.GetInt(id,0)==0){global::SProgress.SetInt(id,1);MelonLoader.MelonLogger.Msg("MAP MIGRATE: "+old+" -> "+id);}
  return id;
 }
 private static string MapVisitKey(int floor,string room){return "SignalisVR.Map.Visited.v1:"+floor+"|"+room;}
 private void MapMarkVisited(){var r=global::PlayerState.currentRoom;if(r==null||r.minimapRoom==null)return;string k=MapVisitKey((int)r.floor,r.minimapRoom.name);if(global::SProgress.GetInt(k,0)==0){global::SProgress.SetInt(k,1);nextModMapRefresh=0;}}
 private float MapDiscoveryDistance(MapPoint point,Vector3 player){
  // Native interaction range is an authoritative close-enough observation.
  if(point.Inter!=null&&point.Inter.inRange)return 0;
  var p=point.Target.position;float d=new Vector2(player.x-p.x,player.y-p.y).magnitude;
  if(point.Inter!=null&&point.Inter.pointOfInterest!=null){p=point.Inter.pointOfInterest.position;d=Mathf.Min(d,new Vector2(player.x-p.x,player.y-p.y).magnitude);}
  return d/UnitsPerMetre;
 }
 private void MapRememberPosition(MapPoint point,Vector2 position,global::PersistentMinimapFloor floor,Transform basis){
  if(point.Room.minimapRoom==null)return;Vector2 lo,hi;if(!MapCatalogueBounds(floor,basis,point.Room.minimapRoom.name,out lo,out hi))return;
  var raw=position/modMapScale+modMapCenter;
  int x=(int)(Mathf.InverseLerp(lo.x,hi.x,raw.x)*100000),y=(int)(Mathf.InverseLerp(lo.y,hi.y,raw.y)*100000);
  if(global::SProgress.GetInt(point.Id+":position",0)==0||global::SProgress.GetInt(point.Id+":x",0)!=x||global::SProgress.GetInt(point.Id+":y",0)!=y){global::SProgress.SetInt(point.Id+":x",x);global::SProgress.SetInt(point.Id+":y",y);global::SProgress.SetInt(point.Id+":position",1);}
 }
 private void AddMapLabel(Vector2 point,string text,float scale=.20f,bool gold=false){
  if(string.IsNullOrWhiteSpace(text))return;
  text=System.Text.RegularExpressions.Regex.Replace(text,"<[^>]+>","");
  scale*=MapTextSizeFactor();
  var lines=text.Replace("\r","").Split('\n');
  for(int i=0;i<lines.Length;i++)if(!string.IsNullOrWhiteSpace(lines[i])){mapLabelPoints.Add(point+new Vector2(0,((lines.Length-1)*.5f-i)*.0045f*UnitsPerMetre*(scale/.20f)));mapLabelTexts.Add(lines[i].Trim().ToUpperInvariant());mapLabelScales.Add(scale);mapLabelGold.Add(gold);}
 }
 private void AddMapKeyHint(Vector2 lockPoint,string text){
  if(string.IsNullOrWhiteSpace(text))return;
  text=System.Text.RegularExpressions.Regex.Replace(text,"<[^>]+>","").Trim().ToUpperInvariant();
  AddMapLabel(lockPoint+new Vector2(0,-.0038f*UnitsPerMetre*MapTextSizeFactor()),text,.16f,true);
 }
 private void AddRoomMapLabel(Vector2 low,Vector2 high,string text){
  if(string.IsNullOrWhiteSpace(text))return;
  text=System.Text.RegularExpressions.Regex.Replace(text,"<[^>]+>","").ToUpperInvariant();
  float width=(high.x-low.x)*modMapScale*.82f,height=(high.y-low.y)*modMapScale*.70f;
  if(width<=0||height<=0)return;
  float scale=.20f*MapTextSizeFactor(),unit=.014f*UnitsPerMetre/32f*scale;
  var lines=new List<string>();string line="";
  foreach(var paragraph in text.Replace("\r","").Split('\n')){
   foreach(var word in paragraph.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries)){
    string next=line.Length==0?word:line+" "+word;
    if(line.Length>0&&(PixelTextWidth(next)+128)*unit>width){lines.Add(line);line=word;}else line=next;
   }if(line.Length>0){lines.Add(line);line="";}
  }
  if(lines.Count==0)return;
  float widest=0;foreach(var row in lines)widest=Math.Max(widest,(PixelTextWidth(row)+128)*unit);
  // Keep the same font size in every room; wrap instead of shrinking.
  AddMapLabel(((low+high)*.5f-modMapCenter)*modMapScale,string.Join("\n",lines.ToArray()),scale/MapTextSizeFactor());
 }
 private void MapRoomLabels(global::PersistentMinimapFloor floor,Transform basis){
  var rooms=new List<global::PersistentMinimapRoom>();if(floor.Rooms!=null)foreach(var r in floor.Rooms)if(r!=null&&!rooms.Contains(r))rooms.Add(r);foreach(var r in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true))if(r!=null&&!rooms.Contains(r))rooms.Add(r);
  foreach(var room in rooms){
   if(room.RoomID==null)continue;
   bool visited=global::SProgress.GetInt(MapVisitKey((int)floor.FloorID,room.RoomID.name),0)!=0;
   var live=global::PlayerState.currentRoom;
   bool current=live!=null&&(room.room==live||room.RoomID==live.minimapRoom);
   if(!room.discovered&&!visited&&!current&&!MapRoomHasKnownLadder(room,(int)floor.FloorID))continue;
   Vector2 labelLow,labelHigh;if(!MapCatalogueBounds(floor,basis,room.RoomID.name,out labelLow,out labelHigh))continue;
   if(!((int)floor.FloorID==11&&room.RoomID.name=="Service Tunnel"))MapRoomLabelBounds(room,basis,ref labelLow,ref labelHigh);
   MapLadderLabelBounds(room,(int)floor.FloorID,ref labelLow,ref labelHigh);
   if(room.RoomLabel!=null&&!string.IsNullOrWhiteSpace(room.RoomLabel.text)){
    AddRoomMapLabel(labelLow,labelHigh,room.RoomLabel.text);
   }else AddRoomMapLabel(labelLow,labelHigh,room.RoomID.name);

  }
 }
 private void MapPuzzleLabel(global::MinimapPOI poi,Transform basis){
  foreach(var text in poi.GetComponentsInChildren<TMPro.TextMeshPro>(true)){
   if(string.IsNullOrWhiteSpace(text.text))continue;var p=basis.InverseTransformPoint(text.transform.position);AddMapLabel((new Vector2(p.x,p.y)-modMapCenter)*modMapScale,text.text);
  }
 }
 private Mesh mapLabelsBatch;private MeshRenderer mapLabelsView;private bool mapLabelsDirty=true;
 private readonly List<Vector2> mapLabelLayoutPositions=new List<Vector2>();
 private readonly List<string> mapLabelLayoutTexts=new List<string>();
 private readonly List<float> mapLabelLayoutScales=new List<float>();
 private bool MapLabelLayoutChanged(){
  if(mapLabelLayoutTexts.Count!=mapLabelTexts.Count||mapLabelLayoutGold.Count!=mapLabelGold.Count)return true;
  for(int i=0;i<mapLabelTexts.Count;i++)if(mapLabelLayoutTexts[i]!=mapLabelTexts[i]||mapLabelLayoutPositions[i]!=mapLabelPoints[i]||mapLabelLayoutScales[i]!=mapLabelScales[i]||mapLabelLayoutGold[i]!=mapLabelGold[i])return true;
  return false;
 }
 private void PrepareMapLabels(){
  // Live refresh may change only the arrow or a door. Reuse stable room labels
  // instead of copying all glyph buffers every half-second as exploration grows.
  if(mapLabelsView!=null&&mapLabelsDirty&&!MapLabelLayoutChanged())mapLabelsDirty=false;
  if(!mapLabelsDirty){if(mapLabelsView!=null)mapLabelsView.enabled=mapLabelTexts.Count>0;return;}
  for(int i=0;i<mapLabelTexts.Count;i++){
   if(i>=mapLabelMeshes.Count){var mesh=CreateModHudText("MapLabel"+i,0);var filters=modHudRoot.GetComponentsInChildren<MeshFilter>(true);Transform t=null;foreach(var f in filters)if(f.sharedMesh==mesh&&f.gameObject.name=="MapLabel"+i){t=f.transform;break;}if(t==null)throw new InvalidOperationException("Map label mesh unavailable");t.SetParent(modMapRoot.transform,false);t.gameObject.SetActive(false);mapLabelMeshes.Add(mesh);mapLabelTransforms.Add(t);mapLabelPrevious.Add(null);var owned=t.GetComponentsInChildren<Renderer>(true);foreach(var r in owned)modHudRenderers.Remove(r);mapLabelRenderers.Add(owned);}
   string previous=mapLabelPrevious[i];UpdateModHudText(mapLabelMeshes[i],mapLabelTexts[i],ref previous);mapLabelPrevious[i]=previous;
   var p=mapLabelPoints[i];mapLabelTransforms[i].localPosition=new Vector3(p.x,p.y,-.01f*UnitsPerMetre);mapLabelTransforms[i].localRotation=Quaternion.identity;mapLabelTransforms[i].localScale=Vector3.one*mapLabelScales[i];
   foreach(var r in mapLabelRenderers[i])r.enabled=false;
  }
  for(int i=mapLabelTexts.Count;i<mapLabelRenderers.Count;i++)foreach(var r in mapLabelRenderers[i])r.enabled=false;
  if(mapLabelsView==null&&mapLabelRenderers.Count>0){var go=new GameObject("MapLabelsBatched");go.layer=30;go.transform.SetParent(modMapRoot.transform,false);mapLabelsBatch=new Mesh();mapLabelsBatch.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;go.AddComponent<MeshFilter>().sharedMesh=mapLabelsBatch;mapLabelsView=go.AddComponent<MeshRenderer>();mapLabelsView.sharedMaterial=mapLabelRenderers[0][0].sharedMaterial;mapLabelsView.sortingOrder=5;}
  if(mapLabelsView!=null)RebuildMapLabelBatch();mapLabelsDirty=false;
  mapLabelLayoutPositions.Clear();mapLabelLayoutPositions.AddRange(mapLabelPoints);
  mapLabelLayoutTexts.Clear();mapLabelLayoutTexts.AddRange(mapLabelTexts);
  mapLabelLayoutScales.Clear();mapLabelLayoutScales.AddRange(mapLabelScales);mapLabelLayoutGold.Clear();mapLabelLayoutGold.AddRange(mapLabelGold);
 }
 private void RebuildMapLabelBatch(){
  // CombineInstance[] cannot cross this game's IL2CPP bridge. Merge the glyph
  // channels directly, retaining one draw call and rebuilding only when dirty.
  var vertices=new List<Vector3>();var uv=new List<Vector2>();var colors=new List<Color>();var triangles=new List<int>();
  for(int i=0;i<mapLabelTexts.Count;i++){
   var mesh=mapLabelMeshes[i];var v=mesh.vertices;var u=mesh.uv;var c=mesh.colors;var t=mesh.triangles;
   int start=vertices.Count;var transform=Matrix4x4.TRS(mapLabelTransforms[i].localPosition,Quaternion.identity,mapLabelTransforms[i].localScale);
   for(int j=0;j<v.Length;j++){vertices.Add(transform.MultiplyPoint3x4(v[j]));uv.Add(u[j]);colors.Add(mapLabelGold[i]?new Color(1f,.85f,.05f,c[j].a):c[j]);}
   for(int j=0;j<t.Length;j++)triangles.Add(start+t[j]);
  }
  mapLabelsBatch.Clear();mapLabelsBatch.vertices=vertices.ToArray();mapLabelsBatch.uv=uv.ToArray();mapLabelsBatch.colors=colors.ToArray();mapLabelsBatch.triangles=triangles.ToArray();mapLabelsBatch.RecalculateBounds();mapLabelsView.enabled=vertices.Count>0;
 }
}}





