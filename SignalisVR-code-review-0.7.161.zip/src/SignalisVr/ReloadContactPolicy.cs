namespace SignalisVrTracking {
 public static class ReloadContactPolicy {
  public static bool PistolCapture(float lateral,float along){return !float.IsNaN(lateral)&&!float.IsNaN(along)&&lateral>=0&&lateral<.06f&&along>=-.16f&&along<=.12f;}
  public static bool PistolSeated(float along){return along>=-.018f;}
  // Wider exit envelope keeps a captured magazine on its rail through hand jitter.
  public static bool PistolRetain(float lateral,float along){return !float.IsNaN(lateral)&&!float.IsNaN(along)&&lateral>=0&&lateral<.08f&&along>=-.18f&&along<=.12f;}
  public static float Slide(float along){return System.Math.Min(0,along);}
 }
}

