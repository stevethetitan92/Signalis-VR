using System;
namespace SignalisVrTracking {
 public sealed class CylinderFlickPolicy {
  private float since=-1,total;
  public void Reset(){since=-1;total=0;}
  public bool Tick(float now,float roll,bool enabled){
   if(!enabled||float.IsNaN(roll)||float.IsInfinity(roll)||Math.Abs(roll)>90){Reset();return false;}
   if(Math.Abs(roll)<.15f)return false;
   if(since<0||now-since>.18f){since=now;total=0;}
   total+=roll;
   if(Math.Abs(total)>=30f){Reset();return true;}return false;
  }
 }
 public sealed class CylinderSwingMotion {
  private float value,start,elapsed;private bool target;
  public void Reset(){value=start=elapsed=0;target=false;}
  public float Tick(bool open,float dt){
   if(open!=target){start=value;elapsed=0;target=open;}
   if(float.IsNaN(dt)||float.IsInfinity(dt)||dt<0)return value;
   elapsed+=Math.Min(.05f,dt);float t=Math.Min(1,elapsed/(open?.18f:.28f));
   float blend=t*t*(3-2*t);value=start+((open?1:0)-start)*blend;return value;
  }
 }
 public static class RifleCases {
  public static int Fired(int spent,int capacity){return Math.Max(0,Math.Min(Math.Max(0,capacity),spent+1));}
  public static int Eject(int spent){return Math.Max(0,Math.Min(2,spent));}
 }
}
