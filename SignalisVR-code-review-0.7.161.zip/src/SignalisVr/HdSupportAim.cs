﻿using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool hdSupportHeld,hdSupportPrevious;private string hdSupportKind;
 private Vector3 hdSupportLocal;
 private Vector3 HdSupportPoint(string kind){
  if(kind=="Rifle")return HdRifleData.Support;
  if(kind=="Shotgun")return ShortenShotgun(HdShotgunData.Pump);
  if(kind=="SMG")return new Vector3(0,.0575f,.24f);
  if(kind=="Pistol")return HdPistolData.Support;
  if(kind=="Revolver")return HdRevolverData.Support;
  return HdFlareGunData.Support;
 }
 private Vector3 smoothedWeaponPalm;
 private Quaternion smoothedWeaponRotation,inertialWeaponRotation;
 private float weaponSmoothTime=-100;private string weaponSmoothKind;
 private void ApplyHdSupportAim(){
  bool gripDown=manualLeftGrip&&!hdSupportPrevious;hdSupportPrevious=manualLeftGrip;
  var w=global::InventoryManager.EquippedWeapon;string kind=w!=null&&w.parentItem!=null?WeaponFamily(w.parentItem._item.ToString()):"";
  if(!QuickFirearm(kind)){hdSupportHeld=false;weaponSmoothKind=null;return;}
  var primary=SavedGripData.Get(kind,1);var support=SavedGripData.Get(kind,0);
  var primaryLocal=primary!=null?primary.Palm:Vector3.zero;
  var rightPalm=rightWeaponPosition;var targetRotation=rightWeaponRotation;
  var local=support!=null?support.Palm:HdSupportPoint(kind);
  if(kind=="Shotgun"){primaryLocal=ShortenShotgun(primaryLocal);if(support!=null)local=ShortenShotgun(local);}
  if(kind=="Shotgun")local+=Vector3.back*Mathf.Clamp(shotgunReload.Pull,0,.1f);
  bool longGun=kind=="Rifle"||kind=="Shotgun"||kind=="SMG";
  bool eligible=controllerMarkers[0]!=null&&(controllerVisibility&1)!=0&&!modMenuOpen&&manualReload.Stage!=ManualReloadPolicy.Step.Holding&&manualReload.Stage!=ManualReloadPolicy.Step.RackHolding&&!AdditionalHoldingAmmo()&&!smgHandleStroke.Held&&!rifleBarrelHeld&&shotgunReload.Stage!=ShotgunReloadPolicy.Step.Holding;
  if((kind=="Pistol"&&manualReload.Active)||(kind=="SMG"&&smgReload.Active)||((kind=="Rifle"||kind=="FlareGun")&&hingedReload.Active)||revolverRod.Held)eligible=false;
  var left=controllerMarkers[0]!=null?controllerMarkers[0].transform.position:rightPalm;
  var socketRotation=hdSupportHeld&&longGun&&weaponSmoothKind==kind?smoothedWeaponRotation:targetRotation;
  var socket=rightPalm+socketRotation*(local-primaryLocal)*UnitsPerMetre;
  float separation=Vector3.Distance(left,socket)/UnitsPerMetre;
  if(!eligible||kind!=hdSupportKind||!manualLeftGrip||separation>.22f)hdSupportHeld=false;
  if(!hdSupportHeld&&kind=="SMG"&&additionalAnchors&&Vector3.Distance(left,additionalBolt)<Mathf.Min(.085f,separation)*UnitsPerMetre)eligible=false;
  // Reload owns the hand until cocking is complete. Inserting ammunition must
  // never reuse that same held press to attach to a nearby support socket.
  if(!hdSupportHeld){
   if(kind=="Pistol"&&Vector3.Distance(left,ManualSlideRear(rightPalm+targetRotation*(new Vector3(0,.05f,-.02f)*UnitsPerMetre)))<Mathf.Min(.12f,separation)*UnitsPerMetre)eligible=false;
   if(revolverRod.Held)eligible=false;
   if(kind=="Pistol"&&manualReload.Active)eligible=false;
   if(kind=="SMG"&&smgReload.Active)eligible=false;
   if((kind=="Rifle"||kind=="FlareGun")&&hingedReload.Active)eligible=false;
  }
  if(eligible&&!hdSupportHeld&&(gripDown||kind=="Rifle"&&manualLeftGrip||kind=="Shotgun"&&shotgunPumpHeld)&&((separation<.14f)||(kind=="Shotgun"&&shotgunPumpHeld))){hdSupportHeld=true;hdSupportKind=kind;hdSupportLocal=local;}
  if(hdSupportHeld&&longGun){
   var span=left-rightPalm;var authored=targetRotation*(local-primaryLocal);
   if(span.sqrMagnitude>.0025f*UnitsPerMetre*UnitsPerMetre&&authored.sqrMagnitude>1e-6f)targetRotation=Quaternion.FromToRotation(authored,span)*targetRotation;
  }
  float now=Time.realtimeSinceStartup,dt=now-weaponSmoothTime;
  bool reset=weaponSmoothKind!=kind||dt<0||dt>.15f||Vector3.Distance(smoothedWeaponPalm,rightPalm)>.5f*UnitsPerMetre;
  if(reset){smoothedWeaponPalm=rightPalm;smoothedWeaponRotation=inertialWeaponRotation=targetRotation;}
  else if(dt>0){
   float blend=1-Mathf.Exp(-dt/.025f);
   inertialWeaponRotation=Quaternion.Slerp(inertialWeaponRotation,targetRotation,blend);
   smoothedWeaponRotation=Quaternion.Slerp(smoothedWeaponRotation,inertialWeaponRotation,blend);
  }
  weaponSmoothTime=now;weaponSmoothKind=kind;
  // The palm is the tracked anchor, not an inertial world-space object.
  // Filtering its position delays joystick locomotion relative to the eyes.
  smoothedWeaponPalm=rightPalm;
  rightWeaponRotation=smoothedWeaponRotation;
  rightWeaponPosition=smoothedWeaponPalm-rightWeaponRotation*primaryLocal*UnitsPerMetre;
 }
 private void ApplyHdVisualRecoil(){
  var w=global::InventoryManager.EquippedWeapon;if(w==null||w.Pointer!=heldShotWeapon||w.parentItem==null)return;
  float age=Time.realtimeSinceStartup-heldShotTime;if(age<0||age>.18f)return;
  float t=age<.028f?age/.028f:1-(age-.028f)/.152f;t=Mathf.Clamp01(t);t=t*(2-t);
  string kind=WeaponFamily(w.parentItem._item.ToString());float amount=kind=="Rifle"?8f:kind=="Shotgun"?4.5f:kind=="Revolver"?3.5f:kind=="SMG"?1.3f:2.2f;
  if(hdSupportHeld)amount*=.55f;
  rightWeaponPosition-=rightWeaponRotation*Vector3.forward*((kind=="Rifle"?.014f:.006f)*t*UnitsPerMetre);
  rightWeaponRotation*=Quaternion.AngleAxis(-amount*t,Vector3.right);
 }
} }






