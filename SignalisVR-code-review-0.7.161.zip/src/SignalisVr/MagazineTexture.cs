using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Material[] magazineMaterials;
  private Mesh magazineMesh;
  private Mesh magazineEmptyMesh;
  private void ApplyMagazineTexture() {
   // Actual extruded silhouette: canted body, stepped heel and raised feed lips.
   // Dimensions remain normalized to the existing magazine/grab/insertion scale.
   var vertices=new List<Vector3>();var groups=new[]{new List<int>(),new List<int>(),new List<int>(),new List<int>(),new List<int>()};
   MagazinePrism(vertices,groups[0],.34f,-.42f,.38f,-.44f,.21f,-.17f,.48f);
   // Dark vertical stamped rib, raised subtly on both broad faces.
   MagazinePrism(vertices,groups[1],.355f,-.35f,.32f,-.37f,-.31f,-.145f,-.085f);
   // Beveled lower collar and broad stepped baseplate.
   MagazinePrism(vertices,groups[2],.39f,-.44f,-.37f,-.47f,.27f,-.44f,.24f);
   MagazinePrism(vertices,groups[1],.48f,-.50f,-.44f,-.50f,.36f,-.50f,.36f);
   // Raised rear shoulder and two separated feed lips: visible open channel.
   MagazinePrism(vertices,groups[0],.30f,.38f,.45f,-.17f,.19f,-.14f,.16f);
   MagazinePrism(vertices,groups[2],.065f,.38f,.50f,-.10f,.40f,-.07f,.36f,-.265f);
   MagazinePrism(vertices,groups[2],.065f,.38f,.50f,-.10f,.40f,-.07f,.36f,.265f);
   // One seated cartridge: brass case/rim and copper rounded projectile.
   // Radius compensates for the magazine's unequal XYZ scaling.
   MagazineRound(vertices,groups[3],-.09f,-.055f,1.08f,1.08f);
   MagazineRound(vertices,groups[3],-.055f,.27f,1f,1f);
   MagazineRound(vertices,groups[4],.27f,.36f,1f,.78f);
   MagazineRound(vertices,groups[4],.36f,.42f,.78f,.12f);
   var weapon=global::InventoryManager.EquippedWeapon;int capacity=weapon==null?10:Math.Min(40,weapon.MagSize);
   for(int round=1;round<capacity;round++){float y=.485f-round*.068f;MagazineRound(vertices,groups[3],-.055f,.27f,1f,1f,y);MagazineRound(vertices,groups[4],.27f,.42f,1f,.12f,y);}
   magazineMesh=new Mesh();magazineMesh.name="SignalisVR_ShapedPistolMagazine";
   magazineMesh.vertices=vertices.ToArray();magazineMesh.subMeshCount=groups.Length;
   for(int i=0;i<groups.Length;i++)magazineMesh.SetTriangles(groups[i].ToArray(),i);
   magazineMesh.RecalculateNormals();magazineMesh.RecalculateBounds();
   magazineEmptyMesh=UnityEngine.Object.Instantiate(magazineMesh);magazineEmptyMesh.name="SignalisVR_EmptyPistolMagazine";
   magazineEmptyMesh.SetTriangles(new int[0],3);magazineEmptyMesh.SetTriangles(new int[0],4);
   var shader=Shader.Find("Unlit/Color");
   if(shader==null)throw new InvalidOperationException("Magazine material shader missing");
   // Muted rose/charcoal metal matches the pistol rather than the old blue-gray cue.
   var palette=new[]{new Color(.34f,.27f,.29f),new Color(.13f,.105f,.115f),new Color(.43f,.34f,.36f),new Color(.68f,.48f,.19f),new Color(.63f,.31f,.17f)};
   magazineMaterials=new Material[palette.Length];
   for(int i=0;i<palette.Length;i++){magazineMaterials[i]=new Material(shader);magazineMaterials[i].color=palette[i];if(magazineMaterials[i].HasProperty("_Glossiness"))magazineMaterials[i].SetFloat("_Glossiness",0f);}
   foreach(var r in new[]{manualMagazine,manualEjected}) {r.GetComponent<MeshFilter>().sharedMesh=magazineMesh;r.sharedMaterials=magazineMaterials;}
  }
  private static void MagazineRound(List<Vector3> v,List<int> tris,float rear,float front,float radiusRear,float radiusFront,float height=.485f) {
   for(int i=0;i<8;i++) {
    float a=i*(float)Math.PI/4f,b=(i+1)*(float)Math.PI/4f;
    var p=new Vector3((float)Math.Cos(a)*.15f,.0f+(float)Math.Sin(a)*.0341f,0);
    var q=new Vector3((float)Math.Cos(b)*.15f,(float)Math.Sin(b)*.0341f,0);
    var r0=new Vector3(0,height,rear);var r1=new Vector3(0,height,front);
    MagazineQuad(v,tris,r0+p*radiusRear,r0+q*radiusRear,r1+q*radiusFront,r1+p*radiusFront);
    int n=v.Count;v.Add(r0);v.Add(r0+q*radiusRear);v.Add(r0+p*radiusRear);tris.Add(n);tris.Add(n+1);tris.Add(n+2);
    n=v.Count;v.Add(r1);v.Add(r1+p*radiusFront);v.Add(r1+q*radiusFront);tris.Add(n);tris.Add(n+1);tris.Add(n+2);
   }
  }
  private static void MagazinePrism(List<Vector3> v,List<int> tris,float half,float bottom,float top,float backBottom,float frontBottom,float backTop,float frontTop,float x=0f) {
   var a=new Vector3(x-half,bottom,backBottom);var b=new Vector3(x+half,bottom,backBottom);
   var c=new Vector3(x+half,bottom,frontBottom);var d=new Vector3(x-half,bottom,frontBottom);
   var e=new Vector3(x-half,top,backTop);var f=new Vector3(x+half,top,backTop);
   var g=new Vector3(x+half,top,frontTop);var h=new Vector3(x-half,top,frontTop);
   MagazineQuad(v,tris,b,f,g,c);MagazineQuad(v,tris,d,h,e,a);
   MagazineQuad(v,tris,a,e,f,b);MagazineQuad(v,tris,c,g,h,d);
   MagazineQuad(v,tris,e,h,g,f);MagazineQuad(v,tris,a,b,c,d);
  }
  private static void MagazineQuad(List<Vector3> v,List<int> tris,Vector3 a,Vector3 b,Vector3 c,Vector3 d) {
   int start=v.Count;v.Add(a);v.Add(b);v.Add(c);v.Add(d);
   tris.Add(start);tris.Add(start+1);tris.Add(start+2);tris.Add(start);tris.Add(start+2);tris.Add(start+3);
  }
  private void DestroyMagazineTexture() {
   if(magazineMaterials!=null)foreach(var material in magazineMaterials)if(material!=null)UnityEngine.Object.Destroy(material);
   if(magazineMesh!=null)UnityEngine.Object.Destroy(magazineMesh);
   if(magazineEmptyMesh!=null)UnityEngine.Object.Destroy(magazineEmptyMesh);
   magazineEmptyMesh=null;
   magazineMaterials=null;magazineMesh=null;
  }
 }
}
