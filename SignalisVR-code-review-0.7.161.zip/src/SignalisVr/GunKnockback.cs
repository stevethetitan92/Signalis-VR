using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 // Harmony keys __state by declaring type. Keep this bool scope separate
 // from Tracking's existing WeaponPoseScope state on the same native method.
 private static class GunKnockbackScopeHooks {
  public static void Begin(out bool __state){BeginGunKnockbackScope(out __state);}
  public static Exception End(Exception __exception,bool __state){return EndGunKnockbackScope(__exception,__state);}
 }
 private static int gunKnockbackDepth;
 private static readonly HashSet<int> gunHeadshotPushed=new HashSet<int>();
 private static bool HeadshotPushWeapon(){var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null)return false;switch(w.parentItem._item){case global::Items.itemlist.Pistol:case global::Items.itemlist.Revolver:case global::Items.itemlist.Shotgun:case global::Items.itemlist.Rifle:case global::Items.itemlist.SMG:return true;default:return false;}}
 private static bool HeadshotPushEnemy(global::EnemyController e){
  if(e==null)return false;
  if(e.Preset!=null&&(e.Preset.Type==global::AnEnemy.AnEnemyType.KNCR||e.Preset.Type==global::AnEnemy.AnEnemyType.ADLR))return false;
  return e.GetComponentInParent<global::END_Boss>()==null&&e.GetComponentInParent<global::LAB_ChimeraBoss>()==null&&e.GetComponentInParent<global::MED_MynahBoss>()==null;
 }
 private static readonly Dictionary<int,float> gunKnockbackUntil=new Dictionary<int,float>();
 private static readonly List<int> expiredGunKnockbacks=new List<int>();
 private static float gunKnockbackCleanup;
 private static void ClearGunKnockback(){if(weaponOwner!=null)weaponOwner.shotEnemyHp.Clear();gunHeadshotPushed.Clear();gunKnockbackUntil.Clear();expiredGunKnockbacks.Clear();gunKnockbackDepth=0;gunKnockbackCleanup=0;}
 private static void BeginGunKnockbackScope(out bool __state){
  var q=weaponOwner;__state=q!=null&&q.ProdVrMode()&&q.WeaponGameplayReady();
  if(__state){if(gunKnockbackDepth==0){gunHeadshotPushed.Clear();q.CaptureGunHeadshotHp();}gunKnockbackDepth++;}
 }
 private static Exception EndGunKnockbackScope(Exception __exception,bool __state){
  if(__state){gunKnockbackDepth=Math.Max(0,gunKnockbackDepth-1);if(gunKnockbackDepth==0){gunHeadshotPushed.Clear();if(weaponOwner!=null)weaponOwner.shotEnemyHp.Clear();}}
  return __exception;
 }
 private static bool AllowGunKnockback(global::EnemyController __instance){
  var e=__instance;
  // Only native gun-ray knockback. GetPushed, physical strikes, scripted
  // reactions, damage and ordinary hurt/death animations are untouched.
  if(gunKnockbackDepth==0||e==null)return true;
  // A classified headshot gets exactly one native reaction per shot, including
  // repeated SMG shots inside the ordinary body-hit cooldown.
  if(HeadshotPushWeapon()&&weaponOwner!=null&&weaponOwner.shotCriticalTargets.Contains(e.GetInstanceID())&&HeadshotPushEnemy(e))return gunHeadshotPushed.Add(e.GetInstanceID());
  if(e.Preset==null)return true;
  var type=e.Preset.Type;
  if(type==global::AnEnemy.AnEnemyType.MNHR||type==global::AnEnemy.AnEnemyType.KNCR||type==global::AnEnemy.AnEnemyType.ADLR)return true;
  float now=Time.time;
  if(now>=gunKnockbackCleanup){
   expiredGunKnockbacks.Clear();
   foreach(var entry in gunKnockbackUntil)if(now>=entry.Value)expiredGunKnockbacks.Add(entry.Key);
   foreach(int id in expiredGunKnockbacks)gunKnockbackUntil.Remove(id);
   gunKnockbackCleanup=now+3f;
  }
  int key=e.GetInstanceID();float until;
  if(gunKnockbackUntil.TryGetValue(key,out until)&&now<until)return false;
  gunKnockbackUntil[key]=now+3f;return true;
 }
 private static void ForgetGunKnockback(global::EnemyController __instance){if(__instance!=null){gunKnockbackUntil.Remove(__instance.GetInstanceID());if(weaponOwner!=null)weaponOwner.enemyHeadBones.Remove(__instance.GetInstanceID());}}
}}

