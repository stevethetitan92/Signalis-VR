using System;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private void InstallQuestPuzzleInput(IntPtr gameBase) {
   if(QuestNativeAddress(typeof(global::InteractionTypeIcon),"NativeMethodInfoPtr_Update_Private_Void_0").ToInt64()-gameBase.ToInt64()!=0x60E5C0)throw new InvalidOperationException("Native event icon layout differs from inspected build");
   questHarmony.Patch(AccessTools.Method(typeof(global::InteractionTypeIcon),"Update"),postfix:new HarmonyMethod(typeof(Tracking),nameof(NativeEventIconUpdated)));
   if(QuestNativeAddress(typeof(global::EventScreen3DCam),"NativeMethodInfoPtr_GetInteractionUnderCursor_Private_Void_0").ToInt64()-gameBase.ToInt64()!=0xB29090)throw new InvalidOperationException("Event interaction cursor layout differs from inspected build");
   questHarmony.Patch(AccessTools.Method(typeof(global::EventScreen3DCam),"GetInteractionUnderCursor"),prefix:new HarmonyMethod(typeof(Tracking),nameof(TrainInteractionRay)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(RestoreTrainInteractionRay)));
   if(QuestNativeAddress(typeof(global::EventWalking),"NativeMethodInfoPtr_Update_Private_Void_0").ToInt64()-gameBase.ToInt64()!=0xB2E5E0)throw new InvalidOperationException("Event walking input layout differs from inspected build");
   questHarmony.Patch(AccessTools.Method(typeof(global::EventWalking),"Update"),prefix:new HarmonyMethod(typeof(Tracking),nameof(EventWalkingInput)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(QuestPuzzleFinalizer)));
   if(QuestNativeAddress(typeof(global::EventScreen3DCam),"NativeMethodInfoPtr_Update_Private_Void_0").ToInt64()-gameBase.ToInt64()!=0xB29D50 ||
      QuestNativeAddress(typeof(global::ROT_Cursor),"NativeMethodInfoPtr_Update_Private_Void_0").ToInt64()-gameBase.ToInt64()!=0x4B74A0)
    throw new InvalidOperationException("Puzzle cursor layout differs from inspected build");
   foreach(var type in new[]{typeof(global::EventScreen3DCam),typeof(global::ROT_Cursor)})
    questHarmony.Patch(AccessTools.Method(type,"Update"),prefix:new HarmonyMethod(typeof(Tracking),type==typeof(global::EventScreen3DCam)?nameof(EventCameraInput):nameof(QuestPuzzlePrefix)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(QuestPuzzleFinalizer)));
  }
  // Scoped to native puzzle consumers: never change the global CharacterAction
  // update or shared getters. Keep native cursor movement, selection and clicks.
  private struct QuestPuzzleState {
   public bool restoreCursorMode,cursorUnlocked;
   public global::EventWalking walker;
   public float walkSpeed,strafeSpeed,turnSpeed;
   public global::CharacterAction input;
   public Vector2 move;
   public Vector2 peek;
   public bool restorePeek;
   public global::CharacterAction.inputDevice device;
  }
  private static void QuestPuzzlePrefix(System.Reflection.MethodBase __originalMethod,out QuestPuzzleState __state) {
   __state=default(QuestPuzzleState);
   var q=questOwner;
   if(q!=null && q.questNativeAvailable && System.Threading.Thread.CurrentThread.ManagedThreadId==q.questNativeThread && __originalMethod.DeclaringType==typeof(global::EventScreen3DCam))q.CenterSnowCursorBeforeInput();
   if(q==null || !q.questNativeAvailable || System.Threading.Thread.CurrentThread.ManagedThreadId!=q.questNativeThread || !q.QuestOwnsInputMode())return;
   var input=global::PlayerState.input;
   if(input==null)return;
   __state.input=input;__state.move=input.Move;__state.device=input.lastActiveController;
   // EventScreen3DCam reads CharacterAction.Peek directly for view rotation.
   // Keep this scoped to that consumer; ROT_Cursor still receives only Move.
   if((__originalMethod.DeclaringType==typeof(global::EventScreen3DCam)||__originalMethod.DeclaringType==typeof(global::EventWalking))&&q.QuestLookBlocker(true)==null) {
    __state.peek=input.Peek;__state.restorePeek=true;
    var peek=input.Peek;
    if(Math.Abs(q.questFrame.lookX)>Math.Abs(peek.x))peek.x=q.questFrame.lookX;
    // Native Peek can already contain right-stick Y. Suppress it only in the
    // active stereo event, and restore the shared input in finalizer.
    if(q.EventWalkCamera()!=null)peek.y=0;
    input.Peek=peek;
    q.QuestLookConsumed("native "+__originalMethod.DeclaringType.Name+" Peek X only");
   }
   // Use the left UI axes even when FP locomotion suppresses MoveHorizontal.
   // Stronger physical input still wins; Quest movement is never added twice.
   var move=input.Move;
   if(Math.Abs(q.questFrame.uiX)>Math.Abs(move.x))move.x=q.questFrame.uiX;
   if(Math.Abs(q.questFrame.uiY)>Math.Abs(move.y))move.y=q.questFrame.uiY;
   // With a centered/locked cursor the native event camera uses Move for
   // rotation; Peek is only consumed by its unlocked-cursor branch.
   if(__originalMethod.DeclaringType==typeof(global::EventScreen3DCam)&&
    !global::EventScreen3DCam.unlockedCursor&&q.QuestLookBlocker(true)==null&&
    Math.Abs(q.questFrame.lookX)>Math.Abs(move.x))move.x=q.questFrame.lookX;
   if(__originalMethod.DeclaringType==typeof(global::EventScreen3DCam)&&q.EventWalkCamera()!=null)move.y=0;
   input.Move=move;
   input.lastActiveController=global::CharacterAction.inputDevice.Controller;
  }
  private static Exception QuestPuzzleFinalizer(Exception __exception,QuestPuzzleState __state) {
   if(__state.restoreCursorMode)global::EventScreen3DCam.unlockedCursor=__state.cursorUnlocked;
   // Restore even if the original throws; do not suppress its exception.
   if(__state.walker!=null){__state.walker.walkSpeed=__state.walkSpeed;__state.walker.strafeSpeed=__state.strafeSpeed;__state.walker.turnSpeed=__state.turnSpeed;}
   if(__state.input!=null) {
    __state.input.Move=__state.move;
    if(__state.restorePeek)__state.input.Peek=__state.peek;
    __state.input.lastActiveController=__state.device;
   }
   return __exception;
  }
 }
}



