using UnityEngine;
using UnityStandardAssets.ImageEffects;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private readonly ScreenOverlay[] playerEyeOverlays=new ScreenOverlay[4];
 private Camera playerEffectsCamera;
 private global::DamageCameraEffects playerEffects;
 private readonly Kino.DigitalGlitch[] playerEyeGlitches=new Kino.DigitalGlitch[2];
 private Random.State playerGlitchRandom;
 private void ResetPlayerScreenEffects(){
  for(int i=0;i<playerEyeGlitches.Length;i++){if(playerEyeGlitches[i]!=null)Object.Destroy(playerEyeGlitches[i]);playerEyeGlitches[i]=null;}
  for(int i=0;i<playerEyeOverlays.Length;i++){if(playerEyeOverlays[i]!=null)Object.Destroy(playerEyeOverlays[i]);playerEyeOverlays[i]=null;}
  playerEffectsCamera=null;playerEffects=null;
 }
 private void RenderPlayerScreenEffects(int eyeIndex){
  var main=global::PlayerState.cameraMain;
  if(main==null)return;
  if(playerEffectsCamera!=main||playerEffects==null){
   if(playerEffectsCamera!=main)ResetPlayerScreenEffects();
   playerEffectsCamera=main;playerEffects=main.GetComponent<global::DamageCameraEffects>();
  }
  if(playerEffects==null||!playerEffects.isActiveAndEnabled)return;
  RenderPlayerDigitalGlitch(eyeIndex,playerEffects.dGlitch);
  RenderPlayerOverlay(eyeIndex,0,playerEffects.redVignette);
  RenderPlayerOverlay(eyeIndex,1,playerEffects.healOverlay);
 }
 private void RenderPlayerDigitalGlitch(int eyeIndex,Kino.DigitalGlitch source){
  if(source==null||!source.isActiveAndEnabled||source.intensity<=0||source._shader==null)return;
  // Native DamageFade drives the strength. Never reuse native trash-frame
  // buffers: doing so would mix desktop, left-eye and right-eye images.
  var savedRandom=Random.state;var savedTarget=RenderTexture.active;
  if(eyeIndex==0)playerGlitchRandom=savedRandom;
  RenderTexture temporary=null;
  try{
   Random.state=playerGlitchRandom;
   var effect=playerEyeGlitches[eyeIndex];
   if(effect==null){effect=eyes[eyeIndex].gameObject.AddComponent<Kino.DigitalGlitch>();effect.enabled=false;playerEyeGlitches[eyeIndex]=effect;}
   effect.enabled=false;effect._shader=source._shader;effect.intensity=source.intensity;
   effect.SetUpResources();
   // Use the same native noise in both eyes without transferring ownership.
   if(source._noiseTexture!=null&&effect._noiseTexture!=null&&source._noiseTexture.width==effect._noiseTexture.width&&source._noiseTexture.height==effect._noiseTexture.height)
    Graphics.CopyTexture(source._noiseTexture,effect._noiseTexture);
   else effect.UpdateNoiseTexture();
   // Resource setup may consume random values only on the first eye. Reset
   // before choosing the trash frame so both eyes make the same choice.
   Random.state=playerGlitchRandom;
   var target=textures[eyeIndex];temporary=RenderTexture.GetTemporary(target.width,target.height,0,target.format);
   effect.OnRenderImage(target,temporary);Graphics.Blit(temporary,target);
  }finally{if(temporary!=null)RenderTexture.ReleaseTemporary(temporary);RenderTexture.active=savedTarget;Random.state=savedRandom;}
 }
 private void RenderPlayerOverlay(int eyeIndex,int effectIndex,ScreenOverlay source){
  // CopyFrom omits image-effect components. Use native live values, including
  // the game's fade/pulse timing, on private eye components instead.
  if(source==null||!source.isActiveAndEnabled||source.intensity<=0||source.overlayShader==null)return;
  int index=eyeIndex*2+effectIndex;var overlay=playerEyeOverlays[index];
  if(overlay==null){overlay=eyes[eyeIndex].gameObject.AddComponent<ScreenOverlay>();overlay.enabled=false;playerEyeOverlays[index]=overlay;}
  overlay.enabled=false;overlay.blendMode=source.blendMode;overlay.intensity=source.intensity;
  overlay.texture=source.texture;overlay.overlayShader=source.overlayShader;
  var target=textures[eyeIndex];var saved=RenderTexture.active;
  var temporary=RenderTexture.GetTemporary(target.width,target.height,0,target.format);
  try{overlay.OnRenderImage(target,temporary);Graphics.Blit(temporary,target);}
  finally{RenderTexture.ReleaseTemporary(temporary);RenderTexture.active=saved;}
 }
}}
