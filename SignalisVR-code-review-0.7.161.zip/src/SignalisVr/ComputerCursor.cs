using UnityEngine;
using UnityEngine.UI;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private global::InteractionTypeIcon computerCursorSource;
 private int computerCursorFrame=-1;
 private GameObject computerCursorRoot;
 private Canvas computerCursorCanvas;
 private Image computerCursorDot,computerCursorIcon;
 private void ObserveComputerCursor(global::InteractionTypeIcon source){
  if(!active||!stereo||desktopMouseOnly||stopping||!nativeEventContext||source==null||source.Event==null||source.Event.cam==null)return;
  var root=ComputerContentRoot(source.Event.cam);
  if(root==null||ComputerSurfaceName(root.name)!="ROT_PC")return;
  computerCursorSource=source;computerCursorFrame=Time.frameCount;
 }
 private bool ComputerCursorVisible(){
  return active&&stereo&&!desktopMouseOnly&&!stopping&&nativeEventContext&&
   computerGuiPresented&&computerStagePresented&&computerCursorFrame==Time.frameCount&&
   !pauseMenuVisible&&!bookScreenVisible&&!modMenuOpen&&
   global::PlayerState.gameState==global::PlayerState.gameStates.eventScreen&&
   computerCursorSource!=null&&computerCursorSource.isActiveAndEnabled&&computerCursorSource.Event!=null&&
   computerCursorSource.Event.cam==computerStageCamera&&ComputerStageReady();
 }
 private Image CreateComputerCursorImage(string name){
  var go=new GameObject(name);go.layer=31;go.AddComponent<RectTransform>();go.transform.SetParent(computerCursorRoot.transform,false);
  var image=go.AddComponent<Image>();image.raycastTarget=false;return image;
 }
 private void RenderComputerCursor(){
  HideComputerCursor();if(!ComputerCursorVisible())return;
  var source=computerCursorSource;
  // Native Dot lives under the normalized (1x1) Pivot, with an inverse
  // pixel scale. Icon is its child. Preserve this hierarchy, not a second
  // canvas-pixel division that would make Dot almost invisible.
  var originalRect=source.dot==null||source.dot.rectTransform.parent==null?null:source.dot.rectTransform.parent.GetComponent<RectTransform>();
  if(originalRect==null)return;
  var size=originalRect.rect.size;if(size.x<=0f||size.y<=0f)return;
  if(computerCursorRoot==null){
   computerCursorRoot=new GameObject("SignalisVR_ComputerInteractionCursor");computerCursorRoot.layer=31;
   computerCursorRoot.AddComponent<RectTransform>();computerCursorRoot.transform.SetParent(puzzleScreen.transform,false);
   computerCursorCanvas=computerCursorRoot.AddComponent<Canvas>();computerCursorCanvas.renderMode=RenderMode.WorldSpace;
   computerCursorCanvas.overrideSorting=true;computerCursorCanvas.sortingOrder=32760;computerCursorCanvas.enabled=false;
   computerCursorDot=CreateComputerCursorImage("Native computer dot");computerCursorIcon=CreateComputerCursorImage("Native computer hover icon");
   computerCursorIcon.rectTransform.SetParent(computerCursorDot.rectTransform,false);
  }
  CopyNativeCursorImage(source.dot,computerCursorDot);CopyNativeCursorImage(source.icon,computerCursorIcon);
  if(source.icon!=null)computerCursorIcon.rectTransform.anchoredPosition3D=source.icon.rectTransform.anchoredPosition3D;
  if(!computerCursorDot.enabled&&!computerCursorIcon.enabled)return;
  var rect=computerCursorRoot.GetComponent<RectTransform>();rect.sizeDelta=size;
  // Native viewport coordinates drive both the interaction ray and this overlay.
  // Parent coordinates refer to the full authored stage, not its monitor subrect.
  var cursor=global::EventScreen3DCam.cursorPosition;
  rect.localPosition=new Vector3(cursor.x-.5f,cursor.y-.5f,-.002f);
  rect.localRotation=Quaternion.identity;rect.localScale=new Vector3(1f/size.x,1f/size.y,1f);
  computerCursorCanvas.enabled=true;Canvas.ForceUpdateCanvases();
 }
 private void HideComputerCursor(){if(computerCursorCanvas!=null)computerCursorCanvas.enabled=false;}
 private void ClearComputerCursor(){
  HideComputerCursor();if(computerCursorRoot!=null)UnityEngine.Object.Destroy(computerCursorRoot);
  computerCursorSource=null;computerCursorFrame=-1;computerCursorRoot=null;computerCursorCanvas=null;computerCursorDot=null;computerCursorIcon=null;
 }
}}
