﻿using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class PickupModelCopy {public global::ItemPickup Pickup;public GameObject Root;public Renderer[] Originals;public bool[] Enabled;}
 private readonly Dictionary<int,PickupModelCopy> pickupModelCopies=new Dictionary<int,PickupModelCopy>();
 private float nextPickupModelPoll;
 private void PollPickupModels(){
  if(Time.realtimeSinceStartup<nextPickupModelPoll)return;nextPickupModelPoll=Time.realtimeSinceStartup+.25f;
  var stale=new List<int>();foreach(var entry in pickupModelCopies)if(entry.Value.Pickup==null||entry.Value.Root==null)stale.Add(entry.Key);
  foreach(var id in stale){ReleasePickupModel(pickupModelCopies[id]);pickupModelCopies.Remove(id);}
  foreach(var point in mapObjects){
   var pickup=point.Pickup;if(pickup==null||pickup._item==null||!pickup.gameObject.activeInHierarchy)continue;
   var itemKind=pickup._item._item;if(itemKind!=global::Items.itemlist.Tape&&itemKind!=global::Items.itemlist.PaintingKey&&itemKind!=global::Items.itemlist.RustedKey&&itemKind!=global::Items.itemlist.SMG)continue;string kind=itemKind.ToString();
   if(itemKind==global::Items.itemlist.SMG){ApplyInventorySmgIcon(null);BindSmgCatalogueModel(pickup._item);}
   int id=pickup.GetInstanceID();PickupModelCopy copy;
   if(!pickupModelCopies.TryGetValue(id,out copy)){
    if(pickup._item.Image3D==null)continue;
    var originals=new List<Renderer>();var enabled=new List<bool>();Bounds bounds=new Bounds();bool found=false;
    foreach(var r in pickup.GetComponentsInChildren<Renderer>(true)){
     if(r==null||!r.enabled||r.gameObject.layer==23||r.gameObject.layer==30||r.GetComponentInParent<global::interactionPopup>()!=null||r.GetComponent<TMPro.TextMeshPro>()!=null)continue;
     if(r.GetComponent<MeshRenderer>()==null&&r.GetComponent<SpriteRenderer>()==null&&r.TryCast<SkinnedMeshRenderer>()==null)continue;
     originals.Add(r);enabled.Add(r.enabled);if(!found){bounds=r.bounds;found=true;}else bounds.Encapsulate(r.bounds);
    }
    if(!found)continue;
    var prefab=pickup._item.Image3D.transform;var root=new GameObject("SignalisVR_Pickup_"+kind);root.transform.SetParent(pickup.transform,false);
    bool geometry=false;Vector3 faceNormal=Vector3.zero;
    copy=new PickupModelCopy{Pickup=pickup,Root=root,Originals=originals.ToArray(),Enabled=enabled.ToArray()};
    try{
    foreach(var filter in prefab.GetComponentsInChildren<MeshFilter>(true)){
     var renderer=filter.GetComponent<MeshRenderer>();if(filter.sharedMesh==null||renderer==null)continue;
     if(!geometry)faceNormal=prefab.InverseTransformDirection(filter.transform.TransformDirection(kind=="Tape"?Vector3.up:Vector3.right));
     var go=new GameObject(filter.name);go.layer=pickup.gameObject.layer;go.transform.SetParent(root.transform,false);
     go.transform.localPosition=prefab.InverseTransformPoint(filter.transform.position);go.transform.localRotation=Quaternion.Inverse(prefab.rotation)*filter.transform.rotation;
     var a=filter.transform.lossyScale;var b=prefab.lossyScale;go.transform.localScale=new Vector3(a.x/b.x,a.y/b.y,a.z/b.z);
     go.AddComponent<MeshFilter>().sharedMesh=filter.sharedMesh;go.AddComponent<MeshRenderer>().sharedMaterials=renderer.sharedMaterials;geometry=true;
    }
    if(!geometry){ReleasePickupModel(copy);continue;}
    root.transform.rotation=pickup.transform.rotation;
    // Native inventory meshes: tape cylinder axis Y, key thin axis X. Lay
    // those faces on the game's XY tabletop plane, not the inventory tilt.
    root.transform.rotation=Quaternion.FromToRotation(root.transform.rotation*faceNormal,Vector3.back)*root.transform.rotation;
    Bounds model=new Bounds();bool first=true;foreach(var r in root.GetComponentsInChildren<Renderer>()){if(first){model=r.bounds;first=false;}else model.Encapsulate(r.bounds);}
    float desired=Mathf.Max(bounds.size.x,Mathf.Max(bounds.size.y,bounds.size.z));float actual=Mathf.Max(model.size.x,Mathf.Max(model.size.y,model.size.z));
    root.transform.localScale*=desired/Mathf.Max(.001f,actual);
    first=true;foreach(var r in root.GetComponentsInChildren<Renderer>()){if(first){model=r.bounds;first=false;}else model.Encapsulate(r.bounds);}
    var placement=bounds.center-model.center;placement.z=bounds.max.z-model.max.z;root.transform.position+=placement;
    pickupModelCopies.Add(id,copy);itemBoundsCache.Clear();
    }catch{ReleasePickupModel(copy);throw;}
   }
   // The parent still owns activation, pickup, scene unload and save/load.
   foreach(var r in copy.Originals)if(r!=null)r.enabled=false;
  }
 }
 private void ReleasePickupModel(PickupModelCopy copy){for(int i=0;i<copy.Originals.Length;i++)if(copy.Originals[i]!=null)copy.Originals[i].enabled=copy.Enabled[i];if(copy.Root!=null)UnityEngine.Object.Destroy(copy.Root);}
 private void ClearPickupModels(){foreach(var copy in pickupModelCopies.Values)ReleasePickupModel(copy);pickupModelCopies.Clear();nextPickupModelPoll=0;}
}}
