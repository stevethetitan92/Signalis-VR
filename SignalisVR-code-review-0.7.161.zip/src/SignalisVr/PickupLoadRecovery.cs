using System;
using MelonLoader;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static bool CollectedPickupNeedsReload(bool active,bool hasIdentity,bool savedExists){return active&&hasIdentity&&!savedExists;}
 private void RepairCollectedPickups(){
  // Native existence is authoritative. Inventory ownership alone cannot prove
  // collection (storage, cheats and distinct pickups can share an item asset).
  if(global::SaveManager.saving||global::PlayerState.gameState!=global::PlayerState.gameStates.play||global::PlayerState.currentRoom==null)return;
  foreach(var point in mapObjects){
   var pickup=point.Pickup;if(pickup==null||pickup.dontDestroyOnPickup||!MapSameRoom(point.Room,global::PlayerState.currentRoom))continue;
   try{
    var uid=pickup.GetComponent<global::UniqueId>();string id=uid==null?null:uid.id;
    if(!CollectedPickupNeedsReload(pickup.gameObject.activeInHierarchy,!string.IsNullOrEmpty(id),string.IsNullOrEmpty(id)||global::SProgress.GetBool("exists: "+id,true)))continue;
    string item=pickup._item==null?"unknown":pickup._item._item.ToString();
    // Reuse the native LoadState behavior, including dontDestroyOnPickup.
    // Never rewrite existence, inventory, save files or interaction callbacks.
    pickup.LoadState();nextModMapRefresh=0;itemBoundsCache.Clear();
    MelonLogger.Msg("PICKUP LOAD REPAIR: native LoadState reapplied; item="+item+" id="+id+" savedExists=False room="+point.Room.name);
   }catch(Exception ex){MelonLogger.Warning("Pickup load reconciliation: "+ex.Message);}
  }
 }
 private static void ReportLoadedSave(int __0){
  try{
   int inventory=-1;var all=global::InventoryManager.allItems;
   if(all!=null&&all.ContainsKey(global::Items.itemlist.OwlKey)){var item=all[global::Items.itemlist.OwlKey];var carried=global::InventoryManager.elsterItems;if(carried!=null&&carried.ContainsKey(item))inventory=carried[item];}
   MelonLogger.Msg("SAVE LOAD: requestedSlot="+__0+" scene="+global::SProgress.GetString("SceneName","")+" room="+global::SProgress.GetString("RoomName","")+" time="+global::SProgress.GetString("SaveTime","")+" owlSaved="+global::SProgress.GetInt("OwlKey",0)+" owlCarriedAtProgressLoad="+inventory+" owlPickupExists="+global::SProgress.GetBool("exists: RES_Residential_042581f7-3fc5-46b1-8747-9e77ceacb335",true));
  }catch(Exception ex){MelonLogger.Warning("Save load diagnostics: "+ex.Message);}
 }
}}
