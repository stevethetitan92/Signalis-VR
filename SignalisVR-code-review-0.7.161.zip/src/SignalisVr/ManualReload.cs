using System;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly ManualReloadPolicy manualReload=new ManualReloadPolicy { RequireFreshRackGrip=true, InsertionDwell=.02f };
  private bool manualB,manualFailed,manualSeatLatched,manualGuideCaptured;
  private float manualGuideStart;
  private Vector3 manualGuideOffset;private Quaternion manualGuideRotation;
  private int manualVisualFrame=-1,manualPulseUntil=-1,manualReports,manualAmmoBefore;
  private float manualEjectTime=-100f;
  private Vector3 manualEjectPosition;
  private Quaternion manualEjectRotation;
  private bool manualEjectedLoaded;
  private IntPtr manualWeapon;
  private float manualRackStarted=-100f;
  private IntPtr manualRackWeapon;
  private bool manualRackPending;
  private GameObject manualRoot;
  private MeshRenderer manualMagazine,manualPouch,manualSocket,manualEjected;
  private Material manualMetalMaterial,manualCueMaterial;
  private bool ManualPistolEligible() {
   var w=global::InventoryManager.EquippedWeapon;
   return manualReloadEnabled&&!modMenuOpen&&!manualFailed&&!mouseWeaponTest&&questPolicy.RightArmed&&questPolicy.LeftArmed
    &&ManualReloadContextReady()&&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput
    &&w!=null&&w.parentItem!=null&&w.parentItem._item==global::Items.itemlist.Pistol;
  }
  private bool RetainPhysicalReload(){var w=global::InventoryManager.EquippedWeapon;return manualReloadEnabled&&!manualFailed&&!additionalFailed&&w!=null&&((manualReload.Active&&manualWeapon==w.Pointer)||(AdditionalReloadActive()&&additionalWeapon==w.Pointer));}
  private bool ManualReloadContextReady(){
   // Update input must not depend on a render-pose timestamp. Slow frames otherwise
   // discard B presses and cancel held shells/pump travel before the next eye render.
   return weaponHooksReady&&!weaponAimFailed&&controllerMotionEnabled&&QuestUnifiedReady()&&questAvailabilityValue
    &&!questMenuScene&&!pauseMenuVisible&&!bookScreenVisible&&!dialogueScreenVisible
    &&WeaponGameplayReady()&&!global::PlayerState.paused&&!global::PlayerState.eventScreen;
  }
  private bool ManualHasAmmo(global::AnWeapon w) {
   if(infiniteAmmo&&w!=null&&w.ammoItem!=null)return true;
   return w!=null&&w.ammoItem!=null&&global::InventoryManager.elsterItems!=null
    &&global::InventoryManager.elsterItems.ContainsKey(w.ammoItem)&&global::InventoryManager.elsterItems[w.ammoItem]>0;
  }
  private void CancelManualReload(){manualGuideCaptured=false;manualSeatLatched=false;CancelAdditionalReload();CancelShotgunReload();manualReload.Cancel();manualPulseUntil=-1;manualWeapon=IntPtr.Zero;manualEjectTime=-100f;manualRackStarted=-100f;manualRackWeapon=IntPtr.Zero;manualRackPending=false;HideManualReload();}
  private void FilterManualReloadInput() {
   bool b=(questFrame.buttons&(1<<7))!=0;
   try {
    if(AdditionalGunEligible()){manualReload.Cancel();CancelShotgunReload();manualPulseUntil=-1;manualRackPending=false;FilterAdditionalReloadInput(b);manualB=b;return;}
    FilterAdditionalReloadInput(b);
    if(ManualShotgunEligible()){manualReload.Cancel();manualPulseUntil=-1;manualRackPending=false;FilterShotgunReloadInput(b);manualB=b;return;}
    FilterShotgunReloadInput(b);
    if(!ManualPistolEligible()){if(!RetainPhysicalReload())CancelManualReload();else questFrame.buttons&=~((1<<7)|(1<<6));manualB=b;return;}
    var w=global::InventoryManager.EquippedWeapon;float now=Time.realtimeSinceStartup;
    if(manualWeapon!=IntPtr.Zero&&manualWeapon!=w.Pointer)CancelManualReload();
    var before=manualReload.Stage;
    if(manualReload.ObserveGame(now,global::PlayerState.reloading,w.magAmmo>manualAmmoBefore)) {
     manualWeapon=IntPtr.Zero;manualPulseUntil=-1;ManualReloadReport("native reload completed; magazine="+w.magAmmo+" reserve="+(ManualHasAmmo(w)?"available":"empty"));
    }else if(before==ManualReloadPolicy.Step.AwaitingGame&&manualReload.Stage==ManualReloadPolicy.Step.Inserted)
     ManualReloadReport("native reload not accepted; grip and release slide to retry");
    if(manualRackPending) {
     manualRackPending=false;
     bool racked=manualReload.RequiresRack;
     CommitPhysicalMagazine(w);manualReload.Cancel();manualSeatLatched=false;manualPulseUntil=-1;
     if(racked){PlayMechanismSound("Pistol","SlideForward");manualRackStarted=now;manualRackWeapon=w.Pointer;}
     ManualReloadReport("Physical reload complete; magazine="+w.magAmmo);
    }
    bool canReload=true; // Native automatic reload is suppressed in manual VR mode.
    if(b&&!manualB) {
     var old=manualReload.Stage;
     manualReload.PressB(now,manualLeftGrip,canReload,w.magAmmo==0);
     if(old==ManualReloadPolicy.Step.Idle&&manualReload.Stage==ManualReloadPolicy.Step.Ejected) {
      PlayMechanismSound("Pistol","MagDrop");manualWeapon=w.Pointer;manualAmmoBefore=w.magAmmo;
      manualEjectedLoaded=w.magAmmo>0;
      manualEjectTime=now;manualEjectPosition=rightWeaponPosition+rightWeaponRotation*(new Vector3(0f,-.06f,0f)*UnitsPerMetre);manualEjectRotation=rightWeaponRotation;
      ManualReloadReport(manualReload.RequiresRack?"B eject: empty; insert magazine, then pull and release slide":"B eject: chambered round retained; insert magazine to finish");
     }else if(!canReload)ManualReloadReport("reload unavailable: magazine full, no reserve ammo, or game already reloading");
    }
    questFrame.buttons&=~(1<<7);
    if(b)questFrame.buttons&=~(1<<1);
    if(manualReload.Active)questFrame.buttons&=~(1<<6);
    if(Time.frameCount<=manualPulseUntil)questFrame.buttons|=1<<7;
    manualB=b;
   }catch(Exception ex){manualFailed=true;CancelManualReload();MelonLogger.Warning("Manual reload disabled; native reload retained: "+ex.Message);}
  }
  private bool ManualReloadOwnsInput(){return ManualPistolEligible()||ManualShotgunEligible()||AdditionalGunEligible();}
  private bool ManualReloadBlocksAttack(){return ((ManualPistolEligible()&&manualReload.Active)||(ManualShotgunEligible()&&shotgunReload.BlocksAttack)||(AdditionalGunEligible()&&AdditionalReloadActive()))&&questAvailabilityValue&&!questMenuScene&&!pauseMenuVisible&&!bookScreenVisible&&!dialogueScreenVisible;}
  private void ManualReloadReport(string value){if(manualReports++<160)MelonLogger.Msg("MANUAL PISTOL RELOAD: "+value);}
  private void EnsureManualReloadVisuals() {
   if(manualRoot!=null)return;
   manualRoot=new GameObject("SignalisVR_ManualReload");UnityEngine.Object.DontDestroyOnLoad(manualRoot);
   manualRoot.transform.localScale=Vector3.one*UnitsPerMetre;
   var mesh=controllerBodies[0].GetComponent<MeshFilter>().sharedMesh;
   var shader=Shader.Find("Unlit/Color");if(shader==null)throw new InvalidOperationException("Reload cue shader missing");
   manualMetalMaterial=new Material(shader);manualMetalMaterial.color=new Color(.32f,.36f,.40f);
   manualCueMaterial=new Material(shader);manualCueMaterial.color=new Color(.15f,.65f,.9f);
   manualMagazine=CreateControllerPart(manualRoot,mesh,manualMetalMaterial,"ReplacementMagazine",Vector3.zero,new Vector3(.025f,.11f,.04f));
   manualEjected=CreateControllerPart(manualRoot,mesh,manualMetalMaterial,"ReleasedMagazine",Vector3.zero,new Vector3(.025f,.11f,.04f));
   manualMagazine.GetComponent<MeshFilter>().sharedMesh=null;manualEjected.GetComponent<MeshFilter>().sharedMesh=null;
   ApplySelectedHeldMagazine();
   manualPouch=CreateControllerPart(manualRoot,mesh,manualCueMaterial,"LeftHipPouch",Vector3.zero,new Vector3(.08f,.10f,.035f));
   manualSocket=CreateControllerPart(manualRoot,mesh,manualCueMaterial,"ReloadTarget",Vector3.zero,new Vector3(.025f,.025f,.025f));
  }
  private void PrepareManualReload() {
   HideManualReload();PrepareShotgunReload();PrepareAdditionalReload();
   if(!manualReload.Active)return;
   try {
    if(!ManualPistolEligible()){if(!RetainPhysicalReload())CancelManualReload();return;}
    // A temporary missed eye pose must not eject/cancel a magazine on its own.
    if(!handsScoped||renderedWeapon==null||controllerMarkers[0]==null)return;
    EnsureManualReloadVisuals();if(!ApplySelectedHeldMagazine())return;
    var left=controllerMarkers[0].transform;
    var yaw=BodyHipRotation();
    var pouch=stereoPosition+yaw*(new Vector3(-.22f,-.5f,0f)*UnitsPerMetre);
    var rightPalm=handsObjects[1].transform.TransformPoint(handPalmCenters[1]);
    var well=SelectedActive("Pistol")?SelectedMagazineWell():rightPalm-rightWeaponRotation*Vector3.up*(.055f*UnitsPerMetre);
    var slide=ManualSlideRear(rightWeaponPosition+rightWeaponRotation*(new Vector3(0f,.05f,-.02f)*UnitsPerMetre));
    var pinch=leftPinchThumb!=null&&leftPinchIndex!=null?(leftPinchThumb.position+leftPinchIndex.position)*.5f:left.position;
    // In a wrapped magazine grip the feed end exits on the thumb/index side,
    // not along the fingers. Broad textured faces lie against the palm;
    // the narrow edge follows the finger direction. Keep this hand-relative.
    var handBasis=WeaponAimPolicy.ControllerRotation(left.rotation);
    var magazineRotation=handBasis;
    var magazineCenter=left.position+magazineRotation*Vector3.right*(.025f*UnitsPerMetre);
    var rawMagazineCenter=magazineCenter;var rawMagazineRotation=magazineRotation;
    var magazineTip=magazineCenter+magazineRotation*Vector3.up*((SelectedActive("Pistol")&&selectedHeldMagazine!=null?selectedHeldMagazine.bounds.extents.y:.055f)*UnitsPerMetre);
    bool magazineAtWell=Vector3.Distance(magazineTip,well)<.065f*UnitsPerMetre;
    bool magazineInGuide=false;
    if(SelectedActive("Pistol")&&selectedHeldMagazine!=null){
     // Follow the authored sloping rear wall, as in the approved insertion preview.
     var axis=(HdPistolData.MagazineTop-selectedMagazine.GetComponent<MeshFilter>().sharedMesh.bounds.center).normalized;
     var seated=selectedMagazine.GetComponent<MeshFilter>().sharedMesh.bounds.center;
     var centre=Quaternion.Inverse(rightWeaponRotation)*(magazineCenter-rightWeaponPosition)/UnitsPerMetre;
     var offset=centre-seated;float along=Vector3.Dot(offset,axis);
     float lateral=(offset-axis*along).magnitude;
     magazineAtWell=false;
     if(manualReload.Stage!=ManualReloadPolicy.Step.Holding){manualSeatLatched=false;manualGuideCaptured=false;}
     bool wasCaptured=manualGuideCaptured;
     manualGuideCaptured=manualReload.Stage==ManualReloadPolicy.Step.Holding&&(manualSeatLatched||(manualGuideCaptured?lateral<.18f&&along>-.24f&&along<.20f:ReloadContactPolicy.PistolCapture(lateral,along)));
     if(manualGuideCaptured&&!wasCaptured){manualGuideStart=Time.realtimeSinceStartup;manualGuideOffset=offset;manualGuideRotation=Quaternion.Inverse(rightWeaponRotation)*magazineRotation;}
     if(manualGuideCaptured){
      magazineInGuide=true;
      float t=Mathf.Clamp01((Time.realtimeSinceStartup-manualGuideStart)/.10f);float blend=t*t*(3-2*t);
      magazineRotation=rightWeaponRotation*Quaternion.Slerp(manualGuideRotation,Quaternion.identity,blend);
      // Align sideways, but preserve hand-driven travel along the well.
      var rail=axis*ReloadContactPolicy.Slide(along);
      var lateralOffset=offset-axis*along;
      magazineCenter=rightWeaponPosition+rightWeaponRotation*(seated+rail+lateralOffset*(1-blend))*UnitsPerMetre;
      magazineAtWell=manualSeatLatched||(t>=1&&ReloadContactPolicy.PistolSeated(along));
      if(magazineAtWell)manualSeatLatched=true;
     }
    }
    if(manualVisualFrame!=Time.frameCount) {
     manualVisualFrame=Time.frameCount;var old=manualReload.Stage;
     if(manualSeatLatched&&!manualLeftGrip&&manualReload.Seat(Time.realtimeSinceStartup))manualRackPending=true;
     if(manualReload.Tick(Time.realtimeSinceStartup,true,manualLeftGrip,
      Vector3.Distance(left.position,pouch)<.27f*UnitsPerMetre,
      magazineAtWell,
      Math.Min(Vector3.Distance(pinch,slide),Vector3.Distance(left.position,slide))<.12f*UnitsPerMetre,
      Vector3.Dot(left.position-rightWeaponPosition,rightWeaponRotation*Vector3.back)/UnitsPerMetre))manualRackPending=true;
     if(old==ManualReloadPolicy.Step.Holding&&manualReload.Stage==ManualReloadPolicy.Step.Ejected) {
      manualEjectedLoaded=ManualHasAmmo(global::InventoryManager.EquippedWeapon);
      manualEjectTime=Time.realtimeSinceStartup;manualEjectPosition=magazineCenter;manualEjectRotation=magazineRotation;
     }
     if(old==ManualReloadPolicy.Step.Holding&&(manualReload.Stage==ManualReloadPolicy.Step.Inserted||manualReload.Stage==ManualReloadPolicy.Step.AwaitingGame))PlayMechanismSound("Pistol","MagInsert");
     if(old!=manualReload.Stage)ManualReloadReport("stage="+manualReload.Stage+(manualReload.Stage==ManualReloadPolicy.Step.Inserted?"; grip slide then release":""));
    }
    if(!manualReload.Active)return;
    manualPouch.transform.position=pouch;manualPouch.transform.rotation=yaw;manualPouch.enabled=manualReload.Stage==ManualReloadPolicy.Step.Ejected;
    manualMagazine.transform.position=magazineCenter;manualMagazine.transform.rotation=magazineRotation;
    manualMagazine.enabled=manualReload.Stage==ManualReloadPolicy.Step.Holding;
    // The Elster hand follows the guided magazine throughout insertion.
    if(manualMagazine.enabled)FollowAmmoWithHand(rawMagazineCenter,rawMagazineRotation,magazineCenter,magazineRotation);
    // Keep the imported Beretta mesh/material pair; never overwrite it with the generic magazine.
    if(!ApplySelectedHeldMagazine()){HideManualReload();return;}
    bool inserted=manualReload.Stage==ManualReloadPolicy.Step.Inserted||manualReload.Stage==ManualReloadPolicy.Step.RackHolding||manualReload.Stage==ManualReloadPolicy.Step.AwaitingGame;
    manualSocket.transform.position=inserted?slide:well;manualSocket.transform.rotation=rightWeaponRotation;manualSocket.transform.localScale=Vector3.one*.009f;manualSocket.enabled=false;
    float age=Time.realtimeSinceStartup-manualEjectTime;
    if(age>=0&&age<.45f) {
     manualEjected.transform.position=manualEjectPosition-(controllerTrackingToWorld*Vector3.up)*(Math.Min(.6f,.5f*9.81f*age*age)*UnitsPerMetre);
     manualEjected.transform.rotation=manualEjectRotation;manualEjected.enabled=true;
    }
   }catch(Exception ex){manualFailed=true;CancelManualReload();MelonLogger.Warning("Manual reload visuals disabled; native reload retained: "+ex.Message);}
  }
  private bool manualLeftGrip;
  private void HideManualReload(){HideHipAmmo();HideAdditionalReload();HideShotgunReload();if(manualMagazine!=null)manualMagazine.enabled=false;if(manualPouch!=null)manualPouch.enabled=false;if(manualSocket!=null)manualSocket.enabled=false;if(manualEjected!=null)manualEjected.enabled=false;}
  private void DestroyManualReload(){DestroyHipAmmo();CancelManualReload();DestroyAdditionalVisual();DestroyReloadAmmoDetails();DestroyShotgunReload();DestroyMagazineTexture();if(manualRoot!=null)UnityEngine.Object.Destroy(manualRoot);if(manualMetalMaterial!=null)UnityEngine.Object.Destroy(manualMetalMaterial);if(manualCueMaterial!=null)UnityEngine.Object.Destroy(manualCueMaterial);manualMetalMaterial=null;manualCueMaterial=null;manualRoot=null;manualMagazine=null;manualPouch=null;manualSocket=null;manualEjected=null;}
 }
}






