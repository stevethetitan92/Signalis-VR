using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private readonly Dictionary<int,float> receiverFooterChecks=new Dictionary<int,float>();
 private void UpdateReceiverFooter(global::RadioUI panel){
  if(!QuestPromptControl())return;
  int id=panel.GetInstanceID();float next;
  if(receiverFooterChecks.TryGetValue(id,out next)&&Time.realtimeSinceStartup<next)return;
  if(receiverFooterChecks.Count>16)receiverFooterChecks.Clear();receiverFooterChecks[id]=Time.realtimeSinceStartup+.25f;
  // The native and enhanced-resolution UI copies each own their own footer.
  // Work from the visible panel, leaving its radio input/controller untouched.
  foreach(var label in panel.transform.root.GetComponentsInChildren<TMPro.TMP_Text>(true)){
   string text=label.text??"";bool frequency=text.Contains("ADJUST FREQUENCY"),toggle=text.Contains("TOGGLE RADIO");
   if(!frequency&&!toggle)continue;
   var parent=label.transform.parent;if(parent==null)continue;
   if(frequency)label.text="GRIPS  ADJUST FREQUENCY";
   foreach(var prompt in parent.GetComponentsInChildren<global::InputActionPromptIcon>(true)){
    // Only prompt artwork in this hint group, never puzzle/world markers.
    var sprite=QuestPromptSprite(frequency?"":"A");
    if(prompt.IMG!=null)prompt.IMG.sprite=sprite;if(prompt.SR!=null)prompt.SR.sprite=sprite;
   }
  }
 }
}}

