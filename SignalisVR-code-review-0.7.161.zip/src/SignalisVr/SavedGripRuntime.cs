﻿using UnityEngine;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private readonly SavedGrip[] activeSavedGrip=new SavedGrip[2];
 private readonly float[] savedThumbScale=new float[]{1,1};
 private void ResolveSavedGrip(int hand,ref Vector3 palm,ref Quaternion basis,ElsterGripKind pose){
  activeSavedGrip[hand]=null;string key=null;Transform frame=null;Vector3 origin=rightWeaponPosition;Quaternion rotation=rightWeaponRotation;
  if(hand==1){
   if(heldQuickHealth!=null){if(heldQuickHealth._item==global::Items.itemlist.Health25&&patchGripFrame!=null){key="RepairPatch";origin=patchGripFrame.TransformPoint(patchGripFrame.GetComponent<MeshFilter>().sharedMesh.bounds.center);rotation=patchGripFrame.rotation;}else if(healthGripFrame!=null){key="RepairSpray";origin=healthGripFrame.TransformPoint(new Vector3(.40f,-.36f,.285f));rotation=healthGripFrame.rotation*Quaternion.Euler(0,-90,0);}}
   else if(ProdEligible()&&prodPoseValid){key="StunProd";origin=prodResolved;rotation=prodResolvedRotation;}
   else if(ThermiteEligible()&&thermiteHand!=null){key="ThermiteFlare";frame=thermiteHand.transform;}
   else if(pose==ElsterGripKind.Trigger){var w=global::InventoryManager.EquippedWeapon;if(w!=null&&w.parentItem!=null)key=WeaponFamily(w.parentItem._item.ToString());}
  }else{
   if(shotgunPumpHeld&&SelectedActive("Shotgun")&&selectedMoving!=null){key="Shotgun";frame=selectedMoving.transform;}
   else if(revolverRod.Held&&SelectedActive("Revolver"))return;
   else if(hdSupportHeld){key=hdSupportKind;if(key=="Shotgun"&&selectedMoving!=null)frame=selectedMoving.transform;}
   else if(manualMagazine!=null&&manualMagazine.enabled&&manualReload.Active){key="PistolMagazine";frame=manualMagazine.transform;}
   else if(AdditionalHoldingAmmo()&&additionalAmmo!=null){key=additionalVisualKind=="SMG"?"SMGMagazine":additionalVisualKind+"Ammo";frame=additionalAmmo.transform;}
   else if(shotgunShell!=null&&shotgunShell.enabled){key="ShotgunAmmo";frame=shotgunShell.transform;}
   else if(manualReload.Stage==ManualReloadPolicy.Step.RackHolding&&SelectedActive("Pistol")&&selectedMoving!=null){key="PistolSlide";frame=selectedMoving.transform;}
   else if(smgHandleStroke.Held&&xiphiasHandle!=null){key="SMGCharging";frame=xiphiasHandle.transform;}
   else if(rifleBarrelHeld&&SelectedActive("Rifle")&&selectedMoving!=null){key="Rifle";frame=selectedMoving.transform;}
  }
  if(key==null)return;var g=SavedGripData.Get(key,hand);if(g==null)return;
  if(frame!=null){origin=frame.position;rotation=frame.rotation;}
  palm=origin+rotation*(key=="Shotgun"?ShortenShotgun(g.Palm):g.Palm)*UnitsPerMetre;basis=rotation*g.Turn*elsterHandBasis[hand];activeSavedGrip[hand]=g;
 }
 private void ApplySavedThumb(int hand){
  var g=activeSavedGrip[hand];float scale=g==null?1:g.Thumb;string side=hand==0?".l":".r";
  for(int j=2;j<=3;j++){int b=EB("thumb"+j+side);elsterBones[b].localPosition=(elsterRest[b]-elsterRest[elsterParents[b]])*scale;}
  if(Mathf.Abs(savedThumbScale[hand]-scale)<.000001f)return;savedThumbScale[hand]=scale;
  var binds=new Matrix4x4[elsterRest.Length];for(int b=0;b<binds.Length;b++)binds[b]=Matrix4x4.TRS(-elsterRest[b],Quaternion.identity,Vector3.one);
  for(int h=0;h<2;h++)for(int j=1;j<=3;j++){
   string s=h==0?".l":".r";int b=EB("thumb"+j+s),a=j<3?b:EB("thumb2"+s),next=j<3?EB("thumb"+(j+1)+s):b;var axis=(elsterRest[next]-elsterRest[a]).normalized;var matrix=Matrix4x4.identity;float k=savedThumbScale[h]-1;
   for(int row=0;row<3;row++)for(int col=0;col<3;col++)matrix[row,col]+=(axis[row]*axis[col]*k);
   var t=matrix.MultiplyVector(-elsterRest[b]);matrix.m03=t.x;matrix.m13=t.y;matrix.m23=t.z;binds[b]=matrix;
  }
  foreach(var mesh in elsterMeshes)if(mesh!=null)mesh.bindposes=binds;
 }
}}
