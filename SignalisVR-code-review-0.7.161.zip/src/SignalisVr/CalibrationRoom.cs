using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private GameObject calibrationRoot;
  private string calibrationBuildStage;
  private readonly List<Material> calibrationMaterials=new List<Material>();
  private Transform calibrationPlayer;
  private global::Room calibrationSourceRoom;
  private Vector3 calibrationReturnPosition,calibrationCentre;
  private Quaternion calibrationReturnRotation;
  private static bool CalibrationRoomTransitionGuard(){return weaponOwner==null||weaponOwner.calibrationRoot==null;}
  private void CalibrationPiece(string name,Vector3 local,Vector3 size,Color color,bool solid){
   var part=GameObject.CreatePrimitive(PrimitiveType.Cube);part.name=name;part.transform.SetParent(calibrationRoot.transform,false);part.transform.localPosition=local*UnitsPerMetre;part.transform.localScale=size*UnitsPerMetre;
   // Native movement/projectile wall queries use the player attack's wall mask.
   int mask=global::PlayerAttack.instance==null?1:(int)global::PlayerAttack.instance.WallMask;int layer=0;while(layer<31&&(mask&(1<<layer))==0)layer++;part.layer=layer;
   var collider=part.GetComponent<Collider>();collider.enabled=solid;
   var shader=Shader.Find("Standard");if(shader==null)shader=Shader.Find("Unlit/Color");if(shader==null)throw new InvalidOperationException("Calibration shader unavailable");var material=new Material(shader);material.color=color;calibrationMaterials.Add(material);part.GetComponent<Renderer>().material=material;
  }
  private void EnterCalibrationRoom(){
   if(!testHooksReady||!CheatPlayerReady()||global::PlayerState.hp<=0||global::PlayerState.cutscene){testMenuStatus="Load a living character in a normal room first.";return;}
   var control=global::PlayerState.player.GetComponent<global::AlternatePlayerController>();
   if(control==null||control.traversing){testMenuStatus="Wait until the doorway transition finishes.";return;}
   calibrationBuildStage="validate storage";ValidateCalibrationStorage();calibrationPlayer=global::PlayerState.player.transform;calibrationReturnPosition=calibrationPlayer.position;calibrationReturnRotation=calibrationPlayer.rotation;calibrationSourceRoom=global::PlayerState.currentRoom;
   calibrationCentre=calibrationReturnPosition+new Vector3(1000*UnitsPerMetre,0,0);
   DestroyTestEnemy();
   try {
    calibrationBuildStage="room geometry";calibrationRoot=new GameObject("SignalisVR_TemporaryCalibrationRoom");calibrationRoot.transform.SetPositionAndRotation(calibrationCentre,Quaternion.Euler(-90f,0f,0f));
    CalibrationPiece("Floor",new Vector3(0,-.15f,0),new Vector3(12,.3f,12),new Color(.17f,.19f,.2f),true);
    CalibrationPiece("Ceiling",new Vector3(0,4.65f,0),new Vector3(12,.3f,12),new Color(.28f,.3f,.31f),true);
    foreach(int side in new[]{-1,1}){
     CalibrationPiece("Wall X",new Vector3(side*6f,2.25f,0),new Vector3(.3f,4.5f,12.3f),new Color(.25f,.28f,.29f),true);
     CalibrationPiece("Wall Z",new Vector3(0,2.25f,side*6f),new Vector3(12.3f,4.5f,.3f),new Color(.25f,.28f,.29f),true);
    }
    for(int i=-5;i<=5;i++){
     CalibrationPiece("Metre grid X",new Vector3(i,.003f,0),new Vector3(.012f,.004f,11.7f),new Color(.32f,.42f,.44f),false);
     CalibrationPiece("Metre grid Z",new Vector3(0,.003f,i),new Vector3(11.7f,.004f,.012f),new Color(.32f,.42f,.44f),false);
    }
    CalibrationPiece("Centre X",new Vector3(0,.007f,0),new Vector3(.025f,.004f,1),new Color(.15f,.85f,.95f),false);
    CalibrationPiece("Centre Z",new Vector3(0,.007f,0),new Vector3(1,.004f,.025f),new Color(.15f,.85f,.95f),false);
    foreach(int side in new[]{-1,1})CalibrationPiece("Ceiling light",new Vector3(side*3,4.48f,0),new Vector3(.4f,.04f,10),new Color(.65f,.88f,.9f),false);
    var lightObject=new GameObject("Calibration light");lightObject.transform.SetParent(calibrationRoot.transform,false);lightObject.transform.localPosition=Vector3.up*3*UnitsPerMetre;var light=lightObject.AddComponent<Light>();light.type=LightType.Point;light.range=15*UnitsPerMetre;light.intensity=2f;light.color=new Color(.8f,.92f,1f);
    calibrationBuildStage="inventory";CreateCalibrationStorage();calibrationBuildStage="player move";MoveCalibrationPlayer(calibrationRoot.transform.TransformPoint(new Vector3(0,0,-2.5f)*UnitsPerMetre),calibrationReturnRotation);SpawnTestEnemy();SetTestHalfHealth();testMenuStatus="Health: 50 / 100. Infinite Life OFF. Calibration room: 12 x 12 metres. Leave returns to your starting location.";
    calibrationBuildStage="weapon warmup";WarmSelectedModels();
    FinishModMenu();
   }catch(Exception ex){MelonLoader.MelonLogger.Warning("Calibration stage "+calibrationBuildStage+": "+ex);try{LeaveCalibrationRoom(true);}catch(Exception cleanup){MelonLoader.MelonLogger.Warning("Calibration cleanup: "+cleanup);}throw;}
  }
  private void MoveCalibrationPlayer(Vector3 position,Quaternion rotation){
   if(calibrationPlayer==null)return;calibrationPlayer.SetPositionAndRotation(position,rotation);
   var body=calibrationPlayer.GetComponent<Rigidbody>();if(body!=null){body.position=position;body.velocity=Vector3.zero;body.angularVelocity=Vector3.zero;}
   var control=calibrationPlayer.GetComponent<global::AlternatePlayerController>();if(control!=null)control.lastPos=new Vector2(position.x,position.y);
   ResetDoorCamera();ResetProdSample();CancelManualReload();Physics.SyncTransforms();
  }
  private void PollCalibrationRoom(){
   if(calibrationRoot==null)return;RefillCalibrationStorage();
   if(calibrationPlayer==null||!CheatPlayerReady()||calibrationPlayer!=global::PlayerState.player.transform||calibrationSourceRoom!=global::PlayerState.currentRoom){LeaveCalibrationRoom(false);return;}
   var position=calibrationPlayer.position;var relative=calibrationRoot.transform.InverseTransformPoint(position);
   // Keep locomotion and room-scale movement away from the void; real walls remain collidable.
   if(Math.Abs(relative.x)>5.5f*UnitsPerMetre||Math.Abs(relative.z)>5.5f*UnitsPerMetre||relative.y<-.5f*UnitsPerMetre){relative.x=Mathf.Clamp(relative.x,-5.4f*UnitsPerMetre,5.4f*UnitsPerMetre);relative.z=Mathf.Clamp(relative.z,-5.4f*UnitsPerMetre,5.4f*UnitsPerMetre);relative.y=0;MoveCalibrationPlayer(calibrationRoot.transform.TransformPoint(relative),calibrationPlayer.rotation);}
  }
  private void LeaveCalibrationRoom(bool restore){
   if(calibrationRoot==null)return;DestroyTestEnemy();RestoreCalibrationStorage();
   if(restore&&calibrationPlayer!=null&&global::PlayerState.player!=null&&calibrationPlayer==global::PlayerState.player.transform)MoveCalibrationPlayer(calibrationReturnPosition,calibrationReturnRotation);
   calibrationRoot.SetActive(false);UnityEngine.Object.Destroy(calibrationRoot);calibrationRoot=null;
   foreach(var material in calibrationMaterials)if(material!=null)UnityEngine.Object.Destroy(material);calibrationMaterials.Clear();calibrationPlayer=null;calibrationSourceRoom=null;
   testMenuStatus="Returned from calibration room.";
  }
 }
}



