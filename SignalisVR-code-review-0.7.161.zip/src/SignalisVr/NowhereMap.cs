﻿using System;using System.Collections.Generic;using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool nowhereMapActive;private NowhereMapLayout.Cell nowhereCurrent;
 private sealed class NowherePuzzle {public global::Room Room;public Transform Target;public string Label,Reward;public global::Lab_PatternLockControl Pattern;public global::DoorLockEventInteraction Gate;public global::LAB_Rings Rings;public global::LAB_MultiLock Plates;public global::UseItemInteraction Use;public global::LAB_Waage Scales;public bool LastGone;}
 private readonly HashSet<int> nowherePuzzleRooms=new HashSet<int>();
 private int nowherePuzzleScan=-1,nowherePuzzleScanFrame=-1;
 private readonly List<NowherePuzzle> nowherePuzzles=new List<NowherePuzzle>();
 private static NowhereMapLayout.Cell NowhereCell(global::Room room){return room==null||room.gameObject.scene.name!="LAB_Labyrinth"?null:NowhereMapLayout.Find(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name,(int)room.floor,room.name);}
 private static string NowhereVisit(NowhereMapLayout.Cell cell){return "SignalisVR.Map.NowhereVisited.v1:"+cell.Floor+":"+cell.Name;}
 private static bool NowherePuzzleGone(NowherePuzzle p){return (p.Gate!=null&&p.Gate.done)||(p.Pattern!=null&&p.Pattern._lock!=null&&p.Pattern._lock.solved)||(p.Rings!=null&&p.Rings.solved)||(p.Plates!=null&&p.Plates.unlocked)||(p.Use!=null&&p.Use.unlocked)||(p.Scales!=null&&p.Scales.content!=null&&p.Scales.content._item==global::Items.itemlist.PlateBalance)||(!string.IsNullOrEmpty(p.Reward)&&!global::SProgress.GetBool("exists: "+p.Reward,true));}
 private void PollNowhereState(){ScanNowherePuzzles();var c=NowhereCell(global::PlayerState.currentRoom);if(c==null)return;if(global::SProgress.GetInt(NowhereVisit(c),0)==0){global::SProgress.SetInt(NowhereVisit(c),1);nextModMapRefresh=0;}foreach(var p in nowherePuzzles){bool gone=NowherePuzzleGone(p);if(gone!=p.LastGone){p.LastGone=gone;nextModMapRefresh=0;}if(gone&&p.Gate!=null&&p.Gate.done&&p.Gate.Door!=null&&p.Room!=null&&p.Room.Doors!=null)foreach(var door in p.Room.Doors)if(door!=null&&(door.transform==p.Gate.Door.transform||door.transform.IsChildOf(p.Gate.Door.transform)||(door.door!=null&&door.door.transform.IsChildOf(p.Gate.Door.transform)))){var key=MapDoorHistory(door);if(key!=null&&global::SProgress.GetInt(key+":observedState",0)==4)ObserveMapDoorState(door,ReadActualMapDoorState(door));}}}
 private void BeginNowherePuzzles(){nowherePuzzles.Clear();nowherePuzzleRooms.Clear();nowherePuzzleScan=UnityEngine.SceneManagement.SceneManager.GetActiveScene().name=="LAB_Labyrinth"?0:-1;nowherePuzzleScanFrame=-1;}
 private void ScanNowherePuzzles(){if(nowherePuzzleScan<0||nowherePuzzleScanFrame==Time.frameCount)return;nowherePuzzleScanFrame=Time.frameCount;var current=global::PlayerState.currentRoom;int index=nowherePuzzleScan++;var room=index==0?current:(index-1<mapRooms.Length?mapRooms[index-1]:null);if(room!=null&&(index==0||room!=current)){int before=nowherePuzzles.Count;ConfigureNowherePuzzlesRoom(room);if(nowherePuzzles.Count!=before)nextModMapRefresh=0;}if(nowherePuzzleScan>mapRooms.Length){nowherePuzzleScan=-1;CompleteManualMapRefresh();}}
 private void ConfigureNowherePuzzlesRoom(global::Room room){
  if(NowhereCell(room)==null||room.chunk==null||!nowherePuzzleRooms.Add(room.GetInstanceID()))return;
   foreach(var pattern in room.chunk.GetComponentsInChildren<global::Lab_PatternLockControl>(true))nowherePuzzles.Add(new NowherePuzzle{Room=room,Target=pattern.transform,Label="PATTERN LOCK",Pattern=pattern,Gate=pattern.GetComponentInChildren<global::DoorLockEventInteraction>(true)});
   foreach(var plates in room.chunk.GetComponentsInChildren<global::LAB_MultiLock>(true))nowherePuzzles.Add(new NowherePuzzle{Room=room,Target=plates.transform,Label="SIX PLATES",Plates=plates});
  foreach(var ev in mapEvents){if(ev==null||ev.EventObject==null)continue;if(MapOwner(ev.transform)!=room)continue;var c=NowhereCell(room);if(c==null)continue;
   if(c.Name=="Chapel"){var rings=ev.EventObject.GetComponentInChildren<global::LAB_Rings>(true);if(rings!=null)nowherePuzzles.Add(new NowherePuzzle{Room=room,Target=ev.transform,Label="BRIDE STATUE",Rings=rings,Reward="LAB_Labyrinth_5b0392b7-9e69-489b-bd03-96db82756279"});}
   else if(c.Name=="Scale Room")nowherePuzzles.Add(new NowherePuzzle{Room=room,Target=ev.transform,Label="SCALES",Scales=ev.EventObject.GetComponentInChildren<global::LAB_Waage>(true),Reward="LAB_Labyrinth_92fd1681-141c-494d-bfe7-fabccb342f74"});
   else if(c.Name=="Shrine Room"){global::UseItemInteraction use=null;foreach(var u in ev.EventObject.GetComponentsInChildren<global::UseItemInteraction>(true))if(u.customFailureText!=null&&u.customFailureText.StartsWith("LAB_Shrine_",StringComparison.Ordinal)){use=u;break;}nowherePuzzles.Add(new NowherePuzzle{Room=room,Target=ev.transform,Label="SHRINE OFFERING",Use=use,Reward="LAB_Labyrinth_bb2a1a36-c8ba-4937-ae0b-81fb73f3ac99"});}
   else if(c.Name=="Pattern Viewer")nowherePuzzles.Add(new NowherePuzzle{Room=room,Target=ev.transform,Label="GLASS BELL"});
  }
  foreach(var p in nowherePuzzles)if(p.Room==room)p.LastGone=NowherePuzzleGone(p);
 }
 private bool NowhereKnown(NowhereMapLayout.Cell cell){if(cell==null)return false;if(mapComplete||cell==nowhereCurrent||global::SProgress.GetInt(NowhereVisit(cell),0)!=0)return true;foreach(var room in mapRooms)if(NowhereCell(room)==cell&&room.minimapRoom!=null&&global::SProgress.GetInt(MapVisitKey((int)room.floor,room.minimapRoom.name),0)!=0)return true;return false;}
 private Vector2 NowhereInset(NowhereMapLayout.Cell cell,Vector2 p){float margin=.0025f*UnitsPerMetre/modMapScale;var lo=cell.Shape.Low+new Vector2(margin,margin);var hi=cell.Shape.High-new Vector2(margin,margin);return new Vector2(Math.Max(lo.x,Math.Min(hi.x,p.x)),Math.Max(lo.y,Math.Min(hi.y,p.y)));}
 private void NowhereText(Vector2 low,Vector2 high,string text,float scale=.20f){
  if(string.IsNullOrWhiteSpace(text))return;
  float unit=.014f*UnitsPerMetre/32f*scale*MapTextSizeFactor(),width=(high.x-low.x)*modMapScale;
  var rows=new List<string>();string line="";
  foreach(var paragraph in text.Replace("\r","").Split('\n')){foreach(var word in paragraph.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries)){string next=line.Length==0?word:line+" "+word;if(line.Length>0&&(PixelTextWidth(next)+32)*unit>width){rows.Add(line);line=word;}else line=next;}if(line.Length>0){rows.Add(line);line="";}}
  AddMapLabel(((low+high)*.5f-modMapCenter)*modMapScale,string.Join("\n",rows.ToArray()),scale);
 }
 private void NowhereRoomCaption(NowhereMapLayout.Cell cell){var size=cell.Shape.High-cell.Shape.Low;NowhereText(cell.Shape.Low+new Vector2(size.x*.07f,size.y*.12f),cell.Shape.Low+new Vector2(size.x*.93f,size.y*.56f),cell.Label);}
 private Vector2 NowherePhysicalPoint(NowhereMapLayout.Cell cell,Vector3 world){return NowhereInset(cell,cell.Project(new Vector2(world.x,world.y),true));}
 private void NowherePuzzleSymbol(NowhereMapLayout.Cell cell,Vector3 world,string label){
  var size=cell.Shape.High-cell.Shape.Low;var icon=NowherePhysicalPoint(cell,world);NowherePoint(icon,0,null);
  float up=.009f*UnitsPerMetre/modMapScale;float y=Math.Min(cell.Shape.High.y-size.y*.13f,Math.Max(cell.Shape.Low.y+size.y*.68f,icon.y+up));
  NowhereText(new Vector2(cell.Shape.Low.x+size.x*.07f,y-size.y*.08f),new Vector2(cell.Shape.High.x-size.x*.07f,y+size.y*.08f),label,.16f);
 }
 private void NowhereServices(global::Room room,NowhereMapLayout.Cell cell){MapPoint tv=null,box=null;foreach(var p in mapObjects)if(p.Room==room&&p.Source!=null&&p.Target!=null&&!MapPuzzleGone(p)&&(mapComplete||global::SProgress.GetInt(p.Id,0)!=0)){if(p.Kind==1)tv=p;if(p.Kind==2)box=p;}Vector2 a=Vector2.zero,b=Vector2.zero;if(tv!=null)a=NowhereInset(cell,cell.Project(new Vector2(tv.Target.position.x,tv.Target.position.y),true));if(box!=null)b=NowhereInset(cell,cell.Project(new Vector2(box.Target.position.x,box.Target.position.y),true));float gap=.006f*UnitsPerMetre/modMapScale;if(tv!=null&&box!=null&&(a-b).sqrMagnitude<gap*gap){float center=(a.x+b.x)*.5f,sign=a.x>=b.x?1:-1;a=NowhereInset(cell,new Vector2(center+sign*gap*.5f,a.y));b=NowhereInset(cell,new Vector2(center-sign*gap*.5f,b.y));}if(tv!=null)NowherePoint(a,1,null);if(box!=null)NowherePoint(b,2,null);}
 private void NowherePoint(Vector2 p,int kind,string label){mapPointPositions.Add((p-modMapCenter)*modMapScale);mapPointKinds.Add(kind);if(!string.IsNullOrEmpty(label))AddMapLabel((p-modMapCenter)*modMapScale+new Vector2(0,.007f*UnitsPerMetre),label,.16f);}
 // Avoid subpixel outlines on the large board; preserve the native/mines widths.
 private void NowhereEdge(Vector2 a,Vector2 b,Color color){MineEdge(a,b,color,.0015f*UnitsPerMetre);}
 private void NowherePolygon(MinesMapLayout.Cell cell,bool current){
  var edge=current?new Color(1,.12f,.12f,.9f):new Color(.35f,.85f,1,.8f);MapRoomQuad(cell.Low,cell.High,new Color(edge.r*.12f,edge.g*.12f,edge.b*.12f,.6f));
  for(int i=0;i<cell.Polygon.Length;i++)NowhereEdge(cell.Polygon[i],cell.Polygon[(i+1)%cell.Polygon.Length],edge);
  // Rectangular Nowhere rooms need one fill quad; bound decorative dot density.
  for(float x=cell.Low.x+.6f;x<cell.High.x-.18f;x+=1.3f)for(float y=cell.Low.y+.6f;y<cell.High.y-.18f;y+=1.3f)MapRoomQuad(new Vector2(x-.18f,y-.18f),new Vector2(x+.18f,y+.18f),new Color(edge.r*.2f,edge.g*.2f,edge.b*.2f,.6f));
 }
 private bool RefreshNowhereMap(){
  var live=global::PlayerState.currentRoom;nowhereCurrent=NowhereCell(live);if(nowhereCurrent==null)return false;
  nowhereMapActive=true;PollNowhereState();modMappedRoom=live;modMapCenter=MinesMapLayout.P(1896,1912);modMapScale=.003f*UnitsPerMetre;modCurrentLow=nowhereCurrent.Shape.Low;modCurrentHigh=nowhereCurrent.Shape.High;
  BeginMapStrokeMesh();minesMapEdges.Clear();minesMapEdgeColors.Clear();var revisions=new List<int>();
  foreach(var cell in NowhereMapLayout.Cells){if(mapComplete&&global::SProgress.GetInt(NowhereVisit(cell),0)==0)global::SProgress.SetInt(NowhereVisit(cell),1);if(!NowhereKnown(cell))continue;
   NowherePolygon(cell.Shape,cell==nowhereCurrent);NowhereRoomCaption(cell);
   global::Room room=null;foreach(var candidate in mapRooms)if(NowhereCell(candidate)==cell){room=candidate;break;}if(room==null&&cell==nowhereCurrent)room=live;if(room==null)continue;
   if(room.Doors!=null)for(int n=0;n<room.Doors.Count&&n<cell.Shape.Doors.Length;n++){var door=room.Doors[n];if(door==null)continue;var at=cell.Shape.Doors[n];var key=MapDoorHistory(door);int state=key==null?0:global::SProgress.GetInt(key+":observedState",0);if(!ValidObservedDoorState(state))state=0;int revision=key==null?0:global::SProgress.GetInt(key+":revision",0);string label=state==4?(MapDoorRequiredKey(door)??global::SProgress.GetString(key+":keyName","")):null;int slot=-1;for(int j=0;j<modDoorPoints.Count;j++)if((modDoorPoints[j]-at).sqrMagnitude<.00001f){slot=j;break;}
    if(slot<0){modDoorPoints.Add(at);modDoorStates.Add(state);modDoorKeyLabels.Add(label);modDoorRotations.Add(MinesMapLayout.DoorAngle(cell.Shape,at));revisions.Add(revision);}else if(PreferMapDoorObservation(modDoorStates[slot],revisions[slot],state,revision)){modDoorStates[slot]=state;modDoorKeyLabels[slot]=label;revisions[slot]=revision;}
   }
   foreach(var point in mapObjects){if(point.Room!=room||point.Source==null||point.Target==null||MapPuzzleGone(point)||(point.Kind!=0&&point.Kind!=1&&point.Kind!=2&&point.Kind!=11))continue;if(!mapComplete&&global::SProgress.GetInt(point.Id,0)==0)continue;if(point.Kind==1||point.Kind==2||(point.Kind==11&&cell.Name=="Chimera Room"))continue;if(point.Kind==0){if(point.NativeId=="RES_Falke")NowherePuzzleSymbol(cell,point.Target.position,"MUSIC BOX");continue;}NowherePoint(cell.Project(new Vector2(point.Target.position.x,point.Target.position.y),true),point.Kind,null);}
   NowhereServices(room,cell);foreach(var p in nowherePuzzles)if(p.Room==room&&p.Target!=null&&!NowherePuzzleGone(p))NowherePuzzleSymbol(cell,p.Target.position,p.Label);
  }
  foreach(var link in NowhereMapLayout.Links){if(!NowhereKnown(NowhereMapLayout.Named(link.A))||!NowhereKnown(NowhereMapLayout.Named(link.B)))continue;int state=0;foreach(var at in new[]{link.Points[0],link.Points[link.Points.Length-1]})for(int j=0;j<modDoorPoints.Count;j++)if((modDoorPoints[j]-at).sqrMagnitude<.00001f&&modDoorStates[j]>state)state=modDoorStates[j];var color=link.Kind==11||state==3?new Color(1,.25f,.25f,.85f):state==4?new Color(1,.8f,.1f,.85f):new Color(.35f,.85f,1,.6f);for(int i=0;i+1<link.Strokes.Length;i+=2)if((link.Strokes[i+1]-link.Strokes[i]).sqrMagnitude>.00001f)NowhereEdge(link.Strokes[i],link.Strokes[i+1],color);}
  FinishMapStrokeMesh(ref joinedRoomMesh,ref joinedRoomRenderer,"JoinedMapRooms");joinedRoomRenderer.sortingOrder=0;
  for(int i=0;i<modDoorPoints.Count;i++)if(mapHints&&modDoorStates[i]==4&&!string.IsNullOrWhiteSpace(modDoorKeyLabels[i]))AddMapKeyHint((modDoorPoints[i]-modMapCenter)*modMapScale,modDoorKeyLabels[i]);ReportModMap("");return true;
 }
}}






