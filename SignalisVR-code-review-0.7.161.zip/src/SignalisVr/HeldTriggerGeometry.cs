﻿using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 // Four disjoint clipped strips preserve the original UV interpolation outside
 // the opening. No material transparency hack and no original mesh mutation.
 internal static class GuardOpening {
  private struct Vertex {public Vector3 p,n;public Vector2 uv;public Vertex Mix(Vertex b,float t){return new Vertex{p=Vector3.Lerp(p,b.p,t),n=Vector3.Lerp(n,b.n,t).normalized,uv=Vector2.Lerp(uv,b.uv,t)};}}
  private static List<Vertex> Clip(List<Vertex> poly,int axis,float edge,bool greater) {
   var result=new List<Vertex>();if(poly.Count==0)return result;var a=poly[poly.Count-1];float da=(axis==0?a.p.x:a.p.y)-edge;bool ina=greater?da>=0:da<=0;
   foreach(var b in poly){float db=(axis==0?b.p.x:b.p.y)-edge;bool inb=greater?db>=0:db<=0;if(ina!=inb)result.Add(a.Mix(b,da/(da-db)));if(inb)result.Add(b);a=b;da=db;ina=inb;}return result;
  }
  internal static Mesh Cut(Mesh source,Rect hole) {
   var mesh=new Mesh();mesh.name=source.name+"_OpenGuard";var v=source.vertices;var n=source.normals;var uv=source.uv;
   var positions=new List<Vector3>();var normals=new List<Vector3>();var textures=new List<Vector2>();var subs=new List<int[]>();
   for(int s=0;s<source.subMeshCount;s++) {
    var result=new List<int>();var triangles=source.GetTriangles(s);
    for(int t=0;t<triangles.Length;t+=3){var poly=new List<Vertex>();for(int j=0;j<3;j++){int i=triangles[t+j];poly.Add(new Vertex{p=v[i],n=n.Length==v.Length?n[i]:Vector3.forward,uv=uv.Length==v.Length?uv[i]:Vector2.zero});}
     var strips=new[]{Clip(poly,0,hole.xMin,false),Clip(poly,0,hole.xMax,true),Clip(Clip(Clip(poly,0,hole.xMin,true),0,hole.xMax,false),1,hole.yMin,false),Clip(Clip(Clip(poly,0,hole.xMin,true),0,hole.xMax,false),1,hole.yMax,true)};
     foreach(var strip in strips){if(strip.Count<3)continue;int start=positions.Count;foreach(var p in strip){positions.Add(p.p);normals.Add(p.n);textures.Add(p.uv);}for(int j=1;j<strip.Count-1;j++){if(Vector3.Cross(strip[j].p-strip[0].p,strip[j+1].p-strip[0].p).sqrMagnitude<1e-12f)continue;result.Add(start);result.Add(start+j);result.Add(start+j+1);}}
    }subs.Add(result.ToArray());
   }
   mesh.vertices=positions.ToArray();mesh.normals=normals.ToArray();mesh.uv=textures.ToArray();mesh.subMeshCount=subs.Count;for(int s=0;s<subs.Count;s++)mesh.SetTriangles(subs[s],s);mesh.RecalculateBounds();return mesh;
  }
 }
 public sealed partial class Tracking {
  private readonly List<Mesh> heldPrivateMeshes=new List<Mesh>();
  private readonly List<Renderer> heldTriggerRenderers=new List<Renderer>();
  private Material heldTriggerMaterial;
  private Transform gunTriggerPivot,gunTriggerFrame;
  private Transform gunTriggerBody;
  private Vector3 gunTriggerRest,gunTriggerContact;
  private bool TryGuardProfile(Mesh mesh,out Rect hole) {
   hole=new Rect();var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null||!mesh.isReadable)return false;
   string id=WeaponFamily(w.parentItem._item.ToString());string name=mesh.name;
   if(id=="Pistol"&&name=="Pistol"&&mesh.vertexCount==124)hole=Rect.MinMaxRect(.13f,.102f,.35f,.195f);
   else if(id=="Revolver"&&name=="Revolver")hole=Rect.MinMaxRect(.105f,.11f,.39f,.205f);
   else if(id=="Shotgun"&&name=="Shotgun")hole=Rect.MinMaxRect(.025f,.12f,.255f,.225f);
   else if(id=="Rifle"&&name=="Rifle")hole=Rect.MinMaxRect(.10f,.106f,.25f,.195f);
   else if(id=="SMG"&&name=="SMG")hole=Rect.MinMaxRect(.065f,.113f,.40f,.245f);
   else if(id=="FlareGun"&&name=="Pistol"&&mesh.vertexCount==132)hole=Rect.MinMaxRect(.065f,.105f,.27f,.23f);
   else return false;return true;
  }
  private Mesh CreateOpenGunGuard(Mesh source,Transform frame) {
   Rect hole;if(!TryGuardProfile(source,out hole))return source;
   bool flare=IsFlaregun(global::InventoryManager.EquippedWeapon.parentItem._item);Mesh normalized=source;
   if(flare){normalized=UnityEngine.Object.Instantiate(source);var verts=normalized.vertices;var ns=normalized.normals;var turn=Quaternion.Euler(90,0,0);for(int i=0;i<verts.Length;i++)verts[i]=turn*verts[i];for(int i=0;i<ns.Length;i++)ns[i]=turn*ns[i];normalized.vertices=verts;normalized.normals=ns;normalized.RecalculateBounds();}
   var mesh=GuardOpening.Cut(normalized,hole);heldPrivateMeshes.Add(mesh);
   if(flare){var verts=mesh.vertices;var ns=mesh.normals;var turn=Quaternion.Euler(-90,0,0);for(int i=0;i<verts.Length;i++)verts[i]=turn*verts[i];for(int i=0;i<ns.Length;i++)ns[i]=turn*ns[i];mesh.vertices=verts;mesh.normals=ns;mesh.RecalculateBounds();UnityEngine.Object.Destroy(normalized);}
   var bodyFrame=frame;if(flare){var axis=new GameObject("CanonicalGuardAxes");axis.layer=30;axis.transform.SetParent(frame,false);axis.transform.localRotation=Quaternion.Euler(-90,0,0);frame=axis.transform;}
   gunTriggerBody=bodyFrame;gunTriggerFrame=frame;var pivot=new GameObject("SignalisVR_MovingTrigger");pivot.layer=30;pivot.transform.SetParent(frame,false);gunTriggerPivot=pivot.transform;
   gunTriggerRest=new Vector3(hole.xMin+hole.width*.23f,hole.yMax,0);gunTriggerPivot.localPosition=gunTriggerRest;
   float height=hole.height*.70f,width=hole.width*.065f,depth=Math.Min((flare?source.bounds.size.y:source.bounds.size.z)*.55f,hole.height*.5f);
   AddTriggerBlock(pivot.transform,new Vector3(0,-height*.48f,0),new Vector3(width,height,depth));
   gunTriggerContact=gunTriggerRest+new Vector3(width*.55f,-height*.70f,0);
   // Dark inner walls close the exposed volume while leaving a genuine hole.
   float z=flare?source.bounds.extents.y:source.bounds.extents.z;AddTriggerBlock(frame,new Vector3(hole.xMin-width*.5f,hole.center.y,0),new Vector3(width,hole.height,2*z));AddTriggerBlock(frame,new Vector3(hole.xMax+width*.5f,hole.center.y,0),new Vector3(width,hole.height,2*z));
   AddTriggerBlock(frame,new Vector3(hole.center.x,hole.yMin-width*.5f,0),new Vector3(hole.width,width,2*z));AddTriggerBlock(frame,new Vector3(hole.center.x,hole.yMax+width*.5f,0),new Vector3(hole.width,width,2*z));
   return mesh;
  }
  private Renderer AddTriggerBlock(Transform parent,Vector3 position,Vector3 size) {
   if(heldTriggerMaterial==null){heldTriggerMaterial=new Material(Shader.Find("Unlit/Color"));heldTriggerMaterial.color=new Color(.08f,.085f,.09f,1);}
   var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.name="TriggerGeometry";go.layer=30;UnityEngine.Object.Destroy(go.GetComponent<Collider>());go.transform.SetParent(parent,false);go.transform.localPosition=position;go.transform.localScale=size;
   var r=go.GetComponent<MeshRenderer>();r.sharedMaterial=heldTriggerMaterial;r.enabled=false;heldTriggerRenderers.Add(r);return r;
  }
  private void PrepareGunTrigger() {
   if(gunTriggerPivot==null||gunTriggerFrame==null)return;float squeeze=GunSqueeze();gunTriggerPivot.localPosition=gunTriggerRest;gunTriggerPivot.localRotation=Quaternion.Euler(0,0,-18*squeeze);
   foreach(var r in heldTriggerRenderers)if(r!=null&&r.transform.IsChildOf(equippedVisualRoot.transform))r.enabled=gunTriggerBody.GetComponent<MeshRenderer>().enabled;
   var point=gunTriggerPivot.TransformPoint(new Vector3(.003f,-.04f,0));
   // Use the stored authored contact transformed about the trigger pivot.
   point=gunTriggerPivot.TransformPoint(gunTriggerContact-gunTriggerRest);
   FitFingerToContact(1,"index",point+gunTriggerPivot.right*(.008f*UnitsPerMetre),8);
  }
  private void DestroyGunTriggers(){gunTriggerPivot=null;gunTriggerFrame=null;gunTriggerBody=null;foreach(var mesh in heldPrivateMeshes)if(mesh!=null)UnityEngine.Object.Destroy(mesh);heldPrivateMeshes.Clear();heldTriggerRenderers.Clear();}
 }
}
