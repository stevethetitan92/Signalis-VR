using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public static class FlashlightPlacementPolicy {public static int Next(int current,int direction){return (current+direction+3)%3;}}
 public sealed partial class Tracking {
  private static bool CarriedFlashlightModule(){var items=global::InventoryManager.elsterItems;if(items==null)return false;foreach(var item in items)if(item.Key!=null&&item.Key._item==global::Items.itemlist.Flashlight&&item.Value>0)return true;return false;}
  private int modFlashlightPlacement;
  private int flashlightLastPlacement=1;
  private readonly RadioPowerButton flashlightShortcut=new RadioPowerButton();
  private void PollFlashlightShortcut(bool available,QuestSample left){
   bool ready=available&&questPolicy.LeftArmed&&!heldReceiver&&!manualLeftGrip&&!modMenuOpen&&!quickSelect.Open&&inventoryWheelView==null&&WeaponGameplayReady()&&!global::PlayerState.paused&&!global::PlayerState.cutscene&&!global::PlayerState.eventScreen&&!global::PlayerState.suspendInput;
   if(!flashlightShortcut.Update(ready,left.Button(1))||!CarriedFlashlightModule())return;
   if(modFlashlightPlacement!=0){flashlightLastPlacement=modFlashlightPlacement;modFlashlightPlacement=0;}else modFlashlightPlacement=flashlightLastPlacement==2?2:1;
   try{SaveModSettings();}catch(System.Exception ex){MelonLoader.MelonLogger.Warning("Flashlight toggle settings: "+ex.Message);}
  }
  private int modFlashlightBrightness=100,modFlashlightSize=100;
  private static readonly string[] flashlightLocations={"OFF","HEAD","GUN"};
  private global::ElsterFlashLight placedFlashlight;
  private float nextFlashlightSearch;private Light vrFlashlightBeam;
  private readonly List<Light> vrFlashlightSpill=new List<Light>();
  private Light[] flashlightProfile;private Transform flashlightProfileHolder;private float nextFlashlightProfile;
  private readonly List<FlashlightPose> flashlightPoses=new List<FlashlightPose>();
  private struct FlashlightPose {public Transform Transform;public Vector3 Position;public Quaternion Rotation;}
  private struct FlashlightLightState {public Light Light;public float Intensity,Range,Angle;}
  private readonly List<FlashlightLightState> flashlightLightStates=new List<FlashlightLightState>();
  private bool flashlightPlacementFailed;
  private Camera.CameraCallback flashlightBeforeRender,flashlightAfterRender;
  private Camera flashlightFlatCamera;
  private int flashlightFlatFrame=-1;
  private void InstallFlashlightRenderScope(){
   if(flashlightBeforeRender!=null)return;
   flashlightBeforeRender=(Action<Camera>)BeforeFlatFlashlight;
   flashlightAfterRender=(Action<Camera>)AfterFlatFlashlight;
   Camera.onPreCull+=flashlightBeforeRender;Camera.onPostRender+=flashlightAfterRender;
  }
  private void BeforeFlatFlashlight(Camera view){
   // A flat dialogue captures native cameras, so eye-only suppression is too late.
   // Keep nested reflection cameras inside the outer scope, with one restoration.
   if(flashlightFlatFrame!=Time.frameCount&&flashlightFlatCamera!=null){RestoreFlashlightPlacement();flashlightFlatCamera=null;}
   if(!ProdVrMode()||!recovery.Paused||view==null||flashlightFlatCamera!=null)return;
   flashlightFlatCamera=view;flashlightFlatFrame=Time.frameCount;PrepareFlashlightPlacement();
  }
  private void AfterFlatFlashlight(Camera view){if(view!=flashlightFlatCamera)return;RestoreFlashlightPlacement();flashlightFlatCamera=null;}
  private void PrepareFlashlightPlacement(){if(flashlightPlacementFailed)return;try{PrepareFlashlightPlacementCore();}catch(Exception ex){RestoreFlashlightPlacement();flashlightPlacementFailed=true;MelonLoader.MelonLogger.Warning("Flashlight placement disabled: "+ex.Message);}}
  private void PrepareFlashlightPlacementCore(){
   RestoreFlashlightPlacement();if(!ProdVrMode()||global::PlayerState.player==null)return;
   if(placedFlashlight==null&&Time.realtimeSinceStartup>=nextFlashlightSearch){nextFlashlightSearch=Time.realtimeSinceStartup+1f;foreach(var light in Resources.FindObjectsOfTypeAll<global::ElsterFlashLight>())if(light!=null&&light.gameObject.scene.IsValid()&&light.transform.root==global::PlayerState.player.transform.root){placedFlashlight=light;break;}}
   // Placement is the power switch; native inventory/tool-slot state remains untouched.
   Transform holder=placedFlashlight==null||placedFlashlight.FlashLightHolder==null?null:placedFlashlight.FlashLightHolder.transform;
   Transform model=placedFlashlight==null||placedFlashlight.FlashLightModel==null?null:placedFlashlight.FlashLightModel.transform;
   if(holder!=null){SuppressHandFlashlight(model,holder);foreach(var r in holder.GetComponentsInChildren<Renderer>(true))if(r.enabled){flashlightHiddenNative.Add(r);r.enabled=false;}}
   if(modFlashlightPlacement==0||!CarriedFlashlightModule())return;
   // A flat dialogue retains the last same-camera grip until stereo resumes.
   Vector3 position;Quaternion rotation;
   if(modFlashlightPlacement==2&&global::InventoryManager.EquippedWeapon!=null&&rightWeaponFrame>=0&&rightWeaponCamera==camera&&(rightWeaponPosition-stereoPosition).sqrMagnitude<4f*UnitsPerMetre*UnitsPerMetre){
    rotation=rightWeaponRotation;Vector3 muzzleOffset;position=rightWeaponPosition+rotation*((ImportedMuzzle(out muzzleOffset)?muzzleOffset:Vector3.zero)+new Vector3(0,-.045f,-.07f))*UnitsPerMetre;
   }
   else {rotation=stereoRotation;position=stereoPosition+rotation*(new Vector3(.055f,-.025f,.04f)*UnitsPerMetre);}
   var beam=holder==null?null:holder.GetComponentInChildren<Light>(true);
   // A private spotlight also works when the original uses a projected mesh instead of a Light.
   if(vrFlashlightBeam==null){var go=new GameObject("SignalisVR_PlacedFlashlightBeam");UnityEngine.Object.DontDestroyOnLoad(go);vrFlashlightBeam=go.AddComponent<Light>();vrFlashlightBeam.type=LightType.Spot;vrFlashlightBeam.spotAngle=48;vrFlashlightBeam.range=12*UnitsPerMetre;vrFlashlightBeam.intensity=2;vrFlashlightBeam.cullingMask&=~(1<<30);vrFlashlightBeam.color=Color.white;}
   vrFlashlightBeam.spotAngle=Math.Max(1f,48f*modFlashlightSize/100f);
   vrFlashlightBeam.range=12f*UnitsPerMetre*Mathf.Clamp01(modFlashlightSize/100f);
   vrFlashlightBeam.intensity=2f*Mathf.Clamp01(modFlashlightBrightness/100f);
   vrFlashlightBeam.transform.SetPositionAndRotation(position,rotation);vrFlashlightBeam.enabled=modFlashlightBrightness>0&&modFlashlightSize>0;
   PrepareFullFlashlight(holder,position,rotation);
   if(beam!=null&&beam.enabled){flashlightHiddenLights.Add(beam);beam.enabled=false;}

  }
  private void RestoreFlashlightPlacement(){foreach(var light in vrFlashlightSpill)if(light!=null)light.enabled=false;foreach(var state in flashlightLightStates)if(state.Light!=null){state.Light.intensity=state.Intensity;state.Light.range=state.Range;state.Light.spotAngle=state.Angle;}flashlightLightStates.Clear();if(vrFlashlightBeam!=null)vrFlashlightBeam.enabled=false;HideFlashlightGrip();for(int i=flashlightPoses.Count-1;i>=0;i--){var pose=flashlightPoses[i];if(pose.Transform!=null){pose.Transform.position=pose.Position;pose.Transform.rotation=pose.Rotation;}}flashlightPoses.Clear();}
  private void ResetFlashlightPlacement(){RestoreFlashlightPlacement();flashlightFlatCamera=null;DestroyFlashlightGrip();if(vrFlashlightBeam!=null)UnityEngine.Object.Destroy(vrFlashlightBeam.gameObject);vrFlashlightBeam=null;vrFlashlightSpill.Clear();flashlightProfile=null;flashlightProfileHolder=null;nextFlashlightProfile=0;placedFlashlight=null;nextFlashlightSearch=0;flashlightPlacementFailed=false;}
  private void PrepareFullFlashlight(Transform holder,Vector3 position,Quaternion rotation){
   if(!flashlightModActive)return;
   if(flashlightProfile==null||flashlightProfileHolder!=holder||Time.realtimeSinceStartup>=nextFlashlightProfile){flashlightProfileHolder=holder;nextFlashlightProfile=Time.realtimeSinceStartup+1f;flashlightProfile=holder==null?new Light[0]:holder.GetComponentsInChildren<Light>(true);}
   // Match the flashlight mod's native broad lights, without activating its
   // disabled spooky artwork or changing native tool/power state.
   float brightness=Mathf.Clamp01(modFlashlightBrightness/100f),width=Mathf.Clamp01(modFlashlightSize/100f);
   int index=0;Light spot=null;foreach(var source in flashlightProfile)if(source!=null&&source.type==LightType.Spot){spot=source;break;}
   var anchor=spot==null?holder:spot.transform;
   foreach(var source in flashlightProfile){if(source==null||source.type!=LightType.Point||index>=8)continue;
    while(vrFlashlightSpill.Count<=index){var go=new GameObject("SignalisVR_FlashlightSpill_"+index);go.transform.SetParent(vrFlashlightBeam.transform,false);var light=go.AddComponent<Light>();light.enabled=false;light.type=LightType.Point;vrFlashlightSpill.Add(light);}
    var copy=vrFlashlightSpill[index++];copy.color=source.color;copy.cullingMask=source.cullingMask&~(1<<30);copy.shadows=LightShadows.None;
    var offset=anchor==null?Vector3.zero:Quaternion.Inverse(anchor.rotation)*(source.transform.position-anchor.position);
    copy.transform.SetPositionAndRotation(position+rotation*offset,rotation);copy.intensity=source.intensity*brightness;copy.range=source.range*width;copy.enabled=brightness>0&&width>0;
   }
   // Missing native hierarchy during an armor/camera handoff must not lose spill.
   if(index==0){while(vrFlashlightSpill.Count<2){var go=new GameObject("SignalisVR_FlashlightSpill_Fallback");go.transform.SetParent(vrFlashlightBeam.transform,false);var light=go.AddComponent<Light>();light.type=LightType.Point;light.enabled=false;vrFlashlightSpill.Add(light);}
    for(int i=0;i<2;i++){var copy=vrFlashlightSpill[i];copy.color=Color.white;copy.cullingMask=vrFlashlightBeam.cullingMask;copy.shadows=LightShadows.None;copy.transform.SetPositionAndRotation(position,rotation);copy.range=12f*UnitsPerMetre*width;copy.intensity=(i==0?.55f:.15f)*brightness;copy.enabled=brightness>0&&width>0;}index=2;
   }
   for(int i=index;i<vrFlashlightSpill.Count;i++)vrFlashlightSpill[i].enabled=false;
   vrFlashlightBeam.color=spot==null?Color.white:spot.color;vrFlashlightBeam.intensity=(spot==null?2f:spot.intensity)*brightness;vrFlashlightBeam.spotAngle=Math.Max(1f,(spot==null?48f:spot.spotAngle)*width);vrFlashlightBeam.range=(spot==null?12f*UnitsPerMetre:spot.range)*width;vrFlashlightBeam.enabled=brightness>0&&width>0;
  }
 }
}


