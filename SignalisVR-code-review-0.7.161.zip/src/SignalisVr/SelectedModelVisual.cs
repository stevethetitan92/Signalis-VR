﻿using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private GameObject selectedRoot;private string selectedKind;private bool selectedFailed;
  private readonly List<MeshRenderer> selectedParts=new List<MeshRenderer>();private readonly List<int> selectedRoles=new List<int>();
  private readonly List<Mesh> selectedMeshes=new List<Mesh>();private readonly List<Material> selectedMaterials=new List<Material>();private readonly List<Texture2D> selectedTextures=new List<Texture2D>();
  private MeshRenderer selectedMagazine,selectedMoving;private Mesh selectedHeldMagazine;
  private bool SelectedActive(string kind){return selectedRoot!=null&&!selectedFailed&&selectedKind==kind&&global::InventoryManager.EquippedWeapon!=null&&global::InventoryManager.EquippedWeapon.parentItem!=null&&WeaponFamily(global::InventoryManager.EquippedWeapon.parentItem._item.ToString())==kind;}
  private void EnsureSelected(string kind){
   if(selectedRoot!=null&&selectedKind==kind)return;CacheSelected();if(RestoreSelectedCache(kind))return;selectedKind=kind;
   string raw=kind=="Revolver"?HdRevolverData.Geometry:kind=="Pistol"?HdPistolData.Geometry:kind=="Shotgun"?HdShotgunData.Geometry:kind=="FlareGun"?HdFlareGunData.Geometry:HdRifleData.Geometry;
   var textures=kind=="Revolver"?HdRevolverData.Textures:kind=="Pistol"?HdPistolData.Textures:kind=="Shotgun"?HdShotgunData.Textures:kind=="FlareGun"?HdFlareGunData.Textures:HdRifleData.Textures;
   var colors=kind=="Revolver"?HdRevolverData.Colors:kind=="Pistol"?HdPistolData.Colors:kind=="Shotgun"?HdShotgunData.Colors:kind=="FlareGun"?HdFlareGunData.Colors:HdRifleData.Colors;
   for(int i=0;i<textures.Length;i++){var shader=Shader.Find(textures[i].Length==0?"Unlit/Color":"Unlit/Texture");if(shader==null)shader=Shader.Find(textures[i].Length==0?"Unlit/Color":"Unlit/Texture");if(shader==null)throw new InvalidOperationException("Imported gun shader unavailable");var mat=new Material(shader);selectedMaterials.Add(mat);if(kind=="Pistol"||kind=="Shotgun"||kind=="Rifle"||kind=="FlareGun"){mat.SetFloat("_Glossiness",0f);mat.SetFloat("_Metallic",0f);mat.SetFloat("_SpecularHighlights",0f);mat.SetFloat("_GlossyReflections",0f);mat.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");mat.EnableKeyword("_GLOSSYREFLECTIONS_OFF");}if(textures[i].Length==0){float shade=kind=="Pistol"?.40f:kind=="FlareGun"?.82f:1f;mat.color=(kind=="Pistol"||kind=="Shotgun")?CharcoalGunColor(new Color(colors[i*4],colors[i*4+1],colors[i*4+2],colors[i*4+3])):new Color(colors[i*4]*shade,colors[i*4+1]*shade,colors[i*4+2]*shade,colors[i*4+3]);if(kind=="Shotgun"&&i==3)mat.color=new Color(.16f,.16f,.16f,1f);}else{var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);selectedTextures.Add(tex);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(textures[i]),true))throw new InvalidOperationException("Imported gun texture invalid");tex.filterMode=FilterMode.Bilinear;mat.mainTexture=tex;}}
   Material pixelRounds=kind=="Revolver"?CreatePixelRevolverRounds():null;
   selectedRoot=new GameObject("SignalisVR_Imported_"+kind);UnityEngine.Object.DontDestroyOnLoad(selectedRoot);
   using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(raw)))){int count=r.ReadInt32();for(int k=0;k<count;k++){int role=r.ReadInt32(),material=r.ReadInt32(),nv=r.ReadInt32(),nt=r.ReadInt32();var v=new Vector3[nv];var uv=new Vector2[nv];var t=new int[nt];for(int i=0;i<nv;i++)v[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());if(kind=="Shotgun")for(int i=0;i<nv;i++)v[i]=ShortenShotgun(v[i]);for(int i=0;i<nv;i++)uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());for(int i=0;i<nt;i++)t[i]=r.ReadInt32();var mesh=new Mesh();mesh.name=kind+"_Imported_"+k;mesh.vertices=v;mesh.uv=uv;mesh.triangles=t;mesh.RecalculateNormals();mesh.triangles=HandSurfaceTopology.DoubleSided(t);mesh.RecalculateBounds();if(kind=="Revolver"&&role>=10)PixelRevolverRoundUv(mesh);selectedMeshes.Add(mesh);var part=CreateControllerPart(selectedRoot,mesh,kind=="Revolver"&&role>=10?pixelRounds:selectedMaterials[material],mesh.name,Vector3.zero,Vector3.one);part.enabled=false;selectedParts.Add(part);selectedRoles.Add(role);if(role==1)selectedMagazine=part;if(role==2&&selectedMoving==null)selectedMoving=part;}}
   if(selectedMoving==null)throw new InvalidOperationException("Imported gun action missing");
   EnsureHeldMagazineMesh();
  }
  private void EnsureHeldMagazineMesh(){
   if(selectedHeldMagazine!=null||selectedMagazine==null)return;
   var source=selectedMagazine.GetComponent<MeshFilter>().sharedMesh;if(source==null)return;
   selectedHeldMagazine=UnityEngine.Object.Instantiate(source);
   selectedHeldMagazine.hideFlags=HideFlags.DontUnloadUnusedAsset;
   var v=selectedHeldMagazine.vertices;var center=selectedHeldMagazine.bounds.center;
   for(int i=0;i<v.Length;i++)v[i]-=center;
   selectedHeldMagazine.vertices=v;selectedHeldMagazine.RecalculateBounds();
   SelectedCache cached;if(selectedCache.TryGetValue(selectedKind,out cached)&&cached.Root==selectedRoot)cached.Held=selectedHeldMagazine;
  }
  // Keep original color accents, black grip and bright lettering. Darken only neutral midtones.
  private static Color CharcoalGunColor(Color c){
   float high=Math.Max(c.r,Math.Max(c.g,c.b)),low=Math.Min(c.r,Math.Min(c.g,c.b));
   float luminance=.2126f*c.r+.7152f*c.g+.0722f*c.b;
   if(high-low>.10f||luminance<.10f||luminance>.78f)return c;
   return new Color(c.r*.5f,c.g*.5f,c.b*.5f,c.a);
  }
  private static void CharcoalGunTexture(Texture2D texture){
   var pixels=texture.GetPixels32();for(int i=0;i<pixels.Length;i++)pixels[i]=CharcoalGunColor(pixels[i]);
   texture.SetPixels32(pixels);texture.Apply(false,true);
  }
  // Compress the entire length about the right-hand grip; width/height stay unchanged.
  private static Vector3 ShortenShotgun(Vector3 v){v.z=-.004f+(v.z+.004f)*.85f;return v;}
  private static void DarkenFlareOrange(Texture2D texture){
   Color32[] pixels=texture.GetPixels32();
   for(int i=0;i<pixels.Length;i++){var c=pixels[i];if(c.r>c.g*1.15f&&c.r>c.b*1.5f){c.r=(byte)(c.r*.82f);c.g=(byte)(c.g*.82f);c.b=(byte)(c.b*.82f);pixels[i]=c;}}
   texture.SetPixels32(pixels);texture.Apply(false,true);
  }
  private void PrepareSelected(){
   HideSelected();var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null||selectedFailed)return;string kind=WeaponFamily(w.parentItem._item.ToString());if(kind!="Pistol"&&kind!="Shotgun"&&kind!="Rifle"&&kind!="Revolver"&&kind!="FlareGun")return;
   try{EnsureSelected(kind);selectedRoot.transform.position=rightWeaponPosition;selectedRoot.transform.rotation=rightWeaponRotation;selectedRoot.transform.localScale=Vector3.one*UnitsPerMetre*(kind=="Revolver"?AmmoGuidePolicy.RevolverScale:1f);foreach(var p in selectedParts){p.transform.localPosition=Vector3.zero;p.transform.localRotation=Quaternion.identity;p.enabled=true;}foreach(var p in equippedCopies)if(p!=null)p.enabled=false;}
   catch(Exception e){DestroySelected();selectedFailed=true;MelonLogger.Warning("Imported gun unavailable; native model retained: "+e.Message);}
  }
  private bool PrepareSelectedMechanism(){
   if(selectedRoot==null||selectedFailed)return false;
   if(SelectedActive("Revolver")){PrepareAglMechanism();return true;}
   if(SelectedActive("Pistol")){
    float extension=manualReload.Stage==ManualReloadPolicy.Step.RackHolding?Math.Min(.009f,manualReload.RackPull*.25f):0;
    var weapon=global::InventoryManager.EquippedWeapon;
    float firing=manualReload.Active?0:PistolSlideVisualPolicy.ShotAmount(Time.realtimeSinceStartup-heldShotTime,heldShotWeapon==weapon.Pointer,weapon.magAmmo<=0);
    float pull=pistolSlideVisual.Override ? Math.Max(.035f*firing,.035f*pistolSlideVisual.Amount+extension):.035f*firing;
    for(int i=0;i<selectedParts.Count;i++)if(selectedRoles[i]==2)selectedParts[i].transform.localPosition=Vector3.back*pull;
    if(selectedMagazine!=null)selectedMagazine.enabled=!manualReload.Active||manualReload.Stage==ManualReloadPolicy.Step.Inserted||manualReload.Stage==ManualReloadPolicy.Step.RackHolding||manualReload.Stage==ManualReloadPolicy.Step.AwaitingGame;
    return true;
   }
   if(SelectedActive("Shotgun")){if(ManualShotgunEligible())for(int i=0;i<selectedParts.Count;i++)if(selectedRoles[i]==2||selectedRoles[i]==5)selectedParts[i].transform.localPosition=Vector3.back*Math.Min(.1f,Math.Max(0,shotgunReload.Pull));return true;}
   if(SelectedActive("FlareGun")){
    var rotation=Quaternion.AngleAxis(40*additionalOpen,Vector3.right);var pivot=HdFlareGunData.Pivot;
    for(int i=0;i<selectedParts.Count;i++)if(selectedRoles[i]==2){var t=selectedParts[i].transform;t.localRotation=rotation;t.localPosition=pivot-rotation*pivot;}
    additionalChamber=selectedRoot.transform.TransformPoint(pivot+rotation*(HdFlareGunData.Chamber-pivot));additionalLoadDirection=rightWeaponRotation*rotation*Vector3.forward;additionalBolt=additionalChamber;additionalAnchors=AdditionalGunEligible();if(additionalOpen>.8f)EjectFlareCase();PrepareChamberRound("FlareGun",0,additionalChamber,additionalLoadDirection,additionalOpen>.05f&&global::InventoryManager.EquippedWeapon.magAmmo>0);return true;
   }
   if(SelectedActive("Rifle")){
    if(!AdditionalGunEligible())return true;float e=additionalOpen;var rotation=Quaternion.AngleAxis(RifleHingePolicy.MaxAngle*e,Vector3.right);var pivot=HdRifleData.Pivot;
    for(int i=0;i<selectedParts.Count;i++)if(selectedRoles[i]==2){var t=selectedParts[i].transform;t.localRotation=rotation;t.localPosition=pivot-rotation*pivot;}
    PrepareRifleChambers(rotation,pivot);additionalLoadDirection=rightWeaponRotation*rotation*Vector3.forward;additionalBolt=additionalChamber;additionalAnchors=true;for(int c=0;c<2;c++)PrepareChamberRound("Rifle",c,rifleChamberWorld[c],additionalLoadDirection,additionalOpen>.05f&&!rifleChambers.Empty(c));return true;
   }return false;
  }
  private Vector3 SelectedSlideContact(){var b=selectedMoving.GetComponent<MeshFilter>().sharedMesh.bounds;return selectedMoving.transform.TransformPoint(new Vector3(0,b.center.y,b.min.z+.025f));}
  private Vector3 SelectedMagazineWell(){var b=selectedMagazine.GetComponent<MeshFilter>().sharedMesh.bounds;return selectedMagazine.transform.TransformPoint(new Vector3(b.center.x,b.max.y,b.center.z));}
  private bool magazineBindingWarned;
  private float magazineBindingRetryAt;
  private bool ApplySelectedHeldMagazine(){
   if(Time.realtimeSinceStartup<magazineBindingRetryAt)return false;
   try{
    EnsureSelected("Pistol");EnsureHeldMagazineMesh();
    // Asset readiness is independent of the native equip transition's item state.
    if(selectedRoot==null||selectedKind!="Pistol"||selectedHeldMagazine==null||selectedMagazine==null)throw new InvalidOperationException("asset state root="+(selectedRoot!=null)+" kind="+selectedKind+" mesh="+(selectedHeldMagazine!=null)+" renderer="+(selectedMagazine!=null));
    EnsurePistolMagazineRound();
    foreach(var r in new[]{manualMagazine,manualEjected})if(r!=null){bool loaded=r==manualMagazine?ManualHasAmmo(global::InventoryManager.EquippedWeapon):manualEjectedLoaded;r.GetComponent<MeshFilter>().sharedMesh=loaded?selectedLoadedMagazine:selectedHeldMagazine;r.sharedMaterials=loaded?new[]{selectedMagazine.sharedMaterial,selectedRoundBrass,selectedRoundCopper}:selectedMagazine.sharedMaterials;r.transform.localScale=Vector3.one;}
    magazineBindingWarned=false;return true;
   }catch(Exception e){
    magazineBindingRetryAt=Time.realtimeSinceStartup+1f;
    if(!magazineBindingWarned){magazineBindingWarned=true;MelonLogger.Warning("Beretta magazine binding deferred; VR retained: "+e.Message);}
    return false;
   }
  }
  private void HideSelected(){HideRevolverEjected();HideChamberRounds();foreach(var p in selectedParts)if(p!=null)p.enabled=false;}
  private sealed class SelectedCache {
   internal GameObject Root;internal MeshRenderer Magazine,Moving;internal Mesh Held;
   internal MeshRenderer[] Parts;internal int[] Roles;internal Mesh[] Meshes;internal Material[] Materials;internal Texture2D[] Textures;
  }
  private readonly Dictionary<string,SelectedCache> selectedCache=new Dictionary<string,SelectedCache>();
  private void CacheSelected(){
   DestroyRevolverCases();DestroyRifleContactMeshes();DestroyPistolMagazineRound();HideSelected();
   SelectedCache retained;
   if(selectedRoot!=null&&(!selectedCache.TryGetValue(selectedKind,out retained)||retained.Root!=selectedRoot))selectedCache[selectedKind]=new SelectedCache{Root=selectedRoot,Magazine=selectedMagazine,Moving=selectedMoving,Held=selectedHeldMagazine,Parts=selectedParts.ToArray(),Roles=selectedRoles.ToArray(),Meshes=selectedMeshes.ToArray(),Materials=selectedMaterials.ToArray(),Textures=selectedTextures.ToArray()};
   selectedRoot=null;selectedKind=null;selectedMagazine=selectedMoving=null;selectedHeldMagazine=null;selectedParts.Clear();selectedRoles.Clear();selectedMeshes.Clear();selectedMaterials.Clear();selectedTextures.Clear();
  }
  private bool RestoreSelectedCache(string kind){
   SelectedCache c;if(!selectedCache.TryGetValue(kind,out c))return false;
   selectedRoot=c.Root;selectedKind=kind;selectedMagazine=c.Magazine;selectedMoving=c.Moving;selectedHeldMagazine=c.Held;
   selectedParts.AddRange(c.Parts);selectedRoles.AddRange(c.Roles);selectedMeshes.AddRange(c.Meshes);selectedMaterials.AddRange(c.Materials);selectedTextures.AddRange(c.Textures);return true;
  }
  private void WarmSelectedModels(){foreach(var kind in new[]{"Rifle","FlareGun","Revolver","Pistol","Shotgun"})EnsureSelected(kind);HideSelected();}
  private void DestroySelected(){
   CacheSelected();foreach(var c in selectedCache.Values){if(c.Root!=null)UnityEngine.Object.Destroy(c.Root);foreach(var m in c.Meshes)if(m!=null)UnityEngine.Object.Destroy(m);foreach(var m in c.Materials)if(m!=null)UnityEngine.Object.Destroy(m);foreach(var t in c.Textures)if(t!=null)UnityEngine.Object.Destroy(t);if(c.Held!=null)UnityEngine.Object.Destroy(c.Held);}selectedCache.Clear();
  }
 }
}







