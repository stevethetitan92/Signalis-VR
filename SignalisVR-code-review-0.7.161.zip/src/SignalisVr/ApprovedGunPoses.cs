﻿using System;
using System.IO;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private GameObject approvedPoseRoot;
  private Material approvedPoseMaterial,approvedRightMaterial;
  private readonly MeshRenderer[] approvedPoseRenderers=new MeshRenderer[8];
  private readonly Mesh[] approvedPoseMeshes=new Mesh[8];
  private bool approvedPoseFailed;
  private void EnsureApprovedGunPoses(){
   if(approvedPoseRoot!=null)return;
   approvedPoseRoot=new GameObject("ApprovedGunPoses");UnityEngine.Object.DontDestroyOnLoad(approvedPoseRoot);
   var shader=Shader.Find("Unlit/Color");if(shader==null)throw new InvalidOperationException("Hand pose shader unavailable");
   approvedPoseMaterial=new Material(shader);approvedPoseMaterial.color=new Color(.015f,.018f,.02f,1);
   approvedRightMaterial=new Material(shader);approvedRightMaterial.color=new Color(.015f,.018f,.02f,1);
   string[] data={ApprovedGunPoseData.SmgRight,ApprovedGunPoseData.SmgLeft,ApprovedGunPoseData.RifleLeft,ApprovedGunPoseData.PistolRight,ApprovedGunPoseData.PistolLeft,PsxModelData.Right,ShotgunPoseData.Left,PsxModelData.Left};
   for(int k=0;k<data.Length;k++)using(var reader=new BinaryReader(new MemoryStream(Convert.FromBase64String(data[k])))){
    int nv=reader.ReadInt32(),nt=reader.ReadInt32();var vertices=new Vector3[nv];var indices=new int[nt];
    for(int i=0;i<nv;i++)vertices[i]=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle());
    for(int i=0;i<nt;i++)indices[i]=reader.ReadInt32();
    var mesh=new Mesh();approvedPoseMeshes[k]=mesh;mesh.vertices=vertices;mesh.triangles=HandSurfaceTopology.DoubleSided(indices);mesh.RecalculateNormals();mesh.RecalculateBounds();
    approvedPoseRenderers[k]=CreateControllerPart(approvedPoseRoot,mesh,(k==0||k==3||k==5)?approvedRightMaterial:approvedPoseMaterial,"ApprovedPose"+k,Vector3.zero,Vector3.one);approvedPoseRenderers[k].enabled=false;
   }
  }
  private void ShowApprovedPose(int pose,int hand,Vector3 position,Quaternion rotation){
   if((handPreparedMask&(1<<hand))==0)return;
   var r=approvedPoseRenderers[pose];r.transform.position=position;r.transform.rotation=rotation;r.transform.localScale=Vector3.one*UnitsPerMetre*(pose==5?AmmoGuidePolicy.RevolverScale:1f);if(pose==7)r.transform.position+=rotation*(new Vector3(0,-.04025f,0)*(AmmoGuidePolicy.RevolverScale-1)*UnitsPerMetre);r.enabled=true;
   if(handsRenderers[hand]!=null)handsRenderers[hand].enabled=false;
  }
  private void PrepareApprovedGunPoses(){
   HideApprovedGunPoses();if(!handsScoped||approvedPoseFailed)return;
   bool smg=IsXiphias()&&xiphiasRoot!=null&&AdditionalGunEligible();
   bool rifle=SelectedActive("Rifle")&&rifleBarrelHeld;
   bool pistol=SelectedActive("Pistol");
   bool revolver=SelectedActive("Revolver");
   bool shotgun=SelectedActive("Shotgun")&&selectedMoving!=null&&manualLeftGrip&&controllerMarkers[0]!=null&&(shotgunReload.Stage==ShotgunReloadPolicy.Step.Pumping||Vector3.Distance(controllerMarkers[0].transform.position,selectedRoot.transform.TransformPoint(ShortenShotgun(new Vector3(0,.0084f,.2994f))))<.12f*UnitsPerMetre);
   if(!smg&&!rifle&&!pistol&&!revolver&&!shotgun)return;
   try{
    EnsureApprovedGunPoses();
    if(shotgun)ShowApprovedPose(6,0,rightWeaponPosition+selectedMoving.transform.position-selectedRoot.transform.position+rightWeaponRotation*(ShortenShotgun(HdShotgunData.Pump)-HdShotgunData.Pump)*UnitsPerMetre,rightWeaponRotation);
    if(revolver){AnimateAglHand();ShowApprovedPose(5,1,rightWeaponPosition,rightWeaponRotation);if(AdditionalHoldingAmmo()&&additionalAmmo!=null)ShowApprovedPose(7,0,additionalAmmo.transform.position,additionalAmmo.transform.rotation);}
    if(smg){
     AnimateImportedIndex(0,ImportedTriggerPivot());ShowApprovedPose(0,1,rightWeaponPosition,rightWeaponRotation);
     if(smgReload.Stage==ManualReloadPolicy.Step.RackHolding)ShowApprovedPose(1,0,rightWeaponPosition+xiphiasHandle.transform.position-xiphiasRoot.transform.position,rightWeaponRotation);
    }
    if(rifle){var rotation=Quaternion.AngleAxis(RifleHingePolicy.MaxAngle*additionalOpen,Vector3.right);ShowApprovedPose(2,0,rightWeaponPosition+rightWeaponRotation*(RiflePivot-rotation*RiflePivot)*UnitsPerMetre,rightWeaponRotation*rotation);}
    if(pistol){AnimateImportedIndex(3,ImportedTriggerPivot());ShowApprovedPose(3,1,rightWeaponPosition,rightWeaponRotation);if(manualReload.Stage==ManualReloadPolicy.Step.RackHolding&&selectedMoving!=null)ShowApprovedPose(4,0,rightWeaponPosition+selectedMoving.transform.position-selectedRoot.transform.position,rightWeaponRotation);}
   }catch(Exception e){HideApprovedGunPoses();approvedPoseFailed=true;for(int h=0;h<2;h++)if(handsRenderers[h]!=null&&(handPreparedMask&(1<<h))!=0)handsRenderers[h].enabled=true;MelonLoader.MelonLogger.Warning("Approved gun pose fallback: "+e.Message);}
  }
  private void HideApprovedGunPoses(){foreach(var r in approvedPoseRenderers)if(r!=null)r.enabled=false;}
  private void DestroyApprovedGunPoses(){HideApprovedGunPoses();if(approvedPoseRoot!=null)UnityEngine.Object.Destroy(approvedPoseRoot);approvedPoseRoot=null;aglHandRest=null;for(int i=0;i<approvedPoseMeshes.Length;i++){if(approvedPoseMeshes[i]!=null)UnityEngine.Object.Destroy(approvedPoseMeshes[i]);approvedPoseMeshes[i]=null;importedIndexRest[i]=null;approvedPoseRenderers[i]=null;}if(approvedPoseMaterial!=null)UnityEngine.Object.Destroy(approvedPoseMaterial);approvedPoseMaterial=null;if(approvedRightMaterial!=null)UnityEngine.Object.Destroy(approvedRightMaterial);approvedRightMaterial=null;}
 }
}
