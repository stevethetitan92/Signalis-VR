using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 // Owned copies only: never edit a shared game/world material in place.
 private readonly Dictionary<int,Material> weaponMatteMaterials=new Dictionary<int,Material>();
 private readonly Dictionary<Renderer,Material[]> weaponMatteOriginals=new Dictionary<Renderer,Material[]>();
 private readonly HashSet<int> weaponMattePreviews=new HashSet<int>();
 private readonly Dictionary<int,string> weaponMatteViews=new Dictionary<int,string>();
 private Material MatteWeaponCopy(Material source){
  if(source==null)return null;Material m;int id=source.GetInstanceID();
  if(weaponMatteMaterials.TryGetValue(id,out m))return m;
  m=new Material(source);m.shader=Shader.Find(source.mainTexture!=null?"Unlit/Texture":"Unlit/Color");
  weaponMatteMaterials[id]=m;weaponMatteMaterials[m.GetInstanceID()]=m;return m;
 }
 private void MatteInventoryWeapon(global::InventoryBase view){
  // Native inspectors may recreate their renderers. Bound retained wrappers.
  if(weaponMatteOriginals.Count>128||weaponMatteMaterials.Count>256)ClearWeaponMatte();
  var item=view.lastItem;
  if(item==null)return;string id=item._item.ToString();
  if(id=="FlakGunAmmo"){ShowGrenadeInventory(view.InspectObj);return;}
  if(grenadeInventory.Count>0)ClearGrenadeInventory();
  if(!QuickFirearm(id)&&id!="Taser"&&id!="PistolAmmo"&&id!="ShotgunAmmo"&&id!="RifleAmmo"&&id!="RevolverAmmo"&&id!="FlareAmmo")return;
  var model=item.Image3D;if(model!=null&&weaponMattePreviews.Add(model.GetInstanceID()))MatteWeaponRenderers(model.GetComponentsInChildren<Renderer>(true));
  if(view.InspectObj==null)return;int key=view.InspectObj.GetInstanceID();string previous;
  if(weaponMatteViews.TryGetValue(key,out previous)&&previous==id)return;
  weaponMatteViews[key]=id;MatteWeaponRenderers(view.InspectObj.GetComponentsInChildren<Renderer>(true));
 }
 private void MatteWeaponRenderers(Renderer[] renderers){
  foreach(var r in renderers){
   var original=r.sharedMaterials;var copies=new Material[original.Length];
   for(int i=0;i<copies.Length;i++)copies[i]=MatteWeaponCopy(original[i]);
   if(!weaponMatteOriginals.ContainsKey(r))weaponMatteOriginals[r]=original;r.sharedMaterials=copies;
  }
 }
 private void ClearWeaponMatte(){
  ClearGrenadeInventory();
  foreach(var pair in weaponMatteOriginals)if(pair.Key!=null)pair.Key.sharedMaterials=pair.Value;
  weaponMatteOriginals.Clear();weaponMattePreviews.Clear();weaponMatteViews.Clear();
  foreach(var m in new HashSet<Material>(weaponMatteMaterials.Values))if(m!=null)UnityEngine.Object.Destroy(m);
  weaponMatteMaterials.Clear();
 }
}}
