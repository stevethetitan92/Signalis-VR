﻿using System;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly ManualReloadPolicy smgReload=new ManualReloadPolicy { MaximumPull=.030f, MinimumPull=.006f, RequireFreshRackGrip=true };
  private readonly HingedReloadPolicy hingedReload=new HingedReloadPolicy();
  private bool additionalRackOnly;
  private readonly SmgHandleStroke smgHandleStroke=new SmgHandleStroke();
  private Vector3 SmgRelativeHand(){return Quaternion.Inverse(rightWeaponRotation)*controllerTrackingToWorld*(rawControllerPositions[0]-rawControllerPositions[1]);}
  private bool additionalFailed,additionalInsert,additionalRack,additionalB,rifleEjectionPending;
  private IntPtr additionalWeapon;
  private int additionalFrame=-1,additionalPulse=-1,additionalAmmoBefore;
  private readonly CylinderSwingMotion cylinderMotion=new CylinderSwingMotion();
  private float additionalSample,additionalOpen,additionalEject=-100,additionalRackTime=-100,additionalReleasePull;
  private Vector3 additionalEjectPoint;private Quaternion additionalEjectRotation;
  private Vector3 additionalChamber,additionalBolt,additionalLoadDirection;private bool additionalAnchors;
  private GameObject additionalRoot;private MeshRenderer additionalAmmo,additionalCase,additionalPouch,additionalTarget,additionalHipAmmo;
  private Mesh additionalLoaderMesh;private Mesh additionalMesh;private Material additionalBrass,additionalCopper,additionalCue;
  private string additionalVisualKind,additionalAmmoAppearance;
  private int additionalLoaderCount,additionalLoaderStart;
  private MeshRenderer additionalLoaderBase,additionalLoaderKnob;private Material additionalLoaderMaterial;
  private bool AdditionalGunEligible(){
   var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null)return false;var id=w.parentItem._item;
   return manualReloadEnabled&&!additionalFailed&&!modMenuOpen&&!mouseWeaponTest&&questPolicy.LeftArmed&&questPolicy.RightArmed&&ManualReloadContextReady()&&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput&&!global::PlayerState.hurt&&!global::PlayerState.grappled
    &&(id==global::Items.itemlist.SMG||id==global::Items.itemlist.Revolver||id==global::Items.itemlist.Rifle||IsFlaregun(id));
  }
  private bool AdditionalReloadActive(){return smgReload.Active||hingedReload.Active||additionalOpen>.01f;}
  private bool AdditionalHoldingAmmo(){return smgReload.Stage==ManualReloadPolicy.Step.Holding||hingedReload.Stage==HingedReloadPolicy.Step.Holding;}
  private void CancelAdditionalReload(){ResetAmmoGuide();smgHandleStroke.Reset();additionalRackOnly=false;rifleCandidate=riflePendingChamber=-1;smgReload.Cancel();hingedReload.Cancel();cylinderFlick.Reset();cylinderMotion.Reset();ResetRifleCloseGesture();ResetRifleBarrelGrip();flickTime=-1;rifleEjectionPending=false;additionalWeapon=IntPtr.Zero;additionalInsert=additionalRack=false;additionalPulse=-1;additionalOpen=0;additionalAnchors=false;HideAdditionalReload();}
  private void FilterAdditionalReloadInput(bool b){
   try{
    PollRevolverEjector();if(!AdditionalGunEligible()){if(!RetainPhysicalReload())CancelAdditionalReload();if(AdditionalReloadActive())questFrame.buttons&=~((1<<7)|(1<<6));additionalB=b;return;}
    var w=global::InventoryManager.EquippedWeapon;float now=Time.realtimeSinceStartup;bool smg=w.parentItem._item==global::Items.itemlist.SMG;
    if(additionalWeapon!=w.Pointer){CancelAdditionalReload();additionalWeapon=w.Pointer;additionalB=b;rifleGripPrevious=manualLeftGrip;return;}
    if(smg){
     // Completion is owned by the physical stroke/insertion transaction below.
     if(additionalRack){additionalRack=false;if(smgReload.RequiresRack){PlayMechanismSound("SMG","SlideForward");additionalRackTime=now;additionalReleasePull=smgReload.RackPull;}if(!additionalRackOnly)CommitPhysicalMagazine(w);additionalRackOnly=false;smgReload.Cancel();additionalPulse=-1;MelonLogger.Msg("MANUAL SMG: physical reload/charge accepted; loaded="+w.magAmmo);}
     if(b&&!additionalB&&smgReload.Stage==ManualReloadPolicy.Step.Idle){PlayMechanismSound("SMG","MagDrop");smgReload.PressB(now,manualLeftGrip,true,w.magAmmo==0);additionalEject=now;additionalEjectPoint=additionalChamber;additionalEjectRotation=rightWeaponRotation;}
    }else{
     if(additionalInsert){additionalInsert=false;int reserve=ShotgunReserve(w),loaded=w.magAmmo;
      int amount=w.parentItem._item==global::Items.itemlist.Revolver?ManualAmmoTransfer.LoaderAmount(loaded,w.MagSize,reserve,infiniteAmmo):ManualAmmoTransfer.Amount(loaded,w.MagSize,reserve,infiniteAmmo);
      if(hingedReload.Stage==HingedReloadPolicy.Step.AwaitingInsert&&amount>0&&(w.parentItem._item!=global::Items.itemlist.Rifle||rifleChambers.Empty(riflePendingChamber))){
       if(!infiniteAmmo)global::InventoryManager.SetCount(w.ammoItem,reserve-amount);
       try{w.magAmmo=loaded+amount;}catch{if(!infiniteAmmo)global::InventoryManager.SetCount(w.ammoItem,reserve);throw;}
       if(w.parentItem._item==global::Items.itemlist.Rifle)rifleChambers.Insert(riflePendingChamber);
       PlayMechanismSound(WeaponFamily(w.parentItem._item.ToString()),"Insert");
       MelonLogger.Msg("MANUAL "+w.parentItem._item+": "+amount+" rounds inserted, loaded="+w.magAmmo);
      }hingedReload.Inserted();riflePendingChamber=-1;
     }
     bool soundWasOpen=hingedReload.Active;
     if(b&&!additionalB){bool wasOpen=hingedReload.Active;hingedReload.PressB();if(!wasOpen){hingeOpened=now;if(w.parentItem._item==global::Items.itemlist.Rifle)rifleEjectionPending=true;}}
     if(w.parentItem._item==global::Items.itemlist.Revolver&&RevolverFlickClose(now))hingedReload.PressB();
     if((w.parentItem._item==global::Items.itemlist.Rifle||IsFlaregun(w.parentItem._item))&&RifleFlickClose(now))hingedReload.PressB();
     additionalOpen=(w.parentItem._item==global::Items.itemlist.Rifle||IsFlaregun(w.parentItem._item))?UpdateRifleBarrelGrip():w.parentItem._item==global::Items.itemlist.Revolver?cylinderMotion.Tick(hingedReload.Active,Time.unscaledDeltaTime):Mathf.MoveTowards(additionalOpen,hingedReload.Active?1:0,Time.unscaledDeltaTime*6f);
     if(soundWasOpen&&!hingedReload.Active)PlayMechanismSound(WeaponFamily(w.parentItem._item.ToString()),"SnapClosed");
    }
    questFrame.buttons&=~(1<<7);if(b)questFrame.buttons&=~(1<<1);
    if(AdditionalReloadActive())questFrame.buttons&=~((1<<5)|(1<<6));
    if(smg&&Time.frameCount<=additionalPulse)questFrame.buttons|=1<<7;
    additionalB=b;
   }catch(Exception ex){additionalFailed=true;CancelAdditionalReload();MelonLogger.Warning("Additional gun reload disabled; native reload available: "+ex.Message);}
  }
  private Mesh additionalSmgSourceMesh;
  private Material additionalSmgSourceMaterial;
  private void EnsureAdditionalAmmo(string kind){
   var weapon=global::InventoryManager.EquippedWeapon;int loaderCount=kind=="Revolver"?ManualAmmoTransfer.LoaderAmount(weapon.magAmmo,weapon.MagSize,ShotgunReserve(weapon),infiniteAmmo):0;
   var smgSource=kind=="SMG"?ReloadCopy("SMG_Mag"):null;
   var smgMesh=smgSource==null?null:smgSource.GetComponent<MeshFilter>().sharedMesh;
   var smgMaterial=smgSource==null?null:smgSource.sharedMaterial;
   // Switching away destroys the Xiphias materials. A cached reload magazine
   // must not retain those destroyed references when the SMG is equipped again.
   bool smgCurrent=kind!="SMG"||(smgMesh!=null&&smgMaterial!=null&&additionalSmgSourceMesh==smgMesh&&additionalSmgSourceMaterial==smgMaterial);
   if(additionalRoot!=null&&additionalVisualKind==kind&&additionalAmmoAppearance==RoundAppearance(kind)&&smgCurrent&&(kind!="Revolver"||additionalLoaderCount==loaderCount&&additionalLoaderStart==weapon.magAmmo))return;DestroyAdditionalVisual();additionalVisualKind=kind;additionalAmmoAppearance=RoundAppearance(kind);additionalLoaderCount=loaderCount;additionalLoaderStart=weapon.magAmmo;
   additionalSmgSourceMesh=smgMesh;additionalSmgSourceMaterial=smgMaterial;
   additionalRoot=new GameObject("SignalisVR_Manual_"+kind);UnityEngine.Object.DontDestroyOnLoad(additionalRoot);additionalRoot.transform.localScale=Vector3.one*UnitsPerMetre;
   var shader=Shader.Find("Unlit/Color");if(shader==null)throw new InvalidOperationException("Reload material unavailable");additionalBrass=new Material(shader);additionalBrass.color=new Color(.68f,.48f,.19f);additionalCopper=new Material(shader);additionalCopper.color=kind=="FlareGun"?new Color(.65f,.12f,.08f):new Color(.63f,.31f,.17f);additionalCue=new Material(shader);additionalCue.color=new Color(.15f,.65f,.9f);
   var box=controllerBodies[0].GetComponent<MeshFilter>().sharedMesh;
   if(kind=="SMG"){
    var native=ReloadCopy("SMG_Mag");if(native==null)throw new InvalidOperationException("Native SMG magazine mesh unavailable");var original=native.GetComponent<MeshFilter>().sharedMesh;additionalMesh=UnityEngine.Object.Instantiate(original);var v=additionalMesh.vertices;for(int i=0;i<v.Length;i++)v[i]-=original.bounds.center;additionalMesh.vertices=v;additionalMesh.RecalculateBounds();
    additionalAmmo=CreateControllerPart(additionalRoot,additionalMesh,additionalBrass,"SMGMagazine",Vector3.zero,Vector3.one);additionalAmmo.sharedMaterials=native.sharedMaterials;additionalAmmo.transform.localScale=native.transform.lossyScale/UnitsPerMetre;AddSmgRounds(infiniteAmmo?weapon.MagSize:Math.Min(weapon.MagSize,weapon.magAmmo+ShotgunReserve(weapon)));
   }else if(kind=="Rifle"||kind=="FlareGun"){CreateHdHeldRound(kind);
   }else if(kind=="Revolver"&&SelectedActive("Revolver")){
    CreateAglLoader(shader,loaderCount);
   }else if(kind=="Revolver"){
    var native=ReloadCopy("Bullets");if(native==null)throw new InvalidOperationException("Native cylinder ammunition unavailable");var source=native.GetComponent<MeshFilter>().sharedMesh;additionalMesh=UnityEngine.Object.Instantiate(source);var v=additionalMesh.vertices;var center=source.bounds.center;for(int i=0;i<v.Length;i++){var p=v[i]-center;v[i]=new Vector3(p.z,p.x,p.y);}additionalMesh.vertices=v;additionalMesh.RecalculateNormals();
    if(source.vertexCount==144&&source.subMeshCount==1){var selected=new System.Collections.Generic.List<int>();var triangles=source.GetTriangles(0);for(int t=0;t<triangles.Length;t+=3)if(RevolverRoundLayout.InLoader(triangles[t],additionalLoaderStart,loaderCount)){selected.Add(triangles[t]);selected.Add(triangles[t+1]);selected.Add(triangles[t+2]);}additionalMesh.SetTriangles(selected.ToArray(),0);}additionalMesh.RecalculateBounds();
    additionalAmmo=CreateControllerPart(additionalRoot,additionalMesh,additionalBrass,"RevolverSpeedloaderRounds",Vector3.zero,Vector3.one);additionalAmmo.sharedMaterials=native.sharedMaterials;var s=native.transform.lossyScale/UnitsPerMetre;additionalAmmo.transform.localScale=new Vector3(s.z,s.x,s.y);
    additionalLoaderMaterial=new Material(shader);additionalLoaderMaterial.color=new Color(.20f,.18f,.18f);additionalCopper.color=new Color(.48f,.46f,.46f);
    additionalLoaderMesh=ReloadCylinderMesh();float radius=0;foreach(var p in source.vertices){float y=(p.y-center.y)*s.y,z=(p.z-center.z)*s.z;radius=Math.Max(radius,Mathf.Sqrt(y*y+z*z));}float diameter=radius*2+.004f;additionalLoaderBase=CreateControllerPart(additionalRoot,additionalLoaderMesh,additionalLoaderMaterial,"SpeedloaderBase",Vector3.zero,Vector3.one);additionalLoaderBase.transform.localScale=new Vector3(diameter,.012f,diameter);
    additionalLoaderKnob=CreateControllerPart(additionalRoot,additionalLoaderMesh,additionalCopper,"SpeedloaderKnob",Vector3.zero,new Vector3(.017f,.019f,.017f));
   }else{
    const int sides=12;var v=new Vector3[sides*2+2];var t=new int[sides*12];for(int i=0;i<sides;i++){float a=i*(float)Math.PI*2/sides;v[i]=new Vector3(Mathf.Cos(a)*.5f,-.5f,Mathf.Sin(a)*.5f);v[i+sides]=new Vector3(v[i].x,.5f,v[i].z);int n=(i+1)%sides,k=i*12;int[] face={i,n,i+sides,n,n+sides,i+sides,sides*2,n,i,sides*2+1,i+sides,n+sides};for(int j=0;j<12;j++)t[k+j]=face[j];}v[sides*2]=new Vector3(0,-.5f,0);v[sides*2+1]=new Vector3(0,.5f,0);additionalMesh=new Mesh();additionalMesh.vertices=v;additionalMesh.triangles=t;additionalMesh.RecalculateNormals();additionalMesh.RecalculateBounds();float diameter=kind=="Revolver"?.012f:kind=="Rifle"?.016f:.0265f;float length=kind=="Revolver"?.045f:kind=="Rifle"?.09f:.08f;
    additionalAmmo=CreateControllerPart(additionalRoot,additionalMesh,additionalBrass,"HeldRound",Vector3.zero,new Vector3(diameter,length,diameter));additionalCase=CreateControllerPart(additionalRoot,kind=="Rifle"?RifleRoundTipMesh():additionalMesh,additionalCopper,"RoundTip",Vector3.zero,new Vector3(diameter*.9f,length*.2f,diameter*.9f));
   }
   additionalHipAmmo=CreateControllerPart(additionalRoot,additionalAmmo.GetComponent<MeshFilter>().sharedMesh,additionalBrass,"VisibleHipAmmo",Vector3.zero,additionalAmmo.transform.localScale);additionalHipAmmo.sharedMaterials=additionalAmmo.sharedMaterials;
   additionalPouch=CreateControllerPart(additionalRoot,box,additionalCue,"AmmoPouch",Vector3.zero,new Vector3(.07f,.09f,.03f));additionalTarget=CreateControllerPart(additionalRoot,box,additionalCue,"ChamberTarget",Vector3.zero,Vector3.one*.009f);
  }
  private void PrepareAdditionalReload(){
   HideAdditionalReload();if(!AdditionalGunEligible()||!handsScoped||!additionalAnchors||controllerMarkers[0]==null)return;
   if(rifleEjectionPending&&SelectedActive("Rifle")&&additionalOpen>.95f){EjectManualRifleCases();rifleEjectionPending=false;}

   try{
    var w=global::InventoryManager.EquippedWeapon;string kind=WeaponFamily(w.parentItem._item.ToString());bool smg=kind=="SMG";EnsureAdditionalAmmo(kind);var left=controllerMarkers[0].transform;var yaw=BodyHipRotation();var pouch=stereoPosition+yaw*(new Vector3(-.22f,-.5f,0)*UnitsPerMetre);var pinch=leftPinchThumb!=null&&leftPinchIndex!=null?(leftPinchThumb.position+leftPinchIndex.position)*.5f:left.position;
    var basis=WeaponAimPolicy.ControllerRotation(left.rotation);var rot=smg?basis:kind=="Rifle"?basis*Quaternion.Euler(0,0,180):basis*Quaternion.Euler(90,0,0);
    float length=additionalAmmo.GetComponent<MeshFilter>().sharedMesh.bounds.size.y*additionalAmmo.transform.lossyScale.y;
    float halfTip=length*.5f;
    var center=smg?left.position+rot*Vector3.right*(.025f*UnitsPerMetre):kind=="Rifle"?left.position:left.position+rot*Vector3.up*(length*.28f);
    if(ElsterAmmoGripData.Has(kind)){
     var fittedBasis=ElsterAmmoGripData.Basis(kind);
     var fittedPalm=ElsterAmmoGripData.Palm(kind);
     rot=basis*Quaternion.Euler(0,0,90)*Quaternion.Inverse(fittedBasis);
     center=left.position-rot*fittedPalm*UnitsPerMetre;
    }
    var savedAmmo=SavedGripData.Get(smg?"SMGMagazine":kind+"Ammo",0);
    if(savedAmmo!=null&&elsterBones!=null){rot=basis*Quaternion.Euler(0,0,90)*Quaternion.Inverse(elsterHandBasis[0])*Quaternion.Inverse(savedAmmo.Turn);center=left.position-rot*savedAmmo.Palm*UnitsPerMetre;}
    var rawCenter=center;var rawRotation=rot;var tip=center+rot*Vector3.up*halfTip;
    bool guidedSeat=GuideAdditionalAmmo(kind,rawCenter,rawRotation,halfTip,ref center,ref rot,ref tip);
    if(additionalFrame!=Time.frameCount){additionalFrame=Time.frameCount;
     if(smg){
      var old=smgReload.Stage;
      // Generic policy owns the magazine only. Its rack Tick is never used by SMG.
      if(old!=ManualReloadPolicy.Step.RackHolding&&smgReload.Tick(Time.realtimeSinceStartup,true,manualLeftGrip,Vector3.Distance(left.position,pouch)<.27f*UnitsPerMetre,guidedSeat,false,0))additionalRack=true;
      bool canCharge=!hdSupportHeld&&(smgReload.Stage==ManualReloadPolicy.Step.Inserted||smgReload.Stage==ManualReloadPolicy.Step.RackHolding||(smgReload.Stage==ManualReloadPolicy.Step.Idle&&w.magAmmo>0));
      bool wasHeld=smgHandleStroke.Held;
      bool accepted=smgHandleStroke.Sample(canCharge,Math.Min(Vector3.Distance(pinch,additionalBolt),Vector3.Distance(left.position,additionalBolt))<.12f*UnitsPerMetre,manualLeftGrip,SmgRelativeHand().z);
      if(!wasHeld&&smgHandleStroke.Held){additionalRackOnly=smgReload.Stage==ManualReloadPolicy.Step.Idle;smgReload.BeginRack(0);MelonLogger.Msg("SMG HANDLE: captured raw tracking stroke");}
      if(smgHandleStroke.Held)smgReload.PresentExternalRack(smgHandleStroke.Pull,smgHandleStroke.Peak);
      if(wasHeld&&!smgHandleStroke.Held){
       smgReload.PresentExternalRack(smgHandleStroke.Peak,smgHandleStroke.Peak);
       smgReload.FinishExternalRack(accepted,Time.realtimeSinceStartup);
       if(accepted)additionalRack=true;else if(additionalRackOnly){smgReload.Cancel();additionalRackOnly=false;}
       MelonLogger.Msg("SMG HANDLE: release accepted="+accepted+" peak="+smgHandleStroke.Peak.ToString("F3"));
      }
      if(old==ManualReloadPolicy.Step.Holding&&(smgReload.Stage==ManualReloadPolicy.Step.Inserted||smgReload.Stage==ManualReloadPolicy.Step.AwaitingGame))PlayMechanismSound("SMG","MagInsert");
      if(old!=smgReload.Stage)MelonLogger.Msg("MANUAL SMG: stage="+smgReload.Stage);
      if(old==ManualReloadPolicy.Step.Holding&&smgReload.Stage==ManualReloadPolicy.Step.Ejected){additionalEject=Time.realtimeSinceStartup;additionalEjectPoint=center;additionalEjectRotation=rot;}
     }else if(!rifleBarrelHeld&&hingedReload.Tick(Time.realtimeSinceStartup,manualLeftGrip,Vector3.Distance(left.position,pouch)<.27f*UnitsPerMetre,(SelectedActive("Rifle")?guidedSeat&&rifleCandidate>=0&&rifleChambers.Empty(rifleCandidate):guidedSeat)&&(SelectedActive("Rifle")?additionalOpen>25f/RifleHingePolicy.MaxAngle:kind=="FlareGun"?additionalOpen>.75f:additionalOpen>.95f),w.magAmmo,w.MagSize,infiniteAmmo?Math.Max(1,ShotgunReserve(w)):ShotgunReserve(w))){additionalInsert=true;riflePendingChamber=SelectedActive("Rifle")?rifleCandidate:-1;additionalSample=Time.realtimeSinceStartup;}
    }
    bool holding=AdditionalHoldingAmmo();additionalAmmo.transform.position=center;additionalAmmo.transform.rotation=rot;additionalAmmo.enabled=holding;
    if(additionalCase!=null){additionalCase.transform.position=center+rot*Vector3.up*(kind=="Rifle"?length*.5f+.009f*UnitsPerMetre:length*.43f);additionalCase.transform.rotation=rot;additionalCase.enabled=holding;}
    if(additionalLoaderBase!=null){additionalLoaderBase.transform.position=center-rot*Vector3.up*(SelectedActive("Revolver")?.02475f*AmmoGuidePolicy.RevolverScale*UnitsPerMetre:length*.5f+.004f*UnitsPerMetre);additionalLoaderBase.transform.rotation=rot;additionalLoaderBase.enabled=holding;additionalLoaderKnob.transform.position=additionalLoaderBase.transform.position-rot*Vector3.up*((SelectedActive("Revolver")?.0155f*AmmoGuidePolicy.RevolverScale:.014f)*UnitsPerMetre);additionalLoaderKnob.transform.rotation=rot;additionalLoaderKnob.enabled=holding;}
    if(holding&&kind!="Rifle"&&kind!="FlareGun"&&!SelectedActive("Revolver"))FollowAmmoWithHand(rawCenter,rawRotation,center,rot);
    additionalPouch.transform.position=pouch;additionalPouch.transform.rotation=yaw;additionalPouch.enabled=(smg?smgReload.Stage==ManualReloadPolicy.Step.Ejected:hingedReload.Stage==HingedReloadPolicy.Step.Open)&&ManualAmmoTransfer.Amount(w.magAmmo,w.MagSize,ShotgunReserve(w),infiniteAmmo)>0;
    additionalHipAmmo.transform.SetPositionAndRotation(pouch,yaw);additionalHipAmmo.enabled=!holding&&ShotgunReserve(w)>0;additionalPouch.enabled=false;
    bool inserted=smg&&(smgReload.Stage==ManualReloadPolicy.Step.Inserted||smgReload.Stage==ManualReloadPolicy.Step.RackHolding);additionalTarget.transform.position=inserted?additionalBolt:additionalChamber;additionalTarget.transform.rotation=rightWeaponRotation;additionalTarget.enabled=false;
    float age=Time.realtimeSinceStartup-additionalEject;if(smg&&!holding&&age>=0&&age<.45f){additionalAmmo.transform.position=additionalEjectPoint-controllerTrackingToWorld*Vector3.up*(.5f*9.81f*age*age*UnitsPerMetre);additionalAmmo.transform.rotation=additionalEjectRotation;additionalAmmo.enabled=true;}
    ShowReloadAmmoDetails();
   }catch(Exception ex){additionalFailed=true;CancelAdditionalReload();MelonLogger.Warning("Manual reload visual disabled: "+ex.Message);}
  }
  private void HideAdditionalReload(){HideReloadAmmoDetails();foreach(var r in new[]{additionalAmmo,additionalCase,additionalPouch,additionalTarget,additionalLoaderBase,additionalLoaderKnob,additionalHipAmmo})if(r!=null)r.enabled=false;}
  private void DestroyAdditionalVisual(){DestroyMagazineRounds();if(rifleRoundTipMesh!=null)UnityEngine.Object.Destroy(rifleRoundTipMesh);rifleRoundTipMesh=null;if(additionalRoot!=null)UnityEngine.Object.Destroy(additionalRoot);if(additionalMesh!=null)UnityEngine.Object.Destroy(additionalMesh);if(additionalLoaderMesh!=null)UnityEngine.Object.Destroy(additionalLoaderMesh);additionalLoaderMesh=null;foreach(var m in new[]{additionalBrass,additionalCopper,additionalCue,additionalLoaderMaterial})if(m!=null)UnityEngine.Object.Destroy(m);additionalRoot=null;additionalMesh=null;additionalAmmo=additionalCase=additionalPouch=additionalTarget=additionalLoaderBase=additionalLoaderKnob=additionalHipAmmo=null;additionalBrass=additionalCopper=additionalCue=additionalLoaderMaterial=null;additionalVisualKind=null;}
 }
}






