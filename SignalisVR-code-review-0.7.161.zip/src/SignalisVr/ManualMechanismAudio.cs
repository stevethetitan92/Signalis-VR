using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool mechanismAudioWarning;
 private void PlayMechanismSound(string weapon,string action){
  // Individual events verified against the game's Weapons.bank. Never invoke
  // native reload(), Reload, or Reload Inventory to accompany a manual gesture.
  try{FMODUnity.RuntimeManager.PlayOneShot("event:/Elster/Weapons/"+weapon+"/"+action,rightWeaponPosition);}
  catch(Exception ex){if(!mechanismAudioWarning){mechanismAudioWarning=true;MelonLoader.MelonLogger.Warning("Manual mechanism sound unavailable: "+ex.Message);}}
 }
}}

