using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private readonly List<Renderer> compositorSurfaces=new List<Renderer>();
 private readonly Stack<ComputerSurfaceScope> computerSurfaceScopes=new Stack<ComputerSurfaceScope>();
 private float nextCompositorSurfaceScan;
 private int computerSurfaceFrame=-1;
 private int computerSurfaceReports;
 private Camera.CameraCallback computerPreCull,computerPostRender;
 private readonly Dictionary<Transform,ComputerContentCache> computerContentCaches=new Dictionary<Transform,ComputerContentCache>();
 private int computerContentReports;
 private int computerOutputReports;
 private sealed class ComputerContentCache {internal float NextScan;internal Renderer[] Renderers;}
 private sealed class ComputerSurfaceScope {internal Camera Camera;internal int Mask;internal Renderer[] Renderers;internal bool[] Hidden,Enabled;internal int[] Layers;}
 private static string ComputerSurfaceName(string name){return (name??"").Replace("(Clone)","").Trim();}
 // The slash is part of the native object's name, not a hierarchy separator.
 private static bool IsEffectsCompositor(string name){name=ComputerSurfaceName(name);return name=="Diag/Effects Camera"||name=="Effects Camera";}
 private static bool IsCompositorSurface(string name,string parent){name=ComputerSurfaceName(name);parent=ComputerSurfaceName(parent);return name=="MainScreen"&&parent=="RenderCam"||name=="UI_overlay"&&IsEffectsCompositor(parent);}
 private static Transform ComputerContentRoot(Camera view){
  if(ComputerSurfaceName(view.name)=="PC Camera"&&view.transform.Find("PC_content")!=null)return view.transform;
  for(var p=view.transform;p!=null;p=p.parent)if(ComputerSurfaceName(p.name)=="ROT_PC")return p;
  return null;
 }
 private int ComputerOriginalLayer(Renderer renderer,int savedLayer){
  int layer=savedLayer;
  // A nested camera must select by authored layers, before its outer scope.
  foreach(var scope in computerSurfaceScopes)for(int i=0;i<scope.Renderers.Length;i++)if(scope.Renderers[i]==renderer)layer=scope.Layers[i];
  return layer;
 }
 private int ComputerOriginalMask(Camera view){int mask=view.cullingMask;foreach(var scope in computerSurfaceScopes)if(scope.Camera==view)mask=scope.Mask;return mask;}
 private void InstallComputerScreenIsolation(){
  computerPreCull=(Action<Camera>)ComputerSurfaceBegin;computerPostRender=(Action<Camera>)ComputerSurfaceEnd;
  Camera.onPreCull+=computerPreCull;Camera.onPostRender+=computerPostRender;
 }
 private void ComputerSurfaceBegin(Camera view){
  // Recover a missing post-render callback before the next frame's cameras.
  if(computerSurfaceFrame!=Time.frameCount){while(computerSurfaceScopes.Count>0)RestoreComputerSurfaceScope(computerSurfaceScopes.Pop());computerSurfaceFrame=Time.frameCount;}
  if((!active&&!desktopMouseOnly)||stopping||view==null||view==eyes[0]||view==eyes[1]||
    !(nativeEventContext||global::PlayerState.gameState==global::PlayerState.gameStates.eventScreen))return;
  // These cameras compose the final native screen; they must retain the quads.
  // Event/world/monitor source cameras must not photograph that output again.
  bool finalEffects=IsEffectsCompositor(view.name);
  bool finalDisplay=view.transform.parent!=null&&ComputerSurfaceName(view.transform.parent.name)=="RenderCam";
  if(ComputerSurfaceName(view.name)=="UI Overlay Camera")return;
  if(Time.realtimeSinceStartup>=nextCompositorSurfaceScan){
   nextCompositorSurfaceScan=Time.realtimeSinceStartup+1f;compositorSurfaces.Clear();
   foreach(var renderer in UnityEngine.Object.FindObjectsOfType<Renderer>()){
    var parent=renderer.transform.parent;
    if(parent!=null&&IsCompositorSurface(renderer.name,parent.name))compositorSurfaces.Add(renderer);
   }
  }
  if(computerSurfaceReports++<6)MelonLoader.MelonLogger.Msg("COMPUTER SOURCE SCOPE: camera="+view.name+" outputQuads="+compositorSurfaces.Count+" mask="+view.cullingMask+" stereo="+stereo);
  // Final cameras need their OWN output plane, but must not also draw the
  // other display planes, including EnhancedResolution's duplicate UI root.
  // Earlier candidates exempted these cameras completely, leaving that path open.
  var excludedOutputs=new List<Renderer>();
  foreach(var r in compositorSurfaces)if(r!=null&&
   !(finalEffects&&r.transform.parent==view.transform||finalDisplay&&r.transform.parent==view.transform.parent))excludedOutputs.Add(r);
  if((finalEffects||finalDisplay)&&computerOutputReports++<12){
   string names="";foreach(var r in excludedOutputs)names+=(names.Length==0?"":" | ")+ComputerOutputPath(r.transform);
   MelonLoader.MelonLogger.Msg("COMPUTER OUTPUT FILTER: camera="+ComputerOutputPath(view.transform)+" removed="+excludedOutputs.Count+" planes="+names);
  }
  var root=finalEffects||finalDisplay?null:ComputerContentRoot(view);Renderer[] content=null;
  if(root!=null){
   ComputerContentCache cache;
   if(!computerContentCaches.TryGetValue(root,out cache)){cache=new ComputerContentCache();computerContentCaches[root]=cache;}
   if(cache.Renderers==null||Time.realtimeSinceStartup>=cache.NextScan){cache.Renderers=root.GetComponentsInChildren<Renderer>(true);cache.NextScan=Time.realtimeSinceStartup+1f;}
   content=cache.Renderers;
   if(computerContentReports++<12)MelonLoader.MelonLogger.Msg("COMPUTER CONTENT SCOPE: camera="+view.name+" root="+root.name+" renderers="+content.Length+" target="+(view.targetTexture!=null?view.targetTexture.name:"backbuffer"));
  }
  if(excludedOutputs.Count==0&&content==null)return;
  var renderers=new List<Renderer>(excludedOutputs);var seen=new HashSet<Renderer>(excludedOutputs);if(content!=null)foreach(var r in content)if(r!=null&&seen.Add(r))renderers.Add(r);
  var scope=new ComputerSurfaceScope{Camera=view,Mask=view.cullingMask,Renderers=renderers.ToArray(),Hidden=new bool[renderers.Count],Enabled=new bool[renderers.Count],Layers=new int[renderers.Count]};
  int selectionMask=ComputerOriginalMask(view);
  // These are display-output quads, not event geometry. Exclude them from the
  // source camera even if another render callback restores renderer visibility.
  // Layer31 is already isolated for our private flat-screen presentation.
  // Native computer cameras have all-layer masks and can capture unrelated
  // scene/cutscene monitor planes. Only their own authored stage may enter.
  // Asset/mod audit: layer28 is unused; 29 and31 contain native fog.
  // Keep computer content separate from our private VR presentation layer31.
  view.cullingMask=content!=null?1<<28:view.cullingMask&~(1<<31);
  for(int i=0;i<scope.Renderers.Length;i++){
   var r=scope.Renderers[i];if(r==null)continue;scope.Hidden[i]=r.forceRenderingOff;scope.Enabled[i]=r.enabled;scope.Layers[i]=r.gameObject.layer;
  }
  for(int i=0;i<scope.Renderers.Length;i++){
   var r=scope.Renderers[i];if(r==null)continue;
   if(excludedOutputs.Contains(r)){r.gameObject.layer=31;r.forceRenderingOff=true;r.enabled=false;}
   else if((selectionMask&(1<<ComputerOriginalLayer(r,scope.Layers[i])))!=0)r.gameObject.layer=28;
   else r.gameObject.layer=31;
  }
  computerSurfaceScopes.Push(scope);
 }
 private static string ComputerOutputPath(Transform t){string path="";for(int i=0;t!=null&&i<8;i++,t=t.parent)path=t.name+(path.Length==0?"":"/"+path);return path;}
 private void ComputerSurfaceEnd(Camera view){
  ObserveComputerGui(view);
  if(computerSurfaceScopes.Count==0||computerSurfaceScopes.Peek().Camera!=view)return;
  RestoreComputerSurfaceScope(computerSurfaceScopes.Pop());
 }
 private static void RestoreComputerSurfaceScope(ComputerSurfaceScope scope){if(scope.Camera!=null)scope.Camera.cullingMask=scope.Mask;for(int i=0;i<scope.Renderers.Length;i++)if(scope.Renderers[i]!=null){var r=scope.Renderers[i];r.forceRenderingOff=scope.Hidden[i];r.enabled=scope.Enabled[i];r.gameObject.layer=scope.Layers[i];}}
 private void ClearComputerScreenIsolation(){while(computerSurfaceScopes.Count>0)RestoreComputerSurfaceScope(computerSurfaceScopes.Pop());compositorSurfaces.Clear();computerContentCaches.Clear();nextCompositorSurfaceScan=0;ClearComputerGui();}
}}

