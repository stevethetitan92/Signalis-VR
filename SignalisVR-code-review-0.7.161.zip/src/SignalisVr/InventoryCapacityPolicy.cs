using System;
namespace SignalisVrTracking {
 public static class InventoryCapacityPolicy {
  public const int Slots=14;
  // Native inventory includes exempt flashlight/radio modules in its item count.
  public static int BaseSlots(bool cheat,bool expandedNative){return cheat?Slots:(expandedNative?8:6);}
  public static int Effective(bool modulesTakeSpace,int modules){return Effective(Slots,modulesTakeSpace,modules);}
  public static int Effective(int slots,bool modulesTakeSpace,int modules){return slots+(modulesTakeSpace?0:Math.Max(0,modules));}
 }
}
