using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Security.Cryptography;
namespace SignalisVrTracking {
 // Keep JSON value tokens verbatim, including float precision and escaped text.
 // Only SignalisVR keys move into a checksummed, losslessly compressed envelope.
 public static class SaveCompression {
  public const string Key="SignalisVR.Packed.v1";
  const int Limit=16*1024*1024;
  static readonly string[] Keys={"intKeys","floatKeys","stringKeys","boolKeys","vectorKeys"};
  static readonly string[] Values={"ints","floats","strings","bools","vectors"};
  static int End(string s,int start){
   bool quoted=false,escaped=false;int depth=0;
   for(int i=start;i<s.Length;i++){char c=s[i];if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;continue;}
    if(c=='"'){quoted=true;continue;}if(c=='['||c=='{')depth++;else if(c==']'||c=='}'){if(depth==0)return i;depth--;}
    else if(c==','&&depth==0)return i;
   }if(quoted||depth!=0)throw new InvalidDataException("Incomplete save JSON");return s.Length;
  }
  static List<string> Array(string s){
   s=s.Trim();if(s.Length<2||s[0]!='['||s[s.Length-1]!=']')throw new InvalidDataException("Invalid save array");
   var a=new List<string>();int p=1;while(p<s.Length-1){while(p<s.Length-1&&char.IsWhiteSpace(s[p]))p++;if(p==s.Length-1)break;int e=End(s,p);a.Add(s.Substring(p,e-p).Trim());p=e+1;}return a;
  }
  static Dictionary<string,string> Object(string s){
   s=s.Trim();if(s.Length<2||s[0]!='{'||s[s.Length-1]!='}')throw new InvalidDataException("Invalid save object");
   var d=new Dictionary<string,string>();int p=1;
   while(p<s.Length-1){while(char.IsWhiteSpace(s[p]))p++;if(s[p]!='"')throw new InvalidDataException("Invalid save field");int q=p+1;bool escape=false;
    for(;q<s.Length;q++){if(escape){escape=false;continue;}if(s[q]=='\\'){escape=true;continue;}if(s[q]=='"')break;}
    string k=Text(s.Substring(p,q-p+1));p=q+1;while(char.IsWhiteSpace(s[p]))p++;if(s[p++]!=':')throw new InvalidDataException("Invalid save field separator");
    while(char.IsWhiteSpace(s[p]))p++;int e=End(s,p);d.Add(k,s.Substring(p,e-p).Trim());p=e+1;
   }return d;
  }
  static string Text(string s){
   if(s.Length<2||s[0]!='"'||s[s.Length-1]!='"')throw new InvalidDataException("Invalid save string");var b=new StringBuilder();
   for(int i=1;i<s.Length-1;i++){char c=s[i];if(c!='\\'){b.Append(c);continue;}c=s[++i];switch(c){case '"':case '\\':case '/':b.Append(c);break;case 'n':b.Append('\n');break;case 'r':b.Append('\r');break;case 't':b.Append('\t');break;case 'b':b.Append('\b');break;case 'f':b.Append('\f');break;case 'u':b.Append((char)Convert.ToInt32(s.Substring(i+1,4),16));i+=4;break;default:throw new InvalidDataException("Invalid JSON escape");}}
   return b.ToString();
  }
  static string Join(List<string> a){return "["+string.Join(",",a.ToArray())+"]";}
  static string Json(Dictionary<string,string> d){var a=new List<string>();foreach(var p in d)a.Add("\""+p.Key+"\":"+p.Value);return "{"+string.Join(",",a.ToArray())+"}";}
  static string Hash(byte[] b){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","");}
  static void Validate(Dictionary<string,string> d){foreach(var k in Keys)if(!d.ContainsKey(k))throw new InvalidDataException("Missing save keys");foreach(var k in Values)if(!d.ContainsKey(k))throw new InvalidDataException("Missing save values");for(int i=0;i<Keys.Length;i++)if(Array(d[Keys[i]]).Count!=Array(d[Values[i]]).Count)throw new InvalidDataException("Unpaired save data");}
  public static string Pack(string json){
   var d=Object(json);Validate(d);var packed=new Dictionary<string,string>();bool any=false;
   for(int i=0;i<Keys.Length;i++){var k=Array(d[Keys[i]]);var v=Array(d[Values[i]]);var nk=new List<string>();var nv=new List<string>();var pk=new List<string>();var pv=new List<string>();
    for(int j=0;j<k.Count;j++){string name=Text(k[j]);if(name==Key)throw new InvalidDataException("Save envelope was not expanded");if(name.StartsWith("SignalisVR",StringComparison.Ordinal)){pk.Add(k[j]);pv.Add(v[j]);any=true;}else{nk.Add(k[j]);nv.Add(v[j]);}}
    d[Keys[i]]=Join(nk);d[Values[i]]=Join(nv);packed[Keys[i]]=Join(pk);packed[Values[i]]=Join(pv);
   }if(!any)return json;
   byte[] raw=Encoding.UTF8.GetBytes(Json(packed));if(raw.Length>Limit)throw new InvalidDataException("Mod save data too large");byte[] bytes;
   using(var m=new MemoryStream()){using(var g=new GZipStream(m,CompressionMode.Compress,true))g.Write(raw,0,raw.Length);bytes=m.ToArray();}
   var sk=Array(d["stringKeys"]);var sv=Array(d["strings"]);sk.Add("\""+Key+"\"");sv.Add("\""+Hash(raw)+":"+Convert.ToBase64String(bytes)+"\"");d["stringKeys"]=Join(sk);d["strings"]=Join(sv);return Json(d);
  }
  public static string Expand(string json){
   if(json==null||json.IndexOf(Key,StringComparison.Ordinal)<0)return json;
   var d=Object(json);Validate(d);var k=Array(d["stringKeys"]);var v=Array(d["strings"]);int index=-1;for(int i=0;i<k.Count;i++)if(Text(k[i])==Key){if(index!=-1)throw new InvalidDataException("Duplicate mod envelope");index=i;}
   if(index<0)return json;string envelope=Text(v[index]);int split=envelope.IndexOf(':');if(split!=64)throw new InvalidDataException("Invalid mod checksum");byte[] raw;
   using(var m=new MemoryStream(Convert.FromBase64String(envelope.Substring(split+1))))using(var g=new GZipStream(m,CompressionMode.Decompress))using(var o=new MemoryStream()){
    var buffer=new byte[8192];int n;while((n=g.Read(buffer,0,buffer.Length))>0){if(o.Length+n>Limit)throw new InvalidDataException("Mod envelope exceeds limit");o.Write(buffer,0,n);}raw=o.ToArray();
   }if(Hash(raw)!=envelope.Substring(0,split))throw new InvalidDataException("Mod save checksum mismatch");
   var packed=Object(new UTF8Encoding(false,true).GetString(raw));Validate(packed);k.RemoveAt(index);v.RemoveAt(index);d["stringKeys"]=Join(k);d["strings"]=Join(v);
   for(int i=0;i<Keys.Length;i++){var dk=Array(d[Keys[i]]);var dv=Array(d[Values[i]]);var pk=Array(packed[Keys[i]]);var pv=Array(packed[Values[i]]);var names=new HashSet<string>();foreach(var entry in dk)names.Add(Text(entry));
    for(int j=0;j<pk.Count;j++){string name=Text(pk[j]);if(name==Key||!name.StartsWith("SignalisVR",StringComparison.Ordinal)||!names.Add(name))throw new InvalidDataException("Invalid/duplicate packed mod key");dk.Add(pk[j]);dv.Add(pv[j]);}d[Keys[i]]=Join(dk);d[Values[i]]=Join(dv);
   }return Json(d);
  }
  public static void CheckCapacity(string json,int width,int height){long bits=(long)Encoding.UTF8.GetByteCount(json)*8;long capacity=((long)width*height-32)*3;if(width<=0||height<=0||bits>capacity)throw new InvalidDataException("Save exceeds image capacity; previous file preserved");}
  public static string BackupPath(string path){return Path.ChangeExtension(path,"vr-backup");}
  public static void Commit(string path,byte[] bytes){
   // Native scanning searches for .png anywhere in a filename. New artifacts
   // must never contain that extension; old artifacts are separately filtered.
   if(bytes==null||bytes.Length==0)throw new InvalidDataException("Empty save rejected");string temp=Path.ChangeExtension(path,"vr-writing-"+Guid.NewGuid().ToString("N"));
   try{using(var f=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){f.Write(bytes,0,bytes.Length);f.Flush(true);}var written=File.ReadAllBytes(temp);if(written.Length!=bytes.Length||Hash(written)!=Hash(bytes))throw new InvalidDataException("Temporary save verification failed; previous file preserved");if(File.Exists(path))File.Replace(temp,path,BackupPath(path));else File.Move(temp,path);}
   finally{if(File.Exists(temp))File.Delete(temp);}
  }
 }
}
