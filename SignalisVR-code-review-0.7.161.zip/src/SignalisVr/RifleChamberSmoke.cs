using System;
using UnityEngine;
namespace SignalisVrTracking {
 public static class RifleSmokeTiming {
  public static float Age(int mask,int chamber,float elapsed,int particle){if((mask&(1<<chamber))==0||elapsed<.025f||elapsed>=2f)return -1;float age=(elapsed-.025f+particle*.075f)%.525f;return age;}
 }
 public sealed partial class Tracking {
  private readonly MeshRenderer[] rifleSmoke=new MeshRenderer[14];
  private Mesh rifleSmokeMesh;private Material rifleSmokeMaterial;private Texture2D rifleSmokeTexture;
  private MaterialPropertyBlock rifleSmokeColors;private int rifleSmokeMask;private bool rifleSmokeFailed;
  private void EnsureRifleSmoke(){
   if(rifleSmokeMesh!=null)return;
   var shader=Shader.Find("Sprites/Default");if(shader==null)throw new InvalidOperationException("Rifle smoke shader missing");
   rifleSmokeTexture=HdFxTexture("fx-smoke.png");
   rifleSmokeMaterial=new Material(shader);rifleSmokeMaterial.mainTexture=rifleSmokeTexture;rifleSmokeColors=new MaterialPropertyBlock();
   rifleSmokeMesh=new Mesh();rifleSmokeMesh.vertices=new[]{new Vector3(-.5f,-.5f,0),new Vector3(.5f,-.5f,0),new Vector3(.5f,.5f,0),new Vector3(-.5f,.5f,0)};rifleSmokeMesh.uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(1,1),new Vector2(0,1)};rifleSmokeMesh.colors=new[]{Color.white,Color.white,Color.white,Color.white};rifleSmokeMesh.triangles=new[]{0,1,2,0,2,3};rifleSmokeMesh.RecalculateBounds();
   for(int i=0;i<14;i++){var go=new GameObject("RifleChamberSmoke_"+i);go.layer=30;UnityEngine.Object.DontDestroyOnLoad(go);go.AddComponent<MeshFilter>().sharedMesh=rifleSmokeMesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=rifleSmokeMaterial;r.enabled=false;r.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;r.receiveShadows=false;rifleSmoke[i]=r;}
  }
  private void ShowRifleSmoke(float elapsed){
   if(rifleSmokeFailed||rifleSmokeMask==0||elapsed<0||elapsed>=2f||!SelectedActive("Rifle")||additionalOpen<.65f)return;
   try{EnsureRifleSmoke();for(int c=0;c<2;c++)for(int j=0;j<7;j++){
    float age=RifleSmokeTiming.Age(rifleSmokeMask,c,elapsed,j);var r=rifleSmoke[c*7+j];if(age<0)continue;
    // Origin follows the chamber opening, never the ejected case.
    r.transform.position=rifleChamberWorld[c]+additionalLoadDirection*(-.002f-.10f*age)*UnitsPerMetre+controllerTrackingToWorld*new Vector3(Mathf.Sin(j*2.4f)*.006f*age,.035f*age,0)*UnitsPerMetre;
    r.transform.rotation=stereoRotation*Quaternion.AngleAxis(j*52+age*17,Vector3.forward);r.transform.localScale=Vector3.one*((.005f+.018f*age)*UnitsPerMetre);
    float alpha=.24f*Math.Min(1,elapsed/.1f)*Math.Min(1,(2f-elapsed)/.4f)*(1-age/.525f);rifleSmokeColors.SetColor("_Color",new Color(1,1,1,alpha));r.SetPropertyBlock(rifleSmokeColors);r.enabled=true;
   }}catch(Exception ex){rifleSmokeFailed=true;HideRifleSmoke();MelonLoader.MelonLogger.Warning("Rifle smoke unavailable: "+ex.Message);}
  }
  private void HideRifleSmoke(){foreach(var r in rifleSmoke)if(r!=null)r.enabled=false;}
  private void DestroyRifleSmoke(){for(int i=0;i<14;i++){if(rifleSmoke[i]!=null)UnityEngine.Object.Destroy(rifleSmoke[i].gameObject);rifleSmoke[i]=null;}if(rifleSmokeMesh!=null)UnityEngine.Object.Destroy(rifleSmokeMesh);if(rifleSmokeMaterial!=null)UnityEngine.Object.Destroy(rifleSmokeMaterial);if(rifleSmokeTexture!=null)UnityEngine.Object.Destroy(rifleSmokeTexture);rifleSmokeMesh=null;rifleSmokeMaterial=null;rifleSmokeTexture=null;rifleSmokeMask=0;}
 }
}


