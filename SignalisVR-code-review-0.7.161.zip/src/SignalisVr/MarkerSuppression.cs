﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SignalisVrTracking
{
    // Camera-wide rendering veto: never change an interaction component, collider,
    // active state, Renderer.enabled, sprite, transform, or shared material.
    internal static class MarkerSuppression
    {
        private static readonly List<Renderer> targets = new List<Renderer>();
        private static readonly HashSet<int> targetIds = new HashSet<int>();
        private static int scannedFrame = -1;
        private static readonly List<global::DoorInteractionPopup> doors = new List<global::DoorInteractionPopup>();
        private static readonly List<global::Ladder> ladders = new List<global::Ladder>();
        private static readonly HashSet<int> doorIds = new HashSet<int>(), ladderIds = new HashSet<int>();
        private static bool registryEnabled;
        private static float nextRegistryScan;
        private static System.Collections.IEnumerator dropArtworkScan;
        private static bool artworkDirty;
        private static readonly HashSet<int> popupIds = new HashSet<int>();
        internal static void RegisterPopup(global::interactionPopup popup) {
            if(popup==null)return;
            // Only prompt sprites, never the physical pickup or its parent renderer.
            AddPrompt(popup.SR);AddDropArtwork(popup.SR);
            if(popupIds.Add(popup.GetInstanceID())) {
                foreach(var sprite in popup.GetComponentsInChildren<SpriteRenderer>(true)) AddPrompt(sprite);
                foreach(var label in popup.GetComponentsInChildren<TMPro.TextMeshPro>(true))
                    if(label!=null)Add(label.GetComponent<Renderer>());
            }
        }
        // Native hole/drop-down icon and caption (confirmed from level17's hole ladder).
        // Copies can live outside the Ladder Icon hierarchy; suppress artwork only.
        private static void AddDropArtwork(SpriteRenderer sprite) {
            if(sprite!=null&&sprite.sprite!=null&&(sprite.sprite.name=="Door_interactions_22"||sprite.sprite.name=="Door_interactions_23"))Add(sprite);
        }
        private static void AddPrompt(SpriteRenderer sprite) {
            if(sprite!=null && sprite.sprite!=null &&
                (sprite.sprite.name=="interaction" || sprite.sprite.name=="interactionScaleable" || sprite.sprite.name=="Interaction_inspect")) Add(sprite);
        }
        internal static void RefreshArtwork() {artworkDirty=true;scannedFrame=-1;}
        private static float nextWarning;
        private static Camera.CameraCallback preCull;
        internal static Action<int,long> TimingObserver=null;
        internal static void EnableRegistry(bool enabled) { registryEnabled=enabled; Reset(); }
        internal static void RegisterDoor(global::DoorInteractionPopup door) {
            if(door!=null) {Add(door.block);Add(door.bar);if(doorIds.Add(door.GetInstanceID())) {doors.Add(door);RefreshArtwork();}}
        }
        internal static void RegisterLadder(global::Ladder ladder) {
            if(ladder!=null) {Add(ladder.block);Add(ladder.bar);if(ladderIds.Add(ladder.GetInstanceID())) {ladders.Add(ladder);RefreshArtwork();}}
        }

        internal static void Install()
        {
            if (preCull != null) return;
            preCull = (Action<Camera>)BeforeCamera;
            Camera.onPreCull += preCull;
        }

        internal static void Reset()
        {
            scannedFrame = -1;
            if(dropArtworkScan is IDisposable)((IDisposable)dropArtworkScan).Dispose();dropArtworkScan=null;
            targets.Clear();
            targetIds.Clear();
            popupIds.Clear();artworkDirty=true;
            doors.Clear(); ladders.Clear(); doorIds.Clear(); ladderIds.Clear(); nextRegistryScan=0f;
        }

        private static void BeforeCamera(Camera unused) { Apply(); }

        internal static void Apply()
        {
            long started=System.Diagnostics.Stopwatch.GetTimestamp();
            try
            {
                // Lifecycle hooks discover new active controllers; a full scan includes
                // inactive objects and refreshes/prunes the registry every five seconds.
                // If hooks were unavailable, retain the original per-frame discovery.
                // Traverse travel artwork only on registration/activation or fallback refresh.
                // Enforce the cached render veto independently before EVERY camera/eye.
                if (scannedFrame != Time.frameCount)
                {
                    long discoveryStarted=System.Diagnostics.Stopwatch.GetTimestamp();
                    if(!registryEnabled || (dropArtworkScan==null&&Time.realtimeSinceStartup >= nextRegistryScan)) {
                        targets.Clear();targetIds.Clear();popupIds.Clear();artworkDirty=true;
                        var foundDoors = Resources.FindObjectsOfTypeAll<global::DoorInteractionPopup>();
                        var foundLadders = Resources.FindObjectsOfTypeAll<global::Ladder>();
                        var foundPopups = Resources.FindObjectsOfTypeAll<global::interactionPopup>();
                        for(int i=0;i<foundPopups.Length;i++)RegisterPopup(foundPopups[i]);
                        if(!registryEnabled)foreach(var sprite in Resources.FindObjectsOfTypeAll<SpriteRenderer>())AddDropArtwork(sprite);
                        else dropArtworkScan=Resources.FindObjectsOfTypeAll<SpriteRenderer>().GetEnumerator();
                        doors.Clear(); ladders.Clear(); doorIds.Clear(); ladderIds.Clear();
                        for(int i=0;i<foundDoors.Length;i++)RegisterDoor(foundDoors[i]);
                        for(int i=0;i<foundLadders.Length;i++)RegisterLadder(foundLadders[i]);
                        nextRegistryScan=Time.realtimeSinceStartup+5f;
                        if(TimingObserver!=null)TimingObserver(28,discoveryStarted);
                    }
                    // Lifecycle hooks still veto new prompts immediately. Only
                    // the fallback search for detached drop artwork is batched.
                    var dropBudget=System.Diagnostics.Stopwatch.StartNew();int dropCount=0;
                    while(dropArtworkScan!=null&&dropCount<32&&dropBudget.Elapsed.TotalMilliseconds<2){
                        if(!dropArtworkScan.MoveNext()){if(dropArtworkScan is IDisposable)((IDisposable)dropArtworkScan).Dispose();dropArtworkScan=null;break;}
                        AddDropArtwork(dropArtworkScan.Current as SpriteRenderer);dropCount++;
                    }
                    long hierarchyStarted=System.Diagnostics.Stopwatch.GetTimestamp();
                    if(artworkDirty) {
                    for (int i = 0; i < doors.Count; i++)
                    {
                        var door = doors[i];
                        if (door == null) continue;
                        Add(door.block);
                        Add(door.bar);
                        // This is the popup hierarchy, NOT door.door or door geometry.
                        AddArtwork(door.transform);
                    }
                    for (int i = 0; i < ladders.Count; i++)
                    {
                        var ladder = ladders[i];
                        if (ladder == null) continue;
                        // Game-owned icon/label references also cover renamed roots.
                        Add(ladder.block);
                        Add(ladder.bar);
                        var children = ladder.GetComponentsInChildren<Transform>(true);
                        for (int j = 0; j < children.Length; j++)
                            if (children[j] != null && children[j].name == "Ladder Icon")
                                AddArtwork(children[j]);
                    }
                    artworkDirty=false;
                    }
                    scannedFrame = Time.frameCount;
                    if(TimingObserver!=null)TimingObserver(36,hierarchyStarted);
                    if(TimingObserver!=null)TimingObserver(26,discoveryStarted);
                }
                for (int i = 0; i < targets.Count; i++)
                    if (targets[i] != null) targets[i].forceRenderingOff = true;
            }
            catch (Exception ex)
            {
                if (Time.realtimeSinceStartup >= nextWarning)
                {
                    nextWarning = Time.realtimeSinceStartup + 10f;
                    MelonLoader.MelonLogger.Warning("Door/ladder artwork suppression failed: " + ex.Message);
                }
            }
            finally {if(TimingObserver!=null)TimingObserver(25,started);}
        }

        private static void AddArtwork(Transform root)
        {
            var artwork = root.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < artwork.Length; i++) Add(artwork[i]);
        }

        private static void Add(Renderer renderer)
        {
            if (renderer != null && targetIds.Add(renderer.GetInstanceID())) targets.Add(renderer);
        }
    }
}
