using System;
using UnityEngine;
using UnhollowerBaseLib;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly PhysicalShovePolicy[] shovePolicy={new PhysicalShovePolicy(),new PhysicalShovePolicy()};
  private readonly Vector3[] shoveRaw=new Vector3[2],shoveResolved=new Vector3[2],shoveDesired=new Vector3[2],shoveNormal=new Vector3[2];
  private readonly bool[] shoveSampled=new bool[2];
  private readonly float[] shoveTime=new float[2];
  private Il2CppStructArray<RaycastHit> shoveHits;
  private Il2CppReferenceArray<Collider> shoveOverlaps;
  private SphereCollider shoveProbe;
  private readonly global::EnemyController[] shoveQueued=new global::EnemyController[2],shovePushOwners=new global::EnemyController[16];
  private readonly Vector3[] shoveQueuedPoint=new Vector3[2];
  private readonly global::EnemyController[] shoveTouch=new global::EnemyController[2],shoveRecent=new global::EnemyController[2];
  private readonly bool[] shoveForward=new bool[2];private readonly float[] shoveRecentTime=new float[2];
  private global::Room shoveRoom;
  private readonly float[] shoveQueuedTime=new float[2],shoveCooldown=new float[2],shovePushUntil=new float[16];private int shovePushSlot;
  private int shoveFrame=-1,shoveReports;
  private bool shoveFailed;
  private bool PhysicalShoveGun(){var w=global::InventoryManager.EquippedWeapon;return w!=null&&w.parentItem!=null&&QuickFirearm(WeaponFamily(w.parentItem._item.ToString()));}
  private bool PhysicalShoveHand(int hand){
   if(hand==1&&PhysicalShoveGun())return true;
   if(hand==0)return manualLeftGrip&&manualReload.Stage!=ManualReloadPolicy.Step.RackHolding&&!smgHandleStroke.Held&&!revolverRod.Held&&!heldReceiver&&!hdSupportHeld&&!rifleBarrelHeld&&!shotgunPumpHeld&&(manualMagazine==null||!manualMagazine.enabled)&&!AdditionalHoldingAmmo()&&(shotgunShell==null||!shotgunShell.enabled);
   return modMenuRightGrip&&global::InventoryManager.EquippedWeapon==null&&heldQuickHealth==null&&!heldEidetic&&!ProdEligible()&&!ThermiteEligible();
  }
  private bool HandContactOccupied(int hand){
   if(hand==1)return global::InventoryManager.EquippedWeapon!=null||heldQuickHealth!=null||heldEidetic||ProdEligible()||ThermiteEligible();
   return heldReceiver||hdSupportHeld||rifleBarrelHeld||shotgunPumpHeld||manualReload.Stage==ManualReloadPolicy.Step.RackHolding||smgHandleStroke.Held||revolverRod.Held||(manualMagazine!=null&&manualMagazine.enabled)||AdditionalHoldingAmmo()||(shotgunShell!=null&&shotgunShell.enabled);
  }
  private bool PhysicalShoveReady(){return !stopping&&!shoveFailed&&ProdVrMode()&&controllerMotionEnabled&&questAvailabilityValue&&WeaponGameplayReady()
   &&!RadioStationActive()&&!questMenuScene&&!modMenuOpen&&!pauseMenuVisible&&!quickSelect.Open&&!bookScreenVisible&&!dialogueScreenVisible
   &&!global::PlayerState.paused&&!global::PlayerState.cutscene&&!global::PlayerState.eventScreen&&!global::PlayerState.suspendInput
   &&!global::PlayerState.grappled&&!global::PlayerState.hurt&&!global::PlayerState.reloading&&global::PlayerState.hp>0;}
  private void ResetPhysicalShove(){gunContactSampled=false;gunContactFrame=-1;gunContactOffset=Vector3.zero;gunShoveSampled=false;foreach(var p in gunShovePolicy)p.Reset();shoveFrame=-1;shoveRoom=null;for(int h=0;h<2;h++){shoveQueued[h]=null;shoveTouch[h]=shoveRecent[h]=null;shoveForward[h]=false;shoveSampled[h]=false;shoveNormal[h]=Vector3.zero;shovePolicy[h].Reset();}}
  private void DestroyPhysicalShove(){ResetPhysicalShove();if(shoveProbe!=null)UnityEngine.Object.Destroy(shoveProbe.gameObject);shoveProbe=null;shoveHits=null;shoveOverlaps=null;shoveFailed=false;Array.Clear(shovePushOwners,0,16);Array.Clear(shovePushUntil,0,16);}
  private global::EnemyController ShoveBody(Collider c){
   if(c==null||!c.enabled||c==shoveProbe)return null;
   var e=c.GetComponentInParent<global::EnemyController>();
   return ProdEnemyValid(e)&&e.isActiveAndEnabled&&c==e._collider?e:null;
  }
  private bool ShoveObstacle(Collider c,out global::EnemyController enemy){
   enemy=ShoveBody(c);if(enemy!=null)return true;
   if(c!=null&&c.enabled&&c!=shoveProbe){var owner=c.GetComponentInParent<global::EnemyController>();if(owner!=null&&owner.isActiveAndEnabled)return true;}
   if(c==null||!c.enabled||c.isTrigger||c==shoveProbe)return false;
   if(global::PlayerState.player!=null&&c.transform.IsChildOf(global::PlayerState.player.transform))return false;
   return global::PlayerAttack.instance!=null&&((1<<c.gameObject.layer)&global::PlayerAttack.instance.WallMask.value)!=0;
  }
  // Read-only physics queries, once per prepared frame, after weapon placement, before final hand poses.
  // No dynamic hand rigidbodies: physical contact cannot invoke native hurtboxes.
  private void PreparePhysicalShove(){
   if(!PhysicalContactReady()){ResetPhysicalShove();return;}
   if(shoveRoom!=global::PlayerState.currentRoom){ResetPhysicalShove();shoveRoom=global::PlayerState.currentRoom;}
   if(shoveFrame==Time.frameCount){for(int h=0;h<2;h++)if((h!=1||!PhysicalShoveGun())&&shoveSampled[h]&&controllerMarkers[h]!=null&&(controllerVisibility&(1<<h))!=0)controllerMarkers[h].transform.position=shoveResolved[h];return;}
   shoveFrame=Time.frameCount;
   try{
    EnsureContactProbe();
    float now=Time.realtimeSinceStartup,radius=.075f*UnitsPerMetre;shoveProbe.radius=radius;
    for(int h=0;h<2;h++){
     if((controllerVisibility&(1<<h))==0||controllerMarkers[h]==null||HandContactOccupied(h)){shoveTouch[h]=shoveRecent[h]=null;shoveSampled[h]=false;shoveNormal[h]=Vector3.zero;shovePolicy[h].Reset();continue;}
     var t=controllerMarkers[h].transform;var desired=t.position;var raw=rawControllerPositions[h]-trackedHeadPosition;
     float dt=now-shoveTime[h];var motion=raw-shoveRaw[h];
     bool continuous=shoveSampled[h]&&dt>0&&dt<=.1f&&(desired-shoveDesired[h]).magnitude<.5f*UnitsPerMetre&&motion.magnitude<=.35f;
     var start=continuous?shoveResolved[h]:desired;var position=desired;var delta=desired-start;
     global::EnemyController touched=null;Vector3 normal=Vector3.zero;
     if(continuous&&delta.sqrMagnitude>1e-10f){
      int n=Physics.SphereCastNonAlloc(start,radius,delta.normalized,shoveHits,delta.magnitude,-1,QueryTriggerInteraction.Collide);float closest=delta.magnitude;
      if(n==32){position=start;continuous=false;}else{
       for(int i=0;i<n;i++){var hit=shoveHits[i];global::EnemyController e;if(!ShoveObstacle(hit.collider,out e)||hit.distance>closest)continue;closest=hit.distance;normal=hit.normal;touched=e;}
       if(normal.sqrMagnitude>.1f)position=start+delta.normalized*Math.Max(0,closest-.002f*UnitsPerMetre);
      }
     }
     for(int pass=0;pass<2;pass++){
      int n=Physics.OverlapSphereNonAlloc(position,radius,shoveOverlaps,-1,QueryTriggerInteraction.Collide);
      if(n==32){position=start;continuous=false;break;}
      bool moved=false;
      for(int i=0;i<n;i++){var c=shoveOverlaps[i];global::EnemyController e;if(!ShoveObstacle(c,out e))continue;Vector3 direction;float depth;
       if(Physics.ComputePenetration(shoveProbe,position,Quaternion.identity,c,c.transform.position,c.transform.rotation,out direction,out depth)){
        position+=direction*(depth+.002f*UnitsPerMetre);normal=direction;touched=e;moved=true;
       }
      }
      if(!moved)break;
     }
     if(h!=1||!PhysicalShoveGun())t.position=position;shoveResolved[h]=position;shoveDesired[h]=desired;shoveNormal[h]=normal;
     // Controller motion relative to the head excludes stick locomotion and
     // common head/hand translation. Tracking jumps never authorize a shove.
     var velocity=continuous?controllerTrackingToWorld*(motion/dt):Vector3.zero;
     shoveTouch[h]=touched;
     if(!continuous)shovePolicy[h].Reset();
     else if(PhysicalShoveReady()&&PhysicalShoveHand(h)&&shovePolicy[h].Step(dt,motion.magnitude,Vector3.Dot(velocity,-normal),touched!=null)&&now>=shoveCooldown[h]&&shoveQueued[h]==null){shoveQueued[h]=touched;shoveQueuedTime[h]=now;shoveQueuedPoint[h]=position;shoveForward[h]=Vector3.Dot(velocity.normalized,stereoRotation*Vector3.forward)>.4f;}
     shoveRaw[h]=raw;shoveTime[h]=now;shoveSampled[h]=true;
    }
    if(PhysicalShoveReady())PrepareGunShove(now);
   }catch(Exception ex){ResetPhysicalShove();shoveFailed=true;MelonLogger.Warning("Physical shove disabled; tracked-hand fallback: "+ex.Message);}
  }
  // Saved item grips can offset the palm after controller collision. Keep the
  // final rendered palm on the outside of the same contact plane as well.
  private Vector3 ConstrainShovePalm(int hand,Vector3 palm){
   if(hand==1&&PhysicalShoveGun())return palm;
   if(shoveFrame!=Time.frameCount||shoveNormal[hand].sqrMagnitude<.1f)return palm;
   float d=Vector3.Dot(palm-shoveResolved[hand],shoveNormal[hand]);return d<0?palm-shoveNormal[hand]*d:palm;
  }
  private bool RecentPhysicalPush(global::EnemyController e){for(int i=0;i<16;i++){if(shovePushUntil[i]<=Time.realtimeSinceStartup)shovePushOwners[i]=null;else if(shovePushOwners[i]==e)return true;}return false;}
  private void ApplyPhysicalStrikeDamage(global::EnemyController e){
   var settings=global::PlayerState.settings;int bonus=settings==null?0:settings.SneakAttackBonusDamage;
   try{
    // Native idle-enemy hits add a separate sneak bonus; physical hits stay 4.
    if(settings!=null)settings.SneakAttackBonusDamage=0;
    e.hitbox.HP=Math.Max(0,e.hitbox.HP-4);
    // Request native Hurt (or resistant-enemy Stagger) and native impact squib.
    // Native death remains authoritative; never restart a dead enemy's pose.
    e.TakeDamage(0f,0f,1f,true);
   }finally{if(settings!=null)settings.SneakAttackBonusDamage=bonus;}
  }
  private void PollPhysicalShove(){
   if(!PhysicalShoveReady()){ResetPhysicalShove();return;}
   for(int h=0;h<2;h++){var e=shoveQueued[h];shoveQueued[h]=null;if(e==null)continue;
   try{
    if(!PhysicalShoveHand(h)||Time.realtimeSinceStartup-shoveQueuedTime[h]>.15f||shoveRoom!=global::PlayerState.currentRoom||Time.realtimeSinceStartup<shoveCooldown[h]
     ||!ProdEnemyValid(e)||!e.isActiveAndEnabled||(e.busy&&!e.isPushed&&e.staggerType!=global::EnemyController.hurtState.hurt)||e.queuedForRespawn||e.permadeath||e.playerPos==null||ProdIsFrozen(e)
     ||(e.staggerType==global::EnemyController.hurtState.critical||e.staggerType==global::EnemyController.hurtState.fire)||(e.customSleep&&!e.woken))continue;
    if(e._collider==null||(e._collider.ClosestPoint(shoveQueuedPoint[h])-shoveQueuedPoint[h]).magnitude>.18f*UnitsPerMetre)continue;
    if(global::PlayerAttack.instance==null||Physics.Linecast(stereoPosition,e._collider.ClosestPoint(stereoPosition),global::PlayerAttack.instance.WallMask.value,QueryTriggerInteraction.Ignore))continue;
    // Native TakeDamage callers subtract HP first. Retain native death/burn
    // handling; a lethal punch must not start a get-up/knockback coroutine.
    ApplyPhysicalStrikeDamage(e);
    if(ProdEnemyValid(e)&&HeadshotPushEnemy(e)&&!RecentPhysicalPush(e)){AddPhysicalShoveDistance(e);if(!e.isPushed)e.GetPushed();shovePushOwners[shovePushSlot]=e;shovePushUntil[shovePushSlot]=Time.realtimeSinceStartup+.12f;shovePushSlot=(shovePushSlot+1)%16;}
    shoveCooldown[h]=Time.realtimeSinceStartup+.12f;
    if(shoveReports++<24)MelonLogger.Msg("PHYSICAL STRIKE: fist/gun contact, native non-boss shove; up to 12cm extra safe travel.");
   }catch(Exception ex){shoveFailed=true;ResetPhysicalShove();MelonLogger.Warning("Physical shove unavailable: "+ex.Message);} }
  }
  private readonly PhysicalShovePolicy[] gunShovePolicy={new PhysicalShovePolicy(),new PhysicalShovePolicy(),new PhysicalShovePolicy()};
  private readonly Vector3[] gunShovePrevious=new Vector3[3];private float gunShoveTime;private bool gunShoveSampled;
  private void PrepareGunShove(float now){
   Vector3 muzzle;if(!PhysicalShoveGun()||rightWeaponFrame!=Time.frameCount||(controllerVisibility&2)==0||!ImportedMuzzle(out muzzle)){gunShoveSampled=false;foreach(var p in gunShovePolicy)p.Reset();return;}
   float dt=now-gunShoveTime;bool sample=gunShoveSampled&&dt>0&&dt<=.1f;
   for(int i=0;i<3;i++){
    var origin=gunContactFrame==Time.frameCount?gunContactRawPosition:rightWeaponPosition;
    var point=origin+rightWeaponRotation*(muzzle*(i*.5f))*UnitsPerMetre;
    var tracking=Quaternion.Inverse(controllerTrackingToWorld)*(point-stereoPosition)/UnitsPerMetre;
    var motion=tracking-gunShovePrevious[i];bool continuous=sample&&motion.magnitude<=.35f;
    var start=continuous?stereoPosition+controllerTrackingToWorld*gunShovePrevious[i]*UnitsPerMetre:point;
    var delta=point-start;global::EnemyController touched=null;var normal=Vector3.zero;var contactPoint=point;
    if(continuous&&delta.sqrMagnitude>1e-10f){int n=Physics.SphereCastNonAlloc(start,.045f*UnitsPerMetre,delta.normalized,shoveHits,delta.magnitude,-1,QueryTriggerInteraction.Collide);float closest=delta.magnitude;
     if(n==32)continuous=false;else for(int k=0;k<n;k++){var hit=shoveHits[k];global::EnemyController e;if(!ShoveObstacle(hit.collider,out e)||hit.distance>closest)continue;closest=hit.distance;normal=hit.normal;contactPoint=hit.point;touched=e;}
    }
    if(!continuous)gunShovePolicy[i].Reset();
    else if(gunShovePolicy[i].Step(dt,motion.magnitude,Vector3.Dot(controllerTrackingToWorld*(motion/dt),-normal),touched!=null)&&shoveQueued[1]==null&&now>=shoveCooldown[1]){shoveQueued[1]=touched;shoveQueuedPoint[1]=contactPoint;shoveQueuedTime[1]=now;shoveForward[1]=false;}
    gunShovePrevious[i]=tracking;
   }gunShoveTime=now;gunShoveSampled=true;
  }
  private void AddPhysicalShoveDistance(global::EnemyController e){
   if(e.agent==null||!e.agent.enabled||e._collider==null||global::AstarPath.active==null)return;
   var direction=e.transform.position-stereoPosition;direction.y=0;if(direction.sqrMagnitude<.00001f)return;direction.Normalize();
   float distance=.12f*UnitsPerMetre;var centre=e._collider.bounds.center;var ext=e._collider.bounds.extents;
   int n=Physics.SphereCastNonAlloc(centre,Math.Max(.025f,Math.Min(ext.x,ext.z)),direction,shoveHits,distance,global::PlayerAttack.instance.WallMask.value,QueryTriggerInteraction.Ignore);
   if(n==32)return;for(int i=0;i<n;i++)distance=Math.Min(distance,Math.Max(0,shoveHits[i].distance-.01f*UnitsPerMetre));
   if(distance<=0)return;var target=e.transform.position+direction*distance;
   var current=global::AstarPath.active.GetNearest(e.transform.position);var next=global::AstarPath.active.GetNearest(target);
   if(current.node==null||next.node==null||!next.node.Walkable||current.node.Area!=next.node.Area)return;
   RaycastHit floor;var feet=e._collider.bounds.min;
   if(!Physics.Raycast(new Vector3(target.x,feet.y+.1f*UnitsPerMetre,target.z),Vector3.down,out floor,.2f*UnitsPerMetre,global::PlayerAttack.instance.WallMask.value,QueryTriggerInteraction.Ignore))return;
   if(Math.Abs(floor.point.y-feet.y)>.05f*UnitsPerMetre)return;
   e.agent.Move(direction*distance);
  }
 }
}



