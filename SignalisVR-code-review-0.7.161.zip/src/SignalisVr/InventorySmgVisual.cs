using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using HarmonyLib;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private static readonly List<Mesh> inventorySmgMeshes=new List<Mesh>();
 private static readonly List<Material> inventorySmgMaterials=new List<Material>();
 private static readonly List<int> inventorySmgSlots=new List<int>();
 private static bool inventorySmgFailed;
 private static Sprite inventorySmgIcon,inventorySmgOldIcon,inventorySmgOldImage;
 private static bool inventorySmgIconFailed;
 private sealed class InventorySmgView {internal global::InventoryBase Owner;internal Transform Parent;internal GameObject Root;internal Renderer[] Originals;internal bool[] Enabled;}
 private static readonly List<InventorySmgView> inventorySmgViews=new List<InventorySmgView>();
 private static readonly Dictionary<int,float> inventorySmgImageChecks=new Dictionary<int,float>();
 private void InstallInventorySmg(){
  var h=new HarmonyLib.Harmony("signalis.vr.inventory.smg");
  h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"Update",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(ReplaceInventorySmg)));
  foreach(var method in new[]{"updateItems","initializeBox"})h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),method,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(ApplyInventorySmgIcon)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::ItemPickup),"ShowImage"),prefix:new HarmonyMethod(typeof(Tracking),nameof(SmgPickupPreviewBegin)));
 }
 private static void SmgPickupPreviewBegin(global::ItemPickup __instance){if(__instance!=null&&__instance._item!=null&&__instance._item._item==global::Items.itemlist.SMG){ApplyInventorySmgIcon(null);BindSmgCatalogueModel(__instance._item);}}
 private static void EnsureInventorySmgAssets(){
   if(inventorySmgMeshes.Count==0){
    var shader=Shader.Find("Unlit/Texture");if(shader==null)throw new InvalidOperationException("Inventory texture shader missing");
    foreach(var encoded in XiphiasData.Textures){var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(encoded),true))throw new InvalidOperationException("SMG texture decode failed");tex.filterMode=FilterMode.Point;inventorySmgMaterials.Add(new Material(shader){mainTexture=tex});}
    using(var reader=new BinaryReader(new MemoryStream(Convert.FromBase64String(XiphiasData.Geometry)))){
     int count=reader.ReadInt32();for(int part=0;part<count;part++){reader.ReadInt32();int material=reader.ReadInt32(),nv=reader.ReadInt32(),nt=reader.ReadInt32();var v=new Vector3[nv];var uv=new Vector2[nv];var tri=new int[nt];for(int i=0;i<nv;i++)v[i]=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle());for(int i=0;i<nv;i++)uv[i]=new Vector2(reader.ReadSingle(),reader.ReadSingle());for(int i=0;i<nt;i++)tri[i]=reader.ReadInt32();var mesh=new Mesh{vertices=v,uv=uv,triangles=HandSurfaceTopology.DoubleSided(tri)};mesh.RecalculateBounds();inventorySmgMeshes.Add(mesh);inventorySmgSlots.Add(material);}
    }
   }
 }
 private static void ApplyInventorySmgIcon(global::InventoryBase __instance){
  if(inventorySmgIconFailed)return;
  try{
   var catalog=global::InventoryManager.allItems;if(catalog==null||!catalog.ContainsKey(global::Items.itemlist.SMG))return;
   var item=catalog[global::Items.itemlist.SMG];if(item==null)return;
   if(inventorySmgIcon==null){
    var texture=new Texture2D(2,2,TextureFormat.RGBA32,false);
    if(!ImageConversion.LoadImage(texture,Convert.FromBase64String(HdAsset.Read("smg-inventory-icon.png")),true))throw new InvalidOperationException("SMG icon decode failed");
    texture.filterMode=FilterMode.Point;texture.wrapMode=TextureWrapMode.Clamp;
    inventorySmgIcon=Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f),100);
    inventorySmgOldIcon=item.Icon;inventorySmgOldImage=item.Image;
   }
   if(item.Icon!=inventorySmgIcon)inventorySmgOldIcon=item.Icon;
   if(item.Image!=inventorySmgIcon)inventorySmgOldImage=item.Image;
   item.Icon=inventorySmgIcon;item.Image=inventorySmgIcon;
   BindSmgCatalogueModel(item);
   float next;bool scan=__instance!=null&&(!inventorySmgImageChecks.TryGetValue(__instance.GetInstanceID(),out next)||Time.realtimeSinceStartup>=next);
   if(scan){if(inventorySmgImageChecks.Count>32)inventorySmgImageChecks.Clear();inventorySmgImageChecks[__instance.GetInstanceID()]=Time.realtimeSinceStartup+.25f;}
   if(scan)foreach(var image in __instance.GetComponentsInChildren<UnityEngine.UI.Image>(true).ToArray()){
    var sprite=image.sprite;
    if(sprite!=null&&((inventorySmgOldIcon!=null&&sprite==inventorySmgOldIcon)||(inventorySmgOldImage!=null&&sprite==inventorySmgOldImage)))image.sprite=inventorySmgIcon;
   }
  }catch(Exception ex){inventorySmgIconFailed=true;MelonLoader.MelonLogger.Warning("Inventory SMG icon retained original: "+ex.Message);}
 }
 private static Transform InventorySmgBoundsFrame(Renderer renderer){var skin=renderer.TryCast<SkinnedMeshRenderer>();return skin!=null&&skin.rootBone!=null?skin.rootBone:renderer.transform;}
 private static bool InventorySmgLocalBounds(Renderer renderer,out Bounds bounds){
  // Native inventory SMG is SMG_Mesh, a SkinnedMeshRenderer with no MeshFilter.
  var skin=renderer.TryCast<SkinnedMeshRenderer>();
  if(skin!=null&&skin.sharedMesh!=null){bounds=skin.localBounds;return true;}
  var filter=renderer.GetComponent<MeshFilter>();
  if(filter!=null&&filter.sharedMesh!=null){bounds=filter.sharedMesh.bounds;return true;}
  bounds=new Bounds();return false;
 }
 private static void ReplaceInventorySmg(global::InventoryBase __instance){
  for(int i=inventorySmgViews.Count-1;i>=0;i--){
   var view=inventorySmgViews[i];
   if(view.Owner==null||view.Parent==null||view.Root==null||
    (view.Owner==__instance&&(view.Parent!=__instance.InspectObj||__instance.lastItem==null||__instance.lastItem._item!=global::Items.itemlist.SMG))){
    for(int j=0;j<view.Originals.Length;j++)if(view.Originals[j]!=null)view.Originals[j].enabled=view.Enabled[j];
    if(view.Root!=null){view.Root.SetActive(false);UnityEngine.Object.Destroy(view.Root);}
    inventorySmgViews.RemoveAt(i);
   }
  }
  // Enhanced Resolution keeps a copied inventory active during gameplay.
  // Its Update still runs while closed; do not traverse every UI image then.
  // updateItems/initializeBox retain their independent catalog refresh hooks.
  if(__instance==null||(!__instance.inventoryOpen&&!(global::PlayerState.gameState==global::PlayerState.gameStates.inventory&&__instance.InventoryCanvas!=null&&__instance.InventoryCanvas.activeInHierarchy)))return;
  ApplyInventorySmgIcon(__instance);
  if(__instance!=null&&__instance.itemDescription!=null){
   var selected=__instance.lastItem;
   if(selected!=null&&selected._item==global::Items.itemlist.SMG)
    __instance.itemDescription.text="A fully automatic submachine gun. Chambered in 8mm Compact Ammo with a 25 round capacity magazine";
  }
  if(inventorySmgFailed||__instance==null||__instance.InspectObj==null)return;
  var catalog=global::InventoryManager.allItems;
  if(catalog==null||!catalog.ContainsKey(global::Items.itemlist.SMG))return;
   var item=catalog[global::Items.itemlist.SMG];var parent=__instance.InspectObj;
   if(parent.name.StartsWith("SignalisVR_SmgCatalogue"))return;
  if(item==null||__instance.lastItem==null||__instance.lastItem._item!=global::Items.itemlist.SMG)return;
  for(int i=inventorySmgViews.Count-1;i>=0;i--){
   var view=inventorySmgViews[i];
   if(view.Parent==null||view.Root==null){inventorySmgViews.RemoveAt(i);continue;}
   if(view.Parent==parent){foreach(var r in view.Originals)if(r!=null)r.enabled=false;return;}
  }
  // The selected item identifies this preview. Instance mesh copies need not
  // share a native pointer with the catalogue prefab (or remain CPU-readable).
  GameObject root=null;
  try{
   var originals=parent.GetComponentsInChildren<Renderer>(true).ToArray();if(originals.Length==0)return;
   var bounds=new Bounds();bool first=true;
   foreach(var r in originals){Bounds b;if(!InventorySmgLocalBounds(r,out b))continue;for(int corner=0;corner<8;corner++){var vertex=b.center+Vector3.Scale(b.extents,new Vector3((corner&1)==0?-1:1,(corner&2)==0?-1:1,(corner&4)==0?-1:1));var p=parent.InverseTransformPoint(InventorySmgBoundsFrame(r).TransformPoint(vertex));if(first){bounds=new Bounds(p,Vector3.zero);first=false;}else bounds.Encapsulate(p);}}
   if(first)return;
   EnsureInventorySmgAssets();
   root=new GameObject("SignalisVR_InventoryXiphias");root.transform.SetParent(parent,false);root.layer=originals[0].gameObject.layer;
   var rotation=bounds.size.x>bounds.size.z?Quaternion.Euler(0,90,0):Quaternion.identity;
   var fit=new Bounds();first=true;
   foreach(var mesh in inventorySmgMeshes)foreach(var vertex in mesh.vertices){var p=rotation*vertex;if(first){fit=new Bounds(p,Vector3.zero);first=false;}else fit.Encapsulate(p);}
   float scale=Math.Min(bounds.size.x/Math.Max(.001f,fit.size.x),Math.Min(bounds.size.y/Math.Max(.001f,fit.size.y),bounds.size.z/Math.Max(.001f,fit.size.z)));
   if(float.IsNaN(scale)||float.IsInfinity(scale)||scale<=0)throw new InvalidOperationException("Invalid SMG preview bounds; native preview retained");
   root.transform.localRotation=rotation;scale*=.72f;root.transform.localScale=Vector3.one*scale;root.transform.localPosition=bounds.center-fit.center*scale;
   for(int i=0;i<inventorySmgMeshes.Count;i++){var part=new GameObject("Xiphias part");part.layer=root.layer;part.transform.SetParent(root.transform,false);part.AddComponent<MeshFilter>().sharedMesh=inventorySmgMeshes[i];part.AddComponent<MeshRenderer>().sharedMaterial=inventorySmgMaterials[inventorySmgSlots[i]];}
   var enabled=originals.Select(r=>r.enabled).ToArray();
   foreach(var r in originals)r.enabled=false;
   inventorySmgViews.Add(new InventorySmgView{Owner=__instance,Parent=parent,Root=root,Originals=originals,Enabled=enabled});
   MelonLoader.MelonLogger.Msg("Inventory SMG: Xiphias preview attached to "+parent.name+"; original renderers="+originals.Length+"; size="+bounds.size+"; scale="+scale+"; layer="+root.layer);
  }catch(Exception ex){if(root!=null)UnityEngine.Object.Destroy(root);inventorySmgFailed=true;MelonLoader.MelonLogger.Warning("Inventory SMG retained original: "+ex.Message);}
 }
} }




