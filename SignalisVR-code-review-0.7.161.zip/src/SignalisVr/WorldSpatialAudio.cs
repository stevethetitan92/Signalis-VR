using System;
using System.Collections.Generic;
using UnityEngine;
using HarmonyLib;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private sealed class PackVoice {internal PackAudio Audio;internal Vector3 Position;internal float Age,Volume;internal global::Room Room;}
 private readonly List<PackVoice> packVoices=new List<PackVoice>();
 private void PlayPackAt(PackAudio clip,Vector3 position,float volume){
  for(int i=packVoices.Count-1;i>=0;i--)if(packVoices[i].Audio==clip)packVoices.RemoveAt(i);
  clip.Stop();clip.SpatialOnce(AudioRelative(position),volume);
  if(packVoices.Count>=32){packVoices[0].Audio.Stop();packVoices.RemoveAt(0);}
  packVoices.Add(new PackVoice{Audio=clip,Position=position,Volume=volume,Room=global::PlayerState.currentRoom});
 }
 private void PollPackVoices(){
  bool paused=global::PlayerState.paused||pauseMenuVisible||modMenuOpen||!WeaponGameplayReady();
  for(int i=packVoices.Count-1;i>=0;i--){var v=packVoices[i];
   if(!ProdVrMode()||v.Room!=global::PlayerState.currentRoom||v.Age>=v.Audio.Duration){v.Audio.Stop();packVoices.RemoveAt(i);continue;}
   if(paused){v.Audio.PauseLoop();continue;}v.Age+=Mathf.Max(0,Time.deltaTime);v.Audio.SpatialOnce(AudioRelative(v.Position),v.Volume);
  }
 }
 private void ClearSpatialVoices(){foreach(var v in packVoices)v.Audio.Stop();packVoices.Clear();foreach(var v in worldVoices){FMOD.ChannelGroup group;if(v.Event.isValid()&&v.Event.getChannelGroup(out group)==FMOD.RESULT.OK){int budget=32;SpatialChannels(group,Vector3.zero,0,ref budget,true);}}worldVoices.Clear();}
 private void RestoreWorldVoice(WorldVoice voice){FMOD.ChannelGroup group;if(voice.Event.isValid()&&voice.Event.getChannelGroup(out group)==FMOD.RESULT.OK){int budget=32;SpatialChannels(group,Vector3.zero,0,ref budget,true);}}
 private sealed class WorldVoice {internal FMOD.Studio.EventInstance Event;internal Transform Follow;internal Vector3 Position;internal int Frame;}
 private readonly List<WorldVoice> worldVoices=new List<WorldVoice>();
 private bool spatialAudioWarning;
 private int worldAudioFrame=-1;
 private static bool PositionalEvent(string path){
  if(string.IsNullOrEmpty(path))return false;
  return path.IndexOf("Music",StringComparison.OrdinalIgnoreCase)<0&&path.IndexOf("Inventory",StringComparison.OrdinalIgnoreCase)<0&&path.IndexOf("/UI/",StringComparison.OrdinalIgnoreCase)<0&&path.IndexOf("Menu",StringComparison.OrdinalIgnoreCase)<0&&!path.StartsWith("snapshot:",StringComparison.OrdinalIgnoreCase);
 }
 private Vector3 AudioRelative(Vector3 point){return Quaternion.Inverse(stereoRotation)*(point-stereoPosition)/UnitsPerMetre;}
 private Vector3 GunAudioPoint(){Vector3 muzzle;return ImportedMuzzle(out muzzle)?rightWeaponPosition+rightWeaponRotation*muzzle*UnitsPerMetre:rightWeaponPosition;}
 private void RememberWorldVoice(FMOD.Studio.EventInstance ev,Vector3 position,Transform follow){
  if(!ev.isValid())return;
  FMOD.Studio.EventDescription desc;bool is3d;
  if(ev.getDescription(out desc)!=FMOD.RESULT.OK||desc.is3D(out is3d)!=FMOD.RESULT.OK||is3d)return;
  // Authored 3D events already use the headset listener; only fill the 2D gap.
  foreach(var old in worldVoices)if(old.Event.handle==ev.handle){old.Position=position;old.Follow=follow;return;}
  if(worldVoices.Count>=32){RestoreWorldVoice(worldVoices[0]);worldVoices.RemoveAt(0);}
  worldVoices.Add(new WorldVoice{Event=ev,Position=position,Follow=follow,Frame=Time.frameCount});
 }
 private static void SpatialEmitterStarted(FMODUnity.StudioEventEmitter __instance){
  var q=weaponOwner;if(q==null||!q.ProdVrMode()||__instance==null||!PositionalEvent(__instance.Event))return;
  try{q.RememberWorldVoice(__instance.EventInstance,__instance.transform.position,__instance.transform);}
  catch(Exception ex){q.SpatialAudioError(ex);}
 }
 private static bool SpatialOneShot(string __0,ref Vector3 __1){
  var q=weaponOwner;if(q==null||!q.ProdVrMode()||!PositionalEvent(__0))return true;
  var position=__1;
  if(position.sqrMagnitude<1e-10f&&__0.StartsWith("event:/Elster/Weapons/",StringComparison.OrdinalIgnoreCase))position=q.GunAudioPoint();
  else if(position.sqrMagnitude<1e-10f)return true; // No supplied source: preserve native behavior instead of inventing one.
  __1=position;return q.PlayPositionedNative(__0,position,null);
 }
 private static bool SpatialAttachedShot(string __0,GameObject __1){
  var q=weaponOwner;if(q==null||!q.ProdVrMode()||__1==null||!PositionalEvent(__0))return true;
  return q.PlayPositionedNative(__0,__1.transform.position,__1.transform);
 }
 private bool PlayPositionedNative(string path,Vector3 position,Transform follow){
  FMOD.Studio.EventInstance ev=default(FMOD.Studio.EventInstance);bool started=false;
  try{
   ev=FMODUnity.RuntimeManager.CreateInstance(path);
   FMOD.Studio.EventDescription desc;bool is3d;
   if(ev.getDescription(out desc)!=FMOD.RESULT.OK||desc.is3D(out is3d)!=FMOD.RESULT.OK||is3d){ev.release();return true;}
   if(ev.start()!=FMOD.RESULT.OK){ev.release();return true;}started=true;
   RememberWorldVoice(ev,position,follow);ev.release();return false;
  }catch(Exception ex){if(ev.isValid())ev.release();SpatialAudioError(ex);return !started;}
 }
 private void SpatialAudioError(Exception ex){if(spatialAudioWarning)return;spatialAudioWarning=true;MelonLoader.MelonLogger.Warning("World spatial audio fallback: "+ex.Message);}
 private static void SpatialListenerUpdated(){var q=weaponOwner;if(q!=null){if(q.ProdVrMode())q.UpdateHeadsetAudio();else q.ClearSpatialVoices();}}
 private void SpatialChannels(FMOD.ChannelGroup group,Vector3 relative,int depth,ref int budget,bool restore=false){
  if(depth>4||budget<=0)return;budget--; // Count groups too, including empty mixer branches.
  int count;if(group.getNumChannels(out count)==FMOD.RESULT.OK)for(int i=0;i<count&&budget>0;i++){
   FMOD.Channel ch;if(group.getChannel(i,out ch)!=FMOD.RESULT.OK)continue;budget--;
   FMOD.MODE mode;if(ch.getMode(out mode)!=FMOD.RESULT.OK)continue;
   mode&=~(FMOD.MODE._2D|FMOD.MODE._3D_WORLDRELATIVE|FMOD.MODE._3D_LINEARROLLOFF|FMOD.MODE._3D_LINEARSQUAREROLLOFF|FMOD.MODE._3D_CUSTOMROLLOFF|FMOD.MODE._3D_INVERSEROLLOFF);
   if(restore){ch.setMode((mode&~(FMOD.MODE._3D|FMOD.MODE._3D_HEADRELATIVE|FMOD.MODE._3D_INVERSETAPEREDROLLOFF))|FMOD.MODE._2D);continue;}
   if(ch.setMode(mode|FMOD.MODE._3D|FMOD.MODE._3D_HEADRELATIVE|FMOD.MODE._3D_INVERSETAPEREDROLLOFF)!=FMOD.RESULT.OK)continue;
   ch.set3DMinMaxDistance(.75f,40f);ch.set3DDopplerLevel(0);
   var p=new FMOD.VECTOR{x=relative.x,y=relative.y,z=relative.z};var v=new FMOD.VECTOR();ch.set3DAttributes(ref p,ref v);
  }
  if(group.getNumGroups(out count)==FMOD.RESULT.OK)for(int i=0;i<count&&budget>0;i++){FMOD.ChannelGroup child;if(group.getGroup(i,out child)==FMOD.RESULT.OK)SpatialChannels(child,relative,depth+1,ref budget,restore);}
 }
 private void PollWorldSpatialAudio(){
  if(worldAudioFrame==Time.frameCount)return;worldAudioFrame=Time.frameCount;PollPackVoices();
  if(!ProdVrMode()){ClearSpatialVoices();return;}
  for(int i=worldVoices.Count-1;i>=0;i--){
   var voice=worldVoices[i];FMOD.Studio.PLAYBACK_STATE state;
   if(!voice.Event.isValid()||voice.Event.getPlaybackState(out state)!=FMOD.RESULT.OK||(state==FMOD.Studio.PLAYBACK_STATE.STOPPED&&Time.frameCount>voice.Frame)){worldVoices.RemoveAt(i);continue;}
   if(voice.Follow!=null)voice.Position=voice.Follow.position;
   FMOD.ChannelGroup group;if(voice.Event.getChannelGroup(out group)==FMOD.RESULT.OK){int budget=32;SpatialChannels(group,AudioRelative(voice.Position),0,ref budget);}
  }
 }
 private void InstallWorldSpatialAudio(HarmonyLib.Harmony h){
  h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.StudioListener),"Update",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(SpatialListenerUpdated)));
  h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.StudioEventEmitter),"PlayInstance",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(SpatialEmitterStarted)));
  var one=new HarmonyMethod(typeof(Tracking),nameof(SpatialOneShot));one.priority=HarmonyLib.Priority.Last;
  var attached=new HarmonyMethod(typeof(Tracking),nameof(SpatialAttachedShot));attached.priority=HarmonyLib.Priority.Last;
  h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.RuntimeManager),"PlayOneShot",new[]{typeof(string),typeof(Vector3)}),prefix:one);
  h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.RuntimeManager),"PlayOneShotAttached",new[]{typeof(string),typeof(GameObject)}),prefix:attached);
 }
}}






