using System;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Texture2D cheatSheetTexture;
  private void DrawCheatsTab(float x,float y,float width,float s) {
   string[] labels={"14 Inventory Slots","Infinite Life","Infinite Ammo","Infinite Stun Prod","All Weapons and Items","Insta-Kill Enemies","Cheat Sheet","Back"};
   bool[] enabled={inventory14Slots,infiniteLife,infiniteAmmo,infiniteStunProd,allWeapons,instantKill};
   string[] descriptions={InventoryCheatWarning,"Block incoming damage and restore health. OFF returns to normal damage. Does not revive a finished game-over.","Keep the equipped firearm magazine full. OFF restores normal ammo use.","Physical stun-prod hits never consume durability. OFF restores three-hit wear.","Adds all six guns, two thermite flares, six rounds per gun, one of each health item and a flashlight to your storage box once when enabled. Save the GAME to retain them.","Enemy hits set enemy health to zero and use normal death handling. OFF restores normal damage."};
   var cyan=new Color(.42f,.8f,.9f);var gray=new Color(.42f,.45f,.43f);var red=new Color(.88f,.12f,.055f);
   for(int i=0;i<labels.Length;i++) {
    float row=y+(120+i*50)*s;bool selected=modMenuSelection==i;
    var area=new Rect(x,row,870*s,50*s);
    if(selected)PaintMenuRect(area,new Color(.12f,.22f,.22f));
    MenuText(new Rect(x,row,530*s,i==4?28*s:50*s),labels[i].ToUpperInvariant(),Color.white,modMenuStyle);
    if(i==4)MenuText(new Rect(x,row+28*s,530*s,22*s),"Find weapons and items in your storage box",cyan,modMenuHelp);
    // Cheat Sheet is a read-only selection: no value, arrows or activation.
    if(i!=6) {
     var box=new Rect(x+600*s,row,230*s,50*s);
     PaintMenuRect(box,selected?Color.white:gray);
     PaintMenuRect(new Rect(box.x+2*s,box.y+2*s,box.width-4*s,box.height-4*s),Color.black);
     MenuText(box,i<6?(enabled[i]?"ON":"OFF"):"< SETTINGS",cyan,modMenuStyle);
    }
    if(MenuClicked(area)){modMenuSelection=i;ActivateModMenu(i);return;}
   }
   PaintMenuRect(new Rect(x+890*s,y+120*s,2*s,590*s),gray);
   if(modMenuSelection==6)DrawCheatSheetImage(new Rect(x+915*s,y+120*s,565*s,590*s));
   else {
    MenuText(new Rect(x+925*s,y+140*s,540*s,48*s),modMenuSelection<6?labels[modMenuSelection].ToUpperInvariant():"BACK",cyan,modMenuStyle);
    MenuText(new Rect(x+925*s,y+215*s,540*s,310*s),modMenuSelection<6?descriptions[modMenuSelection]:"Return to settings.",Color.white,modMenuHelp);
   }
   MenuText(new Rect(x,y+650*s,870*s,80*s),InventoryCheatWarning,Color.white,modMenuHelp);
   MenuText(new Rect(x+470*s,y+750*s,width-470*s,52*s),"LEFT STICK: SELECT / CHANGE   GRIPS: SWITCH TABS",Color.white,modMenuHelp);
   if(modSettingsError!=null)MenuText(new Rect(x,y+818*s,width,36*s),modSettingsError,Color.white,modMenuHelp);
  }
  private void DrawCheatSheetImage(Rect area) {
   if(cheatSheetTexture==null) {
    cheatSheetTexture=new Texture2D(2,2,TextureFormat.RGBA32,false);
    if(!ImageConversion.LoadImage(cheatSheetTexture,Convert.FromBase64String(CheatSheetArtwork.Png),true))throw new InvalidOperationException("Cheat sheet decode failed");
    cheatSheetTexture.filterMode=FilterMode.Bilinear;cheatSheetTexture.wrapMode=TextureWrapMode.Clamp;
   }
   float fit=Math.Min(area.width/cheatSheetTexture.width,area.height/cheatSheetTexture.height);
   float w=cheatSheetTexture.width*fit,h=cheatSheetTexture.height*fit;
   var image=new Rect(area.x+(area.width-w)/2,area.y,w,h);
   PaintMenuRect(new Rect(image.x-2,image.y-2,image.width+4,image.height+4),Color.white);
   GUI.color=Color.white;GUI.DrawTexture(image,cheatSheetTexture);
  }
  private void DestroyCheatSheet(){if(cheatSheetTexture!=null)UnityEngine.Object.Destroy(cheatSheetTexture);cheatSheetTexture=null;}
 }
}








