using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class EnemyEyeOwnerEntry {internal global::Room Room;internal Transform Parent;internal int RoomCount;internal float Retry;}
 private readonly Dictionary<Transform,EnemyEyeOwnerEntry> enemyEyeOwners=new Dictionary<Transform,EnemyEyeOwnerEntry>();
 private global::Room EnemyEyeOwner(Transform source){
  EnemyEyeOwnerEntry entry;
  if(enemyEyeOwners.TryGetValue(source,out entry)&&entry.Parent==source.parent){
   var room=entry.Room;
   // Validate against live authored roots, including separately parented chunks.
   // Reparenting, replaced chunks, unloaded rooms and newly discovered rooms
   // must not keep an old ownership decision.
   if(room!=null&&room.gameObject.scene.IsValid()&&
    (source.IsChildOf(room.transform)||(room.chunk!=null&&source.IsChildOf(room.chunk.transform))||
     (room.Cell!=null&&source.IsChildOf(room.Cell.transform))||(room.instantChunk!=null&&source.IsChildOf(room.instantChunk.transform))))return room;
   if(room==null&&entry.RoomCount==mapRooms.Length&&Time.realtimeSinceStartup<entry.Retry)return null;
  }
  long started=TraceClock();
  try{
   var owner=MapOwner(source);
   enemyEyeOwners[source]=new EnemyEyeOwnerEntry{Room=owner,Parent=source.parent,RoomCount=mapRooms.Length,Retry=Time.realtimeSinceStartup+2f};
   return owner;
  }finally{TraceOperation(81,started);}
 }
}}
