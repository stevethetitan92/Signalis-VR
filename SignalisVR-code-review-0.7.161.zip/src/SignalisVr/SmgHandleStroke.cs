using System;
namespace SignalisVrTracking {
 // Independent SMG stroke detector. Magazine insertion and rendering do not
 // establish travel or complete a stroke; only tracked movement and release do.
 public sealed class SmgHandleStroke {
  public const float Travel=.030f,Threshold=.006f;
  public bool Held {get;private set;}
  public float Pull {get;private set;}
  public float Peak {get;private set;}
  private bool released;
  private float furthest,last;
  public void Reset(){Held=false;Pull=Peak=0;released=false;}
  public bool Sample(bool eligible,bool nearHandle,bool grip,float relativeZ){
   if(!eligible){Reset();released=!grip;return false;}
   if(float.IsNaN(relativeZ)||float.IsInfinity(relativeZ)){Reset();return false;}
   if(!Held){
    if(!grip){released=true;return false;}
    if(!released||!nearHandle)return false;
    Held=true;released=false;furthest=last=relativeZ;Pull=Peak=0;return false;
   }
   if(Math.Abs(relativeZ-last)>.35f){Reset();return false;}
   last=relativeZ;furthest=Math.Max(furthest,relativeZ);
   Pull=Math.Min(Travel,Math.Max(0,furthest-relativeZ));Peak=Math.Max(Peak,Pull);
   if(grip)return false;
   Held=false;released=true;bool accepted=Peak>=Threshold;Pull=0;return accepted;
  }
 }
}
