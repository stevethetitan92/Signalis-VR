using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool mapComplete;
 private sealed class MapPoint {public Component Source;public global::Interaction Inter;public global::Room Room;public Transform Target;public string Id,NativeId;public string Label;public int Kind;public global::ItemPickup Pickup;public global::UseItemInteraction Puzzle;public global::RES_Shutters Shutters;}
 private readonly List<MapPoint> mapObjects=new List<MapPoint>();
 private readonly HashSet<int> mapSourceIds=new HashSet<int>(),mapInteractionIds=new HashSet<int>();
 private readonly HashSet<string> mapPointIds=new HashSet<string>(),mapNativeIds=new HashSet<string>();
 private readonly Dictionary<string,Vector2[]> renderedMapRoomBounds=new Dictionary<string,Vector2[]>();
 private void IndexMapPoint(MapPoint point){
  mapSourceIds.Add(point.Source.GetInstanceID());mapPointIds.Add(point.Id);
  if(point.Inter!=null)mapInteractionIds.Add(point.Inter.GetInstanceID());
  if(!string.IsNullOrEmpty(point.NativeId))mapNativeIds.Add(point.NativeId);
 }
 private void ReindexMapPoints(){
  mapSourceIds.Clear();mapInteractionIds.Clear();mapPointIds.Clear();mapNativeIds.Clear();
  for(int i=mapObjects.Count-1;i>=0;i--){var point=mapObjects[i];if(point.Source==null||point.Target==null||!point.Source.gameObject.scene.IsValid())mapObjects.RemoveAt(i);}
  foreach(var point in mapObjects)IndexMapPoint(point);
 }
 private readonly List<Vector2> mapPointPositions=new List<Vector2>();
 private readonly List<int> mapPointKinds=new List<int>();
 private global::MED_FloodedBathroom mapBathroomFlood;
 private global::RES_Power mapPowerPuzzle;
 private int mapObjectsHandle=-1;private string mapObjectsScene;private float nextMapDiscovery,nextMapScan;
 private int mapScanPhase=-1,mapScanFrame=-1;
 private int mapScanLoaded=-1;
 private readonly Queue<Action> mapScanWork=new Queue<Action>();
 private readonly HashSet<string> rejectedMapIds=new HashSet<string>();
 private global::Room lastMapScanRoom;
 private global::Room[] mapRooms=new global::Room[0];
 private global::EventScreenInteraction[] mapEvents=new global::EventScreenInteraction[0];
 private static string MapObjectId(Transform t,global::Room room){
  var id=t.GetComponent<global::UniqueId>();if(id!=null&&!string.IsNullOrEmpty(id.id))return id.id;
  return MapObjectPathId(t,room);
 }
 private static string MapObjectPathId(Transform t,global::Room room){
  string path="";for(var p=t;p!=null;p=p.parent)path=p.name+(path.Length==0?"":"/"+path);
  return (int)room.floor+"|"+(room.minimapRoom==null?room.name:room.minimapRoom.name)+"|"+path;
 }
 private global::Room MapOwner(Transform t){
  var direct=t.GetComponentInParent<global::Room>();if(direct!=null)return direct;
  foreach(var room in mapRooms){
   if(room==null||!room.gameObject.scene.IsValid())continue;
   if((room.chunk!=null&&t.IsChildOf(room.chunk.transform))||(room.Cell!=null&&t.IsChildOf(room.Cell.transform))||(room.instantChunk!=null&&t.IsChildOf(room.instantChunk.transform)))return room;
  }return null;
 }
 private void AddMapObject(Component source,global::Interaction inter,int kind){
  if(source==null||!source.gameObject.scene.IsValid())return;
  var sourceLadder=source.TryCast<global::Ladder>();if(sourceLadder==null)sourceLadder=source.GetComponentInParent<global::Ladder>();
  if(sourceLadder!=null){source=sourceLadder;inter=sourceLadder.inter;kind=11;}
  if(mapSourceIds.Contains(source.GetInstanceID()))return;
  // CollapsedPOI is the native ground/traversal observation, not a solvable puzzle.
  if(kind==0&&source.name=="CollapsedPOI")return;
  if(kind==0&&inter!=null&&IsTravelOrCombatInteraction(inter))return;
  if(kind==0&&(source.GetComponentInParent<global::AutoTraverseDoor>()!=null||source.GetComponentInParent<global::Doorway_Double>()!=null||source.GetComponent<global::DoorLockEventInteraction>()!=null))return;
  var target=inter!=null?inter.transform:source.transform;
  var room=MapOwner(source.transform);if(room==null&&inter!=null)room=MapOwner(inter.transform);
  var ladder=source.TryCast<global::Ladder>();if(ladder!=null){if(ladder.room!=null)room=ladder.room;if(ladder.A!=null)target=ladder.A;}
  foreach(var ev in mapEvents){
   if(ev==null||ev.EventObject==null||!source.transform.IsChildOf(ev.EventObject.transform))continue;
   // Close-up screen children are not physical objects in the owning room.
   var uid=source.GetComponent<global::UniqueId>();if(uid!=null&&!string.IsNullOrEmpty(uid.id))rejectedMapIds.Add(MapDiscoveryPrefix+uid.id);
   return;
  }
  if(room==null)return;
  if(kind==11&&(int)room.floor==10&&room.minimapRoom!=null&&room.minimapRoom.name=="STAR Dorm"&&source.name=="Hole Drop Target")return;
  bool handle=source.TryCast<global::ItemPickup>()!=null&&(int)room.floor==11&&room.minimapRoom!=null&&room.minimapRoom.name=="Falkes Office"&&source.name=="HandlePickup";
  if(handle)kind=0;
  var native=source.GetComponent<global::MinimapPOIObject>();if(native==null&&inter!=null)native=inter.GetComponent<global::MinimapPOIObject>();
  var point=new MapPoint{Source=source,Inter=inter,Room=room,Target=target,Id=MapCanonicalId(MapObjectId(source.transform,room),kind,room,MapObjectPathId(source.transform,room)),NativeId=native==null?null:native.id,Label=handle?"SHUTTER GATE HANDLE":null,Kind=kind,Pickup=source.TryCast<global::ItemPickup>(),Shutters=source.GetComponentInParent<global::RES_Shutters>()??(inter==null?null:inter.GetComponentInParent<global::RES_Shutters>()),Puzzle=source.GetComponent<global::UseItemInteraction>()??(inter==null?null:inter.GetComponent<global::UseItemInteraction>())};
  if(mapPointIds.Contains(point.Id)||(sourceLadder==null&&inter!=null&&mapInteractionIds.Contains(inter.GetInstanceID())))return;
  IndexMapPoint(point);
  mapObjects.Add(point);highlightContexts.Clear();
 }
 private void PollMapDiscovery(){
  if(global::PlayerState.player==null)return;
  if(lastMapScanRoom==global::PlayerState.currentRoom&&Time.realtimeSinceStartup<nextMapDiscovery&&mapScanPhase<0&&nowherePuzzleScan<0)return;nextMapDiscovery=Time.realtimeSinceStartup+.25f;
  var activeScene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();string scene=activeScene.name;
  if(mapObjectsHandle!=activeScene.handle){mapScanWork.Clear();mapScanLoaded=-1;mapScanPhase=-1;mapObjectsHandle=activeScene.handle;mapObjectsScene=scene;mapObjects.Clear();nowherePuzzles.Clear();nowherePuzzleRooms.Clear();nowherePuzzleScan=-1;rejectedMapIds.Clear();mapBathroomFlood=null;mapPowerPuzzle=null;lastMapScanRoom=null;nextMapScan=0;}
  if(lastMapScanRoom!=global::PlayerState.currentRoom){lastMapScanRoom=global::PlayerState.currentRoom;nextMapScan=0;nextMarkerSpriteSearch=0;nextModMapRefresh=0;}
  if(Time.realtimeSinceStartup>=nextMapScan){
   nextMapScan=Time.realtimeSinceStartup+30;mapScanPhase=0;
   mapScanWork.Clear();mapScanLoaded=-1;
   ReindexMapPoints();highlightContexts.Clear();
  }
  // One global type scan per frame, rather than eight in one movement frame.
  // Interaction callbacks may poll twice; do not advance again in the same frame.
  if(mapScanPhase>=0&&mapScanFrame!=Time.frameCount){
   mapScanFrame=Time.frameCount;var scan=System.Diagnostics.Stopwatch.StartNew();
   if(mapScanLoaded!=mapScanPhase){mapScanLoaded=mapScanPhase;switch(mapScanPhase){
    case 0:{var rooms=new List<global::Room>();foreach(var room in Resources.FindObjectsOfTypeAll<global::Room>())if(room!=null&&room.gameObject.scene.IsValid())rooms.Add(room);mapRooms=rooms.ToArray();foreach(var room in mapRooms)if(room!=null&&room.name=="Protektor Bathroom")mapBathroomFlood=room.GetComponentInChildren<global::MED_FloodedBathroom>(true);break;}
    case 1:{var events=new List<global::EventScreenInteraction>();foreach(var ev in Resources.FindObjectsOfTypeAll<global::EventScreenInteraction>())if(ev!=null&&ev.gameObject.scene.IsValid())events.Add(ev);mapEvents=events.ToArray();break;}
    case 2:foreach(var p in Resources.FindObjectsOfTypeAll<global::SavePoint>())mapScanWork.Enqueue(()=>{if(p!=null)AddMapObject(p,p.inter,1);});break;
    case 3:foreach(var p in Resources.FindObjectsOfTypeAll<global::StorageBox>())mapScanWork.Enqueue(()=>{if(p!=null)AddMapObject(p,p.inter,2);});break;
    case 4:foreach(var p in Resources.FindObjectsOfTypeAll<global::ItemPickup>())mapScanWork.Enqueue(()=>{if(p==null)return;var item=p._item;if(item!=null)AddMapObject(p,p.inter,MapItemKind(item));});break;
    case 5:foreach(var p in Resources.FindObjectsOfTypeAll<global::BookScreen>())mapScanWork.Enqueue(()=>{if(p!=null&&p.book!=null)AddMapObject(p,p.inter,4);});break;
    case 6:foreach(var p in Resources.FindObjectsOfTypeAll<global::ObservationDialogue>())mapScanWork.Enqueue(()=>{if(p!=null)AddMapObject(p,p.inter,4);});break;
    case 9:BeginNowherePuzzles();foreach(var power in Resources.FindObjectsOfTypeAll<global::RES_Power>())if(power!=null&&power.gameObject.scene.IsValid()){mapPowerPuzzle=power;break;}break;
    case 8:foreach(var p in Resources.FindObjectsOfTypeAll<global::Ladder>())mapScanWork.Enqueue(()=>{if(p!=null)AddMapObject(p,p.inter,11);});break;
    case 7:foreach(var p in Resources.FindObjectsOfTypeAll<global::MinimapPOIObject>()){
     mapScanWork.Enqueue(()=>{if(p==null)return;bool exists=!string.IsNullOrEmpty(p.id)&&mapNativeIds.Contains(p.id);if(!exists)AddMapObject(p,p.inter,0);});
    }break;
   }}
   // Stop between objects, retaining classification and refresh completion.
   // A single native call may still exceed the budget; never claim a hard limit.
   int processed=0;while(mapScanWork.Count>0&&processed<8&&scan.Elapsed.TotalMilliseconds<2){mapScanWork.Dequeue()();processed++;}
   if(scan.Elapsed.TotalMilliseconds>8)MelonLoader.MelonLogger.Msg("MAP SCAN SLICE: phase="+mapScanPhase+" ms="+scan.Elapsed.TotalMilliseconds.ToString("F2"));
   if(mapScanWork.Count==0&&++mapScanPhase>=10){mapScanPhase=-1;nextModMapRefresh=0;if(nowherePuzzleScan<0)CompleteManualMapRefresh();MelonLoader.MelonLogger.Msg("MAP POINTS: scene="+scene+" classified="+mapObjects.Count+" scan distributed across 10 phases with budgeted object batches");}
  }
  var player=global::PlayerState.player;if(player==null)return;
  RepairCollectedPickups();
  MapMarkVisited();
  MarkMineVisited();
  PollNowhereState();
  ClearDrainedBathroomPuzzle();
  if(mapPowerPuzzle!=null&&mapPowerPuzzle.solved)foreach(var point in mapObjects)if(point.Kind==0&&point.NativeId=="RES_Power")CompleteMapPuzzle(point);
  foreach(var point in mapObjects){
   if(point.Kind==0&&MapPuzzleGone(point))CompleteMapPuzzle(point);
   if((point.Kind>2&&point.Kind!=11)||point.Source==null||point.Target==null||!point.Source.gameObject.activeInHierarchy)continue;
   if(point.Puzzle!=null&&point.Puzzle.unlocked&&global::SProgress.GetInt(point.Id+":gone",0)==0){global::SProgress.SetInt(point.Id+":gone",1);nextModMapRefresh=0;}
   if(global::SProgress.GetInt(point.Id,0)!=0)continue;
   bool interacted=point.Inter!=null&&point.Inter.triggered;
   bool sameRoom=MapSameRoom(point.Room,global::PlayerState.currentRoom);
   // Room entry discovers eligible POIs without proximity, view or interaction.
   bool discover=interacted||DiscoverPoiOnRoomEntry(point.Kind,sameRoom,point.Target.gameObject.activeInHierarchy);
   if(discover)DiscoverMapPoint(point,interacted?"interaction":"room entry");
  }
 }
 private bool MapRoomHasKnownLadder(global::PersistentMinimapRoom room,int floor){
  if(room==null||room.RoomID==null)return false;
  foreach(var p in mapObjects)if(p.Kind==11&&p.Room!=null&&(int)p.Room.floor==floor&&p.Room.minimapRoom==room.RoomID&&global::SProgress.GetInt(p.Id,0)!=0)return true;
  foreach(var entry in mapLadderCatalogue)if(entry.Floor==floor&&entry.Room==room.RoomID.name&&MapCatalogueLadderKnown(entry))return true;
  return false;
 }
 private static bool MapNativePuzzleDone(string id){return !string.IsNullOrEmpty(id)&&(global::SProgress.GetInt("SignalisVR.Map.Completed.v1:"+id,0)!=0||global::SProgress.GetInt("mPOI"+id,0)==2||(id=="RES_Painting"&&!global::SProgress.GetBool("exists: RES_Residential_74b1bf76-41cf-4768-9387-6f020afc1d57",true)));}
 private static bool MapPuzzleGone(MapPoint point){return MapPointGone(point.Id)||(point.Kind==0&&(MapNativePuzzleDone(point.NativeId)||(point.Puzzle!=null&&point.Puzzle.unlocked)||(point.Shutters!=null&&(point.Shutters.unlocked||(point.Shutters._lock!=null&&!point.Shutters._lock.locked)))));}
 private static void MapPuzzleCompleted(string __0){
  if(string.IsNullOrEmpty(__0))return;var q=questOwner;if(q==null)return;
  global::SProgress.SetInt("SignalisVR.Map.Completed.v1:"+__0,1);
  foreach(var p in q.mapObjects)if(p.Kind==0&&p.NativeId==__0)q.CompleteMapPuzzle(p);
  q.nextModMapRefresh=0;
 }
 private void CompleteMapPuzzle(MapPoint point){if(global::SProgress.GetInt(point.Id+":gone",0)==0){global::SProgress.SetInt(point.Id+":gone",1);nextModMapRefresh=0;}}
 private void ClearDrainedBathroomPuzzle(){
  if(mapBathroomFlood==null||mapBathroomFlood.level<1f)return;
  foreach(var point in mapObjects){
   // The native map POI is a sibling of ObservationFlood, not its child.
   if(point.Kind==0&&point.NativeId=="MED_FloodedBath")CompleteMapPuzzle(point);
   if(point.Kind==11&&MapSameRoom(point.Room,MapOwner(mapBathroomFlood.transform))&&point.Source!=null&&point.Source.gameObject.activeInHierarchy&&global::SProgress.GetInt(point.Id,0)==0)DiscoverMapPoint(point,"bathroom drained");
  }
 }
 private static bool DiscoverPoiOnRoomEntry(int kind,bool sameRoom,bool active){return ((kind>=0&&kind<=2)||kind==11)&&sameRoom&&active;}
 private void DiscoverMapPoint(MapPoint point,string via){
  if(point.Kind==11&&via=="interaction"&&point.Source!=null){
   var source=point.Source.TryCast<global::Ladder>();var destination=source==null?null:source.Destination;
   if(destination!=null&&destination.room!=null){
    string linked=MapCanonicalId(MapObjectId(destination.transform,destination.room),11,destination.room,MapObjectPathId(destination.transform,destination.room));
    if(MapHasAuthoredLadder(linked))global::SProgress.SetInt(linked,1);
   }
  }
  global::SProgress.SetInt(point.Id,1);if(!string.IsNullOrEmpty(point.NativeId))global::SProgress.SetInt("SignalisVR.Map.Native:"+point.NativeId,1);
  nextModMapRefresh=0;MelonLoader.MelonLogger.Msg("MAP DISCOVERY: "+point.Id+" kind="+point.Kind+" via="+via);
 }
 private void InstallMapDiscovery(){
  InstallStorageStereo();
  try{questHarmony.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(global::MinimapPOIManager),"DimPOI",new[]{typeof(string)}),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(MapPuzzleCompleted)));questHarmony.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(global::MinimapPOIManager),"dimPOI",new[]{typeof(string)}),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(MapPuzzleCompleted)));}
  catch(Exception ex){MelonLoader.MelonLogger.Warning("Map puzzle completion hook unavailable: "+ex.Message);}
  questHarmony.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(global::SProgress),"Load",new[]{typeof(int)}),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(SavedMapLoaded)));
  questHarmony.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(global::SProgress),"Load",new[]{typeof(int)}),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(ReportLoadedSave)));
  questHarmony.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(global::SProgress),"ResetProgress",Type.EmptyTypes),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(SavedMapLoaded)));
  questHarmony.Patch(HarmonyLib.AccessTools.Method(typeof(global::PersistentMinimapManager),"Load"),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(SavedMapLoaded)));
  questHarmony.Patch(HarmonyLib.AccessTools.Method(typeof(global::Interaction),"trigger"),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(MapInteractionTriggered)));
  questHarmony.Patch(HarmonyLib.AccessTools.Method(typeof(global::AutoTraverseDoor),"traverse"),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(MapDoorTraversed)));
  questHarmony.Patch(HarmonyLib.AccessTools.Method(typeof(global::InteractiveLockSingle),"StartDialogue"),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(MapDoorChecked)));
  questHarmony.Patch(HarmonyLib.AccessTools.Method(typeof(global::DoorLockEventInteraction),"Interact"),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(MapPuzzleDoorChecked)));
  foreach(var name in new[]{"ATraversed","BTraversed"})questHarmony.Patch(HarmonyLib.AccessTools.Method(typeof(global::ConnectedDoors),name),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(MapConnectedDoorTraversed)));
 }
 private static void MapConnectedDoorTraversed(global::AutoTraverseDoor __0){var q=questOwner;if(q!=null&&__0!=null)q.RememberActualMapDoor(__0,null);}
 private static void MapDoorTraversed(global::AutoTraverseDoor __instance){var q=questOwner;if(q!=null&&__instance!=null&&__instance.traversing)q.RememberActualMapDoor(__instance,null);}
 private static void MapDoorChecked(global::InteractiveLockSingle __instance){var q=questOwner;if(q!=null&&__instance!=null)q.RememberActualMapDoor(null,__instance);}
 private void RememberActualMapDoor(global::AutoTraverseDoor traversed,global::InteractiveLockSingle locked){
  // Native traversal and locked-door dialogue do not require Interaction.trigger.
  // Observe actual actions, never proximity or native minimap tried flags.
  int recorded=0;var direct=MapDoorHistory(traversed);if(traversed!=null){ObserveMapDoor(traversed,true);recorded++;}
  foreach(var room in mapRooms){if(room==null||room.Doors==null)continue;foreach(var door in room.Doors){
   if(door==null)continue;
   // No broadcast through ConnectedDoors/master: a check observes only the
   // physical door acted on. The opposite side has its own native callback.
   bool match=traversed!=null&&door==traversed;
   match|=locked!=null&&locked.door!=null&&door.door==locked.door;
   if(!match)continue;ObserveMapDoor(door,traversed!=null);recorded++;
  }}nextModMapRefresh=0;MelonLoader.MelonLogger.Msg("MAP DOOR ACTION: route="+(traversed!=null?"traverse":"lock")+" recorded="+recorded+" key="+(direct??"none"));
 }
 private static void MapPuzzleDoorChecked(global::DoorLockEventInteraction __instance){
  var q=questOwner;if(q==null||__instance==null||__instance.Door==null)return;
  var target=__instance.Door.transform;var seen=new HashSet<int>();int recorded=0;
  foreach(var room in q.mapRooms){if(room==null||room.Doors==null)continue;foreach(var door in room.Doors){
   if(door==null||!seen.Add(door.GetInstanceID()))continue;
   bool match=door.transform==target||door.transform.IsChildOf(target)||
    (door.door!=null&&(door.door.transform==target||door.door.transform.IsChildOf(target)));
   if(!match)continue;ObserveMapDoorState(door,__instance.done?ReadActualMapDoorState(door):4);recorded++;
  }}q.nextModMapRefresh=0;
  MelonLoader.MelonLogger.Msg("MAP PUZZLE DOOR: target="+target.name+" recorded="+recorded);
 }
 private static void MapInteractionTriggered(global::Interaction __instance){
  var q=questOwner;if(q==null)return;
  try{q.RememberMapDoorInteraction(__instance);q.RememberMultiLockInteraction(__instance);q.nextModMapRefresh=0;q.nextMapDiscovery=0;q.PollMapDiscovery();foreach(var point in q.mapObjects)if((point.Kind<=2||point.Kind==11)&&point.Inter==__instance&&(point.Kind==11||global::SProgress.GetInt(point.Id,0)==0))q.DiscoverMapPoint(point,"interaction");}catch(Exception ex){MelonLoader.MelonLogger.Warning("MAP interaction observer: "+ex.Message);}
 }
 private void RememberMultiLockInteraction(global::Interaction inter){
  if(inter==null)return;var ev=inter.GetComponent<global::EventScreenInteraction>();
  if(ev==null||ev.EventObject==null||!inter.triggered)return;
  // The authored 5-LOCK interaction is separate from its disabled physical
  // door. Follow puzzle -> close-up and unlock-event -> physical door links.
  foreach(var puzzle in Resources.FindObjectsOfTypeAll<global::MED_MultiLock>()){
   if(puzzle==null||puzzle.LeftDoor==null||!puzzle.LeftDoor.IsChildOf(ev.EventObject.transform)||puzzle.onUnlockedLate==null)continue;
   for(int i=0;i<puzzle.onUnlockedLate.GetPersistentEventCount();i++){
    if(puzzle.onUnlockedLate.GetPersistentMethodName(i)!="SetActive")continue;
    var target=puzzle.onUnlockedLate.GetPersistentTarget(i);var go=target==null?null:target.TryCast<GameObject>();
    var physical=go==null?null:go.GetComponent<global::Doorway_Double>();if(physical==null)continue;
    var seen=new HashSet<int>();foreach(var room in mapRooms){if(room==null||room.Doors==null)continue;foreach(var door in room.Doors){
     if(door!=null&&door.door==physical&&seen.Add(door.GetInstanceID()))ObserveMapDoorState(door,puzzle.unlocked?1:4);
    }}
   }
  }
 }
 private static bool MapPointGone(string id){const string prefix="SignalisVR.Map.Discovered.v2:";string native=id.StartsWith(prefix,StringComparison.Ordinal)?id.Substring(prefix.Length):id;return global::SProgress.GetInt(id+":gone",0)!=0||!global::SProgress.GetBool("exists: "+native,true);}
 private static int MapItemKind(global::AnItem item){
  string name=item._item.ToString();
  switch(name){case "PistolAmmo":return 5;case "ShotgunAmmo":return 6;case "SmgAmmo":return 7;case "RifleAmmo":return 8;case "FlareGunAmmo":return 9;}
  if(item.type==global::AnItem.AnItemType.Key||item.type==global::AnItem.AnItemType.Object)return 3;
  return 100+(int)item._item;
 }
 private void CompleteAllMaps(){
  var manager=global::PersistentMinimapManager.instance;if(manager==null||manager.FloorManagers==null)return;
  foreach(var floor in manager.FloorManagers){
   if(floor==null||!floor.gameObject.scene.IsValid())continue;
   if(manager.discoveredFloorManagers!=null&&!manager.discoveredFloorManagers.Contains(floor))manager.discoveredFloorManagers.Add(floor);
   foreach(var room in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true))room.discovered=true;
   if(floor.Rooms!=null)foreach(var room in floor.Rooms)if(room!=null){room.discovered=true;if(room.children!=null)foreach(var child in room.children)if(child!=null)child.discovered=true;}
  }
 }
 private void RefreshMapPoints(global::PersistentMinimapFloor floor,Transform basis){
  mapPointPositions.Clear();mapPointKinds.Clear();mapLabelPoints.Clear();mapLabelTexts.Clear();mapLabelScales.Clear();mapLabelGold.Clear();MapRoomLabels(floor,basis);var ids=new HashSet<string>();
  foreach(var poi in floor.GetComponentsInChildren<global::MinimapPOI>(true)){
   MapPoint match=null;foreach(var item in mapObjects)if(!string.IsNullOrEmpty(item.NativeId)&&item.NativeId==poi.id){match=item;break;}
   if(match==null||match.Kind>2||poi.dim||MapPuzzleGone(match))continue;
   if(match.Kind==1||match.Kind==2)continue; // Native POI placement is not a service anchor.
   bool discovered=global::SProgress.GetInt("SignalisVR.Map.Native:"+poi.id,0)!=0||(match!=null&&global::SProgress.GetInt(match.Id,0)!=0);
   if(!mapComplete&&!discovered)continue;
   var p=basis.InverseTransformPoint(poi.transform.position);
   mapPointPositions.Add((new Vector2(p.x,p.y)-modMapCenter)*modMapScale);mapPointKinds.Add(match==null?0:match.Kind);MapPuzzleLabel(poi,basis);ids.Add(poi.id??"");if(match!=null)ids.Add(match.Id);
  }
  var placed=new HashSet<string>();
  foreach(var item in mapObjects){
   // Fixed save/storage POIs use their room-local catalogue coordinates below.
   // A one-door player estimate must not overwrite their persistent placement.
   if(item.Kind==1||item.Kind==2)continue;
   if(item.Label!=null&&mapCatalogueHas(item.Id,item.Kind))continue;
   if(item.Kind==11&&MapHasAuthoredLadder(item.Id))continue;
   if((item.Kind>2&&item.Kind!=11)||item.Source==null||item.Target==null||!MapSameRoom(item.Room,global::PlayerState.currentRoom)||(!string.IsNullOrEmpty(item.NativeId)&&ids.Contains(item.NativeId)))continue;
   if(!item.Source.gameObject.activeInHierarchy||ids.Contains(item.Id)||placed.Contains(item.Id)||MapPuzzleGone(item)||(!mapComplete&&global::SProgress.GetInt(item.Id,0)==0))continue;
   Vector2 p;if(MapLadderOpening(item,floor,basis,out p)||MapPlayerPoint(item.Target.position,out p)){mapPointPositions.Add(p);mapPointKinds.Add(item.Kind);if(item.Label!=null)AddMapLabel(p+new Vector2(0,.007f*UnitsPerMetre),item.Label,.16f);placed.Add(item.Id);MapRememberPosition(item,p,floor,basis);}
  }
  // Retain discovered ladders when their room is no longer current. Positions
  // use the same persisted room-relative projection as other live POIs.
  foreach(var item in mapObjects){
   if(item.Kind==11&&MapHasAuthoredLadder(item.Id))continue;
   if((item.Kind!=11&&item.Label==null)||(item.Label!=null&&mapCatalogueHas(item.Id,item.Kind))||placed.Contains(item.Id)||MapPuzzleGone(item)||item.Room==null||item.Room.minimapRoom==null||(int)item.Room.floor!=(int)floor.FloorID||global::SProgress.GetInt(item.Id,0)==0||global::SProgress.GetInt(item.Id+":position",0)==0)continue;
   Vector2 lo,hi;if(!MapCatalogueBounds(floor,basis,item.Room.minimapRoom.name,out lo,out hi))continue;
   var p=new Vector2(Mathf.Lerp(lo.x,hi.x,global::SProgress.GetInt(item.Id+":x",0)/100000f),Mathf.Lerp(lo.y,hi.y,global::SProgress.GetInt(item.Id+":y",0)/100000f));
   mapPointPositions.Add((p-modMapCenter)*modMapScale);mapPointKinds.Add(item.Kind);if(item.Label!=null)AddMapLabel((p-modMapCenter)*modMapScale+new Vector2(0,.007f*UnitsPerMetre),item.Label,.16f);
  }
  var boundsCache=new Dictionary<string,Vector2[]>();
  foreach(var entry in mapCatalogue){
   if(entry.Kind>2||entry.Floor!=(int)floor.FloorID||entry.Id.Contains("|Events/"))continue;
   if(entry.Kind==0){bool known=false;foreach(var live in mapObjects)if(live.Kind==0&&live.Id==MapDiscoveryPrefix+entry.Id&&!MapPuzzleGone(live)){known=true;break;}if(!known)continue;}
   string id="SignalisVR.Map.Discovered.v2:"+entry.Id;
   if(rejectedMapIds.Contains(id)||ids.Contains(id)||placed.Contains(id)||!MapDiscoveryPolicy.Visible(mapComplete,global::SProgress.GetInt(id,0)!=0,MapPointGone(id)))continue;
   Vector2[] cached;if(!boundsCache.TryGetValue(entry.Room,out cached)){Vector2 lo,hi;cached=MapCatalogueBounds(floor,basis,entry.Room,out lo,out hi)?new[]{lo,hi}:null;boundsCache[entry.Room]=cached;}
   if(cached==null)continue;var low=cached[0];var high=cached[1];
   float nx=entry.X,ny=entry.Y;if(entry.Kind!=1&&entry.Kind!=2&&entry.Id!="RES_Residential_cb602f7f-a81a-41f7-9131-3cfcebe64ffc"&&global::SProgress.GetInt(id+":position",0)!=0){nx=global::SProgress.GetInt(id+":x",0)/100000f;ny=global::SProgress.GetInt(id+":y",0)/100000f;}
   var p=new Vector2(Mathf.Lerp(low.x,high.x,Mathf.Clamp01(nx)),Mathf.Lerp(low.y,high.y,Mathf.Clamp01(ny)));
   mapPointPositions.Add((p-modMapCenter)*modMapScale);mapPointKinds.Add(entry.Kind);if(entry.Id=="RES_Residential_cb602f7f-a81a-41f7-9131-3cfcebe64ffc")AddMapLabel((p-modMapCenter)*modMapScale+new Vector2(0,-.008f*UnitsPerMetre),"SHUTTER GATE HANDLE",.16f);
  }
  foreach(var entry in mapLadderCatalogue){
   if(entry.Floor!=(int)floor.FloorID||!MapCatalogueLadderKnown(entry))continue;
   Vector2 lo,hi;if(!MapCatalogueBounds(floor,basis,entry.Room,out lo,out hi))continue;
   var p=(new Vector2(Mathf.Lerp(lo.x,hi.x,entry.X),Mathf.Lerp(lo.y,hi.y,entry.Y))-modMapCenter)*modMapScale;
   MapAuthoredLadderOpening(entry,floor,basis,ref p);

   mapPointPositions.Add(p);mapPointKinds.Add(11);
  }
  SeparateMapServices();
 }
 private void SeparateMapServices(){
  // Symbols span 4.8mm. Offset only crowded service icons, after projection,
  // so doors, room geometry and persisted world coordinates are unchanged.
  float gap=.007f*UnitsPerMetre;
  for(int i=0;i<mapPointPositions.Count;i++){
   if(mapPointKinds[i]!=1&&mapPointKinds[i]!=2)continue;
   var origin=mapPointPositions[i];var candidate=origin;
   for(int attempt=0;attempt<=mapPointPositions.Count;attempt++){
    bool occupied=false;for(int j=0;j<i;j++)if((mapPointKinds[j]==1||mapPointKinds[j]==2)&&(candidate-mapPointPositions[j]).sqrMagnitude<gap*gap){occupied=true;break;}
    if(!occupied)break;candidate=origin+new Vector2((attempt+1)*gap,0);
   }
   mapPointPositions[i]=candidate;
  }
 }
 private static bool mapCatalogueHas(string id,int kind){foreach(var entry in mapCatalogue)if(entry.Kind==kind&&MapDiscoveryPrefix+entry.Id==id)return true;return false;}
 private static bool MapCatalogueBounds(global::PersistentMinimapFloor floor,Transform basis,string name,out Vector2 low,out Vector2 high){
  low=new Vector2(float.PositiveInfinity,float.PositiveInfinity);high=new Vector2(float.NegativeInfinity,float.NegativeInfinity);bool found=false;
  Vector2[] drawn;if(questOwner!=null&&questOwner.renderedMapRoomBounds.TryGetValue((int)floor.FloorID+"|"+name,out drawn)){low=drawn[0];high=drawn[1];return true;}
  var records=new List<global::PersistentMinimapRoom>();
  if(floor.Rooms!=null)foreach(var record in floor.Rooms)if(record!=null&&!records.Contains(record))records.Add(record);
  foreach(var record in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true))if(record!=null&&!records.Contains(record))records.Add(record);
  foreach(var room in records){
   if(room==null||room.RoomID==null||room.RoomID.name!=name)continue;
   Vector2 missingLow,missingHigh;if(MapMissingRoomBounds(floor,basis,room,out missingLow,out missingHigh)){low=missingLow;high=missingHigh;return true;}
   var shapes=new List<global::MinimapActiveRoom>();if(room.shapes!=null)foreach(var shape in room.shapes)if(shape!=null&&!shapes.Contains(shape))shapes.Add(shape);
   foreach(var shape in room.GetComponentsInChildren<global::MinimapActiveRoom>(true))if(shape!=null&&!shapes.Contains(shape))shapes.Add(shape);
   foreach(var shape in shapes){
    var sr=shape.SR;if(sr==null)sr=shape.GetComponent<SpriteRenderer>();if(sr==null||sr.sprite==null)continue;
    var b=MapSpriteBounds(sr);for(int k=0;k<8;k++){var p=basis.InverseTransformPoint(sr.transform.TransformPoint(b.center+Vector3.Scale(b.extents,new Vector3((k&1)==0?-1:1,(k&2)==0?-1:1,(k&4)==0?-1:1))));low=Vector2.Min(low,new Vector2(p.x,p.y));high=Vector2.Max(high,new Vector2(p.x,p.y));found=true;}
   }
   if(!found&&MapMissingRoomBounds(floor,basis,room,out missingLow,out missingHigh)){low=missingLow;high=missingHigh;found=true;}
  }return found;
 }
}}















