using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private void MapDoorLines(Vector2 p,int state,float size,float angle,Action<Vector2,Vector2,Color,float> draw){
  if(mapDoorLocks&&(state==0||state==1||state==2||state==4)){
   Color tint=state==4?new Color(1,.85f,.1f):state==2?new Color(1,.12f,.12f):state==0?new Color(.52f,.54f,.53f):new Color(.1f,.8f,1);
   // Upright symbols share the exact door anchor/state with the flat design.
   Action<float,float,float,float,float> stroke=(x,y,u,v,w)=>draw(p+new Vector2(x,y)*size,p+new Vector2(u,v)*size,tint,w*size);
   if(state==0||state==1){stroke(-2,-3,-2,3,1);stroke(-2,3,2,3,1);stroke(2,3,2,-3,1);stroke(-2,1,2,1,1);}
   else {stroke(0,-2,0,1,4);stroke(-1.2f,1,-1.2f,3.5f,.8f);stroke(-1.2f,3.5f,1.2f,3.5f,.8f);stroke(1.2f,3.5f,1.2f,1,.8f);}
   return;
  }
  size*=.54f;
  Color color=state==4?new Color(1,.85f,.1f):state==2?new Color(1,.12f,.12f):state==1?new Color(.1f,.8f,1):new Color(.52f,.54f,.53f);
  float ca=Mathf.Cos(angle),sa=Mathf.Sin(angle);
  Func<float,float,Vector2> at=(x,y)=>p+new Vector2(x*ca-y*sa,x*sa+y*ca)*size;
  Action<float,float,float,float,float> line=(x,y,u,v,w)=>draw(at(x,y),at(u,v),color,w*size);
  float h=state==0?1.5f:2.7f;
  line(-5.1f,-h,5.1f,-h,.7f);line(5.1f,-h,5.1f,h,.7f);line(5.1f,h,-5.1f,h,.7f);line(-5.1f,h,-5.1f,-h,.7f);
  line(-3.4f,-h+.6f,-3.4f,h-.6f,.9f);line(3.4f,-h+.6f,3.4f,h-.6f,.9f);
  line(-2.8f,0,2.8f,0,state==0?.7f:2.5f);
 }
}}


