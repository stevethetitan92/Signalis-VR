using System;
namespace SignalisVrTracking {
 public sealed class ProdContactPolicy {
  private bool contactLatched;
  private double separatedAt=-1,nextTouch;
  public void Reset(){contactLatched=false;separatedAt=-1;nextTouch=0;}
  public bool Touch(bool touching,bool valid,double now){
   if(double.IsNaN(now)||double.IsInfinity(now))return false;
   if(!touching){
    if(separatedAt<0)separatedAt=now;
    if(now-separatedAt>=.08)contactLatched=false;
    return false;
   }
   // Brief collision gaps must not turn a held contact into another charge.
   if(separatedAt>=0&&now-separatedAt>=.08)contactLatched=false;
   separatedAt=-1;
   if(contactLatched)return false;
   contactLatched=true;
   if(!valid||now<nextTouch)return false;
   nextTouch=now+.25;return true;
  }
 }
}
