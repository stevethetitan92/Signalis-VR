using System;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private int shotgunAimLogs;
  private ShotgunAimSnapshot CaptureShotgunCone(global::PlayerAttack attack) {
   if(!(mouseWeaponTest?weaponHooksReady&&!weaponAimFailed&&MouseWeaponReady():ControllerWeaponReady()))return null;
   var muzzle=global::PlayerAttack.muzzle;
   if(muzzle==null)return null;
   ShotgunAimSnapshot result=null;
   // Shot-only lookup. Use the game's actual shape rather than inventing a spread angle.
   foreach(var cone in attack.transform.root.GetComponentsInChildren<global::ShotgunCone>(true)) {
    if(cone==null||!cone.gameObject.activeInHierarchy)continue;
    foreach(var shape in cone.GetComponents<Collider>()) {
     if(shape==null||!shape.enabled||!shape.isTrigger)continue;
     var mesh=shape.TryCast<MeshCollider>();
     if(shape.TryCast<BoxCollider>()==null&&shape.TryCast<SphereCollider>()==null
       &&shape.TryCast<CapsuleCollider>()==null&&(mesh==null||!mesh.convex))continue;
     if(result!=null){ShotgunAimStatus("Ambiguous spread colliders; retaining native shotgun aim");return null;}
     result=new ShotgunAimSnapshot(cone,shape,muzzle,attack.transform.root);
    }
   }
   if(result==null)ShotgunAimStatus("No supported active spread collider; retaining native shotgun aim");
   return result;
  }
  private void ShotgunAimStatus(string message){if(shotgunAimLogs++<8)MelonLogger.Msg("SHOTGUN AIM: "+message);}
 }
 internal sealed class ShotgunAimSnapshot {
  private readonly global::ShotgunCone cone;
  private readonly Collider shape;
  private readonly Transform muzzle,playerRoot;
  private readonly Vector3 oldMuzzle,oldPosition,oldCenter;
  private readonly Quaternion oldRotation,oldMuzzleRotation;
  private readonly float radius;
  internal ShotgunAimSnapshot(global::ShotgunCone cone,Collider shape,Transform muzzle,Transform root) {
   this.cone=cone;this.shape=shape;this.muzzle=muzzle;playerRoot=root;
   oldMuzzle=muzzle.position;oldMuzzleRotation=muzzle.rotation;
   oldPosition=shape.transform.position;oldRotation=shape.transform.rotation;
   var bounds=shape.bounds;oldCenter=bounds.center;radius=bounds.extents.magnitude;
  }
  internal Action Apply() {
   if(radius<=0f||float.IsNaN(radius)||float.IsInfinity(radius))throw new InvalidOperationException("Invalid shotgun collider bounds");
   var delta=muzzle.rotation*Quaternion.Inverse(oldMuzzleRotation);
   var position=muzzle.position+delta*(oldPosition-oldMuzzle);
   var rotation=delta*oldRotation;
   var center=muzzle.position+delta*(oldCenter-oldMuzzle);
   // Broad phase only; exact overlap uses the original collider at the aimed pose.
   // Explicit poses avoid moving a physics object or forcing global SyncTransforms.
   var candidates=Physics.OverlapSphere(center,radius,~0,QueryTriggerInteraction.Collide);
   var original=global::PlayerAttack.shotgunTargets;
   var temporary=new Il2CppSystem.Collections.Generic.List<GameObject>();
   global::PlayerAttack.shotgunTargets=temporary;
   try {
    foreach(var other in candidates) {
     if(other==null||other==shape||other.transform.IsChildOf(playerRoot))continue;
     Vector3 direction=new Vector3();float distance=0f;
     if(Physics.ComputePenetration(shape,position,rotation,other,other.transform.position,other.transform.rotation,out direction,out distance))
      cone.OnTriggerStay(other); // Retain native tag eligibility and duplicate filtering.
    }
   }catch {global::PlayerAttack.shotgunTargets=original;throw;}
   return delegate {global::PlayerAttack.shotgunTargets=original;};
  }
 }
}
