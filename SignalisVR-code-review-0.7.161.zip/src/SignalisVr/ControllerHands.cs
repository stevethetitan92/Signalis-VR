using System;
using System.Collections.Generic;
using MelonLoader;
using UnityEngine;

namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Transform handsModel;
  private int handsVisualType=-1;private Transform handsVisualRoot;
  private static int NativePlayerVisualType(){var t=global::CharacterModelType.instance;return t==null?-1:(int)t.modelState;}
  private static Transform NativePlayerVisualRoot(){var t=global::CharacterModelType.instance;if(t==null)return null;var go=t.modelState==global::CharacterModelType.ElsterType.armored?t.armored:t.modelState==global::CharacterModelType.ElsterType.eva?t.eva:t.modelState==global::CharacterModelType.ElsterType.crippled?t.crippled:t.modelState==global::CharacterModelType.ElsterType.isa?t.isa:t.normal;return go==null?null:go.transform;}
  private SkinnedMeshRenderer handsSourceBody;
  private SkinnedMeshRenderer[] handsBody;
  private bool[] handsBodyEnabled;
  private readonly GameObject[] handsObjects=new GameObject[2];
  private readonly Mesh[] handsMeshes=new Mesh[2];
  private readonly SkinnedMeshRenderer[] handsRenderers=new SkinnedMeshRenderer[2];
  private readonly Transform[][] handSourceBones=new Transform[2][],handCopyBones=new Transform[2][];
  private readonly Vector3[] handPalmCenters=new Vector3[2];
  private readonly Quaternion[][] handNeutralRotations=new Quaternion[2][];
  private readonly Vector3[][] handNeutralPositions=new Vector3[2][],handNeutralScales=new Vector3[2][];
  private Transform handGripModel;
  private Transform handGripCalibrationModel;
  private Vector3 handGripPosition;
  private Quaternion handGripRotation;
  private readonly Transform[] handsWrists=new Transform[2];
  private readonly Quaternion[] handsCorrections=new Quaternion[2];
  private float nextHandsDiscovery;
  private bool handsScoped,handsFailed;
  private int handPreparedMask;
  private int handAnchorReports;
  private readonly int[][] handPalmVertices=new int[2][];
  private readonly bool[] handPalmCalibrated=new bool[2];
  private Quaternion[] leftRackRotations,rightProdRotations;
  private Transform leftPinchThumb,leftPinchIndex;
  private Material handsFillMaterial;

  // Private skinned hand geometry and copied finger bones. Native skeleton and
  // weapon parents are read-only; only the clones follow the controllers.
  private void PrepareControllerHands() {
   RestoreControllerHands();
   if(RadioStationActive())return;
   if(handsFailed||!controllerMotionEnabled||!ControllerVisualStateReady()||!questAvailabilityValue||questMenuScene||pauseMenuVisible||bookScreenVisible||dialogueScreenVisible||!(WeaponGameplayReady()||DoorNativeTraversing()||DoorCameraBlocked())||global::PlayerState.paused||global::PlayerState.eventScreen)return;
   try {
    if(handsSourceBody!=null&&(!handsSourceBody.gameObject.activeInHierarchy||handsVisualType!=NativePlayerVisualType()||handsVisualRoot!=NativePlayerVisualRoot())){DestroyControllerHands();nextHandsDiscovery=0;}
    if(handsModel==null) {
     if(Time.realtimeSinceStartup<nextHandsDiscovery)return;
     nextHandsDiscovery=Time.realtimeSinceStartup+2f;
     DestroyControllerHands();
     var attack=global::PlayerAttack.instance;if(attack==null)return;
     var animators=attack.transform.root.GetComponentsInChildren<Animator>(true);
     Animator player=null;
     foreach(var a in animators)if(a!=null&&a.isHuman&&a.transform.name=="Character Root"){player=a;break;}
     if(player==null)return;
     var model=player.transform;
     var visual=NativePlayerVisualRoot();
     var skins=(visual!=null?visual:model).GetComponentsInChildren<SkinnedMeshRenderer>(true);
     SkinnedMeshRenderer body=null;
     foreach(var s in skins)if(s!=null&&s.gameObject.activeInHierarchy&&s.enabled&&s.sharedMesh!=null&&s.sharedMesh.name=="Body_Suit"){body=s;break;}
     if(body==null)foreach(var s in skins)if(s!=null&&s.enabled&&s.gameObject.activeInHierarchy&&s.sharedMesh!=null&&s.sharedMesh.name=="Body"){body=s;break;}
     if(body==null)foreach(var candidate in skins)if(candidate!=null&&candidate.gameObject.activeInHierarchy&&candidate.sharedMesh!=null&&candidate.bones.Length>20&&(body==null||candidate.sharedMesh.vertexCount>body.sharedMesh.vertexCount))body=candidate;
     if(body==null)return;
     handsWrists[0]=player.GetBoneTransform(HumanBodyBones.LeftHand);
     handsWrists[1]=player.GetBoneTransform(HumanBodyBones.RightHand);
     for(int h=0;h<2;h++)CreateControllerHand(body,h);
     handsBody=new SkinnedMeshRenderer[skins.Length];handsBodyEnabled=new bool[skins.Length];
     for(int i=0;i<skins.Length;i++)handsBody[i]=skins[i];
     handsModel=model;handsSourceBody=body;handsVisualType=NativePlayerVisualType();handsVisualRoot=visual;
     MelonLogger.Msg("PLAYER HAND SOURCE: object="+body.name+" mesh="+body.sharedMesh.name+" bones="+body.bones.Length);
     MelonLogger.Msg("CONTROLLER HANDS: private left/right hand meshes ready; body hidden only during eligible stereo eye renders. Finger animation copied from native hands; palm-centered tracking and native right-hand grip.");
    }
    // Evaluate each hand independently: loss of one pose must not hide the other.
    int trackedMask=controllerVisibility;
    handPreparedMask=HandMeshSelection.ReadyMask(trackedMask,
     handsWrists[0]!=null&&handsRenderers[0]!=null,
     handsWrists[1]!=null&&handsRenderers[1]!=null);
    if(handPreparedMask==0)return;
    for(int i=0;i<handsBody.Length;i++)if(handsBody[i]!=null)handsBodyEnabled[i]=handsBody[i].enabled;
    handsScoped=true;
    for(int i=0;i<handsBody.Length;i++)if(handsBody[i]!=null)handsBody[i].enabled=false;
    handGripModel=null;
    var attackForGrip=global::PlayerAttack.instance;
    if(attackForGrip!=null&&ControllerWeaponVisualReady()) {
     var gun=EquippedControllerGun(FindRifleOwner(attackForGrip));
     if(gun!=null) {
      handGripModel=gun.transform;
      if(handGripCalibrationModel!=handGripModel) {
       handGripCalibrationModel=handGripModel;
       handGripPosition=handGripModel.InverseTransformPoint(handsWrists[1].position);
       handGripRotation=Quaternion.Inverse(handGripModel.rotation)*handsWrists[1].rotation;
      }
     }
    }
    for(int h=0;h<2;h++) {
     if((handPreparedMask&(1<<h))==0)continue;
     bool holdingProd=h==1&&(ProdEligible()||ThermiteEligible()||heldQuickHealth!=null||heldEidetic);
     var sources=handSourceBones[h];var copies=handCopyBones[h];
     for(int i=0;i<sources.Length;i++)if(sources[i]!=null&&sources[i]!=handsWrists[h]) {
      bool gripping=h==1&&handGripModel!=null;
      copies[i].localPosition=gripping?sources[i].localPosition:handNeutralPositions[h][i];
      copies[i].localRotation=gripping?sources[i].localRotation:handNeutralRotations[h][i];
      copies[i].localScale=gripping?sources[i].localScale:handNeutralScales[h][i];
      if(holdingProd&&rightProdRotations!=null)copies[i].localRotation=rightProdRotations[i];
      if(h==0&&leftRackRotations!=null&&(manualReload.Stage==ManualReloadPolicy.Step.Holding||shotgunReload.Stage==ShotgunReloadPolicy.Step.Holding||shotgunReload.Stage==ShotgunReloadPolicy.Step.Pumping||AdditionalHoldingAmmo()||smgReload.Stage==ManualReloadPolicy.Step.RackHolding))copies[i].localRotation=Quaternion.Slerp(handNeutralRotations[0][i],leftRackRotations[i],.8f);
     }
     var t=handsObjects[h].transform;var controller=controllerMarkers[h].transform;
     // Thumb up, palms inward. Hand geometry has its own bind axes: do not
     // reuse the gun's 45-degree correction for an already normalized palm.
     // Mirror the 45-degree palm-plane turn on the left; retain accepted right.
     // Apply before bind-axis conversion; the palm anchor is solved below.
     var palmTrim=Quaternion.Euler(0f,h==0?-40f:45f,0f);
     t.rotation=controller.rotation*Quaternion.Euler(0f,0f,h==0?90f:-90f)*palmTrim*handsCorrections[h];
     t.localScale=handsWrists[h].lossyScale;
     t.position=HandPlacement.PalmAnchor(HandPlacement.TrackedPalm(controller.position,controller.rotation,UnitsPerMetre),t.rotation,handPalmCenters[h],t.localScale);
     CalibrateRenderedPalm(h,controller.position);
     if(handAnchorReports<2) {
      var actualPalm=t.TransformPoint(handPalmCenters[h]);
      MelonLogger.Msg("HAND PLACEMENT: hand="+h+" controller="+WeaponVector(controller.position)+" palm="+WeaponVector(actualPalm)+" wrist="+WeaponVector(t.position)+" scale="+WeaponVector(t.localScale));handAnchorReports++;
     }
     handsRenderers[h].enabled=true;
     controllerBodies[h].enabled=controllerTips[h].enabled=false;
     for(int axis=0;axis<3;axis++)if(handPositionCrosses[h,axis]!=null)handPositionCrosses[h,axis].enabled=false;
    }
   }catch(Exception ex){RestoreControllerHands();DestroyControllerHands();handsFailed=true;MelonLogger.Warning("Controller hands disabled; prior visuals retained: "+ex.Message);}
  }
  private void CreateControllerHand(SkinnedMeshRenderer body,int hand) {
   var source=body.sharedMesh;if(!source.isReadable)throw new InvalidOperationException("Body mesh is not readable");
   var wrist=handsWrists[hand];if(wrist==null)throw new InvalidOperationException("Wrist missing");
   var bones=body.bones;var allowed=new bool[bones.Length];int wristIndex=-1,middleIndex=-1,indexIndex=-1,pinkyIndex=-1;
   for(int i=0;i<bones.Length;i++)if(bones[i]!=null) {
    allowed[i]=bones[i]==wrist||bones[i].IsChildOf(wrist);
    if(bones[i]==wrist)wristIndex=i;
    if(allowed[i]) {
     string n=bones[i].name.ToLowerInvariant();
     if(n.Contains("middle")&&n.Contains("01"))middleIndex=i;
     if(n.Contains("index")&&n.Contains("01"))indexIndex=i;
     if(n.Contains("pinky")&&n.Contains("01"))pinkyIndex=i;
    }
   }
   if(wristIndex<0||middleIndex<0||indexIndex<0||pinkyIndex<0)throw new InvalidOperationException("Hand bind axes missing");
   var weights=source.boneWeights;var include=new bool[source.vertexCount];
   if(weights.Length!=include.Length)throw new InvalidOperationException("Hand skin weights missing");
   for(int i=0;i<include.Length;i++) {
    var w=weights[i];float sum=0;
    if(HandMeshSelection.BoneAllowed(allowed,w.boneIndex0))sum+=w.weight0;
    if(HandMeshSelection.BoneAllowed(allowed,w.boneIndex1))sum+=w.weight1;
    if(HandMeshSelection.BoneAllowed(allowed,w.boneIndex2))sum+=w.weight2;
    if(HandMeshSelection.BoneAllowed(allowed,w.boneIndex3))sum+=w.weight3;
    include[i]=sum>=.99f;
   }
   CacheFingerPads(hand,source,allowed);
   var bind=source.bindposes;var toWrist=bind[wristIndex];
   var forward=toWrist.MultiplyPoint3x4(bind[middleIndex].inverse.MultiplyPoint3x4(Vector3.zero));
   var across=toWrist.MultiplyPoint3x4(bind[indexIndex].inverse.MultiplyPoint3x4(Vector3.zero))-toWrist.MultiplyPoint3x4(bind[pinkyIndex].inverse.MultiplyPoint3x4(Vector3.zero));
   var up=Vector3.Cross(across,forward)*(hand==1?1f:-1f);
   if(forward.sqrMagnitude<.000001f||up.sqrMagnitude<.000001f)throw new InvalidOperationException("Degenerate hand bind axes");
   handsCorrections[hand]=Quaternion.Inverse(Quaternion.LookRotation(forward,up));
   var mesh=UnityEngine.Object.Instantiate(source);handsMeshes[hand]=mesh;mesh.name="SignalisVR_HandOnly_"+hand;
   // Anchor to the actual palm surface, not an assumed distance along a bone.
   // Only retained vertices with a majority wrist weight define the palm.
   var usedPalm=new bool[include.Length];var positions=source.vertices;
   for(int sub=0;sub<source.subMeshCount;sub++) {
    var tris=source.GetTriangles(sub);
    for(int k=0;k<tris.Length;k+=3)if(include[tris[k]]&&include[tris[k+1]]&&include[tris[k+2]])
     for(int j=0;j<3;j++)usedPalm[tris[k+j]]=true;
   }
   Vector3 palmSum=Vector3.zero;int palmCount=0;var palmIndices=new List<int>();
   for(int i=0;i<usedPalm.Length;i++)if(usedPalm[i]) {
    var w=weights[i];float wristWeight=(w.boneIndex0==wristIndex?w.weight0:0f)+(w.boneIndex1==wristIndex?w.weight1:0f)+(w.boneIndex2==wristIndex?w.weight2:0f)+(w.boneIndex3==wristIndex?w.weight3:0f);
    if(wristWeight<.5f)continue;
    palmSum+=toWrist.MultiplyPoint3x4(positions[i]);palmCount++;palmIndices.Add(i);
   }
   if(palmCount<3)throw new InvalidOperationException("Cannot establish palm surface anchor");
   handPalmCenters[hand]=palmSum/palmCount;handPalmVertices[hand]=palmIndices.ToArray();handPalmCalibrated[hand]=false;
   MelonLogger.Msg("HAND PALM ANCHOR: hand="+hand+" vertices="+palmCount+" local="+WeaponVector(handPalmCenters[hand]));
   int count=0;
   for(int sub=0;sub<mesh.subMeshCount;sub++) {
    var raw=source.GetTriangles(sub);var indices=new int[raw.Length];for(int i=0;i<raw.Length;i++)indices[i]=raw[i];
    var selected=HandMeshSelection.Filter(indices,include);count+=selected.Length/3;mesh.SetTriangles(selected,sub);
   }
   if(count<10)throw new InvalidOperationException("Too few hand triangles: "+count);
   CloseHandSurface(mesh);
   mesh.RecalculateBounds();
   var root=new GameObject("SignalisVR_CharacterHand_"+hand);handsObjects[hand]=root;root.layer=30;
   UnityEngine.Object.DontDestroyOnLoad(root);
   // Retain source mesh bindposes. For each kept bone, the copied world matrix
   // drives standard GPU skinning; discarded body bones map to the wrist.
   var sources=new Transform[bones.Length];var copies=new Transform[bones.Length];
   for(int i=0;i<bones.Length;i++)if(allowed[i]) {
    sources[i]=bones[i];
    if(i==wristIndex)copies[i]=root.transform;
    else {copies[i]=new GameObject("SignalisVR_"+bones[i].name).transform;copies[i].SetParent(root.transform,false);}
   }
   for(int i=0;i<bones.Length;i++)if(allowed[i]&&i!=wristIndex) {
    Transform parent=root.transform;
    for(int j=0;j<bones.Length;j++)if(allowed[j]&&bones[j]==bones[i].parent){parent=copies[j];break;}
    copies[i].SetParent(parent,false);
    copies[i].localPosition=bones[i].localPosition;copies[i].localRotation=bones[i].localRotation;copies[i].localScale=bones[i].localScale;
   }
   for(int i=0;i<bones.Length;i++)if(copies[i]==null)copies[i]=root.transform;
   handSourceBones[hand]=sources;handCopyBones[hand]=copies;
   if(hand==0)for(int i=0;i<bones.Length;i++)if(allowed[i]){string n=bones[i].name.ToLowerInvariant();if(n.Contains("thumb_02"))leftPinchThumb=copies[i];if(n.Contains("index_02"))leftPinchIndex=copies[i];}
   handNeutralRotations[hand]=new Quaternion[bones.Length];handNeutralPositions[hand]=new Vector3[bones.Length];handNeutralScales[hand]=new Vector3[bones.Length];
   if(hand==0)leftRackRotations=new Quaternion[bones.Length];
   if(hand==1)rightProdRotations=new Quaternion[bones.Length];
   for(int i=0;i<bones.Length;i++)if(allowed[i]&&i!=wristIndex) {
    int parentIndex=wristIndex;
    for(int j=0;j<bones.Length;j++)if(allowed[j]&&bones[j]==bones[i].parent){parentIndex=j;break;}
    var localBind=bind[parentIndex]*bind[i].inverse;
    handNeutralPositions[hand][i]=localBind.MultiplyPoint3x4(Vector3.zero);
    handNeutralScales[hand][i]=localBind.lossyScale;
    // Gentle inward bend around each finger's bind-space palm-width axis.
    // Thumb retains its bind pose; no actor weapon animation on an empty hand.
    var rot=localBind.rotation;var name=bones[i].name.ToLowerInvariant();
    if(!name.Contains("thumb")) {
     var width=bind[i].MultiplyVector(bind[wristIndex].inverse.MultiplyVector(across)).normalized;
     float curl=name.Contains("01")?10f:18f;
     rot=rot*Quaternion.AngleAxis(curl*(hand==1?-1f:1f),width);
    }
    handNeutralRotations[hand][i]=rot;
    if(hand==1) {
     var width=bind[i].MultiplyVector(bind[wristIndex].inverse.MultiplyVector(across)).normalized;
     float curl=name.Contains("thumb")?(name.Contains("01")?25f:35f):(name.Contains("01")?55f:(name.Contains("02")?75f:45f));
     rightProdRotations[i]=localBind.rotation*Quaternion.AngleAxis(-curl,width);
    }
    if(hand==0) {
     var width=bind[i].MultiplyVector(bind[wristIndex].inverse.MultiplyVector(across)).normalized;
     // Rear-serration pinch: relatively straight opposing thumb, hooked index,
     // progressively tucked remaining fingers instead of an identical fist.
     float curl=name.Contains("thumb")?(name.Contains("01")?12f:8f):
      name.Contains("index")?(name.Contains("01")?35f:(name.Contains("02")?80f:45f)):
      (name.Contains("01")?55f:(name.Contains("02")?85f:55f));
     leftRackRotations[i]=localBind.rotation*Quaternion.AngleAxis(curl,width);
    }
   }
   var renderer=root.AddComponent<SkinnedMeshRenderer>();handsRenderers[hand]=renderer;renderer.enabled=false;
   renderer.sharedMesh=mesh;renderer.bones=copies;renderer.rootBone=root.transform;
   // Controller-local hands must not inherit room occlusion decisions for the native body.
   // Keep depth testing: nearby walls still occlude the actual visible geometry.
   renderer.allowOcclusionWhenDynamic=false;
   renderer.localBounds=new Bounds(Vector3.zero,Vector3.one*10f);renderer.updateWhenOffscreen=true;
   var handMaterials=new Material[body.sharedMaterials.Length+1];
   for(int i=0;i<body.sharedMaterials.Length;i++)handMaterials[i]=body.sharedMaterials[i];
   if(handsFillMaterial==null){handsFillMaterial=new Material(Shader.Find("Unlit/Color"));handsFillMaterial.color=new Color(.015f,.018f,.02f,1f);}
   handMaterials[handMaterials.Length-1]=handsFillMaterial;renderer.sharedMaterials=handMaterials;
   foreach(var material in body.sharedMaterials)if(material!=null)MelonLogger.Msg("HAND MATERIAL: hand="+hand+" material="+material.name+" shader="+(material.shader==null?"null":material.shader.name));
   renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;renderer.receiveShadows=false;
   MelonLogger.Msg("CONTROLLER HANDS: hand="+hand+" triangles="+count+" source="+source.name);
  }
  // Called after the existing weapon scope moves the gun. Use the very same
  // rigid change of frame for the wrist; preserve the animated finger grip.
  private void AlignControllerHandGrip() {
   if((handPreparedMask&2)==0||!handsScoped||renderedWeapon==null||handGripModel==null||handsObjects[1]==null)return;
   try {
    var t=handsObjects[1].transform;
    t.position=handGripModel.TransformPoint(handGripPosition);
    t.rotation=handGripModel.rotation*handGripRotation;
   }catch(Exception ex){RestoreControllerHands();handsFailed=true;MelonLogger.Warning("Hand grip disabled: "+ex.Message);}
  }
  private void RestoreControllerHands() {
   HideElsterPlayer();
   HideApprovedGunPoses();
   for(int h=0;h<2;h++)if(handsRenderers[h]!=null)handsRenderers[h].enabled=false;
   if(handsScoped&&handsBody!=null)for(int i=0;i<handsBody.Length;i++)if(handsBody[i]!=null)handsBody[i].enabled=handsBodyEnabled[i];
   handsScoped=false;handPreparedMask=0;
  }
  private void DestroyControllerHands() {
   DestroyElsterPlayer();
   DestroyApprovedGunPoses();
   RestoreControllerHands();
   for(int h=0;h<2;h++) {
    if(handsObjects[h]!=null)UnityEngine.Object.Destroy(handsObjects[h]);
    if(handsMeshes[h]!=null)UnityEngine.Object.Destroy(handsMeshes[h]);
    handsObjects[h]=null;handsMeshes[h]=null;handsRenderers[h]=null;handsWrists[h]=null;handSourceBones[h]=null;handCopyBones[h]=null;handNeutralPositions[h]=null;handNeutralRotations[h]=null;handNeutralScales[h]=null;handPalmVertices[h]=null;handPalmCalibrated[h]=false;
   }
   fingerPads[0]=fingerPads[1]=null;gripPrevious[0]=gripPrevious[1]=null;gripFrames[0]=gripFrames[1]=-1;
   handsModel=null;handsSourceBody=null;handsBody=null;handsBodyEnabled=null;handGripModel=null;
   handGripCalibrationModel=null;heldPoseModel=null;
   leftRackRotations=null;rightProdRotations=null;
   leftPinchThumb=null;leftPinchIndex=null;
   if(handsFillMaterial!=null)UnityEngine.Object.Destroy(handsFillMaterial);handsFillMaterial=null;
  }
 }
 internal static class HandMeshSelection {
  internal static int ReadyMask(int trackedMask,bool leftReady,bool rightReady){return trackedMask&((leftReady?1:0)|(rightReady?2:0));}
  internal static bool BoneAllowed(bool[] allowed,int index){return index>=0&&index<allowed.Length&&allowed[index];}
  internal static int[] Filter(int[] triangles,bool[] include) {
   if(triangles.Length%3!=0)throw new ArgumentException("Incomplete triangle");
   var result=new List<int>();
   for(int i=0;i<triangles.Length;i+=3) {
    int a=triangles[i],b=triangles[i+1],c=triangles[i+2];
    if(BoneAllowed(include,a)&&BoneAllowed(include,b)&&BoneAllowed(include,c)){result.Add(a);result.Add(b);result.Add(c);}
   }
   return result.ToArray();
  }
 }
}









