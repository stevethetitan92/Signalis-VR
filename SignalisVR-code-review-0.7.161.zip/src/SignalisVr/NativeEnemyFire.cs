using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed class LivingBurnClock {
  public float Age;public int Ticks;
  public int Advance(float dt){if(float.IsNaN(dt)||float.IsInfinity(dt)||dt<=0)return 0;Age=Math.Min(6,Age+dt);int due=Math.Min(6,(int)Math.Floor(Age+0.00001f));int count=due-Ticks;Ticks=due;return count;}
 }
 public sealed partial class Tracking {
  private sealed class LivingBurn {internal global::EnemyController Enemy;internal global::SignalFlare Point;internal ThermiteFlight Visual;internal global::Room Room;internal LivingBurnClock Clock=new LivingBurnClock();internal int Damage;}
  private readonly List<LivingBurn> livingBurns=new List<LivingBurn>();
  private void BeginNativeEnemyFire(global::EnemyController enemy,int damage=4){
   if(!FireEnemyValid(enemy))return;
   try{
    if(ProdEnemyValid(enemy))enemy.WakeUpfromGunShot();
    // Native material animation starts immediately, without Fire's forced fall/AI state.
    if(enemy.BurnEffect!=null&&!enemy.BurnEffect.burning)enemy.BurnEffect.Burn();
    RecordIncineration(enemy);
    foreach(var active in livingBurns)if(active.Enemy==enemy){active.Clock=new LivingBurnClock();active.Damage=damage;return;}
    global::SignalFlare point=null;
    if(enemy.flares!=null&&enemy.flares.flarePoints!=null&&enemy.flares.flarePoints.Count>0){
     bool valid=true;foreach(var p in enemy.flares.flarePoints)if(p==null)valid=false;
     if(valid)point=enemy.flares.getClosestFlare();
    }
    // Never start SignalFlare FX: its native flat-view glare/particles can fill
    // stereo eyes. Keep native body burn material and our existing damage clock.
    var visual=CreateBoundedImpactFlame(point!=null?point.transform.position:enemy.transform.position);
    if(!ProdEnemyValid(enemy))enemy.permadeath=true;
    livingBurns.Add(new LivingBurn{Enemy=enemy,Point=point,Visual=visual,Room=global::PlayerState.currentRoom,Damage=damage});
    MelonLoader.MelonLogger.Msg("LIVING BURN: native body material/bounded impact flame; no forced reaction; damage/sec="+damage+" duration=6");
   }catch(Exception ex){MelonLoader.MelonLogger.Warning("Native enemy burn failed: "+ex.Message);}
  }
  private ThermiteFlight CreateBoundedImpactFlame(Vector3 position){
   GameObject root=null;
   try{root=new GameObject("SignalisVR_BoundedImpactFlame");root.transform.localScale=Vector3.one*UnitsPerMetre;root.transform.position=position;
    var visual=new ThermiteFlight{Root=root,Projectile=true};AddThermiteFlame(visual);visual.Bounds=new Bounds(Vector3.zero,Vector3.zero);return visual;
   }catch(Exception ex){if(root!=null)UnityEngine.Object.Destroy(root);MelonLoader.MelonLogger.Warning("Impact flame unavailable; damage retained: "+ex.Message);return null;}
  }

  private void PollLivingBurns(){
   bool audible=ProdVrMode()&&!global::PlayerState.paused&&WeaponGameplayReady()&&!modMenuOpen&&!pauseMenuVisible;
   for(int i=livingBurns.Count-1;i>=0;i--){var burn=livingBurns[i];
    if(!FireEnemyValid(burn.Enemy)||burn.Room!=global::PlayerState.currentRoom){EndLivingBurn(burn);livingBurns.RemoveAt(i);continue;}
    if(burn.Visual!=null&&burn.Visual.Root!=null){burn.Visual.Root.transform.position=burn.Point!=null?burn.Point.transform.position:burn.Enemy.transform.position;burn.Visual.Expires=Time.time+Mathf.Max(0,6-burn.Clock.Age);UpdateThermiteAudio(burn.Visual,Time.time,audible);if(audible)AnimateThermiteFlame(burn.Visual,Time.time);}
    if(!audible)continue;
    int ticks=burn.Clock.Advance(Mathf.Max(0,Time.deltaTime));
    if(ProdEnemyValid(burn.Enemy)&&ticks>0){
     var e=burn.Enemy;e.hitbox.HP=Math.Max(0,e.hitbox.HP-ticks*burn.Damage);
     // No hurt/stagger reaction for nonlethal ticks. Native death handling only at zero HP.
     if(e.hitbox.HP<=0){e.permadeath=true;e.TakeDamage(0f,0f,0f,true);}
    }
    if(!ProdEnemyValid(burn.Enemy))burn.Enemy.permadeath=true;
    if(burn.Clock.Age>=6){EndLivingBurn(burn);livingBurns.RemoveAt(i);}
   }
  }
  private void EndLivingBurn(LivingBurn burn){if(burn.Visual!=null)DisposeThermiteFlight(burn.Visual);}
  private void DestroyLivingBurns(){foreach(var burn in livingBurns)EndLivingBurn(burn);livingBurns.Clear();enemyEligibility.Clear();}
 }
}


