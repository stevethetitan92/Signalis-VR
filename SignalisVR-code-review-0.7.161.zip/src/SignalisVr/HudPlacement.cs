using System;
using UnityEngine;
namespace SignalisVrTracking {
 public static class HudPlacementPolicy {
  public static float Clamp(float value,float limit){return float.IsNaN(value)||float.IsInfinity(value)?0:Math.Max(-limit,Math.Min(limit,value));}
  public static float Move(float value,float axis,float dt,float limit){axis=Clamp(axis,1);if(Math.Abs(axis)<.15f)axis=0;return Clamp(value+axis*.08f*Math.Max(0,Math.Min(.05f,dt)),limit);}
 }
 public sealed partial class Tracking {
  private Vector3 hudPlacementOffset,hudPlacementLeftOffset,hudPlacementForearmOffset,hudPlacementDraft;
  private bool modHudForearm;
  private bool hudPlacementEditing,hudPlacementChoosing,hudPlacementBack;
  private int hudPlacementHand=1;
  private float hudPlacementLeftTrigger,hudPlacementRightTrigger;
  private readonly Texture2D[] hudPlacementArms=new Texture2D[2];
  private void CycleHudMode(int direction){int mode=modHudOn?(modHudRight?2:1):0;mode=(mode+direction+3)%3;modHudOn=mode!=0;modHudForearm=false;if(modHudOn)modHudRight=mode==2;}
  private void OpenHudPlacement(){hudPlacementHand=modHudRight?1:0;hudPlacementChoosing=true;modSettingsError=null;}
  private void EditHudPlacement(){hudPlacementHand=hudPlacementHand==0?0:1;hudPlacementDraft=hudPlacementHand==1?hudPlacementOffset:hudPlacementLeftOffset;hudPlacementChoosing=false;hudPlacementEditing=true;}
  private void DrawHudHandChoice(float x,float y,float width,float s){
   MenuText(new Rect(x,y+180*s,800*s,70*s),"HUD PLACEMENT",Color.white,modMenuTitle);
   MenuText(new Rect(x,y+265*s,800*s,100*s),"LEFT STICK UP / DOWN: SELECT PLACEMENT\nA: OPEN    B: BACK",Color.white,modMenuHelp);
   float bx=x+width-420*s;
   if(MenuRow(new Rect(bx,y+210*s,390*s,70*s),"LEFT HAND",hudPlacementHand==0)){hudPlacementHand=0;EditHudPlacement();}
   MenuText(new Rect(bx,y+290*s,390*s,55*s),"or",Color.white,modMenuStyle);
   if(MenuRow(new Rect(bx,y+355*s,390*s,70*s),"RIGHT HAND",hudPlacementHand==1)){hudPlacementHand=1;EditHudPlacement();}
  }
  private void SaveHudPlacement(){
   var old=hudPlacementOffset;var oldLeft=hudPlacementLeftOffset;var oldForearm=hudPlacementForearmOffset;bool oldRight=modHudRight,oldMode=modHudForearm;
   if(hudPlacementHand==1)hudPlacementOffset=hudPlacementDraft;else hudPlacementLeftOffset=hudPlacementDraft;
   modHudRight=hudPlacementHand!=0;modHudForearm=false;
   try{SaveModSettings();hudPlacementEditing=false;modSettingsError=null;}
   catch(Exception ex){hudPlacementOffset=old;hudPlacementLeftOffset=oldLeft;hudPlacementForearmOffset=oldForearm;modHudRight=oldRight;modHudForearm=oldMode;modSettingsError="Could not save placement. Press A to retry.";MelonLoader.MelonLogger.Warning("HUD placement save: "+ex.Message);}
  }
  private void MoveHudPlacement(float x,float y,float away,float towards){
   float dt=Time.unscaledDeltaTime;
   hudPlacementDraft=new Vector3(HudPlacementPolicy.Move(hudPlacementDraft.x,x,dt,.25f),HudPlacementPolicy.Move(hudPlacementDraft.y,y,dt,.25f),HudPlacementPolicy.Move(hudPlacementDraft.z,away-towards,dt,.2f));
  }
  private void DrawHudPlacement(float x,float y,float width,float s){
   int previewHand=hudPlacementHand==0?0:1;
   if(hudPlacementArms[previewHand]==null){var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(HdAsset.Read(previewHand==1?"hud-placement-arm.png":"hud-placement-left-arm.png")),true))throw new InvalidOperationException("HUD arm preview missing");tex.filterMode=FilterMode.Point;hudPlacementArms[previewHand]=tex;}
   PaintMenuRect(new Rect(x,y,width,44*s),new Color(.88f,.12f,.055f));MenuText(new Rect(x,y,width,44*s),"HUD PLACEMENT",Color.white,modMenuTitle);
   MenuText(new Rect(x,y+58*s,width,38*s),"LEFT STICK: UP / DOWN / LEFT / RIGHT",Color.white,modMenuHelp);
   MenuText(new Rect(x,y+98*s,width,38*s),"LEFT TRIGGER: AWAY    RIGHT TRIGGER: TOWARDS YOU",Color.white,modMenuHelp);
   MenuText(new Rect(x,y+138*s,width,38*s),"A: SAVE PLACEMENT    B: CANCEL",new Color(.42f,.8f,.9f),modMenuHelp);
   float px=x+(width-1100*s)/2,py=y+185*s;
   GUI.color=Color.white;GUI.DrawTexture(new Rect(px,py,1100*s,620*s),hudPlacementArms[previewHand]);
   // Same viewer-relative XYZ offset used by the live HUD, projected beside a fixed wrist.
   bool forearm=false;
   float depth=(forearm?.37f:.474f)+hudPlacementDraft.z-.015f,factor=1050f/depth;
   float hx=px+((forearm?635:(previewHand==1?517:583))+(hudPlacementDraft.x+(forearm?0:(previewHand==1?.055f:-.055f)))*factor)*s,hy=py+((forearm?365:241.8f)-(hudPlacementDraft.y+(forearm?.035f:.015f))*factor)*s;
   float size=.077f*factor*s;
   MenuText(new Rect(hx-size/2,hy-size*.43f,size,size*.3f),"100/100",Color.white,modMenuHelp);
   PaintMenuRect(new Rect(hx-size/2,hy,size,size*.064f),new Color(.45f,.83f,1));
   MenuText(new Rect(hx-size/2,hy+size*.13f,size,size*.3f),"AMMO 25 / 25",Color.white,modMenuHelp);
   var save=new Rect(x+width-270*s,y+755*s,260*s,50*s);PaintMenuRect(save,new Color(.88f,.12f,.055f));MenuText(save,"A  SAVE",Color.white,modMenuStyle);if(MenuClicked(save))SaveHudPlacement();
   MenuText(new Rect(x,y+815*s,width,38*s),modSettingsError??(forearm?"RIGHT FOREARM - A: SAVE":"STATIC ELSTER ARM PREVIEW"),Color.white,modMenuHelp);
  }
 }
}
