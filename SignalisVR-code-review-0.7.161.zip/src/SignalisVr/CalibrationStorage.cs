using System;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Il2CppSystem.Collections.Generic.Dictionary<global::AnItem,int> calibrationOriginalInventory;
  private bool calibrationRadioInstalled,calibrationOriginalInfiniteLife;
  private int calibrationOriginalHealth;
  private readonly System.Collections.Generic.Dictionary<global::AnItem,int> calibrationInventoryCounts=new System.Collections.Generic.Dictionary<global::AnItem,int>();
  private static readonly global::Items.itemlist[] CalibrationSupplies={global::Items.itemlist.Pistol,global::Items.itemlist.Revolver,global::Items.itemlist.Shotgun,global::Items.itemlist.Rifle,global::Items.itemlist.FlareGun,global::Items.itemlist.SMG,global::Items.itemlist.Taser,global::Items.itemlist.SignalFlare,global::Items.itemlist.Health25,global::Items.itemlist.Health50,global::Items.itemlist.Health100,global::Items.itemlist.HealthFast,global::Items.itemlist.Flashlight,global::Items.itemlist.PhotoModule};
  private static bool CalibrationReceiverName(global::AnItem __0,ref string __result){var q=weaponOwner;if(q==null||q.receiverCatalog==null||__0==null||__0.Pointer!=q.receiverCatalog.Pointer)return true;__result="Receiver";return false;}
  private static void CalibrationSupplyRetrieved(global::AnItem __0){var q=weaponOwner;if(q==null||q.calibrationRoot==null)return;if(__0!=null&&q.receiverCatalog!=null&&__0.Pointer==q.receiverCatalog.Pointer)global::RadioManager.moduleInstalled=true;q.RefillCalibrationStorage();}
  private static bool CalibrationReceiverEquip(global::InventoryBase __instance,global::AnItem __0){var q=weaponOwner;if(q==null||q.receiverCatalog==null||__0==null||__0.Pointer!=q.receiverCatalog.Pointer)return true;q.quickInventory=__instance;if(q.heldReceiver)q.ClearHeldModules();else q.EquipHeldModule("Receiver");return false;}
  private void InstallCalibrationStorage(HarmonyLib.Harmony h){
   h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryManager),"getName",new[]{typeof(global::AnItem)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(CalibrationReceiverName)));
   foreach(var types in new[]{new[]{typeof(global::AnItem)},new[]{typeof(global::AnItem),typeof(int)}})h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryManager),"retrieveItem",types),postfix:new HarmonyMethod(typeof(Tracking),nameof(CalibrationSupplyRetrieved)));
   h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"EquipTool",new[]{typeof(global::AnItem)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(CalibrationReceiverEquip)));
  }
  private int calibrationOriginalSlots,calibrationOriginalSettingsSlots,calibrationOriginalModules;
  private global::AnWeapon calibrationOriginalWeapon;
  private global::AnItem calibrationOriginalTool,calibrationOriginalAmmo,calibrationOriginalCurrent;
  private readonly System.Collections.Generic.Dictionary<global::AnWeapon,int> calibrationMagazines=new System.Collections.Generic.Dictionary<global::AnWeapon,int>();
  private static bool CalibrationInventoryActive(){return weaponOwner!=null&&weaponOwner.calibrationOriginalInventory!=null;}
  private void ValidateCalibrationStorage(){var all=global::InventoryManager.allItems;if(all==null||global::InventoryManager.elsterItems==null||global::PlayerState.settings==null)throw new InvalidOperationException("Inventory is not loaded");foreach(var id in CalibrationSupplies)if(!all.ContainsKey(id)||all[id]==null)throw new InvalidOperationException("Missing item definition: "+id);foreach(var id in StorageAmmo)if(!all.ContainsKey(id)||all[id]==null)throw new InvalidOperationException("Missing ammunition definition: "+id);}
  private void CreateCalibrationStorage(){
   ValidateCalibrationStorage();
   calibrationOriginalSlots=global::InventoryManager.maxSlots;calibrationOriginalSettingsSlots=global::PlayerState.settings.maxInventorySlots;calibrationOriginalModules=global::InventoryManager.modules;
   calibrationOriginalWeapon=global::InventoryManager.EquippedWeapon;calibrationOriginalTool=global::InventoryManager.EquippedTool;calibrationOriginalAmmo=global::InventoryManager.EquippedAmmo;calibrationOriginalCurrent=global::InventoryManager.CurrentItem;
   calibrationRadioInstalled=global::RadioManager.moduleInstalled;
   calibrationMagazines.Clear();foreach(var pair in global::InventoryManager.allWeapons)if(pair.Value!=null)calibrationMagazines[pair.Value]=pair.Value.magAmmo;
   calibrationOriginalHealth=global::PlayerState.hp;calibrationOriginalInfiniteLife=infiniteLife;
   calibrationOriginalInventory=global::InventoryManager.elsterItems;calibrationInventoryCounts.Clear();foreach(var pair in calibrationOriginalInventory)calibrationInventoryCounts[pair.Key]=pair.Value;
   global::InventoryManager.elsterItems=new Il2CppSystem.Collections.Generic.Dictionary<global::AnItem,int>();
   foreach(var pair in calibrationOriginalInventory)if(pair.Key!=null&&pair.Key._item==global::Items.itemlist.None)global::InventoryManager.elsterItems[pair.Key]=pair.Value;
   global::PlayerState.settings.maxInventorySlots=50;global::InventoryManager.maxSlots=50;
   var receiver=ReceiverCatalog();receiver._item=(global::Items.itemlist)RadioItemId;receiver.type=global::AnItem.AnItemType.Tool;receiver.maxNumber=1;receiver.Image=receiver.Icon;
   global::RadioManager.moduleInstalled=true;
   RefillCalibrationStorage();
  }
  private void RefillCalibrationStorage(){
   if(calibrationOriginalInventory==null||calibrationRoot==null)return;var all=global::InventoryManager.allItems;var items=global::InventoryManager.elsterItems;if(all==null||items==null)return;
   global::PlayerState.settings.maxInventorySlots=50;global::InventoryManager.maxSlots=50;
   foreach(var id in CalibrationSupplies){var item=all[id];int count=item.type==global::AnItem.AnItemType.Health?Math.Max(1,item.maxNumber):id==global::Items.itemlist.Taser||id==global::Items.itemlist.SignalFlare?3:1;if(!items.ContainsKey(item)||items[item]<count)items[item]=count;}
   foreach(var id in StorageAmmo){var item=all[id];int count=Math.Max(1,item.maxNumber);if(!items.ContainsKey(item)||items[item]<count)items[item]=count;}
   // Receiver ownership is provided by moduleInstalled; avoid a duplicate None-ID inventory entry.
  }
  private void RestoreCalibrationStorage(){
   if(calibrationOriginalInventory==null)return;
   ClearHeldModules();CancelManualReload();
   calibrationOriginalInventory.Clear();foreach(var pair in calibrationInventoryCounts)calibrationOriginalInventory[pair.Key]=pair.Value;calibrationInventoryCounts.Clear();
   global::InventoryManager.elsterItems=calibrationOriginalInventory;global::PlayerState.hp=calibrationOriginalHealth;infiniteLife=calibrationOriginalInfiniteLife;
   global::InventoryManager.EquippedWeapon=calibrationOriginalWeapon;global::InventoryManager.EquippedTool=calibrationOriginalTool;global::InventoryManager.EquippedAmmo=calibrationOriginalAmmo;global::InventoryManager.CurrentItem=calibrationOriginalCurrent;
   foreach(var pair in calibrationMagazines)if(pair.Key!=null)pair.Key.magAmmo=pair.Value;calibrationMagazines.Clear();
   global::InventoryManager.modules=calibrationOriginalModules;global::InventoryManager.maxSlots=calibrationOriginalSlots;global::PlayerState.settings.maxInventorySlots=calibrationOriginalSettingsSlots;
   global::RadioManager.moduleInstalled=calibrationRadioInstalled;calibrationOriginalInventory=null;
  }
 }
}

