using System;
using System.IO;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class SaveImageAttempt {public Texture2D Reference,Image;public string Packed;}
 [ThreadStatic] private static SaveImageAttempt pendingSaveImage;
 [ThreadStatic] private static bool checkingSaveImage;
 private static void PackSaveImage(Texture2D __0,ref string __1,out SaveImageAttempt __state){
  pendingSaveImage=null;
  if(__0==null||__1==null)throw new InvalidDataException("Missing save image/data; previous file preserved");
  string packed=SaveCompression.Pack(__1);SaveCompression.CheckCapacity(packed,__0.width,__0.height);
  __state=new SaveImageAttempt{Reference=__0,Packed=packed};
  MelonLogger.Msg("SAVE IMAGE: lossless mod packing "+System.Text.Encoding.UTF8.GetByteCount(__1)+" -> "+System.Text.Encoding.UTF8.GetByteCount(packed)+" bytes.");__1=packed;
 }
 private static void SaveImageEncoded(Texture2D __result,SaveImageAttempt __state){
  if(__state==null)return;if(__result==null)throw new InvalidDataException("Native save encoder failed; previous file preserved");
  __state.Image=__result;pendingSaveImage=__state;
 }
 private static Exception SaveImageEncodeFinished(Exception __exception){if(__exception!=null)pendingSaveImage=null;return __exception;}
 private static void UnpackSaveImage(ref string __result){if(!checkingSaveImage)__result=SaveCompression.Expand(__result);}
 private static bool CommitSaveImage(Texture2D __0,string __1){
  var attempt=pendingSaveImage;pendingSaveImage=null;
  // Native WriteToDisk is only a save-image writer. An unpaired call must fail
  // before writing, rather than falling back to its destructive direct write.
  if(attempt==null||__0==null||attempt.Image!=__0)throw new InvalidDataException("Unverified save image rejected; previous file preserved");
  Texture2D reload=null;
  try{
   checkingSaveImage=true;
   if(global::Steganography.Decode(__0,attempt.Reference)!=attempt.Packed)throw new InvalidDataException("Save image round-trip mismatch");
   var bytes=ImageConversion.EncodeToPNG(__0);if(bytes==null||bytes.Length==0)throw new InvalidDataException("PNG encoding failed; previous file preserved");
   reload=new Texture2D(2,2,TextureFormat.RGBA32,false);
   if(!ImageConversion.LoadImage(reload,bytes)||global::Steganography.Decode(reload,attempt.Reference)!=attempt.Packed)throw new InvalidDataException("PNG save verification failed; previous file preserved");
   SaveCompression.Expand(attempt.Packed); // Validate compressed contents too.
   SaveCompression.Commit(__1,bytes);
   MelonLogger.Msg("SAVE IMAGE: verified file committed with previous-file backup.");return false;
  }finally{checkingSaveImage=false;if(reload!=null)UnityEngine.Object.Destroy(reload);}
 }
 private void InstallSaveImageProtection(){
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::Steganography),"Encode",new[]{typeof(Texture2D),typeof(string)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(PackSaveImage)),postfix:new HarmonyMethod(typeof(Tracking),nameof(SaveImageEncoded)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(SaveImageEncodeFinished)));
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::Steganography),"Decode",new[]{typeof(Texture2D),typeof(Texture2D)}),postfix:new HarmonyMethod(typeof(Tracking),nameof(UnpackSaveImage)));
  // ReadFromDisk is the native save loader boundary. Its internal decoder call
  // may bypass the patched Decode entry point; expansion is idempotent when both run.
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::Steganography),"ReadFromDisk",new[]{typeof(Texture2D),typeof(string)}),postfix:new HarmonyMethod(typeof(Tracking),nameof(UnpackSaveImage)));
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::Steganography),"WriteToDisk",new[]{typeof(Texture2D),typeof(string)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(CommitSaveImage)));
 }
}}
