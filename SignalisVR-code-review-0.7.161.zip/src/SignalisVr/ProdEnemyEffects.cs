using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class StunVisual {
  public GameObject Root;public Material Material;public LineRenderer[] Arcs;
  public readonly List<Transform> Bones=new List<Transform>();public readonly List<Quaternion> Rest=new List<Quaternion>();
  public Vector3 Centre,Size;
 }
 private void BeginStunVisual(ProdFrozen f){
  var v=new StunVisual();f.Visual=v;v.Root=new GameObject("SignalisVR_StunElectricity");v.Root.transform.SetParent(f.enemy.transform,false);
  v.Material=new Material(Shader.Find("Sprites/Default"));v.Material.color=new Color(.3f,.85f,1,1);
  bool first=true;var bounds=new Bounds();var seen=new HashSet<IntPtr>();
  foreach(var skin in f.enemy.GetComponentsInChildren<SkinnedMeshRenderer>(true)){
   if(first){bounds=skin.bounds;first=false;}else bounds.Encapsulate(skin.bounds);
   foreach(var bone in skin.bones){if(bone==null||!seen.Add(bone.Pointer))continue;var n=bone.name.ToLowerInvariant();
    if(n.Contains("spine")||n.Contains("neck")||n.Contains("head")||n.Contains("upperarm")||n.Contains("upper_arm")){v.Bones.Add(bone);v.Rest.Add(bone.localRotation);}
   }
  }
  // Use collider dimensions rather than artificially enlarged skin culling bounds.
  if(f.enemy._collider!=null)bounds=f.enemy._collider.bounds;
  v.Centre=f.enemy.transform.InverseTransformPoint(bounds.center);v.Size=new Vector3(.22f,1.4f,.18f)*UnitsPerMetre;
  if(f.enemy._collider!=null)v.Size=new Vector3(f.enemy._collider.radius*1.7f,f.enemy._collider.height*.85f,f.enemy._collider.radius*1.7f);
  v.Arcs=new LineRenderer[4];for(int i=0;i<4;i++){var g=new GameObject("Stun arc");g.transform.SetParent(v.Root.transform,false);var a=g.AddComponent<LineRenderer>();a.sharedMaterial=v.Material;a.useWorldSpace=true;a.positionCount=13;a.startWidth=a.endWidth=.002f*UnitsPerMetre;v.Arcs[i]=a;}
 }
 private void AnimateStunVisual(ProdFrozen f){
  var v=f.Visual;if(v==null)return;float t=Time.time;
  for(int i=0;i<v.Bones.Count;i++)if(v.Bones[i]!=null)v.Bones[i].localRotation=v.Rest[i]*Quaternion.Euler(Mathf.Sin(t*43+i*2)*3.2f,Mathf.Sin(t*31+i)*1.5f,Mathf.Sin(t*53+i*3)*2.4f);
  // Short, branching-looking surface strokes between bones, not orbiting helices.
  int tick=(int)(t*24);
  for(int k=0;k<v.Arcs.Length;k++){
   var arc=v.Arcs[k];arc.enabled=(tick+k)%4!=0;
   Vector3 start,end;
   if(v.Bones.Count>1){start=v.Bones[(k*2+tick/3)%v.Bones.Count].position;end=v.Bones[(k*2+tick/3+1)%v.Bones.Count].position;}
   else {var tr=f.enemy.transform;start=tr.TransformPoint(v.Centre+new Vector3((k%2==0?-1:1)*v.Size.x*.25f,-v.Size.y*.2f,0));end=start+controllerTrackingToWorld*Vector3.up*(.25f*UnitsPerMetre);}
   // Bone centres lie inside the body. Offset toward the visible torso surface,
   // alternating sides instead of drawing the discharge through the skeleton.
   var outward=f.enemy.transform.forward*(.085f*UnitsPerMetre)+f.enemy.transform.right*((k%2==0?-1:1)*.025f*UnitsPerMetre);
   for(int j=0;j<13;j++){float u=j/12f;float taper=Mathf.Sin(u*(float)Math.PI);
    var jitter=controllerTrackingToWorld*new Vector3(Mathf.Sin(j*71+tick*19+k*3),Mathf.Sin(j*37+tick*11),Mathf.Sin(j*17+tick*31+k))*taper*.012f*UnitsPerMetre;
    arc.SetPosition(j,Vector3.Lerp(start,end,u)+outward+jitter);
   }
  }
 }
 private void EndStunVisual(ProdFrozen f){var v=f.Visual;if(v==null)return;for(int i=0;i<v.Bones.Count;i++)if(v.Bones[i]!=null)v.Bones[i].localRotation=v.Rest[i];if(v.Root!=null)UnityEngine.Object.Destroy(v.Root);if(v.Material!=null)UnityEngine.Object.Destroy(v.Material);f.Visual=null;}
} }
