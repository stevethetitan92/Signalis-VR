using System;
using HarmonyLib;
using MelonLoader;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class InjectionScope {public global::AnItem previous,injector;}
 private static int injectionErrors;
 private static global::AnItem CarriedInjector(){
  var all=global::InventoryManager.allItems;var carried=global::InventoryManager.elsterItems;
  if(all==null||carried==null||!all.ContainsKey(global::Items.itemlist.HealthFast))return null;
  var item=all[global::Items.itemlist.HealthFast];
  return item!=null&&carried.ContainsKey(item)&&carried[item]>0?item:null;
 }
 private static bool injectorBusy;
 private static void ConfigureCarriedInjector(){
  var all=global::InventoryManager.allItems;if(all==null||!all.ContainsKey(global::Items.itemlist.HealthFast))return;
  var item=all[global::Items.itemlist.HealthFast];if(item==null)return;
  item.type=global::AnItem.AnItemType.Tool;
  item.keinModul=false; // Native inventory's module filter reads this flag, not type.
  var tools=global::InventoryManager.allTools;if(tools!=null)tools[global::Items.itemlist.HealthFast]=item;
 }
 private static bool TryCarriedInjection(){
  if(injectorBusy||!CheatPlayerReady()||global::PlayerState.hp>10||global::PlayerState.paused||global::PlayerState.cutscene||global::PlayerState.eventScreen)return false;
  var injector=CarriedInjector();if(injector==null)return false;
  injectorBusy=true;
  try{
   var previous=global::InventoryManager.EquippedTool;
   global::InventoryManager.RemoveItem(injector);
   global::PlayerState.hp=50;global::PlayerState.healElster();
   var carried=global::InventoryManager.elsterItems;
   if(previous!=injector&&previous!=null&&carried!=null&&carried.ContainsKey(previous)&&carried[previous]>0)global::InventoryManager.EquippedTool=previous;
   MelonLogger.Msg("AUTOINJECTOR: consumed one carried tool at <=10 health; restored to50/100.");
   return true;
  }catch(Exception ex){if(injectionErrors++<4)MelonLogger.Warning("Carried autoinjector: "+ex.Message);return false;}
  finally{injectorBusy=false;}
 }
 private static void PollCarriedAutoinjector(){ConfigureCarriedInjector();ApplyInventoryCapacity();TryCarriedInjection();}
 private static void BeginCarriedInjection(out InjectionScope __state){__state=null;TryCarriedInjection();} private static Exception EndCarriedInjection(Exception __exception,InjectionScope __state){
  if(__state==null)return __exception;
  try{
   var current=global::InventoryManager.EquippedTool;
   // Native consumption can clear the last injector. Preserve a different
   // tool intentionally selected by another callback instead of overwriting it.
   if(current==null||current==__state.injector){
    var previous=__state.previous;var carried=global::InventoryManager.elsterItems;
    global::InventoryManager.EquippedTool=previous!=null&&carried!=null&&carried.ContainsKey(previous)&&carried[previous]>0?previous:null;
   }
  }catch(Exception ex){if(injectionErrors++<4)MelonLogger.Warning("Autoinjector tool restoration: "+ex.Message);}
  return __exception;
 }
 private void InstallCarriedAutoinjector(HarmonyLib.Harmony h){
  h.Patch(AccessTools.DeclaredMethod(typeof(global::GameOverHandler),"hurt",new[]{typeof(int),typeof(UnityEngine.Vector2)}),
   prefix:new HarmonyMethod(typeof(Tracking),nameof(BeginCarriedInjection)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(EndCarriedInjection)));
 }
}}

