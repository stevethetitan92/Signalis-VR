using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  // Disabled, query-only colliders never participate in the game's physics world.
  private readonly List<MeshCollider> rifleContactMeshes=new List<MeshCollider>();
  private readonly MeshCollider[] rifleCaseContacts=new MeshCollider[2];
  private readonly Vector3[] rifleCaseVelocity=new Vector3[2];
  private readonly Vector3[] rifleCaseSpin=new Vector3[2];
  private readonly int[] rifleCaseChambers=new int[2];
  private readonly float[] rifleCaseSimAge=new float[2];
  private readonly bool[] rifleCaseFree=new bool[2];
  private void ResetRifleCaseContacts(){for(int i=0;i<2;i++){rifleCaseSimAge[i]=0;rifleCaseFree[i]=false;rifleCaseVelocity[i]=Vector3.zero;rifleCaseSpin[i]=Vector3.zero;}}
  private void EnsureRifleCaseContacts(int i){
   if(rifleContactMeshes.Count==0&&SelectedActive("Rifle"))foreach(var part in selectedParts){var c=part.gameObject.AddComponent<MeshCollider>();c.enabled=false;c.sharedMesh=part.GetComponent<MeshFilter>().sharedMesh;rifleContactMeshes.Add(c);}
   if(rifleCaseContacts[i]==null){var c=rifleCases[i].gameObject.AddComponent<MeshCollider>();c.enabled=false;c.sharedMesh=rifleCaseMesh;c.convex=true;rifleCaseContacts[i]=c;}
  }
  private void MoveRifleCase(int i,float age){
   EnsureRifleCaseContacts(i);var t=rifleCases[i].transform;
   if(rifleCaseSimAge[i]==0){t.position=rifleCaseOrigins[i];t.rotation=rifleCaseRotation;rifleCaseSpin[i]=rifleCaseChambers[i]==0?new Vector3(155,85,-55):new Vector3(-120,110,70);}
   // Bound linear and angular travel between queries, including low frame rates.
   while(rifleCaseSimAge[i]<age){
    float dt=Math.Min(.001f,age-rifleCaseSimAge[i]);rifleCaseSimAge[i]+=dt;
    if(!rifleCaseFree[i]&&rifleCaseSimAge[i]>=.11f){int chamber=rifleCaseChambers[i];rifleCaseFree[i]=true;rifleCaseVelocity[i]=rifleCaseRotation*new Vector3(RifleCaseMotion.LaunchX(chamber),RifleCaseMotion.LaunchY(chamber),RifleCaseMotion.LaunchZ(chamber))*UnitsPerMetre;}
    var old=t.position;var oldRotation=t.rotation;
    if(!rifleCaseFree[i]){rifleCaseVelocity[i]=rifleCaseRotation*Vector3.back*(.8f*UnitsPerMetre);t.position+=rifleCaseVelocity[i]*dt;}
    else{
     var gravity=controllerTrackingToWorld*Vector3.up*(-RifleCaseMotion.Gravity*UnitsPerMetre);var v=rifleCaseVelocity[i];
     var delta=new Vector3(RifleCaseMotion.Step(ref v.x,gravity.x,dt),RifleCaseMotion.Step(ref v.y,gravity.y,dt),RifleCaseMotion.Step(ref v.z,gravity.z,dt));rifleCaseVelocity[i]=v;
     // Rotate about the casing's centre of mass, not its rear cap.
     var half=new Vector3(0,0,.0375f*UnitsPerMetre);var centre=t.position+t.rotation*half;
     t.rotation=t.rotation*Quaternion.Euler(rifleCaseSpin[i]*dt);t.position=centre+delta-t.rotation*half;rifleCaseSpin[i]*=RifleCaseMotion.SpinDecay(dt);
    }
    bool unresolved=false;
    for(int pass=0;pass<4;pass++){
     unresolved=false;
     foreach(var c in rifleContactMeshes){if(c==null)continue;Vector3 direction;float depth;
      if(!Physics.ComputePenetration(rifleCaseContacts[i],t.position,t.rotation,c,c.transform.position,c.transform.rotation,out direction,out depth)||depth<=0)continue;
      unresolved=true;t.position+=direction*(depth+.0002f*UnitsPerMetre);float into=Vector3.Dot(rifleCaseVelocity[i],direction);
      if(into<0){var tangent=rifleCaseVelocity[i]-direction*into;rifleCaseVelocity[i]=tangent*.82f-direction*(RifleCaseMotion.Restitution*into);rifleCaseSpin[i]*=.65f;}rifleCaseFree[i]=true;
     }
     if(!unresolved)break;
    }
    // A wedged case stays at the last pose rather than being pushed through geometry.
    if(unresolved){t.position=old;t.rotation=oldRotation;rifleCaseVelocity[i]=Vector3.zero;rifleCaseSpin[i]=Vector3.zero;}
   }
  }
  private void DestroyRifleContactMeshes(){foreach(var c in rifleContactMeshes)if(c!=null)UnityEngine.Object.Destroy(c);rifleContactMeshes.Clear();}
 }
}
