using UnityEngine;
namespace SignalisVrTracking {
 public sealed class PauseHoldPolicy {
  private float started=-1;private bool latched,blocked;
  public bool Tap {get;private set;}
  public bool Consuming {get{return latched;}}
  public bool Update(bool available,bool held,float now){
   Tap=false;
   if(!held){Tap=available&&started>=0&&!latched&&!blocked;started=-1;latched=false;blocked=false;return false;}
   if(latched)return false;
   if(!available){started=-1;blocked=true;return false;}
   if(blocked)return false;
   if(started<0){started=now;return false;}
   if(now-started<3f)return false;
   latched=true;return true;
  }
 }
 public sealed partial class Tracking {
  private readonly PauseHoldPolicy pauseHold=new PauseHoldPolicy();
  private void PollPauseHold(bool inputAvailable,bool held){
   var pause=global::PauseMenu.instance;
   bool ready=inputAvailable&&questPolicy.LeftArmed&&!modMenuOpen&&inventoryWheelView==null&&WeaponGameplayReady()&&!global::PlayerState.paused&&!global::PlayerState.pauseMenu&&!global::PlayerState.eventScreen&&!global::PlayerState.cutscene&&pause!=null;
   if(pauseHold.Update(ready,held,Time.realtimeSinceStartup))pause.setPause(true);
   // Delay gameplay inventory until a short X release; long hold opens pause only.
   if(ready||pauseHold.Consuming)questFrame.buttons&=~(1<<2);
   if(pauseHold.Tap&&!heldReceiver)questFrame.buttons|=1<<2;
  }
 }
}
