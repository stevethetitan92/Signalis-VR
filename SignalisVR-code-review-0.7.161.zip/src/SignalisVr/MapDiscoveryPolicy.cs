using System;
namespace SignalisVrTracking {
 public static class MapDiscoveryPolicy {
  public static bool Discover(bool interacted,bool sameRoom,bool active,double metres){return interacted||(sameRoom&&active&&!double.IsNaN(metres)&&metres>=0&&metres<=1.5);}
  public static bool Sight(bool active,bool sameRoom,bool inView,bool clear){return active&&sameRoom&&inView&&clear;}
  public static bool Visible(bool complete,bool discovered,bool gone){return !gone&&(complete||discovered);}
  public static bool DoorVisible(bool complete,bool tried){return true;}
 }
}
