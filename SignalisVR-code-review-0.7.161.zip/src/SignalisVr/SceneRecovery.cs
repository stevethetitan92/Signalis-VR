using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly HotkeyEdge perspectiveKey = new HotkeyEdge();
  private bool immersiveRequested=true;
  private bool sceneRecoveryRequest,sceneRecoveryInstalled;
  private bool sceneRecoveryDraining;
  private float sceneStableSince=-1f,nextSceneRecovery,nextSnowReport;
  private int sceneRecoveryAttempts,sceneCandidateId;
  private void InstallSceneRecovery() {
   foreach(var mod in MelonHandler.Mods) {
    if(mod.GetType().FullName!="Camera_Perspective_Mod.PerspectiveChange")continue;
    var update=AccessTools.Method(mod.GetType(),"OnUpdate");
    if(update==null)throw new InvalidOperationException("Perspective update missing");
    questHarmony.Patch(update,transpiler:new HarmonyMethod(typeof(Tracking),nameof(SceneRecoveryTranspiler)));
    InstallNativeCutsceneCamera(mod.GetType().Assembly);sceneRecoveryInstalled=true;break;
   }
  }
  private static IEnumerable<CodeInstruction> SceneRecoveryTranspiler(IEnumerable<CodeInstruction> code) {
   int count=0,sceneGates=0; bool holeLiteral=false;
   foreach(var instruction in code) {
    var method=instruction.operand as MethodInfo;
    if(holeLiteral && method!=null && method.DeclaringType==typeof(string) && method.Name=="op_Inequality") {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(PerspectiveSceneAllowed));sceneGates++;
    }
    holeLiteral=instruction.opcode==OpCodes.Ldstr && (instruction.operand as string)=="PEN_Hole";
    if(method!=null&&method.DeclaringType==typeof(Input)&&method.Name=="GetKeyDown"&&method.GetParameters().Length==1&&method.GetParameters()[0].ParameterType==typeof(KeyCode)) {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(SceneRecoveryKey));count++;
    }
    yield return instruction;
   }
   if(sceneGates!=1)throw new InvalidOperationException("Unexpected perspective scene gate");
   if(count==0)throw new InvalidOperationException("Perspective keyboard reads missing");
  }
  private static bool PerspectiveSceneAllowed(string scene,string excluded) { return scene!=excluded; }
  private bool RedPitLayoutReady() {
   if(global::PlayerState.gameState!=global::PlayerState.gameStates.play || global::PlayerState.cutscene || global::PlayerState.suspendInput)return false;
   var root=GameObject.Find("__Prerequisites__/Character Origin/Character Root");
   var rig=GameObject.Find("__Prerequisites__/Angled Camera Rig/LocalSpace");
   var player=global::PlayerState.player;
   var control=player!=null?player.GetComponent<global::AlternatePlayerController>():null;
   return root!=null && rig!=null && control!=null && control.playing && !control.traversing
    && (root.transform.Find("Main Camera")!=null || rig.transform.Find("Main Camera")!=null);
  }
  private static bool SceneRecoveryKey(KeyCode key) {
   var q=questOwner;
   bool physical=key==KeyCode.F1 && q!=null
    ? q.perspectiveKey.Poll((GetAsyncKeyState(0x70)&0x8000)!=0)
    : Input.GetKeyDown(key);
   if(key!=KeyCode.F1||q==null||!q.sceneRecoveryRequest)return physical;
   q.sceneRecoveryRequest=false;
   return physical||(q.CanRecoverScene()&&q.NeedsScenePerspective());
  }
  // PEN_Hole walking uses its own event-screen camera, not the perspective mod.
  // Never convert the orthographic cinematic or red-shaft cameras.
  private bool IsSnowWalkCamera(Camera candidate) { return false; }
  private Camera FindSnowWalkCamera() { return null; }
  private bool snowWalkStereo;
  private bool CanRecoverScene() {
   if(!immersiveRequested||!questMenuScene||!active||!stereo||stopping||questInputStopped||system==null)return false;
   if(SceneManager.GetActiveScene().name=="PEN_Hole")return false;
   if(global::PlayerState.gameState!=global::PlayerState.gameStates.play||global::PlayerState.cutscene||global::PlayerState.suspendInput)return false;
   var root=GameObject.Find("__Prerequisites__/Character Origin/Character Root");
   if(root==null)return false;
   var player=global::PlayerState.player;
   var control=player!=null?player.GetComponent<global::AlternatePlayerController>():null;
   return control!=null&&control.playing&&!control.traversing;
  }
  private void UpdateSceneRecovery() {
   if(!immersiveRequested||!questMenuScene){sceneRecoveryDraining=false;return;}
   if(SceneManager.GetActiveScene().name=="PEN_Hole"&&Time.realtimeSinceStartup>=nextSnowReport) {
    nextSnowReport=Time.realtimeSinceStartup+10f;
    MelonLogger.Msg("SNOW CAMERA: state="+global::PlayerState.gameState+" cutscene="+global::PlayerState.cutscene);
    foreach(var c in Camera.allCameras) {
     if(c==null||c.name.StartsWith("SignalisVR_"))continue;
     MelonLogger.Msg("SNOW CAMERA: name="+c.name+" parent="+(c.transform.parent==null?"<none>":c.transform.parent.name)+" ortho="+c.orthographic+" target="+(c.targetTexture==null?"screen":c.targetTexture.name));
    }
   }
   if(!CanRecoverScene()){sceneRecoveryDraining=false;sceneStableSince=-1f;sceneRecoveryRequest=false;sceneCandidateId=0;return;}
   float now=Time.realtimeSinceStartup;
   var candidate=FindSnowWalkCamera() ?? FindGameplayCamera();
   int id=candidate==null?0:candidate.GetInstanceID();
   if(sceneStableSince<0f||id!=sceneCandidateId){sceneStableSince=now;sceneCandidateId=id;}
   if(candidate==null) {
    sceneRecoveryDraining=false;
    if(sceneRecoveryInstalled&&NeedsScenePerspective()&&now>=nextSceneRecovery) {
     sceneRecoveryAttempts++;nextSceneRecovery=now+3f;sceneRecoveryRequest=true;
     MelonLogger.Msg("SCENE RECOVERY: requesting original first-person camera, attempt="+sceneRecoveryAttempts);
    }
    return;
   }
   // Candidate lookup only returns a usable native gameplay camera.
   // No extra quarter-second flat hold once the native gameplay camera is usable.
   // Drain the prior flat-screen pose before reusing the retained eye textures.
   sceneRecoveryRequest=false;
   sceneRecoveryDraining=true;
   if(bridgeConfigured&&CancelPreparedPose()==0)return;
   camera=candidate;snowWalkStereo=IsSnowWalkCamera(candidate);
   if(snowWalkStereo)CenterSnowEntry(candidate);
   originalRotation=camera.transform.localRotation;
   recovery.Reset();waitingForGameplay=false;menuCaptureReady=false;
   diagnostic.Connected();diagnostic.RenderReady();
   if(!diagnostic.CanSubmit&&!diagnostic.BeginSubmit(now))return;
   questMenuScene=false;sceneRecoveryDraining=false;sceneRecoveryRequest=false;recenterPending=true;diagnosticFrames=0;
   MelonLogger.Msg("SCENE RECOVERY: stereo resumed with camera="+camera.name+" parent="+camera.transform.parent.name+" snow="+snowWalkStereo+". Headset verification required.");
  }
  // A hidden perspective camera is already converted: wait for native activation,
  // rather than sending F1 again and toggling it back into third person.
  private bool NeedsScenePerspective() {
   var go=GameObject.Find("__Prerequisites__/Character Origin/Character Root/Main Camera");
   var c=go==null?null:go.GetComponent<Camera>();
   return c==null||c.orthographic;
  }
  private readonly List<Renderer> cinematicBars=new List<Renderer>();
  private readonly List<Renderer> hiddenCinematicBars=new List<Renderer>();
  private readonly List<UnityEngine.UI.Graphic> cinematicBarGraphics=new List<UnityEngine.UI.Graphic>();
  private readonly List<UnityEngine.UI.Graphic> hiddenBarGraphics=new List<UnityEngine.UI.Graphic>();
  private float nextBarSearch;
  private float nextBarFullSearch;
  private int barSceneHandle=-1,barGameState=-1,barCameraId;
  private readonly Dictionary<int,int> scannedBarCameras=new Dictionary<int,int>();
  private readonly List<Camera> knownBarCameras=new List<Camera>();
  private readonly Dictionary<int,int> scannedBarRoots=new Dictionary<int,int>();
  private readonly Dictionary<int,int> scannedBarParents=new Dictionary<int,int>();
  private global::BlackBars[] knownBarControllers=new global::BlackBars[0];
  private void RegisterBarGraphics(Transform bar) {
   if(bar==null)return;
   int id=bar.GetInstanceID(),children=bar.childCount,previous;
   if(scannedBarRoots.TryGetValue(id,out previous)&&previous==children)return;
   scannedBarRoots[id]=children;
   foreach(var graphic in bar.GetComponentsInChildren<UnityEngine.UI.Graphic>(true)) {
    if(graphic==null||cinematicBarGraphics.Contains(graphic))continue;
    cinematicBarGraphics.Add(graphic);
    if(reportedCinematicBars.Add(graphic.GetInstanceID()))
     MelonLogger.Msg("CINEMATIC BAR UI: BlackBars reference="+bar.name+" graphic="+graphic.name+" parent="+(bar.parent==null?"<none>":bar.parent.name));
   }
  }
  private readonly HashSet<int> reportedCinematicBars=new HashSet<int>();
  private void PrepareCinematicBars() {


   if(!immersiveRequested||stopping){RestoreCinematicBars();return;}
   int sceneHandle=SceneManager.GetActiveScene().handle;
   int gameState=(int)global::PlayerState.gameState;
   int currentCameraId=camera==null?0:camera.GetInstanceID();
   if(sceneHandle!=barSceneHandle||gameState!=barGameState||currentCameraId!=barCameraId) {
    barSceneHandle=sceneHandle;barGameState=gameState;barCameraId=currentCameraId;
    nextBarSearch=0;nextBarFullSearch=0;
   }
   // Known cinematic mask artwork may remain active after the game leaves its cutscene state.
   // These named graphics are authored cinematic masks, not game/UI containers.
   if(Time.realtimeSinceStartup>=nextBarSearch) {
    long barStarted=TraceClock();
    nextBarSearch=Time.realtimeSinceStartup+1f;
    if(Time.realtimeSinceStartup>=nextBarFullSearch) {
     nextBarFullSearch=Time.realtimeSinceStartup+30f;
     scannedBarCameras.Clear();scannedBarParents.Clear();scannedBarRoots.Clear();cinematicBars.Clear();cinematicBarGraphics.Clear();
     knownBarCameras.Clear();knownBarCameras.AddRange(Resources.FindObjectsOfTypeAll<Camera>());
     var controllers=Resources.FindObjectsOfTypeAll<global::BlackBars>();
     knownBarControllers=new global::BlackBars[controllers.Length];
     for(int i=0;i<controllers.Length;i++)knownBarControllers[i]=controllers[i];
    }
    knownBarCameras.RemoveAll(c=>c==null);
    // The active camera list is small and does not search every loaded asset.
    // Newly activated cameras invalidate parent caches, including cloned UI cameras.
    foreach(var live in Camera.allCameras)if(live!=null&&!knownBarCameras.Contains(live)) {
     knownBarCameras.Add(live);scannedBarCameras.Clear();scannedBarParents.Clear();
    }
    cinematicBars.RemoveAll(r=>r==null);cinematicBarGraphics.RemoveAll(g=>g==null);
    // Use the game's own references; RectTransform UI graphics are not Renderers.
    foreach(var controller in knownBarControllers) {
     if(controller==null||!controller.gameObject.scene.IsValid())continue;
     RegisterBarGraphics(controller.barTop);
     RegisterBarGraphics(controller.barBottom);
    }
    // EnhancedResolution clones UI; copied bar graphics need not be referenced by the original BlackBars controller.
    // Only camera descendants can match the authored masks below. Include inactive cameras and children for transitions/clones.
    foreach(var barCamera in knownBarCameras) {
    if(barCamera==null || !barCamera.gameObject.scene.IsValid())continue;
    var cameraTransform=barCamera.transform;
    var cameraParent=cameraTransform.parent;
    int cachedChildren,cachedParent,id=barCamera.GetInstanceID(),children=cameraTransform.childCount;
    int parentId=cameraParent==null?0:cameraParent.GetInstanceID();
    if(scannedBarCameras.TryGetValue(id,out cachedChildren)&&cachedChildren==children
      &&scannedBarParents.TryGetValue(id,out cachedParent)&&cachedParent==parentId)continue;
    scannedBarCameras[id]=children;scannedBarParents[id]=parentId;
    // The outer camera's recursive query already includes nested FX/UI cameras.
    // Scanning those descendants again multiplied the same hierarchy work.
    bool nestedCamera=false;
    for(var ancestor=cameraParent;ancestor!=null;ancestor=ancestor.parent)
     if(ancestor.GetComponent<Camera>()!=null){nestedCamera=true;break;}
    if(nestedCamera)continue;
    foreach(var g in barCamera.GetComponentsInChildren<UnityEngine.UI.Graphic>(true)) {
     if(g==null || !g.gameObject.scene.IsValid() || (g.name!="TopBar" && g.name!="BottomBar"))continue;
     var p=g.transform.parent;
     if(p==null || p.name!="Bars" || p.parent==null || (p.parent.name!="Effects Camera" && p.parent.name!="Diag/Effects Camera"))continue;
     RegisterBarGraphics(g.transform);
    }
    foreach(var r in barCamera.GetComponentsInChildren<Renderer>(true)) {
     var sprite=r as SpriteRenderer;
     if(sprite!=null && sprite.sprite!=null && sprite.sprite.name=="ultrawide_bars" && sprite.GetComponentInParent<Camera>()!=null && sprite.gameObject.scene.IsValid()) {
      if(!cinematicBars.Contains(sprite))cinematicBars.Add(sprite);continue;
     }
     if(r==null||(r.name!="TopBar"&&r.name!="BottomBar"))continue;
     var p=r.transform.parent;
     if(p==null||p.name!="Bars"||p.parent==null||(p.parent.name!="Effects Camera"&&p.parent.name!="Diag/Effects Camera"))continue;
     if(!reportedCinematicBars.Contains(r.GetInstanceID())) { reportedCinematicBars.Add(r.GetInstanceID()); MelonLogger.Msg("CINEMATIC BAR: matched "+p.parent.name+"/Bars/"+r.name); }
     if(!cinematicBars.Contains(r))cinematicBars.Add(r);
    }
    } // Check new/reparented camera roots each second; full refresh on transitions or 30s fallback.
    TraceOperation(22,barStarted);
   }
   SuppressOpeningCreditOverlay();
   foreach(var g in cinematicBarGraphics)if(g!=null&&g.gameObject.activeInHierarchy&&g.enabled){hiddenBarGraphics.Add(g);g.enabled=false;}
   foreach(var r in cinematicBars)if(r!=null&&r.gameObject.activeInHierarchy&&r.enabled){hiddenCinematicBars.Add(r);r.enabled=false;}
   if(hiddenBarGraphics.Count>0)Canvas.ForceUpdateCanvases();
  }
  private void RestoreCinematicBars() {
   foreach(var canvas in hiddenCreditCanvases)if(canvas!=null)canvas.enabled=true;
   hiddenCreditCanvases.Clear();
   foreach(var r in hiddenCinematicBars)if(r!=null)r.enabled=true;
   hiddenCinematicBars.Clear();
   foreach(var g in hiddenBarGraphics)if(g!=null)g.enabled=true;
   hiddenBarGraphics.Clear();
  }
 }
}


namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private bool EventViewCursorActive() {
   // All interactive native 3D events share this camera/interaction path.
   // Keep input-blocking overlays out of both the render and targeting gates.
   return eventWalkStereo && camera!=null && EventWalkCamera()==camera &&
    global::PlayerState.gameState==global::PlayerState.gameStates.eventScreen &&
    !global::PlayerState.cutscene && !global::PlayerState.suspendInput &&
    !global::PlayerState.paused && !modMenuOpen && !pauseMenuVisible;
  }
  private Vector3 EventViewAimPoint() {
   var cursor=global::EventScreen3DCam.cursorPosition;
   return camera.ViewportToWorldPoint(new Vector3(cursor.x,cursor.y,2f*UnitsPerMetre));
  }
  private static void SnowInteractionCursor(global::EventScreen3DCam __instance) {
   var q=questOwner;
   if(q==null || !q.questNativeAvailable || System.Threading.Thread.CurrentThread.ManagedThreadId!=q.questNativeThread ||__instance==null)return;
   if(q.screenCursorControl==__instance&&JoystickCursorPoint(__instance)&&q.ScreenCursorInputReady()){
    global::EventScreen3DCam.cursorPosition=q.screenCursorPosition;return;
   }
   if(!q.EventViewCursorActive() || !__instance.isActiveAndEnabled || __instance.cam!=q.camera)return;
   q.CenterSnowCursorBeforeInput();
  }
  private void DestroySnowCursor() {ClearNativeEventCursor();}
  private float snowTimeSum,snowTimeMax,nextSnowTiming;
  private int snowTimeCount,snowSlowFrames;
  private void UpdateSnowTiming() {
   if(!snowWalkStereo){snowTimeSum=snowTimeMax=0f;snowTimeCount=snowSlowFrames=0;nextSnowTiming=Time.realtimeSinceStartup+5f;return;}
   float dt=Time.unscaledDeltaTime;snowTimeSum+=dt;snowTimeMax=Math.Max(snowTimeMax,dt);snowTimeCount++;
   if(dt>0.0333f)snowSlowFrames++;
   if(Time.realtimeSinceStartup<nextSnowTiming)return;
   MelonLogger.Msg("SNOW TIMING: update-ms avg="+(1000f*snowTimeSum/Math.Max(1,snowTimeCount)).ToString("F1")+" max="+(1000f*snowTimeMax).ToString("F1")+" over33ms="+snowSlowFrames+" frames="+snowTimeCount+" (not GPU timing)");
   snowTimeSum=snowTimeMax=0f;snowTimeCount=snowSlowFrames=0;nextSnowTiming=Time.realtimeSinceStartup+5f;
  }
  private void RenderSnowCursor(Camera eye) {RenderNativeEventCursor(eye);}
  private global::TitleScreenTitles[] titleControllers=new global::TitleScreenTitles[0];
  private float nextTitleSearch;

 }
}

namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private int centeredSnowCamera;
  private Camera redPitNativeCamera;
  private Transform redPitNativeParent;
  private global::AngledCamControl redPitNativeControl;
  private bool redPitControlEnabled,redPitUiOrtho;
  private Camera redPitUiCamera;
  private Vector3 redPitNativePosition,redPitNativeScale;
  private Quaternion redPitNativeRotation;
  private bool redPitNativeOrtho;
  private float redPitNativeFov,redPitNativeSize;
  private void RememberRedPitCamera() {
   if(redPitNativeCamera!=null)return;
   var rig=GameObject.Find("__Prerequisites__/Angled Camera Rig/LocalSpace");
   var t=rig==null?null:rig.transform.Find("Main Camera");
   var c=t==null?null:t.GetComponent<Camera>();
   if(c==null)return;
   redPitNativeCamera=c;redPitNativeParent=t.parent;
   redPitNativeControl=c.GetComponent<global::AngledCamControl>();
   redPitControlEnabled=redPitNativeControl!=null && redPitNativeControl.enabled;
   var ui=t.Find("VHS UI");redPitUiCamera=ui==null?null:ui.GetComponent<Camera>();
   redPitUiOrtho=redPitUiCamera!=null && redPitUiCamera.orthographic;
   redPitNativePosition=t.localPosition;redPitNativeRotation=t.localRotation;redPitNativeScale=t.localScale;
   redPitNativeOrtho=c.orthographic;redPitNativeFov=c.fieldOfView;redPitNativeSize=c.orthographicSize;
   MelonLogger.Msg("RED PIT: saved native camera before perspective change.");
  }
  private void RestoreRedPitForTransition() {
   if(redPitNativeCamera==null)return;
   // User retains the native red-pit inspection and jump view. Resume through automatic recovery afterward.
   if(global::PlayerState.gameState==global::PlayerState.gameStates.play && !global::PlayerState.cutscene && !global::PlayerState.suspendInput)return;
   RestoreRedPitCamera();
  }
  private void RestoreRedPitCamera() {
   var c=redPitNativeCamera;var parent=redPitNativeParent;
   var control=redPitNativeControl;var ui=redPitUiCamera;
   redPitNativeControl=null;redPitUiCamera=null;
   redPitNativeCamera=null;redPitNativeParent=null;
   if(c==null || parent==null)return;
   // Only undo the perspective mod's ownership. Never override a camera already
   // reparented by a native event, or force a native-disabled camera active.
   var t=c.transform;
   if(t.parent==null || t.parent.name!="Character Root")return;
   t.SetParent(parent,false);t.localPosition=redPitNativePosition;t.localRotation=redPitNativeRotation;t.localScale=redPitNativeScale;
   if(control!=null)control.enabled=redPitControlEnabled;
   if(ui!=null)ui.orthographic=redPitUiOrtho;
   c.orthographic=redPitNativeOrtho;c.fieldOfView=redPitNativeFov;c.orthographicSize=redPitNativeSize;
   MelonLogger.Msg("RED PIT: returned camera to native rig before non-gameplay sequence; native activation unchanged.");
  }

 }
}

namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private bool snowCenterBeforeFirstEye;
  private readonly List<Canvas> hiddenCreditCanvases=new List<Canvas>();
  private void CenterSnowCursorBeforeInput() {
   if(!EventViewCursorActive())return;
   // Center once on camera entry. Native screen-space targeting owns movement;
   // headset orientation must never rewrite the interaction cursor.
   int id=camera.GetInstanceID();if(centeredSnowCamera==id)return;
   centeredSnowCamera=id;global::EventScreen3DCam.cursorPosition=new Vector2(.5f,.5f);
  }
  private void CenterSnowEntry(Camera candidate) {
   int id=candidate.GetInstanceID();
   if(centeredSnowCamera==id)return;
   global::EventScreen3DCam.cursorPosition=new Vector2(0.5f,0.5f);
   centeredSnowCamera=id;snowCenterBeforeFirstEye=true;
   MelonLogger.Msg("EVENT CURSOR: native aim centered before first eye frame.");
  }
  private void SuppressOpeningCreditOverlay() {
   // Only the broken opening credit canvas, not the later title/story screens.
   if(SceneManager.GetActiveScene().name!="PEN_Wreck")return;
   if(Time.realtimeSinceStartup>=nextTitleSearch) {
    nextTitleSearch=Time.realtimeSinceStartup+1f;
    titleControllers=Resources.FindObjectsOfTypeAll<global::TitleScreenTitles>();
   }
   foreach(var controller in titleControllers) {
    var credit=controller==null?null:controller.roen;
    if(credit==null||credit.canvas==null)continue;
    var canvas=credit.canvas;var c=canvas.worldCamera;
    if(c==null||c.name!="UICamera For Cutscene"||!canvas.gameObject.activeInHierarchy)continue;
    if(canvas.enabled) {
     if(!hiddenCreditCanvases.Contains(canvas))hiddenCreditCanvases.Add(canvas);
     canvas.enabled=false;
     MelonLogger.Msg("OPENING OVERLAY: disabled credit canvas rendering; native sequence retained.");
    }
   }
  }
 }
}








