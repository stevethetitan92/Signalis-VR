using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Transform mineNavigationFrame;private MinePathProjection mineNavigation;
 private bool MineNavigationControls(Transform frame,Transform[] sources,Vector2[] target,int[,] edges,float width){
  if(frame==null||sources.Length!=target.Length)return false;var points=new double[sources.Length,5];
  for(int i=0;i<sources.Length;i++){if(sources[i]==null)return false;var p=frame.InverseTransformPoint(sources[i].position);points[i,0]=p.x;points[i,1]=p.y;points[i,2]=p.z;points[i,3]=target[i].x;points[i,4]=target[i].y;}
  mineNavigationFrame=frame;mineNavigation=new MinePathProjection(points,edges,width);return true;
 }
 private void ConfigureMineNavigation(global::Room room){
  mineNavigationFrame=null;mineNavigation=null;if(room==null||room.chunk==null||room.Doors==null)return;var root=room.chunk.transform;
  if(minesCurrent.Name=="Standseilbahn"&&room.Doors.Count==3){
   var frame=root.Find("Objects/Pivot/Mover");if(frame==null)return;
   MineNavigationControls(frame,new[]{room.Doors[1].transform,frame.Find("Enviroment/Plane_3"),frame.Find("Corridor_3"),frame.Find("Corridor_4"),frame.Find("Enviroment/Ground (2)_2"),room.Doors[2].transform,room.Doors[0].transform},
    new[]{minesCurrent.Doors[1],MinesMapLayout.P(623,660),MinesMapLayout.P(608,715),MinesMapLayout.P(560,765),MinesMapLayout.P(503,817),minesCurrent.Doors[2],minesCurrent.Doors[0]},
    new int[,]{{0,1},{1,2},{2,3},{3,4},{4,5},{0,6}},.045f);
  }else if(minesCurrent.Name=="Mineshaft Access"&&room.Doors.Count==2){
   var left=root.Find("Objects/LeftCorridor/Corridor");var right=root.Find("Objects/RightCorridor/Corridor_4");if(left==null||right==null)return;
   // The two corridor mouths provide the open chamber junction without
   // relying on scenery renderers removed by native mesh combining.
   if(!MineNavigationControls(root,new[]{room.Doors[0].transform,root.Find("Objects/Plane_1"),left,right,root.Find("Objects/RightCorridor/Walls_4"),room.Doors[1].transform},
    new[]{minesCurrent.Doors[0],MinesMapLayout.P(623,65),MinesMapLayout.P(590,164),MinesMapLayout.P(684,194),MinesMapLayout.P(772,278),minesCurrent.Doors[1]},
    new int[,]{{0,1},{1,2},{1,3},{3,4},{2,5}},.04f))return;
  }
 }
}}
