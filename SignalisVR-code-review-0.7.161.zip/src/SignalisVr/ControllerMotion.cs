using System;
using System.Runtime.InteropServices;
using MelonLoader;
using UnityEngine;
using Valve.VR;

namespace SignalisVrTracking {
 public sealed partial class Tracking {
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
  private delegate int DevicePoseDelegate(uint device,long frameId,[Out] float[] matrix);
  private DevicePoseDelegate devicePose;
  private readonly float[] controllerMatrix=new float[12];
  private readonly GameObject[] controllerMarkers=new GameObject[2];
  private readonly MeshRenderer[,] handPositionCrosses=new MeshRenderer[2,3];
  private readonly Vector3[] rawControllerPositions=new Vector3[2];
  private readonly MeshRenderer[] controllerBodies=new MeshRenderer[2],controllerTips=new MeshRenderer[2];
  private readonly Vector3[] controllerGripOffsets=new Vector3[2];
  private readonly uint[] gripDeviceIds={uint.MaxValue,uint.MaxValue};
  private readonly int[] gripAttempts=new int[2];
  private readonly float[] nextGripAttempt=new float[2];
  private readonly bool[] gripResolved=new bool[2];
  // Static controller attachment reference, queried outside the per-frame path
  // after resolution. No additional pose sampling or input action changes.
  private void ResolveControllerGrip(int hand,uint id) {
   if(gripDeviceIds[hand]!=id) {
    gripDeviceIds[hand]=id;gripAttempts[hand]=0;nextGripAttempt[hand]=0;
    gripResolved[hand]=false;controllerGripOffsets[hand]=Vector3.zero;
   }
   if(gripResolved[hand]||gripAttempts[hand]>=3||Time.realtimeSinceStartup<nextGripAttempt[hand])return;
   gripAttempts[hand]++;nextGripAttempt[hand]=Time.realtimeSinceStartup+5f;
   try {
    var error=ETrackedPropertyError.TrackedProp_Success;
    var name=new System.Text.StringBuilder(1024);
    system.GetStringTrackedDeviceProperty(id,ETrackedDeviceProperty.Prop_RenderModelName_String,name,1024,ref error);
    var models=OpenVR.RenderModels;
    if(error!=ETrackedPropertyError.TrackedProp_Success||name.Length==0||models==null)throw new InvalidOperationException("render model unavailable");
    var state=new VRControllerState_t();
    system.GetControllerState(id,ref state,(uint)Marshal.SizeOf(typeof(VRControllerState_t)));
    var mode=new RenderModel_ControllerMode_State_t();
    var component=new RenderModel_ComponentState_t();
    if(!models.GetComponentState(name.ToString(),"handgrip",ref state,ref mode,ref component))throw new InvalidOperationException("handgrip component unavailable for "+name);
    var m=component.mTrackingToComponentLocal;
    var offset=new Vector3(m.m3,m.m7,-m.m11);
    if(float.IsNaN(offset.sqrMagnitude)||float.IsInfinity(offset.sqrMagnitude)||offset.sqrMagnitude>.25f)throw new InvalidOperationException("invalid handgrip translation");
    controllerGripOffsets[hand]=offset;gripResolved[hand]=true;
    MelonLogger.Msg("CONTROLLER GRIP: hand="+hand+" model="+name+" localMetres="+WeaponVector(offset)+" source=runtime-handgrip; existing aim rotation retained");
   }catch(Exception ex) {
    MelonLogger.Warning("CONTROLLER GRIP: hand="+hand+" attempt="+gripAttempts[hand]+" "+ex.Message+"; using raw tracked origin without guessed offset");
   }
  }
  private Quaternion controllerTrackingToWorld;
  private bool controllerMotionFailed;
  private int controllerVisibility=-1,controllerLogCount;
  private readonly HotkeyEdge controllerCompareKey=new HotkeyEdge();
  private bool controllerMotionEnabled=true;
  private int controllerTrialMode=2; // 0 disabled, 1 enabled, 2 ineligible.
  private void PollControllerComparison() {
   if(controllerCompareKey.Poll((GetAsyncKeyState(0x77)&0x8000)!=0)) {
    controllerMotionEnabled=!controllerMotionEnabled;
    MelonLogger.Msg("CONTROLLER COMPARISON: F8 visual feature="+(controllerMotionEnabled?"ON":"OFF")+"; existing gameplay controls unchanged.");
   }
  }

  // Same-pose controller visualization; right pose also feeds the scoped rifle trial.
  private void PrepareControllerMotion() {
   long started=TraceClock();controllerTrialMode=2;rightWeaponTime=-100f;int previousVisibility=controllerVisibility;controllerVisibility=0;
   HideControllerMotion();
   try {
    if(controllerMotionFailed || RadioStationActive() || !ControllerVisualStateReady() || !questAvailabilityValue)return;
    controllerTrialMode=controllerMotionEnabled?1:0;
    if(!controllerMotionEnabled)return;
    if(devicePose==null)devicePose=NativeLibraries.Bind<DevicePoseDelegate>(true,"GetPreparedDevicePose");
    EnsureControllerMarkers();
    int visible=0;
    for(int hand=0;hand<2;hand++) {
     uint id=system.GetTrackedDeviceIndexForControllerRole(hand==0?ETrackedControllerRole.LeftHand:ETrackedControllerRole.RightHand);
     if(id==OpenVR.k_unTrackedDeviceIndexInvalid || devicePose(id,stereoTraceId,controllerMatrix)!=1)continue;
     bool finite=true;
     for(int j=0;j<12;j++)if(float.IsNaN(controllerMatrix[j])||float.IsInfinity(controllerMatrix[j]))finite=false;
     if(!finite)continue;
     var forward=new Vector3(-controllerMatrix[2],-controllerMatrix[6],controllerMatrix[10]);
     var up=new Vector3(controllerMatrix[1],controllerMatrix[5],-controllerMatrix[9]);
     if(forward.sqrMagnitude<0.5f||up.sqrMagnitude<0.5f)continue;
     var position=new Vector3(controllerMatrix[3],controllerMatrix[7],-controllerMatrix[11]);
     rawControllerPositions[hand]=position;
     var transform=controllerMarkers[hand].transform;
     var rawWorld=HeadPosition.Map(DoorCameraOrigin(camera.transform.position),controllerTrackingToWorld,position,neutralHeadPosition,UnitsPerMetre);
     transform.rotation=controllerTrackingToWorld*Quaternion.LookRotation(forward,up);
     ResolveControllerGrip(hand,id);
     transform.position=HandPlacement.CalibrateGrip(rawWorld,transform.rotation,UnitsPerMetre,controllerGripOffsets[hand]);

     controllerBodies[hand].enabled=controllerTips[hand].enabled=false;
     visible|=1<<hand;
    }
    controllerVisibility=visible;
    
    // Support detection needs this frame's completed left/right visibility mask.
    if((visible&2)!=0){var right=controllerMarkers[1].transform;CacheRightWeaponPose(right.position,right.rotation);}
    if(visible!=previousVisibility && controllerLogCount<20) {
     controllerLogCount++;
     MelonLogger.Msg("CONTROLLER MOTION: same-pose-frame="+stereoTraceId+" visibleMask="+visible+" (1 left, 2 right); visual test only.");
    }
   }catch(Exception ex) {
    controllerVisibility=0;controllerMotionFailed=true;HideControllerMotion();
    MelonLogger.Warning("Controller visualization disabled; existing controls retained: "+ex.Message);
   }finally {TraceOperation(33,started,controllerTrialMode);}
  }
  private void HideControllerMotion() {
   for(int i=0;i<2;i++) {
    if(controllerBodies[i]!=null)controllerBodies[i].enabled=false;
    if(controllerTips[i]!=null)controllerTips[i].enabled=false;
    for(int axis=0;axis<3;axis++)if(handPositionCrosses[i,axis]!=null)handPositionCrosses[i,axis].enabled=false;
   }
  }
  private void EnsureControllerMarkers() {
   if(controllerMarkers[0]!=null && controllerMarkers[1]!=null)return;
   var shader=Shader.Find("Unlit/Color");
   if(shader==null || !shader.isSupported)throw new InvalidOperationException("Unlit controller material unavailable");
   var mesh=new Mesh();mesh.name="SignalisVR_ControllerBox";
   mesh.vertices=new Vector3[]{new Vector3(-.5f,-.5f,-.5f),new Vector3(.5f,-.5f,-.5f),new Vector3(.5f,.5f,-.5f),new Vector3(-.5f,.5f,-.5f),new Vector3(-.5f,-.5f,.5f),new Vector3(.5f,-.5f,.5f),new Vector3(.5f,.5f,.5f),new Vector3(-.5f,.5f,.5f)};
   mesh.triangles=new int[]{0,2,1,0,3,2,4,5,6,4,6,7,0,4,7,0,7,3,1,2,6,1,6,5,0,1,5,0,5,4,3,7,6,3,6,2};mesh.RecalculateBounds();
   var white=new Material(shader);white.color=Color.white;
   for(int i=0;i<2;i++) {
    var root=new GameObject(i==0?"SignalisVR_LeftController":"SignalisVR_RightController");
    controllerMarkers[i]=root;root.layer=30;UnityEngine.Object.DontDestroyOnLoad(root);
    root.transform.localScale=Vector3.one*UnitsPerMetre;
    var material=new Material(shader);material.color=i==0?new Color(.1f,.7f,1f):new Color(1f,.45f,.1f);
    for(int axis=0;axis<3;axis++){var size=new Vector3(.005f,.005f,.005f);size[axis]=.09f;handPositionCrosses[i,axis]=CreateControllerPart(root,mesh,white,"TrackedPalmCross"+axis,Vector3.zero,size);}
    controllerBodies[i]=CreateControllerPart(root,mesh,material,"Body",Vector3.zero,new Vector3(.045f,.035f,.11f));
    // White nose shows the tracked local forward direction, not a calibrated gun aim.
    controllerTips[i]=CreateControllerPart(root,mesh,white,"Forward",new Vector3(0,0,.065f),new Vector3(.018f,.018f,.04f));
   }
  }
  private static MeshRenderer CreateControllerPart(GameObject parent,Mesh mesh,Material material,string name,Vector3 position,Vector3 scale) {
   var part=new GameObject(name);part.layer=30;part.transform.SetParent(parent.transform,false);
   part.transform.localPosition=position;part.transform.localScale=scale;
   part.AddComponent<MeshFilter>().sharedMesh=mesh;
   var renderer=part.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;renderer.enabled=false;
   renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;renderer.receiveShadows=false;
   return renderer;
  }
 }
}






