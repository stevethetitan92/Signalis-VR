using System;
using System.Linq;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private void PrepareThermiteCollision(ThermiteFlight f){
  f.Probe=f.Root.AddComponent<BoxCollider>();f.Probe.center=f.Bounds.center;f.Probe.size=f.Bounds.size;f.Probe.enabled=false;
  // Each thrown flare owns its fading materials; held flares are unaffected.
  foreach(var r in f.Root.GetComponentsInChildren<MeshRenderer>(true)){
   var original=r.sharedMaterials;var copies=new Material[original.Length];
   for(int i=0;i<copies.Length;i++){var m=new Material(Shader.Find("Sprites/Default"));m.mainTexture=original[i].mainTexture;m.color=original[i].HasProperty("_Color")?original[i].color:Color.white;copies[i]=m;f.OwnMaterials.Add(m);f.MaterialAlpha.Add(m.color.a);}r.sharedMaterials=copies;
  }
  f.Renderers=f.Root.GetComponentsInChildren<Renderer>(true);f.Fade=new MaterialPropertyBlock();
 }
 private bool ThermiteSolid(ThermiteFlight f,Collider c){return c!=null&&c.enabled&&!c.isTrigger&&c!=f.Probe&&!c.transform.IsChildOf(f.Root.transform)&&(global::PlayerState.player==null||!c.transform.IsChildOf(global::PlayerState.player.transform));}
 private void StepThermite(ThermiteFlight f,float dt,float now){
  var tr=f.Root.transform;var up=calibrationRoot!=null?calibrationRoot.transform.up:controllerTrackingToWorld*Vector3.up;
  f.Velocity-=up*(9.81f*UnitsPerMetre*dt);
  var rotation=tr.rotation*Quaternion.Euler(f.Spin*dt);var delta=f.Velocity*dt;float distance=delta.magnitude;var normal=Vector3.zero;
  var half=f.Bounds.extents*UnitsPerMetre;var centre=tr.position+rotation*(f.Bounds.center*UnitsPerMetre);
  if(distance>1e-7f)foreach(var hit in Physics.BoxCastAll(centre,half,delta.normalized,rotation,distance,-1,QueryTriggerInteraction.Ignore).ToArray())if(ThermiteSolid(f,hit.collider)&&hit.distance<distance){distance=Math.Max(0,hit.distance-.001f*UnitsPerMetre);normal=hit.normal;}
  var next=tr.position+delta.normalized*distance;
  // Resolve rotation overlap too, so the long flare can roll against solids.
  for(int pass=0;pass<4;pass++)foreach(var c in Physics.OverlapBox(next+rotation*(f.Bounds.center*UnitsPerMetre),half,rotation,-1,QueryTriggerInteraction.Ignore).ToArray()){
   if(!ThermiteSolid(f,c))continue;Vector3 direction;float depth;
   if(Physics.ComputePenetration(f.Probe,next,rotation,c,c.transform.position,c.transform.rotation,out direction,out depth)){next+=direction*(depth+.001f*UnitsPerMetre);normal=direction;}
  }
  if(calibrationRoot!=null){
   // Resolve against the room's known floor plane too. This bounds all eight
   // corners after rotation even if a sweep begins already intersecting it.
   var centreNext=next+rotation*(f.Bounds.center*UnitsPerMetre);
   var local=calibrationRoot.transform.InverseTransformPoint(centreNext);
   if(Mathf.Abs(local.x)<=6f*UnitsPerMetre&&Mathf.Abs(local.z)<=6f*UnitsPerMetre){
    float support=Mathf.Abs(Vector3.Dot(up,rotation*Vector3.right))*half.x+Mathf.Abs(Vector3.Dot(up,rotation*Vector3.up))*half.y+Mathf.Abs(Vector3.Dot(up,rotation*Vector3.forward))*half.z;
    float bottom=Vector3.Dot(centreNext-calibrationRoot.transform.position,up)-support;
    if(bottom<.001f*UnitsPerMetre){next+=up*(.001f*UnitsPerMetre-bottom);normal=up;}
   }
  }
  if(normal.sqrMagnitude>.1f){float vn=Vector3.Dot(f.Velocity,normal);if(vn<0)f.Velocity=(f.Velocity-normal*vn)*Mathf.Exp(-3f*dt)-normal*vn*.18f;
   var roll=Vector3.Cross(normal,f.Velocity/UnitsPerMetre)*180f;f.Spin=Quaternion.Inverse(rotation)*Vector3.Lerp(rotation*f.Spin,roll,.2f);f.Spin*=Mathf.Exp(-2f*dt);
  }
  tr.SetPositionAndRotation(next,rotation);
  float alpha=ThermiteFade(f,now);f.Fade.SetColor("_Color",new Color(1,1,1,alpha));for(int i=0;i<f.OwnMaterials.Count;i++){var m=f.OwnMaterials[i];var c=m.color;c.a=f.MaterialAlpha[i]*alpha;m.color=c;}foreach(var r in f.Renderers)if(r!=null&&r.GetComponent<ParticleSystem>()!=null)r.SetPropertyBlock(f.Fade);
  var light=f.Root.GetComponent<Light>();if(light!=null)light.intensity=1.5f*alpha;
  // Fade while the particles remain alive; DisposeThermiteFlight owns teardown.
  // Stopping inherited systems early can invoke their native stop/destroy action.
 }
 private void DisposeThermiteFlight(ThermiteFlight f){if(f.Sound!=null){f.Sound.Dispose();f.Sound=null;}if(f.Root!=null)UnityEngine.Object.Destroy(f.Root);foreach(var m in f.OwnMaterials)if(m!=null)UnityEngine.Object.Destroy(m);f.OwnMaterials.Clear();f.MaterialAlpha.Clear();}
} }

