using System;
using System.Collections.Generic;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public static class ReceiverTuning {
  public static float Turn(float value,float degrees,float minimum,float maximum){if(float.IsNaN(degrees)||float.IsInfinity(degrees)||Math.Abs(degrees)>70)return value;return Math.Max(minimum,Math.Min(maximum,(float)Math.Round((value+degrees/15f)*10)/10));}
 }
 public sealed partial class Tracking {
  private bool heldReceiver,heldEidetic,receiverKnobHeld,receiverArrowArmed;
  private float receiverKnobAngle,receiverPressTime=-100f,receiverGripAmount;
  private int receiverArrowDirection;
  private global::AnItem receiverCatalog;
  private GameObject receiverRoot,eideticRoot;
  private Transform receiverKnob,receiverLeftArrow,receiverRightArrow;
  private readonly List<Renderer> moduleRenderers=new List<Renderer>();
  private readonly List<Material> moduleMaterials=new List<Material>();
  private readonly List<Mesh> moduleMeshes=new List<Mesh>();
  private Mesh receiverDisplay;private string receiverCaption;
  private readonly QuickUsePolicy eideticUse=new QuickUsePolicy();
  private bool snapshotQueued;
  private float nextSnapshot;
  private global::AnItem ReceiverCatalog(){
   if(receiverCatalog!=null)return receiverCatalog;
   receiverCatalog=ScriptableObject.CreateInstance<global::AnItem>();receiverCatalog.name="SignalisVR_ReceiverWheel";receiverCatalog._name="Receiver";receiverCatalog._item=(global::Items.itemlist)RadioItemId;receiverCatalog.type=global::AnItem.AnItemType.Tool;receiverCatalog.maxNumber=1;receiverCatalog.keinModul=true;receiverCatalog.sortingPriority=999;
   var tex=new Texture2D(128,128,TextureFormat.RGBA32,false);tex.filterMode=FilterMode.Point;var pixels=new Color[128*128];
   for(int y=0;y<128;y++)for(int x=0;x<128;x++){
    // Chamfered housing, antenna, knobs, side buttons and two distinct display windows.
    bool body=x>=35&&x<=91&&y>=7&&y<=91&&x+y>=46&&x-y<=80;
    bool inner=x>=39&&x<=87&&y>=11&&y<=87;
    bool aerial=x>=77&&x<=82&&y>=90&&y<=120;
    bool knobs=y>=91&&y<=98&&((x>=43&&x<=51)||(x>=64&&x<=72));
    bool buttons=x>=29&&x<=34&&((y>=62&&y<=74)||(y>=43&&y<=55));
    bool upper=(x>=45&&x<=81&&y>=46&&y<=80)&&(x<=47||x>=79||y<=48||y>=78);
    bool lower=(x>=45&&x<=81&&y>=17&&y<=38)&&(x<=47||x>=79||y<=19||y>=36);
    bool digits=y>=65&&y<=70&&x>=51&&x<=75&&((x-51)%7<4);
    bool spectrum=y>=52&&y<=60&&x>=51&&x<=76&&x%4<2;
    pixels[y*128+x]=(body&&!inner)||aerial||knobs||buttons||upper||lower||digits||spectrum?Color.white:Color.clear;
   }
   tex.SetPixels(pixels);tex.Apply();receiverCatalog.Icon=Sprite.Create(tex,new Rect(0,0,128,128),new Vector2(.5f,.5f));receiverCatalog.Image=receiverCatalog.Icon;return receiverCatalog;
  }

  private bool ReceiverInstalled(){return global::RadioManager.instance!=null&&global::RadioManager.moduleInstalled;}
  private bool ReceiverOwned(){var items=global::InventoryManager.elsterItems;return ReceiverInstalled()&&receiverCatalog!=null&&items!=null&&items.ContainsKey(receiverCatalog)&&items[receiverCatalog]>0;}
  private bool EideticOwned(){var all=global::InventoryManager.allItems;return all!=null&&all.ContainsKey(global::Items.itemlist.PhotoModule)&&QuickCount(all[global::Items.itemlist.PhotoModule])>0;}
  private void ClearHeldModules(){radioButtons.Update(false,false,false,0);radioPowerButton.Update(false,false);heldReceiver=heldEidetic=receiverKnobHeld=false;receiverGripAmount=0;eideticUse.Reset();snapshotQueued=false;HideHeldModules();}
  private bool EquipHeldModule(string id,bool wheelSelection=false) {
   if(id!="Receiver"&&id!="PhotoModule")return false;
   if((id=="Receiver"&&!ReceiverOwned())||(id=="PhotoModule"&&!EideticOwned())){quickStatus="Not carried";return true;}
   if(quickInventory==null||!PrepareProdHand(quickInventory)){quickStatus="Cannot holster now";return true;}
   heldQuickHealth=null;healthUsed=false;quickPreviousWeapon=null;global::InventoryManager.EquippedTool=null;
   ClearHeldModules();heldReceiver=id=="Receiver";heldEidetic=id=="PhotoModule";quickStatus=heldReceiver?"Receiver":"Eidetic Module";if(wheelSelection)PlayWheelItemEquip(id);return true;
  }
  private void PollHeldModules(bool available,QuestSample left,QuestSample right) {
   if(!heldReceiver&&!heldEidetic)return;
   bool ready=available&&ProdVrMode()&&questPolicy.LeftArmed&&questPolicy.RightArmed&&ModHudGameplayReady()&&!modMenuOpen&&!global::PlayerState.reloading&&!global::PlayerState.animating&&!global::PlayerState.grappled&&!global::PlayerState.hurt&&manualReload.Stage==ManualReloadPolicy.Step.Idle&&!shotgunReload.Active&&!AdditionalReloadActive();
   if((heldReceiver&&!ReceiverOwned())||(heldEidetic&&!EideticOwned())||global::InventoryManager.EquippedWeapon!=null){ClearHeldModules();return;}
   questFrame.buttons&=~((1<<5)|(1<<6)|(1<<7));
   if(heldEidetic){if(eideticUse.Update(ready,right.trigger>.55f||right.Button(33))&&Time.realtimeSinceStartup>=nextSnapshot){snapshotQueued=true;nextSnapshot=Time.realtimeSinceStartup+.6f;healthSqueezeTime=Time.realtimeSinceStartup;}return;}
  }

  private Renderer ModulePart(GameObject parent,PrimitiveType type,Vector3 position,Vector3 size,Color color) {
   var go=GameObject.CreatePrimitive(type);go.layer=30;UnityEngine.Object.Destroy(go.GetComponent<Collider>());go.transform.SetParent(parent.transform,false);go.transform.localPosition=position;go.transform.localScale=size;
   var material=new Material(Shader.Find("Unlit/Color"));material.color=color;moduleMaterials.Add(material);var r=go.GetComponent<Renderer>();r.sharedMaterial=material;r.enabled=false;moduleRenderers.Add(r);return r;
  }
  private void EnsureReceiver(){if(receiverRoot==null)BuildPortableReceiver();}
  private void EnsureEidetic(){if(eideticRoot!=null)return;eideticRoot=new GameObject("SignalisVR_HandheldEidetic");UnityEngine.Object.DontDestroyOnLoad(eideticRoot);ModulePart(eideticRoot,PrimitiveType.Sphere,Vector3.zero,new Vector3(.09f,.09f,.09f),new Color(.82f,.84f,.85f));ModulePart(eideticRoot,PrimitiveType.Sphere,new Vector3(0,0,.040f),new Vector3(.045f,.045f,.022f),Color.black);ModulePart(eideticRoot,PrimitiveType.Sphere,new Vector3(0,0,.051f),new Vector3(.023f,.023f,.009f),new Color(.025f,.50f,.8f));ModulePart(eideticRoot,PrimitiveType.Cube,new Vector3(.038f,0,0),new Vector3(.007f,.065f,.060f),new Color(.5f,.045f,.05f));}
  private void PrepareHeldModules() {
   HideHeldModules();if((!heldReceiver&&!heldEidetic)||!handsScoped||!ModHudGameplayReady())return;
   if(heldReceiver){EnsureReceiver();var left=controllerMarkers[0].transform;receiverRoot.transform.position=HandPlacement.TrackedPalm(left.position,left.rotation,UnitsPerMetre)+left.forward*.045f*UnitsPerMetre;receiverRoot.transform.rotation=left.rotation;receiverRoot.transform.localScale=Vector3.one*UnitsPerMetre;PreparePortableReceiver();}
   if(heldEidetic){EnsureEidetic();var right=controllerMarkers[1].transform;eideticRoot.transform.position=HandPlacement.TrackedPalm(right.position,right.rotation,UnitsPerMetre)+right.forward*.035f*UnitsPerMetre;eideticRoot.transform.rotation=right.rotation;eideticRoot.transform.localScale=Vector3.one*UnitsPerMetre;FitHandAroundBox(1,eideticRoot.transform,Vector3.zero,new Vector3(.078f,.078f,.078f));}
   foreach(var r in moduleRenderers)if(r!=null)r.enabled=(heldReceiver&&r.transform.IsChildOf(receiverRoot.transform))||(heldEidetic&&r.transform.IsChildOf(eideticRoot.transform));
  }
  private void HideHeldModules(){foreach(var r in moduleRenderers)if(r!=null)r.enabled=false;}
  private void DestroyHeldModules(){ClearHeldModules();DestroyPortableRadio();if(receiverRoot!=null)UnityEngine.Object.Destroy(receiverRoot);if(eideticRoot!=null)UnityEngine.Object.Destroy(eideticRoot);receiverRoot=eideticRoot=null;receiverDisplay=null;receiverCaption=null;foreach(var m in moduleMaterials)UnityEngine.Object.Destroy(m);foreach(var m in moduleMeshes)UnityEngine.Object.Destroy(m);moduleMaterials.Clear();moduleMeshes.Clear();moduleRenderers.Clear();}
 }
}





