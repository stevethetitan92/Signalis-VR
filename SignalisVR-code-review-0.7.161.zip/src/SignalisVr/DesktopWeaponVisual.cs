﻿using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Camera desktopWeaponView;
 private int desktopWeaponMask;
 private Transform desktopWeaponSource;
 private MeshRenderer[] desktopWeaponOriginals;
 private bool[] desktopWeaponEnabled;
 private bool desktopWeaponScoped;
 private global::PistolSlide desktopPistolSlide;
 private readonly System.Collections.Generic.List<Camera> desktopWeaponNestedViews=new System.Collections.Generic.List<Camera>();
 private System.Collections.Generic.List<MeshRenderer> desktopWeaponParts;
 private bool[] desktopWeaponPartEnabled;
 private float desktopWeaponWarning;
 private void PrepareDesktopWeaponVisual(Camera view){
  if(desktopWeaponScoped&&view!=null&&view!=desktopWeaponView){
   if(desktopWeaponNestedViews.Count==0){
    for(int i=0;i<desktopWeaponParts.Count;i++){var p=desktopWeaponParts[i];desktopWeaponPartEnabled[i]=p!=null&&p.enabled;if(p!=null)p.enabled=false;}
    for(int i=0;i<desktopWeaponOriginals.Length;i++)if(desktopWeaponOriginals[i]!=null)desktopWeaponOriginals[i].enabled=desktopWeaponEnabled[i];
   }
   desktopWeaponNestedViews.Add(view);return;
  }
  // Use only the native gameplay camera, never UI, reflections or VR eye passes.
  if(view==null||view!=global::PlayerState.cameraMain||(active&&stereo)||handsScoped||mouseWeaponTest||!WeaponGameplayReady()||global::PlayerState.paused||global::PlayerState.eventScreen)return;
  RestoreDesktopWeaponVisual();
  var attack=global::PlayerAttack.instance;if(attack==null)return;
  var gun=EquippedControllerGun(FindRifleOwner(attack));
  var muzzle=global::PlayerAttack.muzzle;
  Vector3 localMuzzle;
  if(gun==null||!gun.activeInHierarchy||muzzle==null||!ImportedMuzzle(out localMuzzle))return;
  try{
   if(desktopWeaponSource!=gun.transform||desktopWeaponOriginals==null){
    desktopWeaponSource=gun.transform;desktopWeaponOriginals=gun.GetComponentsInChildren<MeshRenderer>(true);desktopWeaponEnabled=new bool[desktopWeaponOriginals.Length];
    var slides=gun.GetComponentsInChildren<global::PistolSlide>(true);desktopPistolSlide=slides.Length==1?slides[0]:null;
   }
   bool visible=false;
   for(int i=0;i<desktopWeaponOriginals.Length;i++){
    var r=desktopWeaponOriginals[i];desktopWeaponEnabled[i]=r!=null&&r.enabled;
    if(r!=null&&r.enabled&&!r.forceRenderingOff&&r.gameObject.activeInHierarchy&&(view.cullingMask&(1<<r.gameObject.layer))!=0)visible=true;
   }
   if(!visible)return;
   var item=global::InventoryManager.EquippedWeapon.parentItem;string kind=WeaponFamily(item._item.ToString());
   GameObject root;System.Collections.Generic.List<MeshRenderer> parts;
   if(kind=="SMG"){if(xiphiasFailed)return;EnsureXiphias();root=xiphiasRoot;parts=xiphiasParts;}
   else {if(selectedFailed)return;EnsureSelected(kind);root=selectedRoot;parts=selectedParts;}
   // Private geometry follows the authored muzzle; no native transform or laser changes.
   root.transform.rotation=muzzle.rotation;
   root.transform.position=muzzle.position-muzzle.rotation*localMuzzle*UnitsPerMetre;
   root.transform.localScale=Vector3.one*UnitsPerMetre*(kind=="Revolver"?AmmoGuidePolicy.RevolverScale:1f);
   desktopWeaponParts=parts;
   if(desktopWeaponPartEnabled==null||desktopWeaponPartEnabled.Length!=parts.Count)desktopWeaponPartEnabled=new bool[parts.Count];
   desktopWeaponView=view;desktopWeaponMask=view.cullingMask;desktopWeaponScoped=true;
   view.cullingMask|=1<<30;
   foreach(var p in parts)if(p!=null){p.transform.localPosition=Vector3.zero;p.transform.localRotation=Quaternion.identity;p.enabled=true;}
   if(kind=="Pistol"&&desktopPistolSlide!=null&&desktopPistolSlide.slide!=null){
    float amount=DesktopSlideAmount(desktopPistolSlide.slide.localPosition.x,desktopPistolSlide.distance);
    for(int i=0;i<selectedParts.Count;i++)if(selectedRoles[i]==2)selectedParts[i].transform.localPosition=Vector3.back*(.035f*amount);
   }
   foreach(var r in desktopWeaponOriginals)if(r!=null)r.enabled=false;
  }catch(Exception ex){RestoreDesktopWeaponVisual();if(Time.realtimeSinceStartup>=desktopWeaponWarning){desktopWeaponWarning=Time.realtimeSinceStartup+10;MelonLoader.MelonLogger.Warning("Desktop weapon retained native model: "+ex.Message);}}
 }
 private static float DesktopSlideAmount(float position,float travel){
  if(float.IsNaN(position)||float.IsInfinity(position)||float.IsNaN(travel)||float.IsInfinity(travel)||Math.Abs(travel)<.00001f)return 0;
  return Math.Max(0,Math.Min(1,position/travel));
 }
 private void ResumeDesktopWeaponAfterCamera(Camera view){
  if(!desktopWeaponScoped||desktopWeaponNestedViews.Count==0)return;
  int last=desktopWeaponNestedViews.Count-1;
  if(desktopWeaponNestedViews[last]!=view)return;
  desktopWeaponNestedViews.RemoveAt(last);
  if(desktopWeaponNestedViews.Count!=0)return;
  foreach(var r in desktopWeaponOriginals)if(r!=null)r.enabled=false;
  for(int i=0;i<desktopWeaponParts.Count;i++)if(desktopWeaponParts[i]!=null)desktopWeaponParts[i].enabled=desktopWeaponPartEnabled[i];
 }
 private void RestoreDesktopWeaponVisual(){
  if(!desktopWeaponScoped)return;
  try{HideXiphias();HideSelected();}
  finally{
   if(desktopWeaponOriginals!=null)for(int i=0;i<desktopWeaponOriginals.Length;i++)if(desktopWeaponOriginals[i]!=null)desktopWeaponOriginals[i].enabled=desktopWeaponEnabled[i];
   if(desktopWeaponView!=null)desktopWeaponView.cullingMask=desktopWeaponMask;
   desktopWeaponNestedViews.Clear();desktopWeaponScoped=false;desktopWeaponView=null;desktopWeaponParts=null;
  }
 }
}}
