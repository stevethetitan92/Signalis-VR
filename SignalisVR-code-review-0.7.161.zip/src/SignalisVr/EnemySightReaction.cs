using System;
using HarmonyLib;
using MelonLoader;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static bool enemySightWarning;
 private static void ReactToEnemySight(global::EnemyController __instance){
  var q=weaponOwner;var e=__instance;
  if(q==null||!q.ProdVrMode()||!q.WeaponGameplayReady()||q.modMenuOpen||q.pauseMenuVisible
   ||global::PlayerState.paused||global::PlayerState.cutscene||global::PlayerState.suspendInput
   ||global::PlayerState.noplayer||global::PlayerState.gameOver||global::PlayerState.player==null)return;
  if(e==null||!e.isActiveAndEnabled||e.permadeath||e.queuedForRespawn||e.blind||e.busy
   ||e.hitbox==null||e.hitbox.HP<=0||e.playerPos==null
   ||e.staggerType!=global::EnemyController.hurtState.none||e.wakeupDelaying>0
   ||(e.customSleep&&!e.woken))return;
  if(e.state!=global::EnemyController.enemystate.sleep&&e.state!=global::EnemyController.enemystate.pursuit)return;
  try{
   // Run only at the native state-check cadence. Preserve authored obstruction,
   // facing and sight-distance checks; never force LOS true or start attacks.
   if(!e.LOS())return;
   if(e.state==global::EnemyController.enemystate.sleep)e.WakeUp();
   if(e.state==global::EnemyController.enemystate.pursuit){
    e.loseInterestTimer=0;
    e.attackStateDelayTimer=Math.Max(0,e.attackStateTransitionDelay)+.001f;
   }
  }catch(Exception ex){if(!enemySightWarning){enemySightWarning=true;MelonLogger.Warning("Enemy sight reaction retained native fallback: "+ex.Message);}}
 }
}}

