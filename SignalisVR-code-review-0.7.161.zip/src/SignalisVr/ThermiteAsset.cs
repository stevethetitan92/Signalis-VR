using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly List<Mesh> thermiteMeshes=new List<Mesh>();private readonly List<Texture2D> thermiteTextures=new List<Texture2D>();
  private void LoadThermiteAsset(){
   if(thermiteMeshes.Count>0)return;var shader=Shader.Find("Unlit/Texture");if(shader==null)throw new InvalidOperationException("Thermite texture shader unavailable");
   foreach(var encoded in ThermiteAssetData.Textures){var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);thermiteTextures.Add(tex);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(encoded),true))throw new InvalidOperationException("Thermite texture invalid");tex.filterMode=FilterMode.Point;var mat=new Material(shader);mat.mainTexture=tex;thermiteMaterials.Add(mat);}
   using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(ThermiteAssetData.Geometry)))){int count=r.ReadInt32();for(int k=0;k<count;k++){int nv=r.ReadInt32(),nt=r.ReadInt32();var v=new Vector3[nv];var uv=new Vector2[nv];var t=new int[nt];for(int i=0;i<nv;i++)v[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());for(int i=0;i<nv;i++)uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());for(int i=0;i<nt;i++)t[i]=r.ReadInt32();var mesh=new Mesh();mesh.name="ThermiteImported";mesh.vertices=v;mesh.uv=uv;mesh.triangles=HandSurfaceTopology.DoubleSided(t);mesh.RecalculateNormals();mesh.RecalculateBounds();thermiteMeshes.Add(mesh);}}
  }
  private void AlignImportedThermite(){
   if(thermiteHand==null||controllerMarkers[1]==null)return;
   var hand=controllerMarkers[1].transform;var rotation=WeaponAimPolicy.ControllerRotation(hand.rotation);
   thermiteHand.transform.rotation=rotation;thermiteHand.transform.localScale=Vector3.one*UnitsPerMetre;
   thermiteHand.transform.position=hand.position-rotation*new Vector3(.040f,-.075f,0)*UnitsPerMetre;
  }

  private void FitImportedThermite(){if(!ThermiteEligible()||thermiteHand==null||!handsScoped)return;string[] names={"index","middle","ring","pinky","thumb"};for(int i=0;i<names.Length;i++)FitFingerToContact(1,names[i],thermiteHand.transform.TransformPoint(ThermiteAssetData.FingerTargets[i]),14);}
  private void DestroyThermiteAsset(){foreach(var m in thermiteMeshes)if(m!=null)UnityEngine.Object.Destroy(m);foreach(var t in thermiteTextures)if(t!=null)UnityEngine.Object.Destroy(t);thermiteMeshes.Clear();thermiteTextures.Clear();}
 }
}
