﻿using System;
using System.Collections.Generic;
using UnityEngine;
using HarmonyLib;
namespace SignalisVrTracking { public sealed partial class Tracking {

 private readonly Dictionary<string,PackAudio[]> hdShotClips=new Dictionary<string,PackAudio[]>();
 private bool hdAudioFailed;private int hdSoundIndex;
 private bool EnsureHdGunAudio(string kind){
  if(kind=="FlareGun"||hdAudioFailed||!QuickFirearm(kind))return false;
  try{
   if(!hdShotClips.ContainsKey(kind)){
    int count=kind=="SMG"?2:kind=="Rifle"?3:4;var clips=new PackAudio[count];
    try{for(int c=0;c<count;c++){var data=Convert.FromBase64String(HdAsset.Read(kind+"-shot-"+c+".pcm"));clips[c]=new PackAudio(data,22050);}}
    catch{foreach(var clip in clips)if(clip!=null)clip.Dispose();throw;}
    hdShotClips.Add(kind,clips);
   }
   return true;
  }catch(Exception ex){hdAudioFailed=true;MelonLoader.MelonLogger.Warning("HD gun audio unavailable; native sound retained: "+ex.Message);return false;}
 }
 private static bool ReplaceHdShotAudio(string __0){
  var q=weaponOwner;var w=global::InventoryManager.EquippedWeapon;
  if(q==null||!q.ControllerWeaponReady()||w==null||w.parentItem==null||string.IsNullOrEmpty(__0)||__0!=w.shotMod)return true;
  string kind=WeaponFamily(w.parentItem._item.ToString());if(!q.EnsureHdGunAudio(kind))return true;
  try{var clips=q.hdShotClips[kind];q.PlayPackAt(clips[(q.hdSoundIndex++)%clips.Length],q.GunAudioPoint(),.8f);return false;}
  catch(Exception ex){q.hdAudioFailed=true;MelonLoader.MelonLogger.Warning("HD shot audio playback failed; native sound retained: "+ex.Message);return true;}
 }
 private void InstallHdGunAudio(HarmonyLib.Harmony h){
  var prefix=new HarmonyMethod(typeof(Tracking),nameof(ReplaceHdShotAudio));
  h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.RuntimeManager),"PlayOneShot",new[]{typeof(string),typeof(Vector3)}),prefix:prefix);
  h.Patch(AccessTools.DeclaredMethod(typeof(FMODUnity.RuntimeManager),"PlayOneShotAttached",new[]{typeof(string),typeof(GameObject)}),prefix:prefix);
 }
 private void DestroyHdGunAudio(){foreach(var clips in hdShotClips.Values)foreach(var c in clips)if(c!=null)c.Dispose();hdShotClips.Clear();hdAudioFailed=false;}
} }


