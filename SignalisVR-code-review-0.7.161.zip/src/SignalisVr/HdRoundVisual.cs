using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class HdRoundVisual {internal Mesh Mesh;internal Material[] Materials;}
 private readonly Dictionary<string,HdRoundVisual> hdRounds=new Dictionary<string,HdRoundVisual>();
 private static string RoundAppearance(string kind){
  var w=global::InventoryManager.EquippedWeapon;
  return kind=="FlareGun"&&w!=null&&w.ammoItem!=null&&w.ammoItem._item==global::Items.itemlist.FlakGunAmmo?"Grenade":kind;
 }
 private HdRoundVisual GetHdRound(string kind){
  kind=RoundAppearance(kind);if(kind=="FlareRound")kind="FlareGun";
  HdRoundVisual cached;if(hdRounds.TryGetValue(kind,out cached))return cached;
  var buildTimer=System.Diagnostics.Stopwatch.StartNew();
  string data=kind=="Grenade"?HdRoundData.Grenade:kind=="Rifle"?HdRoundData.Rifle:kind=="Shotgun"?HdRoundData.Shotgun:HdRoundData.FlareGun;
  var textures=kind=="Grenade"?HdRoundData.GrenadeTextures:kind=="Rifle"?HdRoundData.RifleTextures:kind=="Shotgun"?HdRoundData.ShotgunTextures:HdRoundData.FlareGunTextures;
  var colors=kind=="Grenade"?HdRoundData.GrenadeColors:kind=="Rifle"?HdRoundData.RifleColors:kind=="Shotgun"?HdRoundData.ShotgunColors:HdRoundData.FlareGunColors;
  var root=new GameObject("HD round import");var parts=new List<MeshRenderer>();var materials=new List<Material>();var meshes=new List<Mesh>();
  LoadHdMelee(root,data,textures,colors,parts,materials,meshes,kind=="Shotgun",kind=="FlareGun");
  if(kind=="Rifle"||kind=="FlareGun"||kind=="Grenade")foreach(var material in materials){var texture=material.mainTexture as Texture2D;if(texture!=null){texture.filterMode=FilterMode.Point;texture.wrapMode=TextureWrapMode.Clamp;}}
  var vertices=new List<Vector3>();var normals=new List<Vector3>();var uv=new List<Vector2>();var triangles=new List<int[]>();var mapped=new List<Material>();
  foreach(var part in parts){var mesh=part.GetComponent<MeshFilter>().sharedMesh;int offset=vertices.Count;vertices.AddRange(mesh.vertices);normals.AddRange(mesh.normals);uv.AddRange(mesh.uv);var t=mesh.triangles;for(int i=0;i<t.Length;i++)t[i]+=offset;triangles.Add(t);mapped.Add(part.sharedMaterial);}
  var combined=new Mesh();combined.vertices=vertices.ToArray();combined.normals=normals.ToArray();combined.uv=uv.ToArray();combined.subMeshCount=triangles.Count;for(int i=0;i<triangles.Count;i++)combined.SetTriangles(triangles[i],i);combined.RecalculateBounds();
  UnityEngine.Object.Destroy(root);foreach(var m in meshes)UnityEngine.Object.Destroy(m);
  cached=new HdRoundVisual{Mesh=combined,Materials=mapped.ToArray()};hdRounds.Add(kind,cached);if(buildTimer.Elapsed.TotalMilliseconds>8)MelonLoader.MelonLogger.Msg("WHEEL ROUND BUILD: "+kind+" ms="+buildTimer.Elapsed.TotalMilliseconds.ToString("F2"));return cached;
 }
 private static Color ShotgunShellColor(Color c){
  // Orange polymer -> dark red; keep bright neutral printed markings.
  if(c.r>c.g*1.35f&&c.g>c.b*1.5f)return new Color(c.r*.75f,c.r*.11f,c.r*.08f,c.a);
  // The atlas base is yellow brass, not part of the red polymer.
  if(c.r>c.g&&c.g>c.b*1.5f)return new Color(c.r*.75f,c.g*.75f,c.b*.75f,c.a);
  return c;
 }
 private static void ColorShotgunShell(Texture2D texture){
  var pixels=texture.GetPixels32();for(int i=0;i<pixels.Length;i++)pixels[i]=ShotgunShellColor(pixels[i]);
  texture.SetPixels32(pixels);texture.Apply(false,true);
 }
 private void CreateHdHeldRound(string kind){var visual=GetHdRound(kind);additionalAmmo=CreateControllerPart(additionalRoot,visual.Mesh,visual.Materials[0],"HD "+kind+" cartridge",Vector3.zero,Vector3.one);additionalAmmo.sharedMaterials=visual.Materials;}
 private void ApplyHdShotgunShell(){var visual=GetHdRound("Shotgun");shotgunShell.GetComponent<MeshFilter>().sharedMesh=visual.Mesh;shotgunShell.sharedMaterials=visual.Materials;shotgunShell.transform.localScale=Vector3.one;}
 private void EnsureHdRifleCase(){
  if(rifleCaseMesh!=null)return;
  var round=GetHdRound("Rifle");var src=round.Mesh;var indices=src.GetTriangles(0);var positions=src.vertices;var sourceNormals=src.normals;var sourceUv=src.uv;
  var map=new Dictionary<int,int>();var v=new List<Vector3>();var n=new List<Vector3>();var uv=new List<Vector2>();var turn=Quaternion.Euler(90,0,0);
  for(int i=0;i<indices.Length;i++){int old=indices[i],next;if(!map.TryGetValue(old,out next)){next=v.Count;map[old]=next;v.Add(turn*(positions[old]+Vector3.up*.057505101f));n.Add(turn*sourceNormals[old]);uv.Add(sourceUv[old]);}indices[i]=next;}
  rifleCaseMesh=new Mesh();rifleCaseMesh.vertices=v.ToArray();rifleCaseMesh.normals=n.ToArray();rifleCaseMesh.uv=uv.ToArray();rifleCaseMesh.triangles=indices;rifleCaseMesh.RecalculateBounds();rifleCaseMaterial=new Material(round.Materials[0]);
 }
 private readonly MeshRenderer[] chamberRoundVisuals=new MeshRenderer[2];
 private void HideChamberRounds(){foreach(var r in chamberRoundVisuals)if(r!=null)r.enabled=false;}
 private void PrepareChamberRound(string kind,int chamber,Vector3 mouth,Vector3 axis,bool visible){
  if(!visible)return;var round=GetHdRound(kind);var r=chamberRoundVisuals[chamber];
  if(r==null){r=CreateControllerPart(selectedRoot,round.Mesh,round.Materials[0],"Seated cartridge "+chamber,Vector3.zero,Vector3.one);chamberRoundVisuals[chamber]=r;}
  r.GetComponent<MeshFilter>().sharedMesh=round.Mesh;r.sharedMaterials=round.Materials;
  r.transform.position=mouth+axis*(round.Mesh.bounds.extents.y*UnitsPerMetre);
  // LookRotation with a fixed gun-down vector projects the up axis away from
  // the hinged bore. Map the cartridge's actual +Y axis directly to the bore.
  r.transform.rotation=Quaternion.FromToRotation(Vector3.up,axis);r.enabled=true;
 }
 private void DestroyHdRounds(){foreach(var v in hdRounds.Values){if(v.Mesh!=null)UnityEngine.Object.Destroy(v.Mesh);foreach(var m in v.Materials)if(m!=null)UnityEngine.Object.Destroy(m);}hdRounds.Clear();}
} }



