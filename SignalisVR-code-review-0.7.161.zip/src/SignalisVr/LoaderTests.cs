using System;
using System.IO;
using System.Runtime.InteropServices;
using SignalisVrTracking;
class LoaderTests
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int Version();
    static int Main(string[] args)
    {
        try
        {
            NativeLibraries.Initialize();
            if (args.Length != 0) throw new Exception("Expected dependency rejection did not occur.");
            if (NativeLibraries.Bind<Version>(true, "GetBridgeVersion")() != 403) throw new Exception("Wrong ABI");
            // Calls the real packaged OpenVR export without connecting a VR scene.
            bool installed = Valve.VR.OpenVR.IsRuntimeInstalled();
            try { NativeLibraries.Bind<Version>(true, "NonexistentExportForTest"); throw new Exception("Missing export accepted"); }
            catch (EntryPointNotFoundException) { }
            Console.WriteLine("PASS relocated native load, bridge ABI, OpenVR delegate, missing-export error: " + NativeLibraries.LibraryDirectory + "; SteamVR installed=" + installed);
            return 0;
        }
        catch (Exception ex)
        {
            if (args.Length == 1 && ex.Message.Contains(args[0])) { Console.WriteLine("PASS rejection: " + ex.Message); return 0; }
            Console.Error.WriteLine(ex); return 1;
        }
    }
}
