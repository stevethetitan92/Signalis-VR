using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class PerspectiveCameraState {
  public Camera Camera,Ui;public Transform Parent;public Vector3 Position,Scale;public Quaternion Rotation;
  public bool Ortho,UiOrtho,ControlEnabled;public float Fov,Size;public global::AngledCamControl Control;
  public PerspectiveCameraState(Camera c){Camera=c;var t=c.transform;Parent=t.parent;Position=t.localPosition;Rotation=t.localRotation;Scale=t.localScale;Ortho=c.orthographic;Fov=c.fieldOfView;Size=c.orthographicSize;Control=c.GetComponent<global::AngledCamControl>();ControlEnabled=Control!=null&&Control.enabled;var ui=t.Find("VHS UI");Ui=ui==null?null:ui.GetComponent<Camera>();UiOrtho=Ui!=null&&Ui.orthographic;}
  public void Apply(){if(Camera==null||Parent==null)return;var t=Camera.transform;t.SetParent(Parent,false);t.localPosition=Position;t.localRotation=Rotation;t.localScale=Scale;Camera.orthographic=Ortho;Camera.fieldOfView=Fov;Camera.orthographicSize=Size;if(Control!=null)Control.enabled=ControlEnabled;if(Ui!=null)Ui.orthographic=UiOrtho;}
 }
 private PerspectiveCameraState nativeCutsceneHome,perspectiveCutsceneReturn;
 private void InstallNativeCutsceneCamera(Assembly assembly){var type=assembly.GetType("Camera_Perspective_Mod.SignalisCodeBank");var method=AccessTools.Method(type,"CustomCamera");if(method==null)throw new InvalidOperationException("Perspective camera handoff missing");questHarmony.Patch(method,prefix:new HarmonyMethod(typeof(Tracking),nameof(RememberNativeCamera)));}
 private static void RememberNativeCamera(GameObject __0){
  var q=questOwner;if(q==null||__0==null||SceneManager.GetActiveScene().name=="PEN_Hole")return;
  var c=__0.GetComponent<Camera>();if(c==null||c.transform.parent==null||c.transform.parent.name=="Character Root")return;
  if(q.nativeCutsceneHome==null||q.nativeCutsceneHome.Camera!=c)q.nativeCutsceneHome=new PerspectiveCameraState(c);
 }
 private void UpdateNativeCutsceneCamera(){
  if(nativeCutsceneHome==null||nativeCutsceneHome.Camera==null){nativeCutsceneHome=perspectiveCutsceneReturn=null;return;}
  if(!immersiveRequested||stopping)return;
  // Dialogue and pickups also set the broad cutscene flag. Only an authored
  // cinematic starts the native camera handoff. Once started, retain it through
  // an authored photo/dialogue until the native sequence clears its flag.
  var state=global::PlayerState.gameState;
  bool cinematic=ModHudCinematicVisible()||state==global::PlayerState.gameStates.cutscene
   ||(perspectiveCutsceneReturn!=null&&global::PlayerState.cutscene)
   ||(global::PlayerState.cutscene&&state!=global::PlayerState.gameStates.dialogue&&!global::BlackSleekGuiSubs.itemView);
  if(StorageStereoActive())cinematic=false;
  if(global::PlayerState.player!=null&&(global::PlayerState.hp<=0||global::PlayerState.gameOver))cinematic=!ProdVrMode();
  if(cinematic&&perspectiveCutsceneReturn==null){var c=nativeCutsceneHome.Camera;if(c.transform.parent==null||c.transform.parent.name!="Character Root")return;perspectiveCutsceneReturn=new PerspectiveCameraState(c);nativeCutsceneHome.Apply();MelonLoader.MelonLogger.Msg("CUTSCENE CAMERA: returned converted camera to its original native rig.");}
  else if(!cinematic&&perspectiveCutsceneReturn!=null){perspectiveCutsceneReturn.Apply();perspectiveCutsceneReturn=null;MelonLoader.MelonLogger.Msg("CUTSCENE CAMERA: restored gameplay perspective after native sequence.");}
 }
}}





