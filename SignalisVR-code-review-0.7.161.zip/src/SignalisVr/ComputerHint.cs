using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Camera computerHintOwner;
 private Transform computerHintPrograms,computerHintLoaders;
 private GameObject computerHintRoot;
 private Mesh computerHintMesh;
 private Material computerHintMaterial;
 private MeshRenderer computerHintRenderer;
 private bool ComputerDesktopHintVisible(){
  return computerGuiPresented&&!computerStagePresented&&ComputerDesktopIdle();
 }
 private bool ComputerDesktopIdle(){
  if(computerGuiCamera==null||global::PlayerState.gameState!=global::PlayerState.gameStates.eventScreen)return false;
  if(computerHintOwner!=computerGuiCamera){
   computerHintOwner=computerGuiCamera;
   computerHintPrograms=computerGuiCamera.transform.Find("PC_content/Programs");
   computerHintLoaders=computerGuiCamera.transform.Find("PC_content/Loaders");
  }
  if(computerHintPrograms==null)return false;
  return !ComputerProgramVisible(computerHintPrograms)&&!ComputerProgramVisible(computerHintLoaders);
 }
 private static bool ComputerProgramVisible(Transform programs){
  if(programs==null)return false;
  for(int i=0;i<programs.childCount;i++)if(programs.GetChild(i).gameObject.activeInHierarchy)return true;
  return false;
 }
 private void RenderComputerHint(){
  if(!ComputerDesktopHintVisible())return;
  if(computerHintRoot==null){
   EnsureGlyphAtlas();var shader=Shader.Find("Sprites/Default");if(shader==null)return;
   computerHintRoot=new GameObject("SignalisVR_ComputerStartupHint");computerHintRoot.layer=31;
   computerHintRoot.transform.SetParent(puzzleScreen.transform,false);
   computerHintRoot.transform.localPosition=new Vector3(0f,-.40f,-.001f);
   computerHintMesh=new Mesh();computerHintMesh.name="Computer startup prompt";
   const string caption="PRESS A TO OPEN POSTBOX";string previous=null;
   UpdateModHudText(computerHintMesh,caption,ref previous);
   float scale=.72f/(PixelTextWidth(caption)*.014f*UnitsPerMetre/32f);
   computerHintRoot.transform.localScale=Vector3.one*scale;
   computerHintRoot.AddComponent<MeshFilter>().sharedMesh=computerHintMesh;
   computerHintMaterial=new Material(shader);computerHintMaterial.mainTexture=modGlyphAtlas;computerHintMaterial.color=Color.white;
   computerHintRenderer=computerHintRoot.AddComponent<MeshRenderer>();computerHintRenderer.sharedMaterial=computerHintMaterial;
   computerHintRenderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;computerHintRenderer.receiveShadows=false;
  }
  computerHintRenderer.enabled=true;
 }
 private void HideComputerHint(){if(computerHintRenderer!=null)computerHintRenderer.enabled=false;}
 private void ClearComputerHint(){
  HideComputerHint();computerHintOwner=null;computerHintPrograms=null;computerHintLoaders=null;
  if(computerHintRoot!=null)UnityEngine.Object.Destroy(computerHintRoot);
  if(computerHintMesh!=null)UnityEngine.Object.Destroy(computerHintMesh);
  if(computerHintMaterial!=null)UnityEngine.Object.Destroy(computerHintMaterial);
  computerHintRoot=null;computerHintMesh=null;computerHintMaterial=null;computerHintRenderer=null;
 }
}}
