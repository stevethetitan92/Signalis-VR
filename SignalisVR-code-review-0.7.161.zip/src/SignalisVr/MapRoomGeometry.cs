using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class JoinedMapRoom {public List<Rect> Rects;public bool Current,Blocked;}
 private readonly List<JoinedMapRoom> joinedRooms=new List<JoinedMapRoom>();
 private readonly List<Rect> joinedDesktopQuads=new List<Rect>();private readonly List<Color> joinedDesktopColors=new List<Color>();
 private readonly List<Vector2[]> mapBarricadeLines=new List<Vector2[]>();
 private Mesh joinedRoomMesh;private MeshRenderer joinedRoomRenderer;
 private static Rect MapShapeRect(SpriteRenderer sr,Transform basis){
  var b=MapSpriteBounds(sr);var lo=new Vector2(float.PositiveInfinity,float.PositiveInfinity);var hi=new Vector2(float.NegativeInfinity,float.NegativeInfinity);
  for(int k=0;k<4;k++){var p=basis.InverseTransformPoint(sr.transform.TransformPoint(b.center+Vector3.Scale(b.extents,new Vector3((k&1)==0?-1:1,(k&2)==0?-1:1,0))));lo=Vector2.Min(lo,new Vector2(p.x,p.y));hi=Vector2.Max(hi,new Vector2(p.x,p.y));}
  return new Rect(lo,hi-lo);
 }
 private static bool InMapRects(List<Rect> rects,float x,float y){foreach(var r in rects)if(x>r.xMin-.001f&&x<r.xMax+.001f&&y>r.yMin-.001f&&y<r.yMax+.001f)return true;return false;}
 private void MapRoomQuad(Vector2 lo,Vector2 hi,Color color){
  if(color.a>.5f){joinedDesktopQuads.Add(new Rect(lo,hi-lo));joinedDesktopColors.Add(color);}
  int start=mapStrokeVertices.Count;
  foreach(var p in new[]{lo,new Vector2(hi.x,lo.y),hi,new Vector2(lo.x,hi.y)}){var q=(p-modMapCenter)*modMapScale;mapStrokeVertices.Add(new Vector3(q.x,q.y,0));mapStrokeColors.Add(color);}
  foreach(var i in new[]{0,1,2,0,2,3})mapStrokeTriangles.Add(start+i);
 }
 private void BuildJoinedMapRooms(){
  // Only the two reported compound rooms. Split at rectangle boundaries so
  // translucent fill never overlaps; emit a border only against empty space.
  BeginMapStrokeMesh();mapBarricadeLines.Clear();joinedDesktopQuads.Clear();joinedDesktopColors.Clear();
  foreach(var room in joinedRooms){
   var xs=new List<float>();var ys=new List<float>();foreach(var r in room.Rects){if(!xs.Contains(r.xMin))xs.Add(r.xMin);if(!xs.Contains(r.xMax))xs.Add(r.xMax);if(!ys.Contains(r.yMin))ys.Add(r.yMin);if(!ys.Contains(r.yMax))ys.Add(r.yMax);}xs.Sort();ys.Sort();
   var edge=room.Current?new Color(1,.12f,.12f,.9f):new Color(.35f,.85f,1,.8f);var fill=edge;fill.r*=.12f;fill.g*=.12f;fill.b*=.12f;fill.a=.6f;
   Action<Vector2,Vector2> border=(a,b)=>{VrMapStroke((a-modMapCenter)*modMapScale,(b-modMapCenter)*modMapScale,edge,.075f*modMapScale,0,0);joinedDesktopQuads.Add(new Rect(Math.Min(a.x,b.x)-.0375f,Math.Min(a.y,b.y)-.0375f,Math.Abs(a.x-b.x)+.075f,Math.Abs(a.y-b.y)+.075f));joinedDesktopColors.Add(edge);};
   for(int x=0;x<xs.Count-1;x++)for(int y=0;y<ys.Count-1;y++){
    float a=xs[x],b=xs[x+1],c=ys[y],d=ys[y+1],mx=(a+b)*.5f,my=(c+d)*.5f;
    if(!InMapRects(room.Rects,mx,my))continue;MapRoomQuad(new Vector2(a,c),new Vector2(b,d),fill);
    if(!InMapRects(room.Rects,a-.01f,my))border(new Vector2(a,c),new Vector2(a,d));
    if(!InMapRects(room.Rects,b+.01f,my))border(new Vector2(b,c),new Vector2(b,d));
    if(!InMapRects(room.Rects,mx,c-.01f))border(new Vector2(a,c),new Vector2(b,c));
    if(!InMapRects(room.Rects,mx,d+.01f))border(new Vector2(a,d),new Vector2(b,d));
   }
   var dot=edge;dot.a=.13f;
   for(float x=xs[0]+.2f;x<xs[xs.Count-1];x+=.4f)for(float y=ys[0]+.2f;y<ys[ys.Count-1];y+=.4f)if(InMapRects(room.Rects,x,y))MapRoomQuad(new Vector2(x-.025f,y-.025f),new Vector2(x+.025f,y+.025f),dot);
   if(room.Blocked){ // Reported blockage halfway along the long hallway arm.
    var arm=room.Rects[0];foreach(var r in room.Rects)if(r.height>arm.height)arm=r;
    var red=new Color(1,.12f,.12f,.95f);float y=arm.center.y,h=.18f;
    Action<Vector2,Vector2> bar=(a,b)=>{VrMapStroke((a-modMapCenter)*modMapScale,(b-modMapCenter)*modMapScale,red,.075f*modMapScale,0,0);mapBarricadeLines.Add(new[]{a,b});};
    bar(new Vector2(arm.xMin,y-h),new Vector2(arm.xMax,y-h));bar(new Vector2(arm.xMin,y+h),new Vector2(arm.xMax,y+h));
    bar(new Vector2(arm.xMin,y-h),new Vector2(arm.xMin,y+h));bar(new Vector2(arm.xMax,y-h),new Vector2(arm.xMax,y+h));
    for(float x=arm.xMin;x<arm.xMax;x+=.4f){float end=Math.Min(x+.36f,arm.xMax);bar(new Vector2(x,y-h),new Vector2(end,y-h+(end-x)));}
   }
  }
  FinishMapStrokeMesh(ref joinedRoomMesh,ref joinedRoomRenderer,"JoinedMapRooms");joinedRoomRenderer.sortingOrder=0;
 }
 private void DrawJoinedMapDesktop(Vector2 center,float factor){
  if(minesMapActive)DrawMineMapDesktop(center,factor);
  else if(nowhereMapActive)DrawMineMapDesktop(center,factor);
  for(int i=0;i<joinedDesktopQuads.Count;i++){var r=joinedDesktopQuads[i];var lo=(new Vector2(r.xMin,r.yMin)-modMapCenter)*modMapScale;var hi=(new Vector2(r.xMax,r.yMax)-modMapCenter)*modMapScale;GUI.color=joinedDesktopColors[i];GUI.DrawTexture(new Rect(center.x+lo.x*factor,center.y-hi.y*factor,(hi.x-lo.x)*factor,(hi.y-lo.y)*factor),Texture2D.whiteTexture);}
  foreach(var line in mapBarricadeLines){var a=(line[0]-modMapCenter)*modMapScale;var b=(line[1]-modMapCenter)*modMapScale;DrawMapLine(new Vector2(center.x+a.x*factor,center.y-a.y*factor),new Vector2(center.x+b.x*factor,center.y-b.y*factor),.075f*modMapScale*factor,new Color(1,.12f,.12f,.95f));}
 }
 private static void MapRoomLabelBounds(global::PersistentMinimapRoom room,Transform basis,ref Vector2 low,ref Vector2 high){
  // Fit inside a real rectangle of a compound room, never its empty bounding box.
  Rect best=new Rect();float area=0;
  foreach(var shape in room.GetComponentsInChildren<global::MinimapActiveRoom>(true)){
   var sr=shape.SR;if(sr==null)sr=shape.GetComponent<SpriteRenderer>();if(sr==null||sr.sprite==null||sr.drawMode==SpriteDrawMode.Simple)continue;
   var r=MapShapeRect(sr,basis);float next=r.width*r.height;
   if(next>area+.001f||(Math.Abs(next-area)<=.001f&&r.width>best.width)){best=r;area=next;}
  }
  if(area>0){low=new Vector2(best.xMin,best.yMin);high=new Vector2(best.xMax,best.yMax);}
 }
 private bool MapLadderOpening(MapPoint point,global::PersistentMinimapFloor floor,Transform basis,out Vector2 position){
  position=Vector2.zero;
  if(point.Kind!=11||point.Source==null||!point.Source.name.StartsWith("PN "))return false;
  // The authored small Paternoster bays are map geometry. A is a standing
  // point in the hallway and must not be used as the ladder opening.
  global::PersistentMinimapRoom owner=null;
  foreach(var room in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true))if(point.Room!=null&&room.RoomID==point.Room.minimapRoom){owner=room;break;}
  if(owner==null)return false;var bays=new List<Rect>();
  foreach(var shape in owner.GetComponentsInChildren<global::MinimapActiveRoom>(true)){var sr=shape.SR;if(sr==null)sr=shape.GetComponent<SpriteRenderer>();if(sr==null||sr.sprite==null||sr.sprite.name!="RoomShapes_5")continue;bays.Add(MapShapeRect(sr,basis));}
  if(bays.Count!=2)return false;bays.Sort((a,b)=>a.center.x.CompareTo(b.center.x));
  var bay=bays[point.Source.name.EndsWith(" D")?0:1];position=(new Vector2(bay.center.x,bay.yMin)-modMapCenter)*modMapScale;return true;
 }
}}
