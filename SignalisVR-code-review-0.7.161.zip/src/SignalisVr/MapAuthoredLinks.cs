// Derived from read-only shipped Room/ConnectedDoors/Ladder links and floor meshes.
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static readonly MapEntry[] mapLadderCatalogue={
new MapEntry("11|Service Tunnel|Service Tunnel/Chunk/Ladder","Service Tunnel",11,.5f,.5f,11),
new MapEntry("2|Lower Gallery|Lower Gallery/Chunk/Ladder","Lower Gallery",2,0.49963230f,0.35518448f,11),
new MapEntry("1|Upper Gallery|Upper Gallery/Chunk/Ladder","Upper Gallery",1,0.49686241f,0.45316687f,11),
new MapEntry("7|Flooded Bathroom|Flooded Bathroom/Chunk/Ladder","Flooded Bathroom",7,0.37731687f,0.39869428f,11),
new MapEntry("6|Protektor Bathroom|Protektor Bathroom/Chunk/Ladder","Protektor Bathroom",6,0.18121758f,0.03000000f,11),
new MapEntry("7|Surgery Mynah|Surgery Mynah/Chunk/Ladder","Surgery Mynah",7,0.54994028f,0.97000000f,11),
new MapEntry("6|Pipe Room Upper|Pipe Room Upper/Chunk/Ladder","Pipe Room Upper",6,0.13776319f,0.86292262f,11),
new MapEntry("7|Pipe Room Lower|Pipe Room Lower/Chunk/Ladder","Pipe Room Lower",7,0.13776319f,0.86292263f,11),
new MapEntry("11|8F S Corridor|8F S Corridor/Chunk/Objects/Paternoster/Interactions/PN 1 D","8F S Corridor",11,0.17058618f,0.97000000f,11),
new MapEntry("10|7F S Corridor|7F S Corridor/Chunk/Objects/Paternoster/Interactions/PN 2 D","7F S Corridor",10,0.17044394f,0.97000000f,11),
new MapEntry("11|8F S Corridor|8F S Corridor/Chunk/Objects/Paternoster/Interactions/PN 1 U","8F S Corridor",11,0.28706361f,0.97000000f,11),
new MapEntry("10|7F S Corridor|7F S Corridor/Chunk/Objects/Paternoster/Interactions/PN 2 U","7F S Corridor",10,0.28692139f,0.97000000f,11),
new MapEntry("9|ARAR Dorm|ARAR Dorm (Boat Room)/Chunk/Hole/Hole Drop","ARAR Dorm",9,0.67725174f,0.79806405f,11),
new MapEntry("9|6F S Corridor|6F S Corridor/Chunk/Objects/Paternoster/Interactions/PN 3 U","6F S Corridor",9,0.28692139f,0.97000000f,11),
new MapEntry("9|6F S Corridor|6F S Corridor/Chunk/Objects/Paternoster/Interactions/PN 3 D","6F S Corridor",9,0.17044394f,0.97000000f,11),
new MapEntry("11|STCR Dorm|KNCR Dorm/Chunk/NestHatch/Hole/Hole Drop","STCR Dorm",11,0.88461647f,0.88704972f,11),
new MapEntry("16|Meat Ladder Room|Meat Ladder Room/Chunk/Ladder ME U","Meat Ladder Room",16,0.50026266f,0.77384260f,11),
new MapEntry("16|Chimera Room|Chimera Room/Chunk/Ladder","Chimera Room",16,0.50026266f,0.58166329f,11),
new MapEntry("13|Tree|Hole/Chunk/Ladder","Tree",13,0.50026223f,0.57562094f,11),
new MapEntry("13|Execution|Execution Room/Chunk/Ladder EX U","Execution",13,0.50026266f,0.28551067f,11),
new MapEntry("14|Nursery|Nursery/Chunk/Ladder NU D","Nursery",14,0.50026260f,0.90105050f,11),
new MapEntry("14|Mid Ladder Room|Mid Ladder Room/Chunk/Ladder ME D","Mid Ladder Room",14,0.50041279f,0.64368075f,11),
new MapEntry("15|Upper Gallery|Upper Gallery Hole/Chunk/Ladder","Upper Gallery",15,0.49057450f,0.03000000f,11),
new MapEntry("17|Lower Gallery|Lower Gallery/Chunk/Ladder","Lower Gallery",17,0.49963230f,0.35518448f,11),
new MapEntry("18|Upper Gallery|Upper Gallery/Chunk/Ladder","Upper Gallery",18,0.49686241f,0.45316687f,11),
new MapEntry("21|Space Between Walls|Space Between Walls/Chunk/Ladder D","Space Between Walls",21,0.24681063f,0.95704514f,11),
new MapEntry("21|Ladder Room (Down)|Ladder Room (Down)/Chunk/Ladder U","Ladder Room (Down)",21,0.50853419f,0.83656584f,11),
new MapEntry("20|Fire Ladder (Top)|Fire Ladder (Top)/Chunk/Ladder D","Fire Ladder (Top)",20,0.37728671f,0.32322894f,11),
new MapEntry("20|Clotheslines Hallway|Clotheslines Hallway/Chunk/Hole Drop","Clotheslines Hallway",20,0.31371671f,0.91485709f,11),
new MapEntry("21|Garbage Chute (Down)|Garbage Chute (Down)/Chunk/Ladder U","Garbage Chute (Down)",21,0.23665919f,0.88569008f,11),
new MapEntry("21|Water Room (Top)|Water Room (Top)/Chunk/Ladder D","Water Room (Top)",21,0.42050299f,0.82184779f,11),
new MapEntry("22|Fire Ladder (Down)|Fire Ladder (Down)/Chunk/Ladder U","Fire Ladder (Down)",22,0.27339711f,0.90285771f,11),
new MapEntry("21|Space Between Walls|Space Between Walls/Chunk/Ladder U","Space Between Walls",21,0.75540124f,0.95704514f,11),
new MapEntry("22|Cooling Room|Cooling Room/Chunk/Hole Drop Target","Cooling Room",22,0.49998043f,0.67046353f,11),
new MapEntry("22|Water Room (Down)|Water Room (Down)/Chunk/Ladder U","Water Room (Down)",22,0.37871538f,0.86657410f,11),
new MapEntry("20|Ladder Room (Top)|Ladder Room (Top)/Chunk/Ladder D","Ladder Room (Top)",20,0.27600178f,0.82335480f,11),
new MapEntry("21|Meat Grinder|Meat Grinder/Chunk/Hole Drop","Meat Grinder",21,0.63520596f,0.81715745f,11),
new MapEntry("23|Yeong Apartment|Apartment (Save Room)/Chunk/Hole Drop","Yeong Apartment",23,0.38507826f,0.97000000f,11),
new MapEntry("23|FinalStudy|Falkes Study/Chunk/Hole Drop","FinalStudy",23,0.50866663f,0.04727690f,11),
new MapEntry("23|Falke|Arena/Chunk/Hole Drop","Falke",23,0.42937112f,0.58090686f,11),
new MapEntry("23|FinalBedroom|Falkes Bedroom/Chunk/Hole Drop","FinalBedroom",23,0.03000000f,0.90240872f,11),
 };
 private static string MapAuthoredRequiredKey(int floor,string room,int count,int index){
  if(floor==1&&room=="Upper Gallery"&&count==4&&index==2)return "Airlock Key";
  if(floor==1&&room=="Mess Hall"&&count==1&&index==0)return "Airlock Key";
  if(floor==1&&room=="Forward Hall"&&count==4&&index==1)return "Airlock Key";
  if(floor==1&&room=="Airlock"&&count==1&&index==0)return "Airlock Key";
  if(floor==2&&room=="Maintenance"&&count==1&&index==0)return "Airlock Key";
  if(floor==2&&room=="Lower Gallery"&&count==2&&index==1)return "Airlock Key";
  if(floor==1&&room=="Upper Gallery"&&count==4&&index==3)return "Airlock Key";
  if(floor==1&&room=="Forward Hall"&&count==4&&index==0)return "Airlock Key";
  if(floor==1&&room=="Forward Hall"&&count==4&&index==3)return "Airlock Key";
  if(floor==1&&room=="Flight Deck"&&count==1&&index==0)return "Airlock Key";
  if(floor==1&&room=="Forward Hall"&&count==4&&index==2)return "Airlock Key";
  if(floor==1&&room=="Storage"&&count==1&&index==0)return "Airlock Key";
  if(floor==1&&room=="Reaktor"&&count==2&&index==1)return "Airlock Key";
  if(floor==1&&room=="Medical"&&count==2&&index==0)return "Airlock Key";
  if(floor==1&&room=="Stern Hall"&&count==4&&index==0)return "Airlock Key";
  if(floor==1&&room=="Cryogenics"&&count==1&&index==0)return "Airlock Key";
  if(floor==3&&room=="SurfaceAccess"&&count==4&&index==2)return "Surface Key";
  if(floor==3&&room=="South Corridor"&&count==6&&index==3)return "Surface Key";
  if(floor==3&&room=="Hole Classroom"&&count==1&&index==0)return "Classroom Key";
  if(floor==3&&room=="Aula"&&count==4&&index==0)return "Classroom Key";
  if(floor==3&&room=="Overlook Office"&&count==1&&index==0)return "Observation Key";
  if(floor==3&&room=="South Corridor"&&count==6&&index==1)return "Observation Key";
  if(floor==5&&room=="Tram Ramp"&&count==5&&index==0)return "Master Key";
  if(floor==5&&room=="North Corridor"&&count==6&&index==4)return "East Wing Key";
  if(floor==5&&room=="North East Corridor"&&count==5&&index==2)return "East Wing Key";
  if(floor==5&&room=="Kitchen"&&count==3&&index==1)return "Mensa Key";
  if(floor==5&&room=="Mensa"&&count==2&&index==0)return "Mensa Key";
  if(floor==5&&room=="Tram Ramp"&&count==5&&index==3)return "West Wing Key";
  if(floor==5&&room=="Elevator Lobby"&&count==5&&index==2)return "West Wing Key";
  if(floor==6&&room=="West Corridor"&&count==6&&index==5)return "Pump Room Key";
  if(floor==6&&room=="Pump Room"&&count==1&&index==0)return "Pump Room Key";
  if(floor==6&&room=="Exam Room"&&count==1&&index==0)return "Exam Room Key";
  if(floor==6&&room=="North Corridor"&&count==5&&index==0)return "Exam Room Key";
  if(floor==6&&room=="Incinerator"&&count==1&&index==0)return "Incinerator Room Key";
  if(floor==6&&room=="Morgue"&&count==2&&index==0)return "Incinerator Room Key";
  if(floor==11&&room=="Mineshaft Elevator"&&count==1&&index==0)return "Administrator's Key";
  if(floor==11&&room=="Mineshaft Access"&&count==2&&index==0)return "Administrator's Key";
  if(floor==11&&room=="Library"&&count==1&&index==0)return "Library Key";
  if(floor==11&&room=="8F S Corridor"&&count==6&&index==0)return "Library Key";
  if(floor==9&&room=="Workshop"&&count==1&&index==0)return "Workshop Key";
  if(floor==9&&room=="6F S Corridor"&&count==6&&index==0)return "Workshop Key";
  if(floor==10&&room=="Rec Room"&&count==1&&index==0)return "Shutter Handle";
  if(floor==10&&room=="7F E Corridor"&&count==3&&index==1)return "Shutter Handle";
  if(floor==8&&room=="5F Flood Overflow"&&count==1&&index==0)return "Overflow Key";
  if(floor==8&&room=="5F Elevator Lobby"&&count==6&&index==2)return "Overflow Key";
  if(floor==9&&room=="EULR Dorm"&&count==1&&index==0)return "Eule Key";
  if(floor==9&&room=="6F Elevator Lobby"&&count==7&&index==2)return "Eule Key";
  if(floor==11&&room=="Adlers Study"&&count==1&&index==0)return "Eagle Key";
  if(floor==11&&room=="Adlers Bedroom"&&count==2&&index==0)return "Eagle Key";
  if(floor==11&&room=="Kolibris Study"&&count==2&&index==1)return "Kolibri Key";
  if(floor==11&&room=="8F E Corridor"&&count==3&&index==1)return "Kolibri Key";
  if(floor==13&&room=="Torture Room"&&count==3&&index==2)return "Rusted Key";
  if(floor==13&&room=="Execution"&&count==4&&index==1)return "Rusted Key";
  if(floor==18&&room=="Forward Hall"&&count==4&&index==2)return "Airlock Key";
  if(floor==18&&room=="Storage"&&count==1&&index==0)return "Airlock Key";
  if(floor==17&&room=="Service Hall B"&&count==4&&index==3)return "Airlock Key";
  if(floor==17&&room=="Service Hall A"&&count==4&&index==0)return "Airlock Key";
  if(floor==17&&room=="Lower Gallery"&&count==2&&index==0)return "Airlock Key";
  if(floor==17&&room=="Service Hall A"&&count==4&&index==3)return "Airlock Key";
  if(floor==17&&room=="Observation"&&count==1&&index==0)return "Airlock Key";
  if(floor==17&&room=="Service Hall B"&&count==4&&index==0)return "Airlock Key";
  if(floor==18&&room=="Upper Gallery"&&count==4&&index==2)return "Airlock Key";
  if(floor==18&&room=="Mess Hall"&&count==1&&index==0)return "Airlock Key";
  if(floor==18&&room=="Forward Hall"&&count==4&&index==1)return "Airlock Key";
  if(floor==17&&room=="Maintenance"&&count==1&&index==0)return "Airlock Key";
  if(floor==17&&room=="Lower Gallery"&&count==2&&index==1)return "Airlock Key";
  if(floor==18&&room=="Upper Gallery"&&count==4&&index==3)return "Airlock Key";
  if(floor==18&&room=="Forward Hall"&&count==4&&index==0)return "Airlock Key";
  if(floor==18&&room=="Forward Hall"&&count==4&&index==3)return "Airlock Key";
  if(floor==18&&room=="Flight Deck"&&count==1&&index==0)return "Airlock Key";
  if(floor==18&&room=="Forward Hall"&&count==4&&index==2)return "Airlock Key";
  if(floor==18&&room=="Storage"&&count==1&&index==0)return "Airlock Key";
  if(floor==18&&room=="Reaktor"&&count==2&&index==1)return "Airlock Key";
  if(floor==18&&room=="Medical"&&count==2&&index==0)return "Airlock Key";
  if(floor==18&&room=="Stern Hall"&&count==4&&index==0)return "Airlock Key";
  if(floor==18&&room=="Cryogenics"&&count==1&&index==0)return "Airlock Key";
  if(floor==4&&room=="Hole Classroom"&&count==1&&index==0)return "Classroom Key";
  if(floor==4&&room=="Aula"&&count==4&&index==0)return "Classroom Key";
  if(floor==20&&room=="Meat Apartment"&&count==1&&index==0)return "Klinik Key";
  if(floor==20&&room=="Apartment Corridor"&&count==5&&index==0)return "Klinik Key";
  if(floor==22&&room=="Metro Station"&&count==5&&index==0)return "Store Key";
  if(floor==22&&room=="Photo Store"&&count==2&&index==1)return "Store Key";
  return null;
 }
 private static bool MapHasAuthoredLadder(string id){foreach(var entry in mapLadderCatalogue)if(id.StartsWith(MapDiscoveryPrefix)&&MapIdentityPolicy.Matches(entry.Id,id.Substring(MapDiscoveryPrefix.Length)))return true;return false;}
 private static bool MapCatalogueLadderKnown(MapEntry entry){
  bool known=global::SProgress.GetInt(MapDiscoveryPrefix+entry.Id,0)!=0;
  bool visited=global::SProgress.GetInt(MapVisitKey(entry.Floor,entry.Room),0)!=0;
  // The tunnel's native jammer/hidden artwork can omit its own visit record.
  // Reveal this authored connection once its adjoining hallway is known.
  if(entry.Floor==11&&entry.Room=="Service Tunnel")return known||visited||global::SProgress.GetInt(MapVisitKey(11,"8F S Corridor"),0)!=0;
  if(entry.Floor==6&&entry.Room=="Protektor Bathroom")return known||(visited&&MapNativePuzzleDone("MED_FloodedBath"));
  return known||visited;
 }
 private static void MapLadderLabelBounds(global::PersistentMinimapRoom room,int floor,ref UnityEngine.Vector2 low,ref UnityEngine.Vector2 high){
  if(room.RoomID==null)return;
  if(room.RoomID.name=="Flood Overflow"||room.RoomID.name.EndsWith(" Flood Overflow",System.StringComparison.Ordinal)){low.y=high.y-(high.y-low.y)*.30f;return;}
  float y=0;int count=0;
  foreach(var e in mapLadderCatalogue)if(e.Floor==floor&&e.Room==room.RoomID.name&&MapCatalogueLadderKnown(e)){y+=e.Y;count++;}
  if(count==0)return;float h=high.y-low.y;

  if(y/count>=.5f)high.y=low.y+h*.45f;else low.y=high.y-h*.45f;
 }
 private void MapAuthoredLadderOpening(MapEntry entry,global::PersistentMinimapFloor floor,UnityEngine.Transform basis,ref UnityEngine.Vector2 position){
  if(entry.Id.IndexOf("/PN ",System.StringComparison.Ordinal)<0)return;
  foreach(var room in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true)){
   if(room.RoomID==null||room.RoomID.name!=entry.Room)continue;
   var bays=new System.Collections.Generic.List<UnityEngine.Rect>();
   foreach(var shape in room.GetComponentsInChildren<global::MinimapActiveRoom>(true)){
    var sr=shape.SR;if(sr==null)sr=shape.GetComponent<UnityEngine.SpriteRenderer>();
    if(sr!=null&&sr.sprite!=null&&sr.sprite.name=="RoomShapes_5")bays.Add(MapShapeRect(sr,basis));
   }
   if(bays.Count!=2)return;bays.Sort((a,b)=>a.center.x.CompareTo(b.center.x));
   var bay=bays[entry.Id.EndsWith(" D")?0:1];position=(new UnityEngine.Vector2(bay.center.x,bay.yMin)-modMapCenter)*modMapScale;return;
  }
 }
}}


