using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static bool AllowEnemyContactDamage(global::Hurtbox __instance,Collider __0){
   var q=weaponOwner;
   if(q==null||!q.ProdVrMode()||__instance==null||__0==null||!__0.CompareTag("Player"))return true;
   var enemy=__instance.GetComponentInParent<global::EnemyController>();
   if(enemy==null)return true;
   // Native Hit/EndHit controls these weapon hurtboxes. Never suppress them,
   // even if an authored hierarchy also places them inside the body object.
   if(__instance==enemy.WeaponHurtbox||__instance==enemy.WeaponHurtboxAlt)return true;
   // Match the explicit native body contact object, not every enemy child:
   // projectiles, lasers, environmental hazards and damage to enemies survive.
   return enemy.hurtbox==null||__instance.gameObject!=enemy.hurtbox;
  }
 }
}
