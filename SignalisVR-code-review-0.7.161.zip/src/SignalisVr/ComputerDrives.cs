using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Camera computerStageCamera;
 private RenderTexture computerStageSource,computerStageCapture;
 private int computerStageFrame=-1;
 private bool computerStagePresented;
 private int computerStageReports;
 private void ObserveComputerStage(Camera view,Transform root){
  if(root==null||ComputerSurfaceName(root.name)!="ROT_PC"||view.targetTexture==null||
   !view.targetTexture.IsCreated()||view.targetTexture.width<=0||view.targetTexture.height<=0)return;
  var authored=root.Find("CameraOrigin/CameraPivot/EventCamera");
  if(authored==null)return;
  bool primary=view.transform==authored;
  // The disk/card close-up is a native overlay on the same stage target.
  bool card=view.transform.parent!=null&&view.transform.parent.name=="MED_XCardPC"&&
   computerStageCamera!=null&&computerStageFrame==Time.frameCount&&view.targetTexture==computerStageSource;
  if(!primary&&!card)return;
  if(!ComputerDesktopIdle()&&global::PlayerState.gameState!=global::PlayerState.gameStates.dialogue)return;
  if(primary){computerStageCamera=view;computerStageSource=view.targetTexture;}
  var source=view.targetTexture;
  if(computerStageCapture==null||computerStageCapture.width!=source.width||computerStageCapture.height!=source.height){
   ReleaseComputerStageTexture();
   computerStageCapture=new RenderTexture(source.width,source.height,0,RenderTextureFormat.ARGB32);
   computerStageCapture.name="SignalisVR_ComputerDrives";computerStageCapture.Create();
  }
  // Save only the completed authored stage, before later desktop compositors
  // overwrite its shared target. No camera rerender, readback or target rebinding.
  var previous=RenderTexture.active;
  try{Graphics.Blit(source,computerStageCapture);computerStageFrame=Time.frameCount;}
  finally{RenderTexture.active=previous;}
 }
 private bool ComputerStageReady(){return computerStageCamera!=null&&computerStageCamera.isActiveAndEnabled&&
  computerStageCamera.targetTexture==computerStageSource&&computerStageSource!=null&&computerStageSource.IsCreated()&&
  computerStageCapture!=null&&computerStageCapture.IsCreated()&&computerStageFrame==Time.frameCount;}
 private void ReleaseComputerStageTexture(){if(computerStageCapture!=null){if(puzzleMaterial!=null&&puzzleMaterial.mainTexture==computerStageCapture)puzzleMaterial.mainTexture=puzzleCapture;computerStageCapture.Release();UnityEngine.Object.Destroy(computerStageCapture);}computerStageCapture=null;}
 private void ClearComputerStage(){computerStageCamera=null;computerStageSource=null;computerStageFrame=-1;computerStagePresented=false;ReleaseComputerStageTexture();}
}}
