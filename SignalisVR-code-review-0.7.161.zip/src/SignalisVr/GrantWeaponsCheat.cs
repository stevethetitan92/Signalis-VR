using System;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static bool allWeapons,grantWeaponsPending;
  private static readonly global::Items.itemlist[] StorageWeapons={global::Items.itemlist.Pistol,global::Items.itemlist.Revolver,global::Items.itemlist.Shotgun,global::Items.itemlist.Rifle,global::Items.itemlist.FlareGun,global::Items.itemlist.SMG};
  private static readonly global::Items.itemlist[] StorageAmmo={global::Items.itemlist.PistolAmmo,global::Items.itemlist.RevolverAmmo,global::Items.itemlist.ShotgunAmmo,global::Items.itemlist.RifleAmmo,global::Items.itemlist.FlareGunAmmo,global::Items.itemlist.SmgAmmo};
  private void PollGrantWeapons() {
   if(!allWeapons||!grantWeaponsPending||!CheatPlayerReady())return;
   var items=global::InventoryManager.allItems;
   if(items==null||global::InventoryManager.boxItems==null)return;
   // Resolve everything before any mutation; never spawn world pickup scripts.
   foreach(var id in StorageWeapons)if(!items.ContainsKey(id)||items[id]==null)return;
   foreach(var id in StorageAmmo)if(!items.ContainsKey(id)||items[id]==null)return;
   foreach(var id in StorageExtras)if(!items.ContainsKey(id)||items[id]==null)return;
   grantWeaponsPending=false;
   try {
    foreach(var id in StorageWeapons)if(!global::InventoryManager.boxContainsItem(items[id]))global::InventoryManager.boxItem(items[id],1);
    foreach(var id in StorageAmmo)global::InventoryManager.boxItem(items[id],6);
    foreach(var id in StorageExtras) {
     if(id==global::Items.itemlist.Flashlight&&global::InventoryManager.boxContainsItem(items[id]))continue;
     global::InventoryManager.boxItem(items[id],id==global::Items.itemlist.SignalFlare?2:1);
    }
    MelonLogger.Msg("ALL WEAPONS AND ITEMS: six guns and flashlight in storage; six rounds per gun, two thermite flares and one of each health item added. Save the game to retain storage changes.");
   }catch(Exception ex){modSettingsError="Storage grant incomplete; see log before trying again.";MelonLogger.Warning("All weapons grant stopped: "+ex.Message);}
  }
  private static readonly global::Items.itemlist[] StorageExtras={global::Items.itemlist.SignalFlare,global::Items.itemlist.Health25,global::Items.itemlist.Health50,global::Items.itemlist.Health100,global::Items.itemlist.HealthFast,global::Items.itemlist.Flashlight};
 }
}
