using System;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly HotkeyEdge desktopMenuKey=new HotkeyEdge();
  private readonly HotkeyEdge desktopMenuChange=new HotkeyEdge();
  private readonly HotkeyEdge desktopPlacementBack=new HotkeyEdge();
  private readonly ModMenuInput desktopMenuNavigation=new ModMenuInput();
  private bool desktopMenuRelease,desktopMenuHookFailed;
  private int desktopMenuClosedFrame;
  private static bool DesktopMenuKeyDown(int key){return (GetAsyncKeyState(key)&0x8000)!=0;}
  private Camera desktopHudCamera;
  private int desktopHudMask;
  private bool desktopHudFailed;
  private GUIStyle desktopHudStyle;
  private bool desktopOverlayFailed;
  private void DrawDesktopModHud() {
   if(desktopOverlayFailed||!ModHudGameplayReady())return;
   var oldColor=GUI.color;var oldMatrix=GUI.matrix;int oldDepth=GUI.depth;
   try {
    GUI.depth=-9000;float s=Math.Min(Screen.width/1920f,Screen.height/1080f);
    if(desktopHudStyle==null){desktopHudStyle=new GUIStyle(GUI.skin.label);desktopHudStyle.alignment=TextAnchor.MiddleCenter;desktopHudStyle.wordWrap=true;}
    desktopHudStyle.fontSize=Math.Max(12,(int)(25*s));
    if(modHudOn){
    float x=modHudRight?Screen.width-330*s:50*s,y=Screen.height-155*s;
    var weapon=global::InventoryManager.EquippedWeapon;float hp=global::PlayerState.hp;
    PaintMenuRect(new Rect(x-12*s,y-6*s,292*s,124*s),new Color(0,0,0,.85f));
    MenuText(new Rect(x,y,268*s,40*s),hp+"/100",Color.white,desktopHudStyle);
    PaintMenuRect(new Rect(x,y+43*s,268*s,14*s),new Color(.12f,.19f,.23f));
    PaintMenuRect(new Rect(x,y+43*s,268*s*Mathf.Clamp01(hp/100f),14*s),new Color(.45f,.83f,1f));
    MenuText(new Rect(x,y+62*s,268*s,42*s),AmmoHudCaption(weapon),Color.white,desktopHudStyle);
    }
    if(!modMiniMap)return;
    if(Time.realtimeSinceStartup>=nextModMapRefresh||modMappedRoom!=global::PlayerState.currentRoom){RefreshModMiniMap();nextModMapRefresh=(modMappedRoom==null||modMapStatus.Length!=0)?Time.realtimeSinceStartup+1f:float.PositiveInfinity;}
    s*=MapSizeFactor();
    var panel=new Rect(40*s,45*s,320*s,350*s);
    if(modMapStatus.Length!=0){MenuText(new Rect(panel.x+15*s,panel.y+65*s,panel.width-30*s,235*s),modMapStatus+"\nOpen the game's map once, then return.",Color.gray,desktopHudStyle);return;}
    Vector2 center=new Vector2(panel.x+160*s,panel.y+190*s);float factor=260*s/(.25f*UnitsPerMetre);
    // Draw the read-only room copies in screen space, independent of world
    // occlusion and camera render textures. Current room is drawn last.
    for(int pass=0;pass<2;pass++)foreach(var r in modMapCopies) {
     if(r==null||r.sprite==null||(r.sortingOrder>0?1:0)!=pass)continue;
     var sprite=r.sprite;var tex=sprite.texture;if(tex==null)continue;
     var tr=r.transform;var b=sprite.bounds;
     var local=tr.localPosition+tr.localRotation*Vector3.Scale(b.center,tr.localScale);
     var at=new Vector2(center.x+local.x*factor,center.y-local.y*factor);
     float w=Math.Abs(b.size.x*tr.localScale.x)*factor,h=Math.Abs(b.size.y*tr.localScale.y)*factor;
     var uv=sprite.textureRect;uv=new Rect(uv.x/tex.width,uv.y/tex.height,uv.width/tex.width,uv.height/tex.height);
     GUI.matrix=oldMatrix;GUIUtility.RotateAroundPivot(-tr.localEulerAngles.z,at);GUI.color=r.color;
     GUI.DrawTextureWithTexCoords(new Rect(at.x-w/2,at.y-h/2,w,h),tex,uv,true);
    }
    GUI.matrix=oldMatrix;
    DrawJoinedMapDesktop(center,factor);
    for(int i=0;i<modDoorPoints.Count;i++){
     var p=(modDoorPoints[i]-modMapCenter)*modMapScale;float dx=center.x+p.x*factor,dy=center.y-p.y*factor;int state=modDoorStates[i];
     MapDoorLines(p,state,UnitsPerMetre*.001f,modDoorRotations[i],(a,b,c,w)=>DrawMapLine(new Vector2(center.x+a.x*factor,center.y-a.y*factor),new Vector2(center.x+b.x*factor,center.y-b.y*factor),w*factor,c));
    }
    for(int i=0;i<mapPointPositions.Count;i++){
     var at=mapPointPositions[i];MapNativeDesktop(new Vector2(center.x+at.x*factor,center.y-at.y*factor),mapPointKinds[i],UnitsPerMetre*.001f*factor);MapPointLines(at,mapPointKinds[i],UnitsPerMetre*.001f,(a,b,c,w)=>DrawMapLine(new Vector2(center.x+a.x*factor,center.y-a.y*factor),new Vector2(center.x+b.x*factor,center.y-b.y*factor),w*factor,c));
    }
    EnsureGlyphAtlas();
    for(int i=0;i<mapLabelTexts.Count;i++){
     var p=mapLabelPoints[i];string caption=mapLabelTexts[i];
     float glyph=.014f*UnitsPerMetre/32f*mapLabelScales[i]*factor;
     float x=center.x+p.x*factor-PixelTextWidth(caption)*glyph*.5f,y=center.y-p.y*factor-20*glyph;
     GUI.color=mapLabelGold[i]?new Color(1,.85f,.05f):new Color(.72f,.75f,.73f);
     foreach(char c in caption){int g=c>=32&&c<=126?c-32:31;if(c!=' ')GUI.DrawTextureWithTexCoords(new Rect(x,y,64*glyph,40*glyph),modGlyphAtlas,GlyphUv(g),true);x+=glyphWidths[g]*glyph;}
    }    var player=global::PlayerState.player;
    Vector2 location,facing;
    if(player!=null&&MapPlayerPoint(player.transform.position,out location)&&MapPlayerFacing(player.transform.position,(mouseWeaponCamera!=null?mouseWeaponCamera.transform.forward:player.transform.forward),location,out facing)){
     ReportMapPosition(player.transform.position,location);var at=new Vector2(center.x+location.x*factor,center.y-location.y*factor);var direction=new Vector2(facing.x-location.x,location.y-facing.y).normalized;
     if(direction.sqrMagnitude<.001f)direction=new Vector2(0,-1);var side=new Vector2(-direction.y,direction.x);
     var tip=at+direction*10*s;var left=at-direction*7*s+side*6*s;var right=at-direction*7*s-side*6*s;
     DrawMapLine(tip,left,2*s);DrawMapLine(left,right,2*s);DrawMapLine(right,tip,2*s);
    }
   }catch(Exception ex){desktopOverlayFailed=true;MelonLogger.Warning("Desktop overlay disabled: "+ex.Message);}
   finally {GUI.color=oldColor;GUI.matrix=oldMatrix;GUI.depth=oldDepth;}
  }
  private static void DrawMapLine(Vector2 a,Vector2 b,float width,Color? tint=null){var matrix=GUI.matrix;try{GUIUtility.RotateAroundPivot(Mathf.Atan2(b.y-a.y,b.x-a.x)*57.29578f,a);PaintMenuRect(new Rect(a.x,a.y-width*.5f,(b-a).magnitude,width),tint??new Color(.4f,1f,1f));}finally{GUI.matrix=matrix;}}
  private void PollDesktopMenuTest() {
   bool focused=MouseGameFocused();
   bool placementConfirm=desktopMenuNavigation.Confirm(DesktopMenuKeyDown(0x0D));bool placementBack=desktopPlacementBack.Poll(DesktopMenuKeyDown(0x1B));
   bool up=DesktopMenuKeyDown(0x26),down=DesktopMenuKeyDown(0x28);
   bool change=desktopMenuChange.Poll(DesktopMenuKeyDown(0x0D)||DesktopMenuKeyDown(0x25)||DesktopMenuKeyDown(0x27));
   bool toggle=desktopMenuKey.Poll(DesktopMenuKeyDown(0x73));
   if(!modMenuOpen&&Time.frameCount>desktopMenuClosedFrame+1&&!up&&!down&&!DesktopMenuKeyDown(0x0D)&&!DesktopMenuKeyDown(0x25)&&!DesktopMenuKeyDown(0x27))desktopMenuRelease=false;
   if(toggle&&focused) {
    if(modMenuOpen)CloseModMenu(true);else OpenModMenu();
    return;
   }
   int move=desktopMenuNavigation.Navigate(modMenuOpen&&focused?(up?1f:0f)-(down?1f:0f):0f,Time.realtimeSinceStartup);
   if(!modMenuOpen||!focused)return;
   if(hudPlacementChoosing){hudPlacementHand=(hudPlacementHand+move+2)%2;if(placementBack)hudPlacementChoosing=false;else if(placementConfirm)EditHudPlacement();return;}
   if(hudPlacementEditing){MoveHudPlacement((DesktopMenuKeyDown(0x27)?1f:0)-(DesktopMenuKeyDown(0x25)?1f:0),(up?1f:0)-(down?1f:0),DesktopMenuKeyDown(0x21)?1f:0,DesktopMenuKeyDown(0x22)?1f:0);if(placementBack){hudPlacementEditing=false;hudPlacementChoosing=true;}else if(placementConfirm)SaveHudPlacement();return;}
   if(PollWheelAssignment((DesktopMenuKeyDown(0x27)?1f:0f)-(DesktopMenuKeyDown(0x25)?1f:0f),(up?1f:0f)-(down?1f:0f)))return;
   modMenuSelection=(modMenuSelection+move+ModMenuCount())%ModMenuCount();
   if(modMenuWheel)wheelListScroll.y=Math.Max(0,(modMenuSelection-7)*58);
   if(change){if(modMenuMap&&!DesktopMenuKeyDown(0x0D))AdjustMapMenu(modMenuSelection,DesktopMenuKeyDown(0x25)?-1:1);else ActivateModMenu(modMenuSelection);}
  }
  private bool EnsureDesktopMenuCapture() {
   if(!desktopMouseOnly||questNativeInstalled)return true;
   if(desktopMenuHookFailed)return false;
   try {InstallQuestNativeReads();return true;}
   catch(Exception ex){desktopMenuHookFailed=true;MelonLogger.Warning("Desktop menu input capture unavailable: "+ex.Message);return false;}
  }
  private void BeforeDesktopHud(Camera c) {
   if(desktopHudFailed||c!=mouseWeaponCamera||modMenuOpen||!WeaponGameplayReady()||c.orthographic)return;
   try {
    RestoreDesktopHud();desktopHudCamera=c;desktopHudMask=c.cullingMask;c.cullingMask|=1<<30;
    PrepareEnemyTargetBoxes();
    var attack=global::PlayerAttack.instance;
    if(attack!=null){var gun=EquippedControllerGun(FindRifleOwner(attack));if(gun!=null)PrepareModLasers(gun.transform);}
   }catch(Exception ex){RestoreDesktopHud();desktopHudFailed=true;MelonLogger.Warning("Desktop HUD preview disabled: "+ex.Message);}
  }
  private void RestoreDesktopHud() {
   try {RestoreModLasers();RestoreEnemyTargetBoxes();}
   finally {if(desktopHudCamera!=null)desktopHudCamera.cullingMask=desktopHudMask;desktopHudCamera=null;HideModHud();}
  }
 }
}











