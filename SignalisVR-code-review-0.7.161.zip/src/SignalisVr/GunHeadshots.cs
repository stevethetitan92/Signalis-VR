using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private readonly Dictionary<int,Transform> enemyHeadBones=new Dictionary<int,Transform>();
 private readonly HashSet<int> shotCriticalTargets=new HashSet<int>();
 private readonly Dictionary<int,int> shotEnemyHp=new Dictionary<int,int>();
 private void CaptureGunHeadshotHp(){
  shotEnemyHp.Clear();if(!HeadshotPushWeapon())return;try{var room=global::PlayerState.currentRoom;if(room==null)return;
  var manager=room.GetComponentInChildren<global::EnemyManager>(true);if(manager==null||manager.enemies==null)return;
  int count=Math.Min(256,manager.enemies.Count);for(int i=0;i<count;i++){var e=manager.enemies[i];if(e!=null&&e.hitbox!=null)shotEnemyHp[e.GetInstanceID()]=e.hitbox.HP;}
  }catch(Exception ex){shotEnemyHp.Clear();if(headshotReports++<3)MelonLoader.MelonLogger.Warning("Headshot HP snapshot: "+ex.Message);}
 }
 private Transform EnemyHead(global::EnemyController e){
  int id=e.GetInstanceID();Transform head;
  if(enemyHeadBones.TryGetValue(id,out head))return head;
  if(e.animator!=null&&e.animator.isHuman)head=e.animator.GetBoneTransform(HumanBodyBones.Head);
  if(head==null)foreach(var t in e.GetComponentsInChildren<Transform>(true)){
   string n=t.name.ToLowerInvariant();
   if(n=="head"||n.EndsWith("_head")||n.EndsWith(" head")||n.EndsWith(":head")){head=t;break;}
  }
  enemyHeadBones[id]=head;return head;
 }
 private static void ApplyGunHeadshot(global::EnemyController __instance,ref float __1){
  var q=weaponOwner;var e=__instance;var a=global::PlayerAttack.instance;
  if(q==null||gunKnockbackDepth==0||!q.ProdVrMode()||e==null||e.hitbox==null||a==null||global::PlayerAttack.muzzle==null)return;
  if(!HeadshotPushWeapon()||!HeadshotPushEnemy(e))return;
  int id=e.GetInstanceID(),before;if(!q.shotEnemyHp.TryGetValue(id,out before))before=e.hitbox.HP;
  int damage=Math.Max(0,before-e.hitbox.HP);q.shotEnemyHp[id]=e.hitbox.HP;
  try{
   var head=q.EnemyHead(e);if(head==null)return;
   var muzzle=global::PlayerAttack.muzzle;var delta=head.position-muzzle.position;
   float forward=Vector3.Dot(delta,muzzle.forward),radius=.12f*UnitsPerMetre;
   if(forward<0||forward>a.radius||(delta-muzzle.forward*forward).sqrMagnitude>radius*radius)return;
   // Native gun hit already accepted this enemy. Test its animated head bone,
   // never screen height. Match the HP loss accepted by the native gun hit.
   if(Physics.Linecast(muzzle.position,head.position,a.WallMask.value,QueryTriggerInteraction.Ignore))return;
   q.shotCriticalTargets.Add(id);
   if(damage>0)e.hitbox.HP=Math.Max(0,e.hitbox.HP-damage);
   q.shotEnemyHp[id]=e.hitbox.HP;
  }catch(Exception ex){if(q.headshotReports++<3)MelonLoader.MelonLogger.Warning("Headshot classification: "+ex.Message);}
 }
 private int headshotReports;
 private static void PushGunHeadshot(global::EnemyController __instance){
  var q=weaponOwner;var e=__instance;
  if(q!=null&&gunKnockbackDepth>0&&e!=null&&e.hitbox!=null&&q.shotEnemyHp.ContainsKey(e.GetInstanceID()))q.shotEnemyHp[e.GetInstanceID()]=e.hitbox.HP;
  if(q==null||gunKnockbackDepth==0||!HeadshotPushWeapon()||e==null||e.hitbox==null||e.hitbox.HP<=0||!q.shotCriticalTargets.Contains(e.GetInstanceID())||gunHeadshotPushed.Contains(e.GetInstanceID())||!HeadshotPushEnemy(e))return;
  // Native damage/death handling completes first. If it already knocked this
  // target back, the Knockback prefix recorded it and this call is skipped.
  try{e.Knockback();}catch(Exception ex){if(q.headshotReports++<3)MelonLoader.MelonLogger.Warning("Headshot pushback: "+ex.Message);}
 }
}}

