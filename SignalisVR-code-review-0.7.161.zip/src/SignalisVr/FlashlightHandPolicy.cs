namespace SignalisVrTracking {
 public static class FlashlightHandPolicy {
  public static bool Suppressed(bool holdingAmmo,bool holdingGrip,bool waitingForGripExit,bool nearGrip){return holdingAmmo||holdingGrip||(waitingForGripExit&&nearGrip);}
 }
}
