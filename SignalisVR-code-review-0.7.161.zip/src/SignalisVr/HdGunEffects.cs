﻿using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private global::MuzzleFlash[] nativeMuzzleEffects;private Transform nativeMuzzleOwner;private float nextNativeMuzzleSearch;
 private readonly System.Collections.Generic.HashSet<int> nativeMuzzleMoved=new System.Collections.Generic.HashSet<int>();
 private readonly System.Collections.Generic.List<FlashlightPose> nativeMuzzlePoses=new System.Collections.Generic.List<FlashlightPose>();
 private void PrepareNativeMuzzleFx(){
  Vector3 local;if(!ImportedMuzzle(out local)||global::PlayerState.player==null)return;
  var owner=global::PlayerState.player.transform.root;
  if(nativeMuzzleEffects==null||nativeMuzzleOwner!=owner||Time.realtimeSinceStartup>=nextNativeMuzzleSearch){nativeMuzzleOwner=owner;nextNativeMuzzleSearch=Time.realtimeSinceStartup+1f;nativeMuzzleEffects=owner.GetComponentsInChildren<global::MuzzleFlash>(true);}
  nativeMuzzleMoved.Clear();
  foreach(var effect in nativeMuzzleEffects){if(effect==null||effect.muzzle==null||!effect.muzzle.activeInHierarchy)continue;
   var t=effect.muzzle.transform;if(!nativeMuzzleMoved.Add(t.GetInstanceID()))continue;
   nativeMuzzlePoses.Add(new FlashlightPose{Transform=t,Position=t.position,Rotation=t.rotation});
   // Native fixed-position FX cache the old gun origin after the firing scope ends.
   // Relocate their artwork and child lights for this eye scope, then restore exactly.
   t.position=rightWeaponPosition+rightWeaponRotation*local*UnitsPerMetre;
  }
 }
 private void RestoreNativeMuzzleFx(){for(int i=nativeMuzzlePoses.Count-1;i>=0;i--){var p=nativeMuzzlePoses[i];if(p.Transform!=null){p.Transform.position=p.Position;p.Transform.rotation=p.Rotation;}}nativeMuzzlePoses.Clear();}
 private MaterialPropertyBlock hdSmokeBlock;private GameObject hdFxRoot;private Mesh hdFxQuad;private Material hdFlashMaterial,hdSmokeMaterial;private Texture2D hdFlashTexture,hdSmokeTexture;
 private readonly MeshRenderer[] hdFlashes=new MeshRenderer[3],hdSmoke=new MeshRenderer[24];
 private readonly Vector3[] hdSmokeOrigins=new Vector3[24];private readonly float[] hdSmokeBirth=new float[24];private int hdSmokeNext;private bool hdFxFailed;
 private Texture2D HdFxTexture(string name){var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(HdAsset.Read(name)),true))throw new InvalidOperationException("HD effect texture");tex.filterMode=FilterMode.Bilinear;return tex;}
 private void EnsureHdFx(){
  if(hdFxRoot!=null)return;hdFxRoot=new GameObject("SignalisVR_HDShotEffects");UnityEngine.Object.DontDestroyOnLoad(hdFxRoot);
  hdFxQuad=new Mesh();hdFxQuad.vertices=new[]{new Vector3(-.5f,-.5f,0),new Vector3(.5f,-.5f,0),new Vector3(.5f,.5f,0),new Vector3(-.5f,.5f,0)};hdFxQuad.uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(1,1),new Vector2(0,1)};hdFxQuad.colors=new[]{Color.white,Color.white,Color.white,Color.white};hdFxQuad.triangles=HandSurfaceTopology.DoubleSided(new[]{0,1,2,0,2,3});hdFxQuad.RecalculateBounds();
  var shader=Shader.Find("Sprites/Default");if(shader==null)throw new InvalidOperationException("HD effect shader");
  hdSmokeBlock=new MaterialPropertyBlock();hdFlashTexture=HdFxTexture("fx-muzzle.png");hdSmokeTexture=HdFxTexture("fx-smoke.png");hdFlashMaterial=new Material(shader);hdFlashMaterial.mainTexture=hdFlashTexture;hdSmokeMaterial=new Material(shader);hdSmokeMaterial.mainTexture=hdSmokeTexture;
  for(int i=0;i<3;i++)hdFlashes[i]=CreateControllerPart(hdFxRoot,hdFxQuad,hdFlashMaterial,"HD muzzle flash",Vector3.zero,Vector3.one);
  for(int i=0;i<24;i++){hdSmoke[i]=CreateControllerPart(hdFxRoot,hdFxQuad,hdSmokeMaterial,"HD muzzle smoke",Vector3.zero,Vector3.one);hdSmokeBirth[i]=-100;}
 }
 private void EmitHdShotSmoke(){if(hdFxFailed)return;try{EnsureHdFx();}catch(Exception){hdFxFailed=true;return;}Vector3 local;if(!ImportedMuzzle(out local))return;var origin=rightWeaponPosition+rightWeaponRotation*local*UnitsPerMetre;for(int i=0;i<3;i++){int slot=hdSmokeNext++%24;hdSmokeBirth[slot]=Time.realtimeSinceStartup+i*.025f;hdSmokeOrigins[slot]=origin;}}
 private void PrepareHdGunEffects(){
  HideHdGunEffects();if(!handsScoped||hdFxFailed)return;
  try{
   EnsureHdFx();PrepareNativeMuzzleFx();ShowPistolCases();var w=global::InventoryManager.EquippedWeapon;Vector3 local;

   float age=Time.realtimeSinceStartup-heldShotTime;
   if(w!=null&&w.parentItem!=null&&!IsFlaregun(w.parentItem._item)&&w.Pointer==heldShotWeapon&&age>=0&&age<.045f&&ImportedMuzzle(out local))for(int i=0;i<3;i++){var r=hdFlashes[i];r.transform.position=rightWeaponPosition+rightWeaponRotation*local*UnitsPerMetre;r.transform.rotation=rightWeaponRotation*Quaternion.Euler(i==2?90:0,i==1?90:0,0);r.transform.localScale=Vector3.one*(.065f*UnitsPerMetre);r.enabled=true;}
   for(int i=0;i<24;i++){float a=Time.realtimeSinceStartup-hdSmokeBirth[i];if(a<0||a>.6f)continue;var r=hdSmoke[i];r.transform.position=hdSmokeOrigins[i]+controllerTrackingToWorld*new Vector3(Mathf.Sin(i*2.4f)*a*.018f,a*.06f,0)*UnitsPerMetre;r.transform.rotation=stereoRotation*Quaternion.AngleAxis(i*53,Vector3.forward);r.transform.localScale=Vector3.one*(.014f+.07f*a)*UnitsPerMetre;var block=hdSmokeBlock;block.SetColor("_Color",new Color(.8f,.8f,.8f,.28f*(1-a/.6f)));r.SetPropertyBlock(block);r.enabled=true;}
  }catch(Exception ex){hdFxFailed=true;HideHdGunEffects();MelonLoader.MelonLogger.Warning("HD shot effects unavailable: "+ex.Message);}
 }
 private void HideHdGunEffects(){RestoreNativeMuzzleFx();HidePistolCases();foreach(var r in hdFlashes)if(r!=null)r.enabled=false;foreach(var r in hdSmoke)if(r!=null)r.enabled=false;}
 private void DestroyHdGunEffects(){HideHdGunEffects();DestroyPistolCases();if(hdFxRoot!=null)UnityEngine.Object.Destroy(hdFxRoot);foreach(var o in new UnityEngine.Object[]{hdFxQuad,hdFlashMaterial,hdSmokeMaterial,hdFlashTexture,hdSmokeTexture})if(o!=null)UnityEngine.Object.Destroy(o);hdFxRoot=null;hdFxFailed=false;nativeMuzzleEffects=null;nativeMuzzleOwner=null;nextNativeMuzzleSearch=0;}
} }

