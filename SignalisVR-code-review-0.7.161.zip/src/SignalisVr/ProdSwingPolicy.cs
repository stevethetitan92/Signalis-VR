using System;
namespace SignalisVrTracking {
 public sealed class ProdSwingPolicy {
  private float distance,quiet; private bool spent,primed;
  public void Reset(){distance=quiet=0;spent=false;primed=false;}
  public void Spend(){spent=true;distance=quiet=0;}
  public bool Sample(float dt,float travel,bool continuous) {
   if(!continuous||float.IsNaN(dt)||float.IsInfinity(dt)||dt<=0||dt>.1f||float.IsNaN(travel)||float.IsInfinity(travel)||travel<0||travel>.5f){Reset();return false;}
   if(!primed){primed=true;return false;}
   float speed=travel/dt;
   if(speed<.25f){quiet+=dt;distance=0;if(quiet>=.15f)spent=false;return false;}
   quiet=0;
   if(speed<.65f){distance=0;return false;}
   distance+=travel;
   return !spent&&distance>=.08f;
  }
 }
}

