using System;using UnityEngine;
namespace SignalisVrTracking {
 public static class MinesMapLayout {
  public sealed class Cell {public string Name,Label;public Vector2[] Polygon,Doors;public Vector2 Caption,Low,High;public Cell(string name,string label,float[] polygon,float[] doors,float x,float y){Name=name;Label=label;Polygon=Points(polygon);Doors=Points(doors);Caption=P(x,y);Low=High=Polygon[0];foreach(var p in Polygon){Low=Vector2.Min(Low,p);High=Vector2.Max(High,p);}}}
  // User reference coordinates, converted once to a small world-independent map.
  public static Vector2 P(float x,float y){return new Vector2(x/20f,(900-y)/20f);}
  private static Vector2[] Points(float[] p){var a=new Vector2[p.Length/2];for(int i=0;i<a.Length;i++)a[i]=P(p[2*i],p[2*i+1]);return a;}
  public static readonly Cell[] Cells={
   new Cell("EXC Elevator","MINE ELEVATOR",new float[]{594f,-79f,654f,-79f,654f,-35f,594f,-35f},new float[]{623f,-35f},623f,-57f),
   new Cell("Mineshaft Access","EXCAVATION\nENTRANCE",new float[]{592f,44f,608f,44f,608f,-35f,638f,-35f,638f,44f,654f,44f,712f,101f,712f,164f,696f,180f,783f,267f,761f,289f,674f,201f,654f,221f,592f,221f,535f,164f,535f,101f},new float[]{623f,-35f,565f,194f},623f,158f),
   new Cell("Cavern","LASER\nSTOCKPILE",new float[]{471f,163f,535f,164f,592f,221f,591f,283f,534f,340f,471f,340f,414f,283f,414f,221f},new float[]{565f,194f,562f,312f},495f,285f),
   new Cell("Monowire","MONOFILAMENT\nSTOCKPILE",new float[]{591f,283f,654f,283f,711f,340f,711f,403f,654f,460f,591f,460f,534f,403f,534f,340f},new float[]{562f,312f,682f,311f,682f,432f,623f,460f},623f,408f),
   new Cell("Office (Save Room)","MINING OFFICE",new float[]{563f,460f,681f,460f,681f,578f,563f,578f},new float[]{623f,460f,623f,578f},623f,549f),
   new Cell("Hatch Room","MATERIAL TRANSPORT\nSHAFT",new float[]{352f,400f,414f,400f,471f,458f,471f,520f,414f,578f,352f,578f,294f,520f,294f,458f},new float[]{383f,578f},383f,525f),
   new Cell("Combat Room","TRANSPORT\nSHAFT NEXUS",new float[]{352f,578f,414f,578f,471f,635f,471f,697f,414f,754f,352f,754f,295f,697f,295f,635f},new float[]{383f,578f,442.5f,725.5f,323.5f,725.5f},383f,698f),
   new Cell("Star Room","LAST STAND",new float[]{232f,697f,295f,697f,352f,754f,352f,817f,295f,874f,232f,874f,175f,817f,175f,755f},new float[]{323.5f,725.5f},264f,824f),
   new Cell("Standseilbahn","SLOPE ELEVATOR",new float[]{592f,578f,654f,578f,712f,635f,712f,697f,654f,755f,591f,755f,591f,817f,534f,874f,472f,874f,414f,817f,414f,754f,471f,697f,535f,697f,535f,635f},new float[]{683f,606.5f,623f,578f,442.5f,725.5f},503f,827f),
   new Cell("The Hole","THE HOLE",new float[]{102f,400f,165f,400f,222f,458f,222f,520f,165f,578f,102f,578f,45f,520f,45f,458f},new float[]{73.5f,429f},133f,549f),
  };
  public static Cell Find(string scene,int floor,string name){if(scene!="EXC_Mines"||floor!=12||name==null)return null;foreach(var c in Cells)if(c.Name==name||c.Name+"(Clone)"==name)return c;return null;}
  public static bool Contains(Vector2[] poly,Vector2 p){bool inside=false;for(int i=0,j=poly.Length-1;i<poly.Length;j=i++){var a=poly[i];var b=poly[j];if((a.y>p.y)!=(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)inside=!inside;}return inside;}
  public static Vector2 Clamp(Cell c,Vector2 p){if(Contains(c.Polygon,p))return p;float best=float.PositiveInfinity;var result=p;for(int i=0;i<c.Polygon.Length;i++){var a=c.Polygon[i];var d=c.Polygon[(i+1)%c.Polygon.Length]-a;float t=Math.Max(0,Math.Min(1,Vector2.Dot(p-a,d)/Math.Max(.00001f,d.sqrMagnitude)));var q=a+d*t;float v=(q-p).sqrMagnitude;if(v<best){best=v;result=q;}}return result;}
  public static float DoorAngle(Cell c,Vector2 p){float best=float.PositiveInfinity,angle=0;for(int i=0;i<c.Polygon.Length;i++){var a=c.Polygon[i];var d=c.Polygon[(i+1)%c.Polygon.Length]-a;float t=Math.Max(0,Math.Min(1,Vector2.Dot(p-a,d)/Math.Max(.00001f,d.sqrMagnitude)));float distance=(a+d*t-p).sqrMagnitude;if(distance<best){best=distance;angle=(float)Math.Atan2(d.y,d.x);}}return angle;}
  public static void CaptionBounds(Cell c,out Vector2 low,out Vector2 high){float x=Math.Min(3,(c.High.x-c.Low.x)*.35f),y=Math.Min(1,(c.High.y-c.Low.y)*.35f);for(int i=0;i<24;i++){if(Contains(c.Polygon,c.Caption+new Vector2(-x,-y))&&Contains(c.Polygon,c.Caption+new Vector2(-x,y))&&Contains(c.Polygon,c.Caption+new Vector2(x,-y))&&Contains(c.Polygon,c.Caption+new Vector2(x,y)))break;x*=.9f;y*=.9f;}low=c.Caption-new Vector2(x,y);high=c.Caption+new Vector2(x,y);}
 }
}


