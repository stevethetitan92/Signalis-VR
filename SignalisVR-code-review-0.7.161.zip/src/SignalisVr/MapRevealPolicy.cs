namespace SignalisVrTracking {
 public sealed class MapRevealPolicy {
  private bool visible,pending;
  private double since=-1;
  public void Reset(){visible=false;pending=false;since=-1;}
  public bool Update(bool eligible,float palmUp,float reach,float height,double now){
   if(!eligible){Reset();return false;}
   bool desired=palmUp>=(visible?.45f:.70f)&&reach>=(visible?.12f:.18f)&&height>=(visible?-.65f:-.55f);
   if(desired==visible){since=-1;return visible;}
   if(since<0||pending!=desired||now<since){pending=desired;since=now;}
   if(now-since>=(desired?.15:.10)){visible=desired;since=-1;}
   return visible;
  }
 }
}
