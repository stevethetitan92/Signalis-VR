using System;
namespace SignalisVrTracking {
 public sealed class FlarePalmClosure {
  public bool Contact {get;private set;}
  private float offset,lastPolar;
  public void Reset(){Contact=false;offset=lastPolar=0;}
  public float Sample(bool available,float distance,float angle,float polar){
   if(!available||float.IsNaN(distance)||float.IsNaN(polar)||float.IsInfinity(polar)||float.IsNaN(angle)||float.IsInfinity(angle)||distance>.11f){Reset();return angle;}
   if(!Contact){if(distance>.065f)return angle;Contact=true;offset=angle-polar;lastPolar=polar;return angle;}
   if(Math.Abs(polar-lastPolar)>30){Reset();return angle;}
   lastPolar=polar;
   // Palm contact pushes shut; it cannot pull the barrel farther open.
   return Math.Max(0,Math.Min(angle,polar+offset));
  }
 }
}
