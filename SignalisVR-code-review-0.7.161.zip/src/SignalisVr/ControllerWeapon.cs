using System;
using HarmonyLib;
using MelonLoader;
using UnityEngine;

namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private GameObject laserSpreadModel;
  private readonly System.Collections.Generic.Dictionary<int,Quaternion> laserSpreadRotations=new System.Collections.Generic.Dictionary<int,Quaternion>();
  private bool weaponHooksReady,weaponHookAttempted,weaponAimFailed;
  private static Tracking weaponOwner;
  private Vector3 rightWeaponPosition;
  private Quaternion rightWeaponRotation;
  private float rightWeaponTime=-100f,nextWeaponSearch;
  private int rightWeaponFrame=-100,weaponLogCount;
  private Camera rightWeaponCamera;
  private global::SetWeapon rifleOwner;
  private GameObject rifleOriginModel;
  private Transform rifleLaserOrigin;
  private WeaponPoseScope renderedWeapon;
  private Transform heldPoseModel;
  private Quaternion heldModelRotation;
  private Vector3 heldPalmOffset,heldMuzzleOffset;
  private string weaponStatus;
  private int weaponStatusLogs;
  private float nextWeaponGateLog;
  private int weaponGateLogs,weaponShotCalls;

  // Firearm trial: retain each weapon's native firing and damage path.
  // No damage replacement, target-list changes, animator patch or input remapping.
  private void InstallControllerWeapon() {
   if(weaponHookAttempted)return;
   weaponHookAttempted=true;
   weaponOwner=this;
   try {
    var h=new HarmonyLib.Harmony("signalis.vr.controller.rifle");
    h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"Update",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(PreparePerPullFire)));
    h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"RaycastShot",Type.EmptyTypes),
     prefix:new HarmonyMethod(typeof(Tracking),nameof(ControllerShotBegin)),
     finalizer:new HarmonyMethod(typeof(Tracking),nameof(ControllerShotEnd)));
    h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"CheckTargetRay",Type.EmptyTypes),
     prefix:new HarmonyMethod(typeof(Tracking),nameof(ControllerShotBegin)),
     finalizer:new HarmonyMethod(typeof(Tracking),nameof(ControllerShotEnd)));
    h.Patch(AccessTools.DeclaredMethod(typeof(global::AimLaser),"Update",Type.EmptyTypes),
     prefix:new HarmonyMethod(typeof(Tracking),nameof(ControllerLaserBegin)),
     finalizer:new HarmonyMethod(typeof(Tracking),nameof(ControllerShotEnd)));
    h.Patch(AccessTools.DeclaredMethod(typeof(global::AimLaser),"miss",Type.EmptyTypes),
     prefix:new HarmonyMethod(typeof(Tracking),nameof(ControllerLaserBegin)),
     finalizer:new HarmonyMethod(typeof(Tracking),nameof(ControllerShotEnd)));
    foreach(string caller in new[]{"Update","ReadyForAttack"})h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),caller,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(ControllerShotBegin)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(ControllerShotEnd)));
    h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"reload",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(ManualNativeReloadGuard)));
    InstallPistolCasings(h);InstallFlareProjectile(h);InstallSwingProd(h);InstallThermite(h);InstallSmgStats(h);InstallSmgShotAudio(h);InstallQuickEquipAudio(h);InstallTestMenu(h);InstallVrDeathScreen(h);
    weaponHooksReady=true;
    MelonLogger.Msg("CONTROLLER WEAPON: all-firearm scoped model/muzzle trial ready; grip/trigger and native damage retained.");
   }catch(Exception ex) {WeaponAimFailure(ex);}
  }
  private void CacheRightWeaponPose(Vector3 position,Quaternion rotation) {
   rightWeaponPosition=HandPlacement.TrackedPalm(position,rotation,UnitsPerMetre);rightWeaponRotation=WeaponAimPolicy.ControllerRotation(rotation);
   ApplyHdSupportAim();ApplyHdVisualRecoil();rightWeaponTime=Time.realtimeSinceStartup;rightWeaponFrame=Time.frameCount;rightWeaponCamera=camera;
  }
  private bool ControllerWeaponReady() {
   return weaponHooksReady&&!weaponAimFailed&&controllerMotionEnabled
    &&WeaponAimPolicy.Fresh(Time.realtimeSinceStartup-rightWeaponTime,Time.frameCount-rightWeaponFrame)
    &&camera!=null&&camera==rightWeaponCamera&&QuestUnifiedReady()&&questAvailabilityValue
    &&!questMenuScene&&!pauseMenuVisible&&!bookScreenVisible&&!dialogueScreenVisible
    &&WeaponGameplayReady()&&!global::PlayerState.paused&&!global::PlayerState.eventScreen
    &&!global::PlayerState.reloading&&(questFrame.buttons&(1<<5))!=0;
  }
  private global::SetWeapon FindRifleOwner(global::PlayerAttack attack) {
   if(rifleOwner!=null&&rifleOwner.transform.IsChildOf(attack.transform.root))return rifleOwner;
   rifleOwner=null;
   if(Time.realtimeSinceStartup<nextWeaponSearch)return null;
   nextWeaponSearch=Time.realtimeSinceStartup+1f;
   // Restrict lookup to this player's hierarchy; no per-frame global scene search.
   foreach(var owner in attack.transform.root.GetComponentsInChildren<global::SetWeapon>(true))
    if(owner!=null&&(owner.Rifle!=null||owner.Pistol!=null||owner.Revolver!=null||owner.Shotgun!=null||owner.FlareGun!=null||owner.SMG!=null)) {rifleOwner=owner;break;}
   return rifleOwner;
  }
  private bool ControllerWeaponVisualReady() {
   return weaponHooksReady&&!weaponAimFailed&&controllerMotionEnabled
    &&WeaponAimPolicy.Fresh(Time.realtimeSinceStartup-rightWeaponTime,Time.frameCount-rightWeaponFrame)
    &&camera!=null&&camera==rightWeaponCamera&&ControllerVisualStateReady()&&questAvailabilityValue
    &&!questMenuScene&&!pauseMenuVisible&&!bookScreenVisible&&!dialogueScreenVisible
    &&(WeaponGameplayReady()||DoorNativeTraversing()||DoorCameraBlocked())&&!global::PlayerState.paused&&!global::PlayerState.eventScreen;
  }
  private static GameObject EquippedControllerGun(global::SetWeapon owner) {
   var weapon=global::InventoryManager.EquippedWeapon;
   if(owner==null||weapon==null||weapon.parentItem==null)return null;
   switch(weapon.parentItem._item) {
    case global::Items.itemlist.Pistol:return owner.Pistol;
    case global::Items.itemlist.Revolver:return owner.Revolver;
    case global::Items.itemlist.Shotgun:return owner.Shotgun;
    case global::Items.itemlist.Rifle:return owner.Rifle;
    case global::Items.itemlist.FlakGun:case global::Items.itemlist.FlareGun:return owner.FlareGun;
    case global::Items.itemlist.SMG:return owner.SMG;
    default:return null;
   }
  }
  private WeaponPoseScope BeginControllerWeapon(global::PlayerAttack attack,bool visualOnly=false) {
   bool ready=mouseWeaponTest?weaponHooksReady&&!weaponAimFailed&&MouseWeaponReady():(visualOnly?ControllerWeaponVisualReady():ControllerWeaponReady());
   if(!ready||attack==null||attack!=global::PlayerAttack.instance
      ||(!visualOnly&&(attack.melee||!attack.aiming)))return null;
   var owner=FindRifleOwner(attack);
   var model=mouseWeaponTest?ActiveSupportedWeapon(owner):EquippedControllerGun(owner);
   if(model==null) {
    WeaponStatus("Waiting for exactly one active firearm model in player hierarchy");return null;
   }
   var muzzle=global::PlayerAttack.muzzle;
   if(muzzle==null){WeaponStatus("Waiting for native weapon muzzle");return null;}
   if(model.transform==muzzle||model.transform.IsChildOf(muzzle))
    throw new InvalidOperationException("Unexpected weapon/muzzle hierarchy; alignment requires inspection");
   // Measured rifle rays are parallel but have different origins. Match only
   // this weapon's shot origin to its existing laser; keep accepted rotation.
   Transform origin=null;
   if(!mouseWeaponTest&&model==owner.Rifle) {
    if(rifleOriginModel!=model) {
     rifleOriginModel=model;rifleLaserOrigin=null;
     var lasers=model.GetComponentsInChildren<global::AimLaser>(true);
     if(lasers.Length==1&&lasers[0]!=null)rifleLaserOrigin=lasers[0].transform;
    }
    if(rifleLaserOrigin!=null&&rifleLaserOrigin!=muzzle&&!rifleLaserOrigin.IsChildOf(muzzle))origin=rifleLaserOrigin;
   }
   var scope=new WeaponPoseScope(model.transform,muzzle,origin);
   scope.weaponName=model.name;
   try {
    if(mouseWeaponTest) {
     var view=mouseWeaponCamera.transform;
     scope.Apply(view.position+view.rotation*(new Vector3(.15f,-.15f,.25f)*UnitsPerMetre),view.rotation);
    }else {
     if(heldPoseModel!=model.transform) {
      if(handsModel==null||handsWrists[1]==null){scope.Apply(rightWeaponPosition,rightWeaponRotation);return scope;}
      heldPoseModel=model.transform;weaponGateLogs=0;
      var inverse=Quaternion.Inverse(muzzle.rotation);
      heldModelRotation=inverse*model.transform.rotation;
      heldPalmOffset=inverse*(handsWrists[1].TransformPoint(handPalmCenters[1])-model.transform.position);
      heldMuzzleOffset=inverse*((origin!=null?origin.position:muzzle.position)-model.transform.position);
     }
     // Freeze the equipped grip frame across native draw/aim transitions.
     // Both rendered gun and actual shot scope use this same calibration.
     scope.ApplyHeld(rightWeaponPosition-rightWeaponRotation*heldPalmOffset,rightWeaponRotation,heldModelRotation,heldMuzzleOffset);
    }
    Vector3 importedMuzzle;if(!mouseWeaponTest&&ImportedMuzzle(out importedMuzzle))scope.AlignMuzzle(rightWeaponPosition+rightWeaponRotation*importedMuzzle*UnitsPerMetre,rightWeaponRotation);
    WeaponStatus("Active: model="+model.name+" muzzle="+muzzle.name);
    return scope;
   }catch {scope.Restore();throw;}
  }
  private static GameObject ActiveSupportedWeapon(global::SetWeapon owner) {
   return owner==null?null:WeaponModelPolicy.Select(owner.Pistol,owner.Rifle,owner.Revolver,owner.Shotgun,owner.FlareGun,owner.SMG);
  }
  private bool WeaponGameplayReady() {
   var pause=global::PauseMenu.instance;
   bool visible=pause!=null&&pause.MenuObject!=null&&pause.MenuObject.activeInHierarchy;
   // Legacy menu flag remained true during live aiming/firing; use current state.
   return WeaponGameplayPolicy.Ready(global::PlayerState.gameState==global::PlayerState.gameStates.play,visible);
  }
  private void WeaponStatus(string status) {
   if(status==weaponStatus)return;
   weaponStatus=status;
   if(weaponStatusLogs++<12)MelonLogger.Msg("CONTROLLER WEAPON: "+status);
  }
  private void PrepareControllerWeapon() {
   try {
    var attack=global::PlayerAttack.instance;
    renderedWeapon=BeginControllerWeapon(attack,!mouseWeaponTest);
    if(renderedWeapon!=null)ReportWeaponRays("render",attack);
    ReportWeaponGate(attack,renderedWeapon!=null);
   }
   catch(Exception ex){WeaponAimFailure(ex);}
  }
  // At most 30 lines per launch, one per second and only during grip/trigger input.
  // Observe all gates together; do not relax a gameplay guard based on a guess.
  private void ReportWeaponGate(global::PlayerAttack attack,bool applied) {
   // Keep blocked requests observable throughout long sessions, including HE swaps.
   if(!verboseDiagnostics&&applied)return;
   bool requested=mouseWeaponTest?(GetAsyncKeyState(0x02)&0x8000)!=0:(questFrame.buttons&96)!=0;
   if(!requested||Time.realtimeSinceStartup<nextWeaponGateLog)return;
   nextWeaponGateLog=Time.realtimeSinceStartup+(applied?1f:5f);weaponGateLogs++;
   MelonLogger.Msg("CONTROLLER WEAPON GATES: source="+(mouseWeaponTest?"mouse":"controller")+" mouseReady="+(mouseWeaponTest&&MouseWeaponReady())+" applied="+applied+" frame="+Time.frameCount
    +" buttons="+questFrame.buttons+" hooks="+weaponHooksReady+" failed="+weaponAimFailed
    +" enabled="+controllerMotionEnabled+" poseAgeMs="+((Time.realtimeSinceStartup-rightWeaponTime)*1000f).ToString("F1")
    +" poseFrame="+rightWeaponFrame+" sameCamera="+(camera!=null&&camera==rightWeaponCamera)
    +" unified="+QuestUnifiedReady()+" input="+questAvailabilityValue
    +" menuScene="+questMenuScene+" pauseUI="+pauseMenuVisible+" bookUI="+bookScreenVisible+" dialogueUI="+dialogueScreenVisible
    +" gameState="+global::PlayerState.gameState+" gameplayReady="+WeaponGameplayReady()+" menu="+global::PlayerState.menu+" paused="+global::PlayerState.paused+" event="+global::PlayerState.eventScreen
    +" reloading="+global::PlayerState.reloading+" attackExists="+(attack!=null)
    +(attack==null?"":" aiming="+attack.aiming+" melee="+attack.melee+" shotgun="+attack.shotgun)
    +" magazine="+(global::InventoryManager.EquippedWeapon==null?-1:global::InventoryManager.EquippedWeapon.magAmmo)+" pistolStage="+manualReload.Stage+" shotgunStage="+shotgunReload.Stage+" smgStage="+smgReload.Stage+" hingeStage="+hingedReload.Stage+" reloadBlocks="+ManualReloadBlocksAttack()
    +" owner="+(rifleOwner!=null)+" nativeShotCalls="+weaponShotCalls);
  }
  private void RestoreControllerWeapon() {
   if(renderedWeapon==null)return;
   try {renderedWeapon.Restore();}finally{renderedWeapon=null;}
  }
  private ShotgunAimSnapshot controllerShotgunCone;
  private static void ControllerShotBegin(global::PlayerAttack __instance,System.Reflection.MethodBase __originalMethod,out WeaponPoseScope __state) {
   __state=null;var q=weaponOwner;if(q==null)return;
   try {
    if(__originalMethod.Name=="RaycastShot"){q.weaponShotCalls++;q.shotCriticalTargets.Clear();}
    bool shotgun=__originalMethod.Name=="RaycastShot"&&__instance.shotgun;
    var previousCone=q.controllerShotgunCone;
     var cone=__instance.shotgun?(previousCone??q.CaptureShotgunCone(__instance)):null;
    __state=q.BeginControllerWeapon(__instance);
    if(__state!=null&&shotgun) {
     if(cone==null){__state.Restore();__state=null;return;}
     __state.restoreTargets=cone.Apply();
    }
    if(__state!=null&&__originalMethod.Name=="RaycastShot") {
     q.ReportWeaponRays("shot",__instance);
     __state.shot=true;__state.shotOrigin=global::PlayerAttack.muzzle.position;
     __state.shotDirection=global::PlayerAttack.muzzle.forward;
     __state.shotRange=__instance.radius;
     __state.shotMask=(int)__instance.TargetMask|(int)__instance.WallMask;
    }
    if(__state!=null&&__originalMethod.Name=="RaycastShot"&&q.weaponLogCount++<12)
     MelonLogger.Msg("CONTROLLER WEAPON SHOT: weapon="+__state.weaponName+" source="+(q.mouseWeaponTest?"mouse":"controller")+" poseAgeMs="+(q.mouseWeaponTest?"current-camera":((Time.realtimeSinceStartup-q.rightWeaponTime)*1000f).ToString("F1"))
      +" unityFrame="+Time.frameCount+" sourceFrame="+q.rightWeaponFrame
      +" muzzle="+WeaponVector(global::PlayerAttack.muzzle.position)+" forward="+WeaponVector(global::PlayerAttack.muzzle.forward));
   }catch(Exception ex){if(__state!=null)__state.Restore();__state=null;q.WeaponAimFailure(ex);}
  }
  private static void ControllerLaserBegin(global::AimLaser __instance,System.Reflection.MethodBase __originalMethod,out WeaponPoseScope __state) {
   __state=null;var q=weaponOwner;if(q==null)return;
   try {
    if(q.mouseWeaponTest? !q.MouseWeaponReady():!q.ControllerWeaponReady())return;
    var attack=global::PlayerAttack.instance;
    var owner=attack!=null?q.FindRifleOwner(attack):null;
    var model=ActiveSupportedWeapon(owner);
    if(model!=null&&__instance.transform.IsChildOf(model.transform)) {
     if(q.laserSpreadModel!=model){
      q.laserSpreadModel=model;q.laserSpreadRotations.Clear();var rays=model.GetComponentsInChildren<global::AimLaser>(true);var forward=Vector3.zero;
      foreach(var ray in rays)if(ray!=null)forward+=ray.transform.forward;
      if(forward.sqrMagnitude>.000001f){var basis=Quaternion.LookRotation(forward.normalized,global::PlayerAttack.muzzle.up);float radius=0;int count=0;foreach(var ray in rays)if(ray!=null){var v=Quaternion.Inverse(basis)*ray.transform.forward;radius=Mathf.Max(radius,new Vector2(v.x,v.y).magnitude/Mathf.Max(.001f,v.z));count++;}int index=0;foreach(var ray in rays)if(ray!=null){float angle=index*2.39996323f,r=radius*Mathf.Sqrt((index+.5f)/Mathf.Max(1,count));q.laserSpreadRotations[ray.GetInstanceID()]=attack.shotgun?Quaternion.LookRotation(new Vector3(Mathf.Cos(angle)*r,Mathf.Sin(angle)*r,1),Vector3.up):Quaternion.Inverse(basis)*ray.transform.rotation;index++;}}
     }
     __state=q.BeginControllerWeapon(attack);
     if(__state!=null){
      Vector3 imported;if(q.ImportedMuzzle(out imported)){
       var t=__instance.transform;var oldPosition=t.position;var oldRotation=t.rotation;
       __state.restoreEffects=()=>{if(t!=null)t.SetPositionAndRotation(oldPosition,oldRotation);};
       t.position=q.rightWeaponPosition+q.rightWeaponRotation*imported*UnitsPerMetre;Quaternion spread; t.rotation=q.rightWeaponRotation*(attack.shotgun&&q.laserSpreadRotations.TryGetValue(__instance.GetInstanceID(),out spread)?spread:Quaternion.identity);
       // miss() consumes cached hitPos/hitNorm; refresh them at this scoped muzzle before emitting FX.
       if(__originalMethod.Name=="miss")__instance.Update();
      }
      q.ReportWeaponRays("laser",attack);
     }
    }
   }catch(Exception ex){q.WeaponAimFailure(ex);}
  }
  private static Exception ControllerShotEnd(Exception __exception,WeaponPoseScope __state) {
   if(__exception==null&&__state!=null&&__state.shot&&weaponOwner!=null){weaponOwner.RecordAimRingShot();weaponOwner.RecordHeldTriggerShot();weaponOwner.RecordManualRifleShot();}
   if(__exception==null&&__state!=null&&__state.shot&&weaponOwner!=null)
    weaponOwner.RecordRifleImpact(__state);
   try {if(__state!=null)__state.Restore();}
   catch(Exception ex){if(weaponOwner!=null)weaponOwner.WeaponAimFailure(ex);}
   return __exception; // Preserve original game exceptions; never suppress firing errors.
  }
  private void WeaponAimFailure(Exception ex) {
   if(!weaponAimFailed)MelonLogger.Warning("CONTROLLER WEAPON: trial disabled; native weapon behavior retained: "+ex.Message);
   weaponAimFailed=true;
  }
 }
 internal static class WeaponAimPolicy {
  // VR-only candidate calibration: zero pitch aimed high; 90 degrees aimed low.
  // Test the 45-degree midpoint. Local +X pitches the shared gun/muzzle down.
  // Apply once on pose receipt, never again inside nested render/fire scopes.
  private static readonly Quaternion controllerOffset=Quaternion.Euler(45f,0f,0f);
  internal static Quaternion ControllerRotation(Quaternion tracked){return tracked*controllerOffset;}
  internal static bool Fresh(float seconds,int frames) {return seconds>=0f&&seconds<=.1f&&frames>=0&&frames<=3;}
 }
 internal static class WeaponModelPolicy {
  internal static GameObject Select(GameObject pistol,GameObject rifle,GameObject revolver=null,GameObject shotgun=null,GameObject flare=null,GameObject smg=null) {
   GameObject selected=null;int count=0;
   Add(pistol,ref selected,ref count);Add(rifle,ref selected,ref count);
   Add(revolver,ref selected,ref count);Add(shotgun,ref selected,ref count);
   Add(flare,ref selected,ref count);Add(smg,ref selected,ref count);
   return count==1?selected:null;
  }
  private static void Add(GameObject model,ref GameObject selected,ref int count) {
   if(model!=null&&model.activeInHierarchy){selected=model;count++;}
  }
 }
 internal static class WeaponGameplayPolicy {
  internal static bool Ready(bool playing,bool pauseVisible){return playing&&!pauseVisible;}
 }
 // Pose writes exist only during both eye renders or one native weapon call.
 // Local restoration also handles muzzle descendants and nested native callbacks.
 internal sealed class WeaponPoseScope {
  internal string weaponName;
  internal Action restoreTargets,restoreEffects;
  internal bool shot;
  internal Vector3 shotOrigin,shotDirection;
  internal float shotRange;
  internal int shotMask;
  private readonly Transform model,muzzle;
  private readonly Vector3 modelLocal,muzzleLocal,modelWorld,muzzleWorld;
  private readonly Quaternion modelLocalRotation,muzzleLocalRotation,modelRotation,muzzleRotation;
  private bool changed;
  internal WeaponPoseScope(Transform model,Transform muzzle,Transform shotOrigin=null) {
   this.model=model;this.muzzle=muzzle;
   modelLocal=model.localPosition;modelLocalRotation=model.localRotation;
   muzzleLocal=muzzle.localPosition;muzzleLocalRotation=muzzle.localRotation;
   modelWorld=model.position;modelRotation=model.rotation;
   muzzleWorld=shotOrigin!=null?shotOrigin.position:muzzle.position;muzzleRotation=muzzle.rotation;
  }
  internal void Apply(Vector3 handPosition,Quaternion handRotation) {
   changed=true;
   Quaternion delta=handRotation*Quaternion.Inverse(muzzleRotation);
   model.rotation=delta*modelRotation;model.position=handPosition;
   muzzle.rotation=handRotation;muzzle.position=handPosition+delta*(muzzleWorld-modelWorld);
  }
  internal void Restore() {
   if(!changed)return;
   changed=false;
   var effects=restoreEffects;restoreEffects=null;if(effects!=null)effects();
   try {if(model!=null){model.localPosition=modelLocal;model.localRotation=modelLocalRotation;}}
   finally {
    try {if(muzzle!=null){muzzle.localPosition=muzzleLocal;muzzle.localRotation=muzzleLocalRotation;}}
    finally {var restore=restoreTargets;restoreTargets=null;if(restore!=null)restore();}
   }
  }
  internal void AlignMuzzle(Vector3 position,Quaternion rotation){changed=true;muzzle.position=position;muzzle.rotation=rotation;}
  internal void ApplyHeld(Vector3 position,Quaternion rotation,Quaternion modelOffset,Vector3 muzzleOffset) {
   changed=true;model.rotation=rotation*modelOffset;model.position=position;
   muzzle.rotation=rotation;muzzle.position=position+rotation*muzzleOffset;
  }
}
}








