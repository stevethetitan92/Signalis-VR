using System;
namespace SignalisVrTracking {
 public static class RifleCaseMotion {
  public const float Gravity=9.81f,Restitution=.18f;
  public static float Step(ref float velocity,float acceleration,float dt){float displacement=velocity*dt+.5f*acceleration*dt*dt;velocity+=acceleration*dt;return displacement;}
  public static float SpinDecay(float dt){return (float)Math.Exp(-.35f*dt);}
  public static float LaunchX(int chamber){return chamber==0?-.27f:-.34f;}
  public static float LaunchY(int chamber){return chamber==0?.19f:.14f;}
  public static float LaunchZ(int chamber){return chamber==0?-.84f:-.77f;}
 }
}
