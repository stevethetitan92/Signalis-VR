using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class EnemyEyeCopy {public SkinnedMeshRenderer Source;public Mesh Original,Mesh;public MeshRenderer View;public Material[] Materials,OriginalMaterials;public string[] OriginalShaders;public MaterialPropertyBlock NativeProperties;public int[][] Triangles;public Color[] Colors;public Vector2[] Uv;public int Frame=-1;}
 private readonly Dictionary<int,EnemyEyeCopy> enemyEyeCopies=new Dictionary<int,EnemyEyeCopy>();
 private readonly List<MeshRenderer> enemyEyeVisible=new List<MeshRenderer>();
 private readonly Dictionary<Renderer,bool> enemyEyeEnabled=new Dictionary<Renderer,bool>();
 private Renderer[] enemyAuxiliaryRenderers;private global::Room enemyAuxiliaryRoom;private float nextEnemyAuxiliaryScan;
 private void PrepareEnemyAuxiliaryMaterials(){
  if(enemyAuxiliaryRenderers==null||enemyAuxiliaryRoom!=global::PlayerState.currentRoom||Time.realtimeSinceStartup>=nextEnemyAuxiliaryScan){
   enemyAuxiliaryRoom=global::PlayerState.currentRoom;nextEnemyAuxiliaryScan=Time.realtimeSinceStartup+2f;
   var list=new List<Renderer>();
   foreach(var enemy in Resources.FindObjectsOfTypeAll<global::EnemyController>()){
    if(enemy==null||OwnsTestEnemy(enemy)||!enemy.gameObject.scene.IsValid())continue;
    var room=EnemyEyeOwner(enemy.transform);if(room!=null&&enemyAuxiliaryRoom!=null&&!MapSameRoom(room,enemyAuxiliaryRoom))continue;
    foreach(var renderer in enemy.GetComponentsInChildren<Renderer>(true)){
     bool overlay;CanReplaceEnemyEyeRenderer(renderer,out overlay);if(overlay&&!list.Contains(renderer))list.Add(renderer);
    }
   }enemyAuxiliaryRenderers=list.ToArray();
  }
  // Amplification passes may be ordinary MeshRenderers, not skinned bodies.
  // Hide only those passes for the eye render and restore their exact state.
  foreach(var renderer in enemyAuxiliaryRenderers)if(renderer!=null&&renderer.enabled&&renderer.gameObject.activeInHierarchy){
   bool overlay;CanReplaceEnemyEyeRenderer(renderer,out overlay);if(!overlay)continue;
   enemyEyeEnabled[renderer]=renderer.enabled;renderer.enabled=false;
  }
 }
 private readonly Dictionary<Animator,AnimatorCullingMode> enemyAnimationModes=new Dictionary<Animator,AnimatorCullingMode>();
 private readonly Dictionary<SkinnedMeshRenderer,bool> enemyOffscreenModes=new Dictionary<SkinnedMeshRenderer,bool>();
 private global::Room eyeEnemyRoom;
 private SkinnedMeshRenderer[] eyeEnemySkins;private float nextEyeEnemyScan;
 private void InstallEnemyEyeLifecycle(){
  var h=new HarmonyLib.Harmony("signalis.vr.enemy.eye.lifecycle");
  foreach(var name in new[]{"OnEnable","Load"})h.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(global::EnemyController),name),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(EnemyEyeActivated)));
 }
 private static void EnemyEyeActivated(global::EnemyController __instance){var q=questOwner;if(q!=null){q.nextEyeEnemyScan=0;q.nextEnemyAuxiliaryScan=0;q.enemyEyeOwners.Clear();if(__instance!=null&&!q.stopping)q.pendingStarAxes.Add(__instance);}}
 private static bool CanReplaceEnemyEyeRenderer(Renderer renderer,out bool overlayOnly){
  // Burn slots keep their native shader/properties on the baked mesh.
  var materials=renderer.sharedMaterials;bool shield=renderer.name=="STARShield";bool body=materials.Length>0;overlayOnly=materials.Length>0;
  foreach(var m in materials){
   if(m==null||m.shader==null){body=false;overlayOnly=false;continue;}
   body&=(shield&&m.mainTexture!=null)||EnemyBurnMaterial(m)||(m.shader.name!="GradualBurn"&&TestEnemyMaterialPolicy.Body(m.shader.name,m.GetTag("RenderType",false,""),m.renderQueue,m.mainTexture!=null));
   overlayOnly&=TestEnemyMaterialPolicy.Overlay(m.shader.name);
  }
  return body;
 }
 private static bool EnemyBurnMaterial(Material m){
  // GradualBurn uses _MainTexture, not Unity's conventional _MainTex slot.
  // Keep the complete native material and animated properties on the eye copy.
  return m!=null&&m.shader!=null&&m.shader.name=="GradualBurn"&&
   ((m.HasProperty("_MainTexture")&&m.GetTexture("_MainTexture")!=null)||(m.HasProperty("_MainTex")&&m.mainTexture!=null));
 }
 private void PrepareEnemyEyeMaterials(){
  if(eyeEnemySkins==null||eyeEnemyRoom!=global::PlayerState.currentRoom||Time.realtimeSinceStartup>=nextEyeEnemyScan){
   eyeEnemyRoom=global::PlayerState.currentRoom;
   var found=new List<SkinnedMeshRenderer>();var foundIds=new HashSet<int>();
   foreach(var enemy in Resources.FindObjectsOfTypeAll<global::EnemyController>())if(enemy!=null&&!OwnsTestEnemy(enemy)&&enemy.gameObject.scene.IsValid())
   {
    var room=EnemyEyeOwner(enemy.transform);
    if(room!=null&&eyeEnemyRoom!=null&&!MapSameRoom(room,eyeEnemyRoom))continue;
    foreach(var skin in enemy.GetComponentsInChildren<SkinnedMeshRenderer>(true)){if(skin!=null&&foundIds.Add(skin.GetInstanceID()))found.Add(skin);}}
   eyeEnemySkins=found.ToArray();nextEyeEnemyScan=Time.realtimeSinceStartup+2f;
   // Baked geometry belongs to the current room. Retaining every visited room's
   // copies accumulates meshes/materials even after those enemies stop rendering.
   var stale=new List<int>();foreach(var entry in enemyEyeCopies)if(entry.Value.Source==null||!foundIds.Contains(entry.Key))stale.Add(entry.Key);
   foreach(var key in stale){DestroyEnemyEyeCopy(enemyEyeCopies[key]);enemyEyeCopies.Remove(key);}
  }
  PrepareEnemyAuxiliaryMaterials();
  foreach(var renderer in eyeEnemySkins){
   if(renderer==null||!renderer.enabled||renderer.forceRenderingOff||!renderer.gameObject.activeInHierarchy||renderer.sharedMesh==null)continue;
   var owner=EnemyEyeOwner(renderer.transform);if(owner!=null&&global::PlayerState.currentRoom!=null&&!MapSameRoom(owner,global::PlayerState.currentRoom))continue;
   if((renderer.bounds.center-stereoPosition).sqrMagnitude>Mathf.Pow(20f*UnitsPerMetre,2))continue;
   bool overlay;bool body=CanReplaceEnemyEyeRenderer(renderer,out overlay);var originals=renderer.sharedMaterials;
   if(!body){if(overlay){enemyEyeEnabled[renderer]=renderer.enabled;renderer.enabled=false;}continue;}
   int id=renderer.GetInstanceID();EnemyEyeCopy c;
   if(enemyEyeCopies.TryGetValue(id,out c)&&(c.Original!=renderer.sharedMesh||c.Materials.Length!=originals.Length)){DestroyEnemyEyeCopy(c);enemyEyeCopies.Remove(id);c=null;}
   if(c!=null)for(int i=0;i<originals.Length;i++){
    if(c.OriginalMaterials[i]!=originals[i]||c.OriginalShaders[i]!=(originals[i]==null||originals[i].shader==null?"":originals[i].shader.name)){
     DestroyEnemyEyeCopy(c);enemyEyeCopies.Remove(id);c=null;break;
    }
    bool nativeBurn=originals[i]!=null&&originals[i].shader!=null&&originals[i].shader.name=="GradualBurn";
    bool copiedBurn=c.Materials[i]!=null&&c.Materials[i].shader!=null&&c.Materials[i].shader.name=="GradualBurn";
    if(nativeBurn!=copiedBurn){DestroyEnemyEyeCopy(c);enemyEyeCopies.Remove(id);c=null;break;}
   }
   if(c==null){
    var shader=Shader.Find("Unlit/Texture");if(shader==null)continue;
    c=new EnemyEyeCopy{Source=renderer,Original=renderer.sharedMesh,Mesh=new Mesh(),Materials=new Material[originals.Length],OriginalMaterials=originals,OriginalShaders=new string[originals.Length]};enemyEyeCopies[id]=c;
    var go=new GameObject("SignalisVR_EnemyBaked_"+renderer.name);go.layer=0;
    c.View=go.AddComponent<MeshRenderer>();c.View.enabled=false;c.View.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;go.AddComponent<MeshFilter>().sharedMesh=c.Mesh;
    for(int i=0;i<originals.Length;i++){
     var original=originals[i];var materialShader=shader;
     c.OriginalShaders[i]=original==null||original.shader==null?"":original.shader.name;
     // Keep the STAR veil's alpha holes instead of flattening them to opaque.
     bool veil=original!=null&&original.shader!=null&&(original.shader.name.StartsWith("Toon/Cutoff",System.StringComparison.Ordinal)||original.GetTag("RenderType",false,"")=="TransparentCutout");
     if(veil){var cutout=Shader.Find("Unlit/Transparent Cutout");materialShader=cutout!=null?cutout:original.shader;}
     if(renderer.name=="STARShield"){var transparent=Shader.Find("Unlit/Transparent");if(transparent!=null)materialShader=transparent;}
     bool burn=EnemyBurnMaterial(original);if(burn&&c.NativeProperties==null)c.NativeProperties=new MaterialPropertyBlock();
     var m=original!=null?new Material(original):new Material(materialShader);if(!burn){m.shader=materialShader;if(m.HasProperty("_Color"))m.color=Color.white;}c.Materials[i]=m;
     if(original!=null&&!burn){m.mainTexture=original.mainTexture;m.mainTextureScale=original.mainTextureScale;m.mainTextureOffset=original.mainTextureOffset;}
    }
    c.Uv=c.Original.uv;c.View.sharedMaterials=c.Materials;c.Triangles=new int[c.Original.subMeshCount][];
    for(int sub=0;sub<c.Triangles.Length;sub++)c.Triangles[sub]=HandSurfaceTopology.DoubleSided(c.Original.GetTriangles(sub));
    MelonLoader.MelonLogger.Msg("ENEMY BAKED EYE: "+renderer.name+" uses calibration body rendering; native AI retained.");
   }
   // Same baked, white-vertex, double-sided texture path as the calibration target.
   if(c.Frame!=Time.frameCount){c.Frame=Time.frameCount;
   if(c.NativeProperties!=null){renderer.GetPropertyBlock(c.NativeProperties);c.View.SetPropertyBlock(c.NativeProperties);}
   for(int i=0;i<c.Materials.Length&&i<originals.Length;i++)if(originals[i]!=null){
    if(originals[i].shader!=null&&originals[i].shader.name=="GradualBurn"){c.Materials[i].shader=originals[i].shader;c.Materials[i].CopyPropertiesFromMaterial(originals[i]);}
    else {c.Materials[i].mainTexture=originals[i].mainTexture;c.Materials[i].mainTextureScale=originals[i].mainTextureScale;c.Materials[i].mainTextureOffset=originals[i].mainTextureOffset;}
   }
   renderer.BakeMesh(c.Mesh);
   // Skin baking supplies positions; authored UVs stay fixed through pose/death changes.
   if(c.Uv!=null&&c.Uv.Length==c.Mesh.vertexCount)c.Mesh.uv=c.Uv;
   if(c.Colors==null||c.Colors.Length!=c.Mesh.vertexCount){c.Colors=new Color[c.Mesh.vertexCount];for(int i=0;i<c.Colors.Length;i++)c.Colors[i]=Color.white;}
   c.Mesh.colors=c.Colors;for(int sub=0;sub<c.Triangles.Length;sub++)c.Mesh.SetTriangles(c.Triangles[sub],sub);c.Mesh.RecalculateBounds();}
   c.View.transform.SetPositionAndRotation(renderer.transform.position,renderer.transform.rotation);c.View.transform.localScale=renderer.transform.lossyScale;
   enemyEyeEnabled[renderer]=renderer.enabled;renderer.enabled=false;enemyEyeVisible.Add(c.View);c.View.enabled=true;
  }
 }
 private void RestoreEnemyEyeMaterials(){foreach(var view in enemyEyeVisible)if(view!=null)view.enabled=false;enemyEyeVisible.Clear();foreach(var pair in enemyEyeEnabled)if(pair.Key!=null)pair.Key.enabled=pair.Value;enemyEyeEnabled.Clear();}
 private void DestroyEnemyEyeCopy(EnemyEyeCopy c){if(c.View!=null)UnityEngine.Object.Destroy(c.View.gameObject);if(c.Mesh!=null)UnityEngine.Object.Destroy(c.Mesh);foreach(var m in c.Materials)if(m!=null)UnityEngine.Object.Destroy(m);}
 private void DestroyEnemyEyeMaterials(){enemyEyeOwners.Clear();RestoreEnemyEyeMaterials();foreach(var pair in enemyAnimationModes)if(pair.Key!=null)pair.Key.cullingMode=pair.Value;enemyAnimationModes.Clear();foreach(var pair in enemyOffscreenModes)if(pair.Key!=null)pair.Key.updateWhenOffscreen=pair.Value;enemyOffscreenModes.Clear();foreach(var c in enemyEyeCopies.Values)DestroyEnemyEyeCopy(c);enemyEyeCopies.Clear();eyeEnemySkins=null;nextEyeEnemyScan=0;enemyAuxiliaryRenderers=null;enemyAuxiliaryRoom=null;nextEnemyAuxiliaryScan=0;}
}}



