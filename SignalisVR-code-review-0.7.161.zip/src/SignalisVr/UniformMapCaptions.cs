using System;using System.Collections.Generic;using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 // Fit all authored room captions together. Exploration does not change font size.
 private sealed class UniformRoomCaption {public Vector2 Low,High;public string Text;public bool Visible;}
 private void AddUniformRoomCaptions(List<UniformRoomCaption> captions){
  var groups=new List<int[]>();float common=float.PositiveInfinity;
  foreach(var c in captions){int first=mapLabelPoints.Count;AddRoomMapLabel(c.Low,c.High,c.Text);int last=mapLabelPoints.Count;groups.Add(new[]{first,last});for(int i=first;i<last;i++)common=Math.Min(common,mapLabelScales[i]);}
  if(float.IsPositiveInfinity(common))return;
  for(int n=captions.Count-1;n>=0;n--){var c=captions[n];var g=groups[n];if(!c.Visible){int count=g[1]-g[0];mapLabelPoints.RemoveRange(g[0],count);mapLabelTexts.RemoveRange(g[0],count);mapLabelScales.RemoveRange(g[0],count);mapLabelGold.RemoveRange(g[0],count);continue;}
   var center=((c.Low+c.High)*.5f-modMapCenter)*modMapScale;for(int i=g[0];i<g[1];i++){float ratio=common/Math.Max(.000001f,mapLabelScales[i]);mapLabelPoints[i]=center+(mapLabelPoints[i]-center)*ratio;mapLabelScales[i]=common;}
  }
 }
}}
