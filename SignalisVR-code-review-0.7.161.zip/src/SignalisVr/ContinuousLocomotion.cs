using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Rigidbody locomotionBody;
 private RigidbodyInterpolation locomotionInterpolation;
 private Animator locomotionAnimator;
 private bool locomotionRootMotion;
 private bool ContinuousLocomotionReady(){return QuestUnifiedReady()&&!modMenuOpen&&!quickSelect.Open&&!global::PlayerState.paused
  &&global::PlayerState.hp>0&&!global::PlayerState.gameOver&&!global::PlayerState.hurt&&!global::PlayerState.grappled
  &&global::PlayerState.gameState==global::PlayerState.gameStates.play
  &&!Input.GetKey(KeyCode.W)&&!Input.GetKey(KeyCode.S)&&!Input.GetKey(KeyCode.A)&&!Input.GetKey(KeyCode.D);}
 public override void OnFixedUpdate(){
  if(!ContinuousLocomotionReady()){ReleaseContinuousLocomotion();return;}
  var model=questFpModel.GetValue(questFpMod) as GameObject;
  var body=model==null?null:model.GetComponent<Rigidbody>();
  if(body==null||body.isKinematic){ReleaseContinuousLocomotion();return;}
  if(locomotionBody!=body){
   ReleaseContinuousLocomotion();locomotionBody=body;locomotionInterpolation=body.interpolation;
   body.interpolation=RigidbodyInterpolation.Interpolate;
   locomotionAnimator=model.GetComponent<Animator>();
   if(locomotionAnimator!=null){locomotionRootMotion=locomotionAnimator.applyRootMotion;locomotionAnimator.applyRootMotion=false;}
  }
  Vector3 direction,side;float forward;
  if(!QuestMovementComponents(model,out direction,out side,out forward))return;
  var up=model.transform.up.normalized;
  // Native floor normal velocity (gravity/elevators) and collider resolution
  // remain native. Only the planar joystick velocity is owned here.
  float speed=MovementMath.TravelSpeed((questFrame.buttons&(1<<4))!=0);
  body.velocity=up*Vector3.Dot(body.velocity,up)+direction*speed;
  ObserveQuestMovement(body,up,direction,speed,1f);
 }
 private void ReleaseContinuousLocomotion(){
  if(locomotionBody!=null)locomotionBody.interpolation=locomotionInterpolation;
  if(locomotionAnimator!=null)locomotionAnimator.applyRootMotion=locomotionRootMotion;
  locomotionBody=null;locomotionAnimator=null;
 }
}}
