using System;
namespace SignalisVrTracking {
 public sealed class QuickUsePolicy {
  private bool released;
  public void Reset(){released=false;}
  public bool Update(bool eligible,bool pressed){if(!eligible){Reset();return false;}if(!pressed){released=true;return false;}if(!released)return false;released=false;return true;}
 }
 public sealed class QuickSelectPolicy {
  private bool neutral,blocked=true;
  public bool Open {get;private set;}
  public void Reset(){Open=false;neutral=false;blocked=true;}
  // Activation begins at the gesture center. One action per directional reach.
  public int Update(bool ready,bool touch,float x,float y) {
   if(!ready||float.IsNaN(x)||float.IsNaN(y)||float.IsInfinity(x)||float.IsInfinity(y)){Reset();return -1;}
   float magnitude=Math.Max(Math.Abs(x),Math.Abs(y));
   if(!touch){Open=false;neutral=false;blocked=false;return -1;}
   if(blocked)return -1;
   Open=true;
   if(magnitude<.25f){neutral=true;return -1;}
   if(!neutral||magnitude<.65f)return -1;
   // Ambiguous diagonals don't consume the centered-stick latch.
   if(Math.Abs(Math.Abs(x)-Math.Abs(y))<.15f)return -1;
   neutral=false;
   return Math.Abs(y)>Math.Abs(x)?(y>0?0:2):(x>0?1:3);
  }
 }
}

