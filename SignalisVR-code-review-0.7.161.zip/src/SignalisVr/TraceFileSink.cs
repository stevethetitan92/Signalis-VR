using System;
using System.IO;
using System.Globalization;
using System.Collections.Generic;
using System.Threading;
using System.Diagnostics;
namespace SignalisVrTracking {
 // Three reusable batches: the game thread never formats rows, opens files,
 // flushes or waits for disk. If the writer falls behind, count/drop a batch.
 internal sealed class TraceFileSink {
  private sealed class Batch {
   internal readonly double[] native=new double[512*20],managed=new double[2048*20];
   internal int nativeCount,managedCount;internal string status;
  }
  private readonly object gate=new object();
  private readonly Queue<Batch> free=new Queue<Batch>(),ready=new Queue<Batch>();
  private readonly AutoResetEvent wake=new AutoResetEvent(false);
  private readonly Thread worker;
  private bool stopping;
  private long dropped;
  private string error;
  private readonly Queue<string> reports=new Queue<string>();
  private string lastReport;
  private int reportCount;
  private readonly long segmentBytes;
  private const string Columns="origin,kind,token,frame,start,end,queued,copyEnd,fenceEnd,leftEnd,rightEnd,leftError,rightError,width,height,generation,slot,hresult,attempts,thread,stereoId";
  internal string LastReport {get{lock(gate)return lastReport;}}
  internal string Error {get{lock(gate)return error;}}
  internal long Dropped {get{lock(gate)return dropped;}}
  internal TraceFileSink(string path,string header,long segmentBytes=8388608) {
   this.segmentBytes=Math.Max(1024,segmentBytes);
   for(int i=0;i<3;i++)free.Enqueue(new Batch());
   worker=new Thread(()=>Run(path,header));worker.IsBackground=true;worker.Name="SIGNALIS trace writer";worker.Start();
  }
  internal bool Report(string snapshot) {
   lock(gate){if(stopping||error!=null||reports.Count>=2||reportCount>=20)return false;reports.Enqueue(snapshot);reportCount++;}
   wake.Set();return true;
  }
  internal bool Enqueue(double[] native,int nativeCount,double[] managed,int managedCount,string status) {
   lock(gate) {
    if(stopping||Error!=null||free.Count==0){dropped++;return false;}
    var b=free.Dequeue();b.nativeCount=Math.Max(0,nativeCount);b.managedCount=managedCount;b.status=status;
    Array.Copy(native,b.native,b.nativeCount*20);Array.Copy(managed,b.managed,managedCount*20);
    ready.Enqueue(b);
   }
   wake.Set();return true;
  }
  internal void Complete(){lock(gate)stopping=true;wake.Set();}
  internal bool Finish(int timeout){Complete();return worker.Join(timeout);}
  private static void Row(StreamWriter writer,string origin,double[] a,int n) {
   writer.Write(origin);
   for(int j=0;j<20;j++){writer.Write(',');writer.Write(a[n+j].ToString("R",CultureInfo.InvariantCulture));}
   writer.WriteLine();
  }
  private void Run(string path,string header) {
   StreamWriter writer=null;
   try {
    Directory.CreateDirectory(Path.GetDirectoryName(path));
    string identity=header;
    string location=typeof(TraceFileSink).Assembly.Location;
    if(String.IsNullOrEmpty(location))identity+="\n# dllSha256=unavailable-dynamic-assembly";
    else using(var hash=System.Security.Cryptography.SHA256.Create())
     using(var dll=File.OpenRead(location))identity+="\n# dllSha256="+BitConverter.ToString(hash.ComputeHash(dll)).Replace("-","");
    int segment=0,reportIndex=0;
    writer=new StreamWriter(path,false,System.Text.Encoding.UTF8,65536);
    {
     writer.WriteLine(identity);writer.WriteLine(Columns);
     while(true) {
      Batch b=null;bool done;string report=null;
      lock(gate){if(reports.Count>0)report=reports.Dequeue();else if(ready.Count>0)b=ready.Dequeue();done=stopping;}
      if(report!=null){
       writer.Flush();
       string folder=Path.Combine(Path.GetDirectoryName(path),"report-"+(++reportIndex).ToString("D2"));Directory.CreateDirectory(folder);
       File.WriteAllText(Path.Combine(folder,"snapshot.txt"),identity+"\n"+report+"\nwriterDroppedBatches="+Dropped);
       for(int i=0;i<4;i++){string part=i==0?path:path+"."+i; if(File.Exists(part))File.Copy(part,Path.Combine(folder,"timeline-"+i+".csv"));}
       // Capture a bounded log tail for exceptions outside the frame recorder.
       try{
        string log=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"MelonLoader","Latest.log");
        if(File.Exists(log))using(var input=new FileStream(log,FileMode.Open,FileAccess.Read,FileShare.ReadWrite)){
         input.Seek(Math.Max(0,input.Length-1048576),SeekOrigin.Begin);
         using(var output=File.Create(Path.Combine(folder,"game-log-tail.txt"))){byte[] chunk=new byte[8192];int remaining=1048576,n;while(remaining>0&&(n=input.Read(chunk,0,Math.Min(remaining,chunk.Length)))>0){output.Write(chunk,0,n);remaining-=n;}}
        }
       }catch(Exception ex){File.WriteAllText(Path.Combine(folder,"log-unavailable.txt"),ex.Message);}
       lock(gate)lastReport=folder;
       continue;
      }
      if(b==null){if(done)break;wake.WaitOne();continue;}
      long begin=Stopwatch.GetTimestamp();
      for(int i=0;i<b.nativeCount;i++)Row(writer,"native",b.native,i*20);
      for(int i=0;i<b.managedCount;i++)Row(writer,"unity",b.managed,i*20);
      writer.WriteLine(b.status);writer.Flush();
      writer.WriteLine("# writer startQpc="+begin+" endQpc="+Stopwatch.GetTimestamp()+" droppedBatches="+Dropped);
      lock(gate){b.status=null;free.Enqueue(b);}
      if(writer.BaseStream.Position>=segmentBytes){
       writer.Dispose();segment=(segment+1)%4;
       writer=new StreamWriter(segment==0?path:path+"."+segment,false,System.Text.Encoding.UTF8,65536);
       writer.WriteLine(identity);writer.WriteLine(Columns);writer.WriteLine("# rolling segment="+segment+" UTC="+DateTime.UtcNow.ToString("o"));
      }
     }
     writer.WriteLine("# complete droppedBatches="+Dropped);
    }
   }catch(Exception ex){lock(gate)error=ex.Message;}
   finally {if(writer!=null)writer.Dispose();}
  }
 }
}
