using System;
namespace SignalisVrTracking {
 // Affine world-XY to map-XY fit. Allows reflected axes and unequal room scales.
 public sealed class RoomMapProjection {
  private double xx,xy,x0,yx,yy,y0;
  // Schematic mines use a measured perpendicular span rather than a third
  // almost-collinear room-centre anchor, which can flatten or shear the fit.
  public static double[,] MinePairs(double[,] doors,double wx,double wy,double ww,double wh,double mx,double my,double mw,double mh) {
   if(ww<=.01||wh<=.01||mw<=.01||mh<=.01)return doors;
   int a=-1,b=-1;double longest=.01;
   for(int i=0;i<doors.GetLength(0);i++)for(int j=i+1;j<doors.GetLength(0);j++){
    double dx=doors[j,0]-doors[i,0],dy=doors[j,1]-doors[i,1],u=doors[j,2]-doors[i,2],v=doors[j,3]-doors[i,3],d=dx*dx+dy*dy;
    if(d>longest&&u*u+v*v>.0001){a=i;b=j;longest=d;}
   }
   if(a<0)return new double[,]{{wx,wy,mx,my},{wx+ww,wy,mx+mw,my},{wx,wy+wh,mx,my+mh}};
   double x=doors[b,0]-doors[a,0],y=doors[b,1]-doors[a,1],u0=doors[b,2]-doors[a,2],v0=doors[b,3]-doors[a,3];
   double wl=Math.Sqrt(longest),ml=Math.Sqrt(u0*u0+v0*v0),nx=-y/wl,ny=x/wl,nu=-v0/ml,nv=u0/ml;
   double ws=Math.Abs(nx)*ww+Math.Abs(ny)*wh,ms=Math.Abs(nu)*mw+Math.Abs(nv)*mh;
   double wc=nx*(wx+ww*.5-doors[a,0])+ny*(wy+wh*.5-doors[a,1]);
   double mc=nu*(mx+mw*.5-doors[a,2])+nv*(my+mh*.5-doors[a,3]);
   double sign=Math.Abs(wc)>ws*.15&&Math.Abs(mc)>ms*.15&&wc*mc<0?-1:1;
   return new double[,]{{doors[a,0],doors[a,1],doors[a,2],doors[a,3]},
    {doors[b,0],doors[b,1],doors[b,2],doors[b,3]},
    {doors[a,0]+nx*ws,doors[a,1]+ny*ws,doors[a,2]+nu*ms*sign,doors[a,3]+nv*ms*sign}};
  }
  public bool Fit(double[,] pairs) {
   if(pairs==null||pairs.GetLength(1)!=4)return false;
   int n=pairs.GetLength(0);if(n<3)return false;
   for(int i=0;i<n;i++)for(int j=0;j<4;j++)if(double.IsNaN(pairs[i,j])||double.IsInfinity(pairs[i,j]))return false;
   double wx=0,wz=0,mx=0,my=0;
   for(int i=0;i<n;i++){wx+=pairs[i,0];wz+=pairs[i,1];mx+=pairs[i,2];my+=pairs[i,3];}
   wx/=n;wz/=n;mx/=n;my/=n;
   double a=0,b=0,c=0,dx=0,ex=0,dy=0,ey=0;
   for(int i=0;i<n;i++){double x=pairs[i,0]-wx,z=pairs[i,1]-wz,u=pairs[i,2]-mx,v=pairs[i,3]-my;a+=x*x;b+=x*z;c+=z*z;dx+=x*u;ex+=z*u;dy+=x*v;ey+=z*v;}
   double det=a*c-b*b;if(a*c<1e-12||det/(a*c)<1e-5)return false;
   xx=(dx*c-ex*b)/det;xy=(ex*a-dx*b)/det;yx=(dy*c-ey*b)/det;yy=(ey*a-dy*b)/det;
   if(Math.Abs(xx*yy-xy*yx)<1e-10)return false;
   x0=mx-xx*wx-xy*wz;y0=my-yx*wx-yy*wz;
   return Finite(xx)&&Finite(xy)&&Finite(x0)&&Finite(yx)&&Finite(yy)&&Finite(y0);
  }
  private static bool Finite(double value){return !double.IsNaN(value)&&!double.IsInfinity(value);}
  public void Point(double x,double z,out double u,out double v){u=xx*x+xy*z+x0;v=yx*x+yy*z+y0;}
 }
}
