using System;
namespace SignalisVrTracking {
 // Relative raw tracked positions: no arbitrary hand-to-handle rotational lever.
 public sealed class SmgChargingTravel {
  private float forwardMost,last;
  public float LastPull {get;private set;}
  public void Begin(float localZ){forwardMost=last=localZ;LastPull=0;}
  public float Pull(float localZ){
   if(float.IsNaN(localZ)||float.IsInfinity(localZ)||Math.Abs(localZ-last)>.35f){LastPull=float.NaN;return LastPull;}
   last=localZ;forwardMost=Math.Max(forwardMost,localZ);
   // A grip caught while approaching the tab may still move forward first.
   // Only rearward motion from that reached position drives the handle.
   LastPull=forwardMost-localZ;return LastPull;
  }
 }
}
