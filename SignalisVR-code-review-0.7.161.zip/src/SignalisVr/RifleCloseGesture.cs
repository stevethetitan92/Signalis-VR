using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly RifleCloseGesturePolicy rifleCloseGesture=new RifleCloseGesturePolicy();
  private Quaternion rifleGesturePrevious=Quaternion.identity;
  private bool rifleGestureSample;
  private void ResetRifleCloseGesture(){rifleCloseGesture.Reset();rifleGestureSample=false;}
  private bool RifleFlickClose(float now){
   bool ready=!rifleBarrelHeld&&(SelectedActive("Rifle")||SelectedActive("FlareGun"))&&hingedReload.Stage==HingedReloadPolicy.Step.Open&&additionalOpen>.95f&&now-hingeOpened>.25f&&!additionalInsert;
   if(!ready){ResetRifleCloseGesture();return false;}
   var current=rightWeaponRotation;
   if(!rifleGestureSample){rifleGesturePrevious=current;rifleGestureSample=true;rifleCloseGesture.Tick(now,0,true);return false;}
   var delta=Quaternion.Inverse(rifleGesturePrevious)*current;rifleGesturePrevious=current;
   float angle;Vector3 axis;delta.ToAngleAxis(out angle,out axis);if(angle>180)angle-=360;
   // Reject discontinuities on every axis, not just pitch.
   if(Mathf.Abs(angle)>45){ResetRifleCloseGesture();return false;}
   return rifleCloseGesture.Tick(now,-angle*axis.x,true);
  }
 }
}
