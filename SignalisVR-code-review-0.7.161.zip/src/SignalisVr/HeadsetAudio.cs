using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool headsetAudioWarning;
 private void UpdateHeadsetAudio(){
  if(!active||!stereo||desktopMouseOnly||stopping||waitingForGameplay||questMenuScene)return;
  try{
   PollWorldSpatialAudio();
   var f=stereoRotation*Vector3.forward;var u=stereoRotation*Vector3.up;
   var attributes=new FMOD.ATTRIBUTES_3D{position=new FMOD.VECTOR{x=stereoPosition.x,y=stereoPosition.y,z=stereoPosition.z},forward=new FMOD.VECTOR{x=f.x,y=f.y,z=f.z},up=new FMOD.VECTOR{x=u.x,y=u.y,z=u.z},velocity=new FMOD.VECTOR()};
   var result=FMODUnity.RuntimeManager.StudioSystem.setListenerAttributes(0,attributes);
   if(result!=FMOD.RESULT.OK&&!headsetAudioWarning){headsetAudioWarning=true;MelonLoader.MelonLogger.Warning("Headset spatial listener: "+result);}
  }catch(System.Exception e){if(!headsetAudioWarning){headsetAudioWarning=true;MelonLoader.MelonLogger.Warning("Headset spatial listener unavailable: "+e.Message);}}
 }
}}

