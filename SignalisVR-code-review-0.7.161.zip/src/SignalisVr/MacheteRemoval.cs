using System;
using HarmonyLib;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static bool RemovedMachete(global::AnItem item){return item!=null&&item._item==global::Items.itemlist.Machete;}
 private static bool RejectMacheteItem(global::AnItem __0){return !RemovedMachete(__0);}
 private static void RemoveExistingMachete(){
  var all=global::InventoryManager.allItems;if(all==null||!all.ContainsKey(global::Items.itemlist.Machete))return;
  var item=all[global::Items.itemlist.Machete];item.hidden=true;
  var held=global::InventoryManager.EquippedWeapon;if(held!=null&&RemovedMachete(held.parentItem))global::InventoryManager.EquippedWeapon=null;
  if(RemovedMachete(global::InventoryManager.EquippedTool))global::InventoryManager.EquippedTool=null;
  if(RemovedMachete(global::InventoryManager.CurrentItem))global::InventoryManager.CurrentItem=null;
  var carried=global::InventoryManager.elsterItems;if(carried!=null)carried.Remove(item);
  var stored=global::InventoryManager.boxItems;if(stored!=null)stored.Remove(item);
 }
 private static bool RemoveMachetePickup(global::ItemPickup __instance){
  // ItemPickup::.ctor initializes _itemEnum to 101 (Machete), including
  // authored ammo/key/health pickups which serialize only their _item asset.
  // An unresolved asset is not evidence of a machete either. Do not suppress
  // native Awake/LoadState or deactivate it based on the constructor default.
  if(__instance==null||!RemovedMachete(__instance._item))return true;
  if(__instance.inter!=null)__instance.inter.enabled=false;
  __instance.gameObject.SetActive(false);return false;
 }
 private void InstallMacheteRemoval(){
  var h=new HarmonyLib.Harmony("signalis.vr.remove.machete");
  var reject=new HarmonyMethod(typeof(Tracking),nameof(RejectMacheteItem));
  foreach(string name in new[]{"AddItem","AddItemToMax","SetCount","boxItem","storeItem"}){
   foreach(var method in AccessTools.GetDeclaredMethods(typeof(global::InventoryManager)))if(method.Name==name&&method.GetParameters().Length>0&&method.GetParameters()[0].ParameterType==typeof(global::AnItem))h.Patch(method,prefix:reject);
  }
  foreach(string name in new[]{"EquipWeapon","EquipTool","useItem"})h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),name,new[]{typeof(global::AnItem)}),prefix:reject);
  var purge=new HarmonyMethod(typeof(Tracking),nameof(RemoveExistingMachete));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::SaveManager),"Load",Type.EmptyTypes),postfix:purge);
  h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryManager),"initializeInventory",Type.EmptyTypes),postfix:purge);
  foreach(string name in new[]{"updateItems","initializeBox"})h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),name,Type.EmptyTypes),prefix:purge);
  foreach(string name in new[]{"Awake","LoadState","pickUp"})h.Patch(AccessTools.DeclaredMethod(typeof(global::ItemPickup),name,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(RemoveMachetePickup)));
 }
}}
