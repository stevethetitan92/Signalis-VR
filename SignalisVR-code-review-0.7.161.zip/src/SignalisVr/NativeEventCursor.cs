using System;
using UnityEngine;
using UnityEngine.UI;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private global::InteractionTypeIcon nativeEventIcon;
 private GameObject nativeCursorRoot;
 private Canvas nativeCursorCanvas;
 private Image nativeCursorIcon,nativeCursorDot;
 private static void NativeEventIconUpdated(global::InteractionTypeIcon __instance){
  var q=questOwner;if(q==null||__instance==null||!__instance.isActiveAndEnabled||__instance.Event==null)return;
  q.ObserveComputerCursor(__instance);
  if(__instance.Event.cam==q.EventWalkCamera())q.nativeEventIcon=__instance;
 }
 private Image CreateNativeCursorImage(string name){
  var go=new GameObject(name);go.layer=31;go.AddComponent<RectTransform>();go.transform.SetParent(nativeCursorRoot.transform,false);
  var image=go.AddComponent<Image>();image.raycastTarget=false;return image;
 }
 private void EnsureNativeCursorCanvas(){
  if(nativeCursorRoot!=null)return;
  nativeCursorRoot=new GameObject("SignalisVR_NativeEventCursor");nativeCursorRoot.layer=31;
  nativeCursorRoot.AddComponent<RectTransform>();nativeCursorCanvas=nativeCursorRoot.AddComponent<Canvas>();
  nativeCursorCanvas.renderMode=RenderMode.WorldSpace;nativeCursorCanvas.overrideSorting=true;nativeCursorCanvas.sortingOrder=32760;nativeCursorCanvas.enabled=false;
  nativeCursorDot=CreateNativeCursorImage("Native dot");nativeCursorIcon=CreateNativeCursorImage("Native interaction icon");
 }
 private static void CopyNativeCursorImage(Image source,Image target){
  target.enabled=source!=null&&source.enabled&&source.gameObject.activeInHierarchy&&source.sprite!=null;
  if(!target.enabled)return;
  // Native controller retains all sprite, colour, fade and size transitions.
  target.sprite=source.overrideSprite!=null?source.overrideSprite:source.sprite;
  target.material=source.material;target.type=source.type;target.preserveAspect=source.preserveAspect;
  target.fillMethod=source.fillMethod;target.fillOrigin=source.fillOrigin;target.fillClockwise=source.fillClockwise;target.fillAmount=source.fillAmount;
  var color=source.color;color.a*=source.canvasRenderer.GetInheritedAlpha();target.color=color;
  var rect=target.rectTransform;rect.anchorMin=rect.anchorMax=rect.pivot=new Vector2(.5f,.5f);
  rect.anchoredPosition3D=Vector3.zero;rect.sizeDelta=source.rectTransform.rect.size;
  rect.localRotation=source.rectTransform.localRotation;rect.localScale=source.rectTransform.localScale;
 }
 private void RenderNativeEventCursor(Camera eye){
  var source=nativeEventIcon;
  if(!EventViewCursorActive()||source==null||!source.isActiveAndEnabled||source.Event==null||source.Event.cam!=camera)return;
  EnsureNativeCursorCanvas();CopyNativeCursorImage(source.dot,nativeCursorDot);CopyNativeCursorImage(source.icon,nativeCursorIcon);
  if(!nativeCursorIcon.enabled&&!nativeCursorDot.enabled)return;
  var originalCanvas=source.icon!=null?source.icon.canvas:source.dot.canvas;
  var originalRect=originalCanvas==null?null:originalCanvas.rootCanvas.GetComponent<RectTransform>();
  var size=originalRect==null?new Vector2(640,360):originalRect.rect.size;
  if(size.x<=0f||size.y<=0f)return;
  var rect=nativeCursorRoot.GetComponent<RectTransform>();rect.sizeDelta=size;
  rect.position=EventViewAimPoint();rect.rotation=camera.transform.rotation;rect.localScale=Vector3.one*(2.4f*UnitsPerMetre/size.x);
  int mask=eye.cullingMask;var clear=eye.clearFlags;var target=RenderTexture.active;
  try{
   nativeCursorCanvas.worldCamera=eye;nativeCursorCanvas.enabled=true;Canvas.ForceUpdateCanvases();
   eye.cullingMask=1<<31;eye.clearFlags=CameraClearFlags.Depth;eye.Render();
  }finally{
   nativeCursorCanvas.enabled=false;eye.cullingMask=mask;eye.clearFlags=clear;RenderTexture.active=target;
  }
 }
 private void ClearNativeEventCursor(){
  ClearOpeningCryo();
  screenCursorPoint=IntPtr.Zero;closeupAnchorPoint=IntPtr.Zero;screenCursorControl=null;screenCursorFrame=-1;centeredSnowCamera=0;
  eventReturnMenu=false;
  if(nativeCursorRoot!=null)UnityEngine.Object.Destroy(nativeCursorRoot);
  nativeCursorRoot=null;nativeCursorCanvas=null;nativeCursorIcon=null;nativeCursorDot=null;nativeEventIcon=null;
 }
}}

