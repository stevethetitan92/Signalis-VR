using System;
namespace SignalisVrTracking {
 // A short, measured 3D walkway graph. Height distinguishes stacked sections
 // of the slope; points live in its moving frame, never in a scene-wide AABB.
 public sealed class MinePathProjection {
  private readonly double[,] points;private readonly int[,] edges;private readonly double width;
  public MinePathProjection(double[,] points,int[,] edges,double width){this.points=points;this.edges=edges;this.width=width;}
  public bool Point(double x,double y,double z,out double u,out double v){
   u=v=0;double best=double.PositiveInfinity;int selected=-1;
   for(int i=0;i<edges.GetLength(0);i++){
    int a=edges[i,0],b=edges[i,1];double dx=points[b,0]-points[a,0],dy=points[b,1]-points[a,1],dz=points[b,2]-points[a,2],length=dx*dx+dy*dy+dz*dz;
    if(length<.0001)continue;double t=((x-points[a,0])*dx+(y-points[a,1])*dy+(z-points[a,2])*dz)/length;t=Math.Max(0,Math.Min(1,t));
    double px=x-points[a,0]-t*dx,py=y-points[a,1]-t*dy,pz=z-points[a,2]-t*dz,d=px*px+py*py+pz*pz;
    if(d<best){best=d;selected=i;}
   }
   if(selected<0)return false;
   int from=edges[selected,0],to=edges[selected,1];double ax=points[to,0]-points[from,0],ay=points[to,1]-points[from,1],az=points[to,2]-points[from,2],len=ax*ax+ay*ay+az*az;
   double along=((x-points[from,0])*ax+(y-points[from,1])*ay+(z-points[from,2])*az)/len;
   // Project a consistent right axis perpendicular to each section. Unlike
   // XY-only normals this does not flip on the rising, overlapping walkway.
   double sx=1-ax*ax/len,sy=-ax*ay/len,sz=-ax*az/len,sl=Math.Sqrt(sx*sx+sy*sy+sz*sz);
   if(sl<.001){sx=-ay;sy=ax;sz=0;sl=Math.Sqrt(sx*sx+sy*sy);}
   double across=sl>.001?((x-points[from,0]-along*ax)*sx+(y-points[from,1]-along*ay)*sy+(z-points[from,2]-along*az)*sz)/sl:0;
   double mu=points[to,3]-points[from,3],mv=points[to,4]-points[from,4],ml=mu*mu+mv*mv;
   double su=ml>.00001?1-mu*mu/ml:1,sv=ml>.00001?-mu*mv/ml:0,sm=Math.Sqrt(su*su+sv*sv);
   if(sm<.001){su=-mv;sv=mu;sm=Math.Sqrt(su*su+sv*sv);}
   u=points[from,3]+along*mu+(sm>.001?su/sm*across*width:0);v=points[from,4]+along*mv+(sm>.001?sv/sm*across*width:0);
   return !(double.IsNaN(u)||double.IsInfinity(u)||double.IsNaN(v)||double.IsInfinity(v));
  }
 }
}
