namespace SignalisVrTracking {
 // Left grip + a fresh Y press reports; consume Y until it is released.
 // The grip keeps its normal support/reload behavior. Reconnect requires Y up.
 public sealed class ReportShortcut {
  private bool armed,latched,previousY;
  public bool Consume {get;private set;}
  public bool Update(bool available,bool grip,bool y){
   Consume=false;
   if(!available){armed=latched=previousY=false;return false;}
   if(!armed){armed=!y;previousY=y;Consume=y;return false;}
   bool fire=grip&&y&&!previousY;previousY=y;
   if(fire)latched=true;
   Consume=latched;
   if(!y)latched=false;
   return fire;
  }
 }
}
