using System;
using System.Text;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private int handRigRootId,handRigReports;
  private float nextHandRigReport;
  // Inspect the unmodified animated player before scoped gun rendering. No pose,
  // renderer, mesh or animator writes. Maximum three root reports per launch.
  private void InspectHandRig() {
   if(handRigReports>=3||Time.realtimeSinceStartup<nextHandRigReport||!QuestUnifiedReady())return;
   nextHandRigReport=Time.realtimeSinceStartup+2f;
   try {
    var attack=global::PlayerAttack.instance;if(attack==null)return;
    var root=attack.transform.root;if(root==null||root.GetInstanceID()==handRigRootId)return;
    handRigRootId=root.GetInstanceID();handRigReports++;
    MelonLogger.Msg("HAND RIG: root="+root.name+" id="+handRigRootId+" frame="+Time.frameCount);
    var animators=root.GetComponentsInChildren<Animator>(true);
    for(int i=0;i<animators.Length&&i<8;i++) {
     var a=animators[i];if(a==null)continue;
     MelonLogger.Msg("HAND RIG ANIMATOR: path="+HandRigPath(a.transform,root)+" human="+a.isHuman+" enabled="+a.enabled);
     if(a.isHuman)foreach(var bone in new[]{HumanBodyBones.LeftUpperArm,HumanBodyBones.LeftLowerArm,HumanBodyBones.LeftHand,HumanBodyBones.RightUpperArm,HumanBodyBones.RightLowerArm,HumanBodyBones.RightHand}) {
      var t=a.GetBoneTransform(bone);
      MelonLogger.Msg("HAND RIG HUMANOID: bone="+bone+" path="+HandRigPath(t,root)+(t==null?"":" pos="+WeaponVector(t.position)+" forward="+WeaponVector(t.forward)+" up="+WeaponVector(t.up)));
     }
    }
    var skins=root.GetComponentsInChildren<SkinnedMeshRenderer>(true);
    for(int i=0;i<skins.Length&&i<12;i++) {
     var r=skins[i];if(r==null)continue;var mesh=r.sharedMesh;
     MelonLogger.Msg("HAND RIG SKIN: path="+HandRigPath(r.transform,root)+" active="+r.gameObject.activeInHierarchy+" enabled="+r.enabled
      +" mesh="+(mesh==null?"null":mesh.name)+" vertices="+(mesh==null?0:mesh.vertexCount)+" readable="+(mesh!=null&&mesh.isReadable));
     var bones=r.bones;var line=new StringBuilder();
     for(int j=0;j<bones.Length&&j<256;j++) {
      var b=bones[j];line.Append(j).Append(':').Append(HandRigPath(b,root));
      if(b!=null)line.Append(" pos=").Append(WeaponVector(b.position));
      line.Append("; ");
      if(j%8==7||j==bones.Length-1||j==255){MelonLogger.Msg("HAND RIG BONES: skin="+i+" "+line);line.Length=0;}
     }
    }
    var renderers=root.GetComponentsInChildren<MeshRenderer>(true);
    for(int i=0;i<renderers.Length&&i<32;i++) {
     var r=renderers[i];if(r!=null)MelonLogger.Msg("HAND RIG STATIC: path="+HandRigPath(r.transform,root)+" active="+r.gameObject.activeInHierarchy+" enabled="+r.enabled);
    }
   }catch(Exception ex){handRigReports=3;MelonLogger.Warning("Hand rig inspection stopped; gameplay unchanged: "+ex.Message);}
  }
  private static string HandRigPath(Transform t,Transform root) {
   if(t==null)return "null";
   string path=t.name;
   for(int i=0;i<12&&t!=root&&t.parent!=null;i++){t=t.parent;path=t.name+"/"+path;}
   return path;
  }
 }
}
