namespace SignalisVrTracking {public sealed partial class Tracking {
 // HE ammunition changes the native item identity, not the physical firearm.
 // Only presentation/mechanism callers use this alias; damage and projectile
 // dispatch continue to receive the original AnWeapon and ammo item.
 internal static string WeaponFamily(string id){return id=="FlakGun"?"FlareGun":id;}
 private static bool IsFlaregun(global::Items.itemlist item){return item==global::Items.itemlist.FlareGun||item==global::Items.itemlist.FlakGun;}
}}
