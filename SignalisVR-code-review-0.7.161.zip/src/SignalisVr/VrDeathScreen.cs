using System;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private global::GameOverHandler vrDeathHandler;
 private bool deathButtonHeld,deathScreenWasVisible;
 private float deathButtonAt=-100;
 private Renderer[] deathPanelRenderers;
 private void ClearVrDeath(){
  if(deathWaitOwner!=null)deathWaitOwner.waitBeforeGameOver=deathOriginalWait;
  deathWaitOwner=vrDeathHandler=null;deathPanelRenderers=null;deathButtonAt=-100;deathButtonHeld=false;
  if(puzzleMaterial!=null)ApplyPuzzleUV();
  if(puzzleScreen!=null)puzzleScreen.transform.localScale=new Vector3(2.4f,2.4f*Screen.height/Screen.width,1);
  deathScreenWasVisible=false;
 }
 private bool VrDeathActive(){return ProdVrMode()&&(global::PlayerState.gameOver||(vrDeathHandler!=null&&vrDeathHandler.dead));}
 private bool PollVrDeathInput(bool available,int buttons){
  if(!VrDeathActive()){deathButtonHeld=false;deathButtonAt=-100;return false;}
  bool down=available&&buttons!=0;
  if(down&&!deathButtonHeld)deathButtonAt=Time.unscaledTime;
  deathButtonHeld=down;questFrame=new QuestFrame();SnapshotQuestNative();return true;
 }
 private static void DeathAnyButton(ref bool __result){
  var q=questOwner;if(q==null||!q.VrDeathActive())return;
  if(q.questAvailabilityValue&&Time.unscaledTime-q.deathButtonAt<.3f){__result=true;q.deathButtonAt=-100;}
 }
 private static bool SkipVrDeathAnimation(){
  var q=questOwner;if(q==null||!q.ProdVrMode()||global::PlayerState.hp>1)return true;
  // Emergency injection is recovery, so do not leave locomotion in the
  // death cutscene when the native GameOverHandler restores the player's HP.
  try{if(CarriedInjector()!=null)return false;}catch(Exception){}
  // Preserve native death input/state transition while omitting the Die animator trigger.
  global::PlayerState.gameState=global::PlayerState.gameStates.cutscene;return false;
 }
 private float deathOriginalWait;private global::GameOverHandler deathWaitOwner;
 private static void DeathSequenceStarted(global::GameOverHandler __instance){
  var q=questOwner;if(q==null||!q.ProdVrMode())return;
  if(q.deathWaitOwner!=__instance){q.deathWaitOwner=__instance;q.deathOriginalWait=__instance.waitBeforeGameOver;}
  q.vrDeathHandler=__instance;q.deathPanelRenderers=null;q.deathButtonAt=-100;q.deathButtonHeld=true;q.puzzleAnchorPending=true;__instance.waitBeforeGameOver=0;
 }
 private static void DeathSequenceDisabled(global::GameOverHandler __instance){
  var q=questOwner;if(q==null)return;
  if(q.deathWaitOwner==__instance){__instance.waitBeforeGameOver=q.deathOriginalWait;q.deathWaitOwner=null;}
  if(q.vrDeathHandler==__instance)q.vrDeathHandler=null;
 }
 private void FitVrDeathScreen(){
  bool visible=VrDeathActive()&&vrDeathHandler!=null&&vrDeathHandler.GameOverObject!=null&&vrDeathHandler.GameOverObject.activeInHierarchy;
  if(!visible){if(deathScreenWasVisible){ApplyPuzzleUV();puzzleScreen.transform.localScale=new Vector3(2.4f,2.4f*Screen.height/Screen.width,1);puzzleAnchorPending=true;}deathScreenWasVisible=false;return;}
  if(!deathScreenWasVisible)puzzleAnchorPending=true;deathScreenWasVisible=true;
  puzzleScreen.transform.localScale=new Vector3(3.2f,3.2f*Screen.height/Screen.width,1);
  // Existing renderer submits this panel separately for each eye with IPD.
  // Crop the native death panel only when its projected bounds are trustworthy.
  var cam=Camera.main;if(cam==null)return;
  float x0=1,y0=1,x1=0,y1=0;bool found=false;
  if(deathPanelRenderers==null)deathPanelRenderers=vrDeathHandler.GameOverObject.GetComponentsInChildren<Renderer>();
  foreach(var r in deathPanelRenderers){
   if(r==null||!r.enabled)continue;var b=r.bounds;
   for(int i=0;i<8;i++){var p=cam.WorldToViewportPoint(b.center+Vector3.Scale(b.extents,new Vector3((i&1)==0?-1:1,(i&2)==0?-1:1,(i&4)==0?-1:1)));if(p.z<=0)return;x0=Math.Min(x0,p.x);x1=Math.Max(x1,p.x);y0=Math.Min(y0,p.y);y1=Math.Max(y1,p.y);found=true;}
  }
  if(!found)return;x0=Mathf.Clamp01(x0-.01f);x1=Mathf.Clamp01(x1+.01f);y0=Mathf.Clamp01(y0-.01f);y1=Mathf.Clamp01(y1+.01f);
  float w=x1-x0,h=y1-y0;if(w<.05f||h<.05f)return;
  puzzleMaterial.mainTextureScale=new Vector2(w,puzzleContentFlip?-h:h);
  puzzleMaterial.mainTextureOffset=new Vector2(x0,puzzleContentFlip?y1:y0);
  puzzleScreen.transform.localScale=new Vector3(3.2f,3.2f*(Screen.height*h)/(Screen.width*w),1);
 }
 private void InstallVrDeathScreen(HarmonyLib.Harmony h){
  h.Patch(AccessTools.DeclaredMethod(typeof(global::ElsterDeathHandler),"hurt"),prefix:new HarmonyMethod(typeof(Tracking),nameof(SkipVrDeathAnimation)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::GameOverHandler),"GameOver"),prefix:new HarmonyMethod(typeof(Tracking),nameof(DeathSequenceStarted)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::GameOverHandler),"OnDisable"),prefix:new HarmonyMethod(typeof(Tracking),nameof(DeathSequenceDisabled)));
  h.Patch(AccessTools.DeclaredMethod(typeof(Rewired.ReInput.ControllerHelper),"GetAnyButton",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(DeathAnyButton)));
 }
}}

