﻿using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private GameObject hipAmmoRoot;private readonly List<MeshRenderer> hipAmmoParts=new List<MeshRenderer>();private string hipAmmoKind;
 private void CopyHipPart(MeshRenderer source,Vector3 offset,Quaternion rotation){
  if(source==null)return;var r=CreateControllerPart(hipAmmoRoot,source.GetComponent<MeshFilter>().sharedMesh,source.sharedMaterial,"HipAmmo",offset,source.transform.localScale);r.sharedMaterials=source.sharedMaterials;r.transform.localRotation=rotation;hipAmmoParts.Add(r);
 }
 private void PrepareHipAmmo(){
  HideHipAmmo();if(!handsScoped||!ControllerWeaponVisualReady()||modMenuOpen)return;var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null)return;
  string kind=WeaponFamily(w.parentItem._item.ToString());if(kind!="Pistol"&&kind!="Shotgun"&&kind!="SMG"&&kind!="Revolver"&&kind!="Rifle"&&kind!="FlareGun")return;
  if(hipAmmoKind!=RoundAppearance(kind)||hipAmmoRoot==null){
   DestroyHipAmmo();hipAmmoRoot=new GameObject("SignalisVR_MatchingHipAmmo");UnityEngine.Object.DontDestroyOnLoad(hipAmmoRoot);hipAmmoKind=RoundAppearance(kind);hipAmmoRoot.transform.localScale=Vector3.one*UnitsPerMetre*(kind=="Revolver"?AmmoGuidePolicy.RevolverScale:1f);
   if(kind=="Pistol"){EnsureManualReloadVisuals();if(!ApplySelectedHeldMagazine()){DestroyHipAmmo();return;}CopyHipPart(manualMagazine,Vector3.zero,Quaternion.identity);}
   else if(kind=="Shotgun"){EnsureShotgunReload();ApplyHdShotgunShell();CopyHipPart(shotgunShell,Vector3.zero,Quaternion.identity);}
   else if(kind=="Revolver"&&SelectedActive("Revolver")){
    var turn=Quaternion.Euler(-90,0,0);var center=HdRevolverData.LoaderCenter;
    for(int i=0;i<selectedParts.Count;i++)if(selectedRoles[i]>=10||selectedRoles[i]==6)CopyHipPart(selectedParts[i],-(turn*center),turn);
   }else{EnsureAdditionalAmmo(kind);CopyHipPart(additionalAmmo,Vector3.zero,Quaternion.identity);if(additionalCase!=null)CopyHipPart(additionalCase,new Vector3(0,kind=="Rifle"?.054f:.034f,0),Quaternion.identity);}
  }
  if(kind=="Pistol"){if(!ApplySelectedHeldMagazine()){DestroyHipAmmo();return;}foreach(var r in hipAmmoParts){r.GetComponent<MeshFilter>().sharedMesh=manualMagazine.GetComponent<MeshFilter>().sharedMesh;r.sharedMaterials=manualMagazine.sharedMaterials;r.transform.localScale=Vector3.one;}}
  var yaw=BodyHipRotation();
  hipAmmoRoot.transform.SetPositionAndRotation(stereoPosition+yaw*(new Vector3(-.22f,-.5f,0)*UnitsPerMetre),yaw);
  foreach(var r in hipAmmoParts)r.enabled=true;
  // These old cube cues occupy exactly the same pickup region; show ammunition instead.
  if(manualPouch!=null)manualPouch.enabled=false;if(shotgunPouch!=null)shotgunPouch.enabled=false;if(additionalPouch!=null)additionalPouch.enabled=false;if(additionalHipAmmo!=null)additionalHipAmmo.enabled=false;
 }
 private void HideHipAmmo(){foreach(var r in hipAmmoParts)if(r!=null)r.enabled=false;}
 private void DestroyHipAmmo(){if(hipAmmoRoot!=null)UnityEngine.Object.Destroy(hipAmmoRoot);hipAmmoRoot=null;hipAmmoKind=null;hipAmmoParts.Clear();}
} }

