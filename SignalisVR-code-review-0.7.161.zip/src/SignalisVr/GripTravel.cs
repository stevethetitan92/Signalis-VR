using UnityEngine;
namespace SignalisVrTracking {
 // Track the grabbed point rigidly with the hand, measuring in the gun's frame.
 internal sealed class GripTravel {
  private Vector3 contactInHand,contactInGun;
  internal void Begin(Vector3 hand,Quaternion handRotation,Vector3 gun,Quaternion gunRotation,Vector3 contact,float scale){
   contactInHand=Quaternion.Inverse(handRotation)*(contact-hand)/scale;
   contactInGun=Quaternion.Inverse(gunRotation)*(contact-gun)/scale;
  }
  internal float Pull(Vector3 hand,Quaternion handRotation,Vector3 gun,Quaternion gunRotation,float scale){
   var contact=hand+handRotation*contactInHand*scale;
   var local=Quaternion.Inverse(gunRotation)*(contact-gun)/scale;
   return contactInGun.z-local.z;
  }
 }
}
