using System;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private global::EventWalking eventWalker;
 private global::EventScreen3DCam stereoEventControl;
 private static void EventCameraInput(global::EventScreen3DCam __instance,System.Reflection.MethodBase __originalMethod,out QuestPuzzleState __state){
  var q=questOwner;if(q!=null&&IsSnowEventControl(__instance))q.stereoEventControl=__instance;
  QuestPuzzlePrefix(__originalMethod,out __state);
  if(q!=null)q.PrepareScreenCursor(__instance,ref __state);
 }
 // The opening snow scene has no EventWalking component. Never use the
 // general EventScreen3DCam fallback: keypad/safe/terminal views use it too.
 private static bool IsSnowEventControl(global::EventScreen3DCam control){
  return false; // Opening snow walk intentionally retains native flat presentation.
 }
 private Camera eventWalkReturnCamera;
 private bool eventWalkStereo;
 private bool eventReturnMenu;
 // Event ownership survives flat cutscenes/menu transitions; do not gate this
 // on an eye submission or camera availability, which can disappear mid-event.
 private bool RadioStationActive(){var w=eventWalker;return IsRadioStationWalker(w)&&w.isActiveAndEnabled&&w.point!=null&&w.point._active;}
 private static bool IsRadioStationWalker(global::EventWalking walker){
  if(walker==null)return false;
  var origin=walker.transform.parent;
  return origin!=null&&origin.name=="CameraOrigin"&&origin.parent!=null&&origin.parent.name=="ROT_RadioStation";
 }
 private static bool IsStereoEventWalker(global::EventWalking walker){
  return walker!=null;
 }
 private static void EventWalkingInput(global::EventWalking __instance,System.Reflection.MethodBase __originalMethod,out QuestPuzzleState __state){
  __state=default(QuestPuzzleState);
  if(!IsStereoEventWalker(__instance))return;
  var q=questOwner;
  if(q!=null&&__instance!=null&&__instance.isActiveAndEnabled&&__instance.point!=null&&__instance.point._active)q.eventWalker=__instance;
  QuestPuzzlePrefix(__originalMethod,out __state);
  if(q!=null&&q.immersiveRequested&&__instance.isActiveAndEnabled&&__instance.point!=null&&__instance.point._active&&global::PlayerState.gameState==global::PlayerState.gameStates.eventScreen&&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput){
   __state.walker=__instance;__state.walkSpeed=__instance.walkSpeed;__state.strafeSpeed=__instance.strafeSpeed;__state.turnSpeed=__instance.turnSpeed;
   __instance.turnSpeed=__state.turnSpeed*QuestInputPolicy.TurnMultiplier(q.modTurnSpeed);
   if(IsRadioStationWalker(__instance)){__instance.walkSpeed=__state.walkSpeed*2f;__instance.strafeSpeed=__state.strafeSpeed*2f;}
  }
 }
 private Camera EventWalkCamera(){
  if(!immersiveRequested||!active||!stereo||stopping||questInputStopped||global::PlayerState.gameOver||global::PlayerState.hp<=0||global::BlackSleekGuiSubs.itemView)return null;
  var cryo=OpeningCryoCamera();if(cryo!=null)return cryo;
  if(global::PlayerState.gameState!=global::PlayerState.gameStates.eventScreen&&global::PlayerState.gameState!=global::PlayerState.gameStates.dialogue)return null;
  var w=eventWalker;
  bool walking=IsStereoEventWalker(w)&&w.isActiveAndEnabled&&w.point!=null&&w.point._active;
  var control=walking?w.point._camera:IsSnowEventControl(stereoEventControl)?stereoEventControl:null;
  if(control==null||!control.isActiveAndEnabled||control.path==null||control.depth<0||control.depth>=control.path.Count)return null;
  var point=control.path[control.depth];if(point==null||!point._active)return null;
  // A walking camera can also zoom into a puzzle. Only its walking point owns
  // stereo; restoring that exact point allows stereo again on puzzle exit.
  if(walking&&point!=w.point)return null;
  var c=control==null?null:control.cam;
  return c!=null&&c.isActiveAndEnabled&&!c.orthographic&&c.transform.parent!=null?c:null;
 }
 private bool UpdateEventWalkCamera(){
  UpdateEventScreenCursorState();
  var target=EventWalkCamera();
  if(target!=null){
   if(eventWalkStereo&&camera==target)return true;
   if(bridgeConfigured&&CancelPreparedPose()==0)return false;
   if(!eventWalkStereo){eventWalkReturnCamera=camera;eventReturnMenu=questMenuScene;}
   // A scene-loaded event can retain flat menu capture even after selecting its camera.
   recovery.Reset();menuCaptureReady=false;sceneRecoveryDraining=false;
   diagnostic.Connected();diagnostic.RenderReady();
   if(!diagnostic.CanSubmit&&!diagnostic.BeginSubmit(Time.realtimeSinceStartup))return false;
   questMenuScene=false;waitingForGameplay=false;
   camera=target;eventWalkStereo=true;originalRotation=camera.transform.localRotation;recenterPending=true;
   MelonLoader.MelonLogger.Msg("EVENT WALK: stereo camera="+camera.name+" walker="+(eventWalker==null?"close-up":eventWalker.name));
  }else if(eventWalkStereo){
   if(bridgeConfigured&&CancelPreparedPose()==0)return false;
   camera=eventWalkReturnCamera;eventWalkReturnCamera=null;eventWalkStereo=false;recenterPending=true;
   if(eventReturnMenu){questMenuScene=true;puzzleAnchorPending=true;}eventReturnMenu=false;
   if(camera!=null)originalRotation=camera.transform.localRotation;
   MelonLoader.MelonLogger.Msg("EVENT WALK: restored prior camera; native screen/gameplay routing resumes.");
  }
  return true;
 }
}}



