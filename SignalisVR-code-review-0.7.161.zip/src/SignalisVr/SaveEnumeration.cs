using System;
using System.Collections.Generic;
using System.IO;
using HarmonyLib;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static bool IsVrSaveArtifact(string path){
  if(string.IsNullOrEmpty(path))return false;
  string name=Path.GetFileName(path.Replace('\\','/'));
  return System.Text.RegularExpressions.Regex.IsMatch(name,@"^cargo[0-9]+\.png\.(vr-backup|vr-writing-[0-9a-f]+)$",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
 }
 private static void FilterSaveArtifacts(ref UnhollowerBaseLib.Il2CppStringArray __result){
  if(__result==null)return;var keep=new List<string>();int removed=0;
  foreach(var path in __result){if(IsVrSaveArtifact(path))removed++;else keep.Add(path);}
  if(removed==0)return;__result=new UnhollowerBaseLib.Il2CppStringArray(keep.ToArray());
  MelonLoader.MelonLogger.Msg("SAVE FILE SCAN: excluded "+removed+" mod backup/temporary files; files preserved on disk.");
 }
 private void InstallSaveEnumeration(){
  foreach(var type in new[]{typeof(global::PlatformManagement.SaveSystemWorkerStandalone),typeof(global::PlatformManagement.SaveSystemWorkerBase)})
   foreach(var signature in new[]{new[]{typeof(string)},new[]{typeof(string),typeof(Il2CppSystem.IO.SearchOption)}}){
    var method=AccessTools.DeclaredMethod(type,"DirectoryGetFiles",signature);
    if(method!=null)questHarmony.Patch(method,postfix:new HarmonyMethod(typeof(Tracking),nameof(FilterSaveArtifacts)));
   }
 }
}}
