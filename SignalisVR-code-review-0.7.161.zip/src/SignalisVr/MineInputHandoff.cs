﻿using System;
using MelonLoader;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool fpCursorGateReported;
 private int fpLayoutReported=-1;
 private static int QuestFpLayoutCount(UnityEngine.Transform root){
  int actual=root.childCount;var q=questOwner;
  // FPv2 uses five attached objects as a proxy for a ready player. Scene
  // handoffs (including skipped cinematics) can change that hierarchy.
  // Validate the live rig every frame instead; never change native locks.
  if(actual==5||q==null||q.QuestLookBlocker(false)!=null||!q.QuestFirstPersonReady())return actual;
  var model=q.questFpModel.GetValue(q.questFpMod) as UnityEngine.GameObject;
  if(model==null||model.transform!=root||model.GetComponent<UnityEngine.Rigidbody>()==null
   ||q.camera==null||q.camera.orthographic||q.camera.transform.parent!=root)return actual;
  if(q.fpLayoutReported!=actual){q.fpLayoutReported=actual;MelonLogger.Msg("FP PLAYER HANDOFF: children="+actual+"; live player/body/camera ready; native cinematic/traversal locks retained.");}
  return 5;
 }
 private static void QuestFpObjectGate(ref bool[] __result){
  var q=questOwner;
  // FPv2 requires the desktop CursorPersistent before reading either stick.
  // VR gameplay uses controller targeting; this cursor can remain inactive
  // after the mine elevator sequence. Never change native input/state locks.
  if(q==null||__result==null||__result.Length!=4||!__result[0]||!__result[1]||!__result[3]||__result[2])return;
  if(q.QuestLookBlocker(false)!=null||!q.QuestFirstPersonReady())return;
  __result[2]=true;
  if(!q.fpCursorGateReported){q.fpCursorGateReported=true;MelonLogger.Msg("FP INPUT HANDOFF: desktop cursor absent; valid VR gameplay retains movement/turning. Native cinematic and traversal locks retained.");}
 }
 private static void FasterEnemyRevivalChecks(global::EnemyManagerManager __instance){
  var q=weaponOwner;
  if(q==null||__instance==null||!q.ProdVrMode()||!q.WeaponGameplayReady()||q.modMenuOpen||q.pauseMenuVisible
   ||global::PlayerState.gameState!=global::PlayerState.gameStates.play||global::PlayerState.paused||global::PlayerState.cutscene
   ||global::PlayerState.suspendInput||global::PlayerState.gameOver||global::PlayerState.hp<=0)return;
  float delta=UnityEngine.Time.deltaTime;
  // The native manager advances this timer and owns the random eligibility,
  // room exclusion, burned/permanent death and revive limits. Use a slightly faster
  // check cadence (2.2x instead of 2x); do not manufacture enemies or restart death states.
  if(delta>0&&delta<=.25f&&__instance.respawnTimer>=0)__instance.respawnTimer+=delta*1.2f;
 }
}}
