﻿using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private int lastPerPullFrame=-1;
 private static void PreparePerPullFire(global::PlayerAttack __instance){
  var q=weaponOwner;
  if(q==null||__instance==null||!q.ControllerWeaponReady()||!q.WeaponGameplayReady()||!q.questPolicy.RightArmed)return;
  if(q.lastPerPullFrame==Time.frameCount||(q.questNativeEdges.Down&(1<<6))==0||(q.questFrame.buttons&(1<<6))==0)return;
  // Never carry a pull through a reload, paused scene, empty weapon or equip gate.
  if(!__instance.aiming||__instance.melee||global::PlayerState.reloading||global::PlayerAttack.reloading||q.ManualReloadBlocksAttack())return;
  var w=global::InventoryManager.EquippedWeapon;
  if(w==null||w.parentItem==null||w.magAmmo<=0||__instance.weapon!=w)return;
  switch(w.parentItem._item){
   case global::Items.itemlist.Pistol:case global::Items.itemlist.Revolver:case global::Items.itemlist.Shotgun:case global::Items.itemlist.Rifle:case global::Items.itemlist.FlakGun:case global::Items.itemlist.FlareGun:break;
   default:return;
  }
  q.lastPerPullFrame=Time.frameCount;
  // Update checks this timer before entering the normal ReadyForAttack path.
  // Reset only on a new controller pull; held input and SMG cadence are untouched.
  if(__instance.timer>0)__instance.timer=0;
 }
}}
