using System;
using HarmonyLib;
using MelonLoader;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static void PrepareSaveLists(){
  // The native save serializes menu ordering even if the inventory/storage UI
  // has never been opened. Wheel use does not initialize those UI lists.
  if(global::InventoryBase.currentItems==null){
   global::InventoryBase.currentItems=new Il2CppSystem.Collections.Generic.List<global::AnItem>();
   if(global::InventoryManager.elsterItems!=null)foreach(var pair in global::InventoryManager.elsterItems)if(pair.Key!=null&&pair.Value>0)global::InventoryBase.currentItems.Add(pair.Key);
   MelonLogger.Msg("SAVE: initialized carried-item ordering from inventory.");
  }
  if(global::InventoryBase.currentBoxItems==null){
   global::InventoryBase.currentBoxItems=new Il2CppSystem.Collections.Generic.List<global::AnItem>();
   if(global::InventoryManager.boxItems!=null)foreach(var pair in global::InventoryManager.boxItems)if(pair.Key!=null&&pair.Value>0)global::InventoryBase.currentBoxItems.Add(pair.Key);
   MelonLogger.Msg("SAVE: initialized storage ordering from inventory.");
  }
  for(int i=global::InventoryBase.currentItems.Count-1;i>=0;i--)if(global::InventoryBase.currentItems[i]==null)global::InventoryBase.currentItems.RemoveAt(i);
  for(int i=global::InventoryBase.currentBoxItems.Count-1;i>=0;i--)if(global::InventoryBase.currentBoxItems[i]==null)global::InventoryBase.currentBoxItems.RemoveAt(i);
 }
 private static Exception FinishSaveAttempt(Exception __exception){
  if(__exception==null){MelonLogger.Msg("SAVE: native Save completed.");return null;}
  // Let SavePoint's existing fade/exit coroutine finish. Never label a failed
  // write as successful, retry automatically, or alter its disk data here.
  try{
   global::SaveManager.saving=false;
   var manager=global::SaveManager.instance;
   if(manager!=null&&manager.SaveConfirmationText!=null)manager.SaveConfirmationText.text="SAVE FAILED. PLEASE TRY AGAIN.";
   MelonLogger.Error("SAVE FAILED: released native confirmation wait. "+__exception);
  }catch(Exception cleanup){MelonLogger.Error("Save failure cleanup: "+cleanup);}
  return __exception;
 }
 private void InstallSaveRecovery(){
  InstallInventoryDisplayRecovery();
  InstallSaveEnumeration();
  InstallSaveImageProtection();
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::SaveManager),"Save",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(PrepareSaveLists)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(FinishSaveAttempt)));
 }
}}
