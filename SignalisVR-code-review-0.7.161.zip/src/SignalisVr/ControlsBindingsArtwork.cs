using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private GUIStyle controlsBindingStyle;
 // Code-rendered captions shared by the full image and cropped pause image.
 // Keep original controller artwork; cover its obsolete binding captions.
 private void DrawControlsBindings(Rect image,bool pauseCrop){
  var oldColor=GUI.color;
  float scale=image.width/(pauseCrop?1644f:1672f);
  float x=image.x-(pauseCrop?14f*scale:0),y=image.y-(pauseCrop?8f*scale:0);
  if(controlsBindingStyle==null){controlsBindingStyle=new GUIStyle(GUI.skin.label);controlsBindingStyle.alignment=TextAnchor.MiddleCenter;controlsBindingStyle.wordWrap=false;}
  ControlsBinding(x,y,scale,615,101,190,44,"Y - FLASHLIGHT",20);
  ControlsBinding(x,y,scale,620,208,184,42,"X - TAP INVENTORY",17);
  ControlsBinding(x,y,scale,620,252,184,55,"HOLD X: PAUSE\n3 SECONDS",18);
  if(!pauseCrop)ControlsBinding(x,y,scale,1425,819,231,34,"VR CONTROLS",18);
  GUI.color=oldColor;
 }
 private void ControlsBinding(float x,float y,float scale,float px,float py,float width,float height,string text,int font){
  var r=new Rect(x+px*scale,y+py*scale,width*scale,height*scale);
  PaintMenuRect(r,Color.black);controlsBindingStyle.fontSize=Math.Max(8,(int)(font*scale));
  DrawPixelText(r,text,new Color(0,.95f,1f),controlsBindingStyle);
 }
}}

