using System;
using System.IO;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Vector3[] aglHandRest,aglHandAnimated;private float[] aglIndexWeights;
  private Material CreatePixelRevolverRounds(){
   // Small, nearest-filtered palette atlas: left half is the case side;
   // lower right is the brass case head/primer, upper right is the brass tip.
   var texture=new Texture2D(32,32,TextureFormat.RGBA32,false);
   var pixels=new Color32[1024];
   for(int y=0;y<32;y++)for(int x=0;x<32;x++){
    int r,g,b;
    if(x<16){
     bool brass=y>=26;int stripe=(x/2)%4;
     int shade=stripe==0?-20:stripe==1?0:stripe==2?16:-7;
     int fleck=((x*7+y*11)%29==0)?-12:0;
     r=(brass?157:132)+shade+fleck;g=(brass?110:133)+shade+fleck;b=(brass?38:132)+shade+fleck;
     if(y==1){r-=18;g-=18;b-=18;}
    }else if(y<16){
     float dx=x-23.5f,dy=y-7.5f,d=dx*dx+dy*dy;
     bool rim=d>36&&d<53,primer=d<5;
     int shade=rim?-32:primer?-38:((x+y)%7==0?-10:0);
     r=164+shade;g=117+shade;b=42+shade/2;
    }else {int shade=((x/3+y/3)%3-1)*9;r=164+shade;g=117+shade;b=42+shade;}
    pixels[y*32+x]=new Color32((byte)r,(byte)g,(byte)b,255);
   }
   texture.SetPixels32(pixels);texture.Apply(false,true);texture.filterMode=FilterMode.Point;texture.wrapMode=TextureWrapMode.Clamp;
   var shader=Shader.Find("Unlit/Texture");if(shader==null)throw new InvalidOperationException("Matte cartridge shader unavailable");
   var material=new Material(shader);material.mainTexture=texture;selectedTextures.Add(texture);selectedMaterials.Add(material);return material;
  }
  private static void PixelRevolverRoundUv(Mesh mesh){
   var vertices=mesh.vertices;var normals=mesh.normals;var bounds=mesh.bounds;var uv=new Vector2[vertices.Length];
   float length=Math.Max(.0001f,bounds.size.z),width=Math.Max(.0001f,bounds.size.x),height=Math.Max(.0001f,bounds.size.y);
   for(int i=0;i<vertices.Length;i++){
    var p=vertices[i];float z=Mathf.Clamp01((p.z-bounds.min.z)/length);
    bool cap=Math.Abs(normals[i].z)>.7f&&(z<.08f||z>.92f);
    if(cap){float x=Mathf.Clamp01((p.x-bounds.min.x)/width),y=Mathf.Clamp01((p.y-bounds.min.y)/height);uv[i]=new Vector2((16.5f+x*15f)/32f,((z<.5f?.5f:16.5f)+y*15f)/32f);}
    else {float angle=(float)(Math.Atan2(p.y-bounds.center.y,p.x-bounds.center.x)/(2*Math.PI)+.5);uv[i]=new Vector2((.5f+angle*15f)/32f,(.5f+z*31f)/32f);}
   }
   mesh.uv=uv;
  }
  private void PrepareAglMechanism(){
   float open=additionalOpen;var swing=Quaternion.AngleAxis(90*open,Vector3.forward);float pull=GunSqueeze();
   var triggerTurn=Quaternion.AngleAxis(18*pull,Vector3.right);
   float cock=pull<.85f?pull/.85f:1-(pull-.85f)/.15f;
   var hammerTurn=Quaternion.AngleAxis(-32*Mathf.Clamp01(cock),Vector3.right);
   var w=global::InventoryManager.EquippedWeapon;PrepareRevolverEjector(swing);
   for(int i=0;i<selectedParts.Count;i++){
    int role=selectedRoles[i];var t=selectedParts[i].transform;Quaternion turn=Quaternion.identity;Vector3 pivot=Vector3.zero;
    if(role==6||i==1||i==5)selectedParts[i].enabled=false;
    // Fired rounds disappear immediately; no invisible ejector prerequisite.
    if(role==2||role>=10){turn=swing;pivot=HdRevolverData.Pivot;if(role>=10){selectedParts[i].enabled=role-10<w.magAmmo;selectedParts[i].GetComponent<MeshFilter>().sharedMesh=selectedMeshes[i];}}
    if(role==3){turn=hammerTurn;pivot=HdRevolverData.HammerPivot;}
    if(role==4){turn=triggerTurn;pivot=HdRevolverData.TriggerPivot;}
    t.localRotation=turn;t.localPosition=pivot-turn*pivot;if(i==1||i==5)t.localPosition-=Vector3.forward*revolverRod.Pull;
   }
   var chamber=HdRevolverData.Chamber;
   additionalChamber=selectedRoot.transform.TransformPoint(HdRevolverData.Pivot+swing*(chamber-HdRevolverData.Pivot));
   additionalLoadDirection=rightWeaponRotation*Vector3.forward;additionalBolt=additionalChamber;additionalAnchors=AdditionalGunEligible();
   ShowRevolverEjected();
  }
  private void CreateAglLoader(Shader shader,int count){
   var vertices=new System.Collections.Generic.List<Vector3>();var normals=new System.Collections.Generic.List<Vector3>();var uv=new System.Collections.Generic.List<Vector2>();
   var triangles=new System.Collections.Generic.List<int[]>();var materials=new System.Collections.Generic.List<Material>();
   var center=HdRevolverData.OpenLoaderCenter;var openTurn=Quaternion.AngleAxis(90,Vector3.forward);
   for(int i=0;i<selectedMeshes.Count;i++)if(selectedRoles[i]==6||(selectedRoles[i]>=10&&selectedRoles[i]-10>=additionalLoaderStart&&selectedRoles[i]-10<additionalLoaderStart+count)){
    var mesh=selectedMeshes[i];int offset=vertices.Count;
    foreach(var v in mesh.vertices){var p=HdRevolverData.Pivot+openTurn*(v-HdRevolverData.Pivot)-center;vertices.Add(new Vector3(p.x,p.z,-p.y));}
    foreach(var n in mesh.normals){var q=openTurn*n;normals.Add(new Vector3(q.x,q.z,-q.y));}uv.AddRange(mesh.uv);var indices=mesh.triangles;for(int j=0;j<indices.Length;j++)indices[j]+=offset;
    triangles.Add(indices);materials.Add(selectedParts[i].sharedMaterial);
   }
   additionalMesh=new Mesh();additionalMesh.vertices=vertices.ToArray();additionalMesh.uv=uv.ToArray();additionalMesh.subMeshCount=triangles.Count;
   for(int i=0;i<triangles.Count;i++)additionalMesh.SetTriangles(triangles[i],i);
   additionalMesh.normals=normals.ToArray();additionalMesh.RecalculateBounds();
   additionalAmmo=CreateControllerPart(additionalRoot,additionalMesh,materials[0],"HDSpeedloader",Vector3.zero,Vector3.one);additionalAmmo.sharedMaterials=materials.ToArray();
  }
  private void AnimateAglHand(){
   var mesh=approvedPoseMeshes[5];if(mesh==null)return;
   if(aglHandRest==null||aglHandRest.Length!=mesh.vertexCount){aglHandRest=mesh.vertices;aglHandAnimated=new Vector3[aglHandRest.Length];aglIndexWeights=new float[aglHandRest.Length];using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(PsxModelData.IndexWeights))))for(int i=0;i<aglIndexWeights.Length;i++)aglIndexWeights[i]=r.ReadSingle();}
   float pull=GunSqueeze();for(int i=0;i<aglHandRest.Length;i++){var turn=Quaternion.AngleAxis(18*pull*aglIndexWeights[i],Vector3.right);aglHandAnimated[i]=HdRevolverData.TriggerPivot+turn*(aglHandRest[i]-HdRevolverData.TriggerPivot);}
   mesh.vertices=aglHandAnimated;mesh.RecalculateNormals();mesh.RecalculateBounds();
  }
 }
}





