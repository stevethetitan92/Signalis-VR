using System;
using System.Collections.Generic;
using HarmonyLib;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class EnemyEligibility {internal global::EnemyController Enemy;internal bool NonBoss;}
 private static readonly Dictionary<int,EnemyEligibility> enemyEligibility=new Dictionary<int,EnemyEligibility>();
 private static bool NonBossEnemy(global::EnemyController e){
  if(e==null||(e.Preset!=null&&e.Preset.cannotRespawn))return false;
  int id=e.GetInstanceID();EnemyEligibility entry;
  if(enemyEligibility.TryGetValue(id,out entry)&&entry.Enemy==e)return entry.NonBoss;
  // Ground-time checks run every frame; scan authored boss ancestry once, bounded.
  if(enemyEligibility.Count>=256)enemyEligibility.Clear();
  bool allowed=e.GetComponentInParent<global::END_Boss>()==null&&e.GetComponentInParent<global::LAB_ChimeraBoss>()==null&&e.GetComponentInParent<global::MED_MynahBoss>()==null;
  enemyEligibility[id]=new EnemyEligibility{Enemy=e,NonBoss=allowed};return allowed;
 }
 private static string IncineratedKey(global::EnemyController e){
  if(e==null||!e.gameObject.scene.IsValid())return null;
  string path=e.name;for(var t=e.transform.parent;t!=null;t=t.parent)path=t.name+"/"+path;
  return "SignalisVR:incinerated:"+e.gameObject.scene.name+":"+path;
 }
 private static bool WasIncinerated(global::EnemyController e){var key=IncineratedKey(e);return key!=null&&global::SProgress.GetBool(key,false);}
 private static void RetainIncineration(global::EnemyController __instance){
  if(!NonBossEnemy(__instance)||!WasIncinerated(__instance))return;
  __instance.permadeath=true;__instance.queuedForRespawn=false;
 }
 private static bool AllowEnemyReset(global::EnemyController __instance){RetainIncineration(__instance);return !NonBossEnemy(__instance)||!WasIncinerated(__instance)||(__instance.hitbox!=null&&__instance.hitbox.HP>0&&__instance.state!=global::EnemyController.enemystate.dead);}
 private static void RetainManagerIncineration(global::EnemyController __0){RetainIncineration(__0);}
 private static bool AllowManagerEnemyReset(global::EnemyController __0){return AllowEnemyReset(__0);}
 private static bool AllowEnemyWake(global::EnemyController __instance){
  RetainIncineration(__instance);
  // A living burning enemy keeps its AI. A dead incinerated enemy cannot revive.
  return !NonBossEnemy(__instance)||!WasIncinerated(__instance)||(__instance.hitbox!=null&&__instance.hitbox.HP>0&&__instance.state!=global::EnemyController.enemystate.dead);
 }
 private static void RecordIncineration(global::EnemyController e){
  if(!NonBossEnemy(e))return;var key=IncineratedKey(e);if(key==null)return;
  global::SProgress.SetBool(key,true);e.permadeath=true;e.queuedForRespawn=false;
 }
 private void InstallIncineration(HarmonyLib.Harmony h){
  h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),"Save",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(RetainIncineration)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),"Load",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(RetainIncineration)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),"TakeDamage",new[]{typeof(float),typeof(float),typeof(float),typeof(bool)}),postfix:new HarmonyMethod(typeof(Tracking),nameof(RetainIncineration)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),"ResetEnemy",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(AllowEnemyReset)),postfix:new HarmonyMethod(typeof(Tracking),nameof(RetainIncineration)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyManager),"ResetEnemy",new[]{typeof(global::EnemyController)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(AllowManagerEnemyReset)),postfix:new HarmonyMethod(typeof(Tracking),nameof(RetainManagerIncineration)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),"WakeUp",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(AllowEnemyWake)));
 }
}}


