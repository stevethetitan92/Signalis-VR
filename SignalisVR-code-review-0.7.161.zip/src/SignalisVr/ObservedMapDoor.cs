namespace SignalisVrTracking {public sealed partial class Tracking {
 private static void ObserveMapDoor(global::AutoTraverseDoor door,bool traversed){
  int state=traversed?1:ReadActualMapDoorState(door);
  ObserveMapDoorState(door,state);
 }
 private static void ObserveMapDoorState(global::AutoTraverseDoor door,int state){
  if(state==0)return;
  int revision=global::SProgress.GetInt("SignalisVR.Map.DoorRevision",0)+1;
  global::SProgress.SetInt("SignalisVR.Map.DoorRevision",revision);
  RememberSavedMapDoor(door,state,revision);
  var key=MapDoorHistory(door);if(key==null)return;
  global::SProgress.SetInt(key,1);
  global::SProgress.SetInt(key+":observedState",state);
  global::SProgress.SetInt(key+":revision",revision);
  string label=MapDoorRequiredKey(door);if(state==4&&!string.IsNullOrEmpty(label))global::SProgress.SetString(key+":keyName",label);
 }
 private static int ReadActualMapDoorState(global::AutoTraverseDoor traversal){
  if(traversal==null)return 0;
  var connection=traversal.connection;var physical=traversal.door;
  if(connection!=null){
   if((int)connection.minimapState==3)return 2;
   if(connection.locked||(physical!=null&&physical.locked))return connection.key!=null||connection.externalUnlocker?4:2;
   return 1;
  }
  return physical==null?0:physical.locked?2:1;
 }
}}
