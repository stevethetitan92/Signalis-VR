using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using MelonLoader;
using UnityEngine;

namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static Tracking questOwner;
  private HarmonyLib.Harmony questHarmony;
  private FieldInfo questFpModel,questFpSensitivity,questFpStrafeActive,questFpSpeed;
  private float questLastActivity=-100f;
  private bool questFpPatched;
  private int questAvailabilityFrame=-1;
  private bool questAvailabilityValue;
  private float questStereoPitch;
  private void InstallQuestFirstPerson() {
   questOwner=this;
   questHarmony=new HarmonyLib.Harmony("signalis.vr.quest.firstperson");
   if(questFpMod!=null) {
    var type=questFpMod.GetType();
    questFpModel=AccessTools.Field(type,"player_model");
    questFpSensitivity=AccessTools.Field(type,"mouse_sens");
    questFpStrafeActive=AccessTools.Field(type,"_x_input");
    questFpSpeed=AccessTools.Field(type,"_x_speed");
    var update=AccessTools.Method(type,"OnUpdate");
    var strafe=AccessTools.Method(type,"x_movement");
    var late=AccessTools.Method(type,"OnLateUpdate");
    if(update==null||strafe==null||late==null||questFpModel==null||questFpSensitivity==null)throw new InvalidOperationException("FPv2 input adapter fields/methods missing");
    var transpiler=new HarmonyMethod(typeof(Tracking),nameof(QuestFpTranspiler));
    questHarmony.Patch(update,transpiler:transpiler,prefix:new HarmonyMethod(typeof(Tracking),nameof(TraceFpBegin)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(TraceFpEnd)));
    questHarmony.Patch(strafe,transpiler:transpiler);
    if(questFpStrafeActive==null||questFpSpeed==null)throw new InvalidOperationException("FPv2 movement fields missing");
    questHarmony.Patch(strafe,prefix:new HarmonyMethod(typeof(Tracking),nameof(QuestUnifiedMovement)));
    questHarmony.Patch(late,transpiler:transpiler);
    var objects=AccessTools.Method(type,"find_objects",new[]{typeof(bool)});
    if(objects==null||objects.ReturnType!=typeof(bool[]))throw new InvalidOperationException("FPv2 object gate layout differs");
    questHarmony.Patch(objects,postfix:new HarmonyMethod(typeof(Tracking),nameof(QuestFpObjectGate)));
    questFpPatched=true;
   }
   questHarmony.Patch(AccessTools.Method(typeof(global::InputControl),"OnGUI"),prefix:new HarmonyMethod(typeof(Tracking),nameof(QuestInputModePrefix)));
   questHarmony.Patch(AccessTools.Method(typeof(global::InputControl),"isMouseKeyboard"),prefix:new HarmonyMethod(typeof(Tracking),nameof(QuestMouseModePrefix)));
   questHarmony.Patch(AccessTools.Method(typeof(global::InputControl),"isControlerInput"),prefix:new HarmonyMethod(typeof(Tracking),nameof(QuestControllerModePrefix)));
   // Unique native bodies audited against all dummy metadata; never patch folded getters.
   IntPtr gameBase=IntPtr.Zero;
   foreach(System.Diagnostics.ProcessModule module in System.Diagnostics.Process.GetCurrentProcess().Modules)
    if(string.Equals(module.ModuleName,"GameAssembly.dll",StringComparison.OrdinalIgnoreCase))gameBase=module.BaseAddress;
   if(gameBase==IntPtr.Zero ||
      QuestNativeAddress(typeof(global::CharacterAction),"NativeMethodInfoPtr_AnyInput_Public_Boolean_0").ToInt64()-gameBase.ToInt64()!=0xC674E0 ||
      QuestNativeAddress(typeof(global::CharacterAction),"NativeMethodInfoPtr_AnyInputUp_Public_Boolean_0").ToInt64()-gameBase.ToInt64()!=0xC67480)
    throw new InvalidOperationException("Title input layout differs from inspected build");
   questHarmony.Patch(AccessTools.Method(typeof(global::CharacterAction),"AnyInput"),postfix:new HarmonyMethod(typeof(Tracking),nameof(QuestAnyInputPostfix)));
   questHarmony.Patch(AccessTools.Method(typeof(global::CharacterAction),"AnyInputUp"),postfix:new HarmonyMethod(typeof(Tracking),nameof(QuestAnyInputUpPostfix)));
   InstallQuestPuzzleInput(gameBase);
   InstallSceneRecovery();
   InstallQuestMenus();
   InstallDoorMotorTrace();
   try{InstallMapDiscovery();}catch(Exception ex){MelonLogger.Warning("Map interaction tracking unavailable: "+ex.Message);}
   MelonLogger.Msg("QUEST FP ADAPTER: keyboard/mouse reads bridged in FPv2 only; active before and during stereo; patched="+questFpPatched);
  }
  // Replace input reads only inside the existing managed FPv2 mod. No global
  // Unity input patch, synthetic OS keystrokes, or installed mod file changes.
  private static IEnumerable<CodeInstruction> QuestFpTranspiler(IEnumerable<CodeInstruction> code,MethodBase __originalMethod) {
   int axes=0,keys=0,forces=0,headings=0,yaws=0,layouts=0;
   foreach(var instruction in code) {
    // Recover the user's view heading only AFTER the native door motor ends.
    // During traversal FPv2's cardinal yaw must reach the shared movement rig.
    if(instruction.opcode==OpCodes.Stfld&&questOwner!=null&&
       instruction.operand as FieldInfo==questOwner.questFpYaw) {
     instruction.opcode=OpCodes.Call;
     instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpStoreYaw));yaws++;
    }
    var ctor=instruction.operand as ConstructorInfo;
    if(instruction.opcode==OpCodes.Newobj&&ctor!=null&&ctor.DeclaringType==typeof(System.IO.StreamReader)
       &&ctor.GetParameters().Length==1&&ctor.GetParameters()[0].ParameterType==typeof(string)) {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(OpenFpSettings));
    }
    var method=instruction.operand as MethodInfo;
    if(__originalMethod.Name=="OnUpdate"&&method!=null&&method.DeclaringType==typeof(Transform)&&method.Name=="get_childCount") {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpLayoutCount));layouts++;
    }else if(method!=null&&method.DeclaringType==typeof(GameObject)&&(method.Name=="Find"||method.Name=="FindGameObjectsWithTag")) {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),method.Name=="Find"?nameof(TraceFindObject):nameof(TraceFindTaggedObjects));
    }else if(method!=null&&method.DeclaringType==typeof(Input)) {
     if(method.Name=="GetAxis"&&method.GetParameters().Length==1) {
      instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpAxis));axes++;
     }else if(method.Name=="GetKey"&&method.GetParameters().Length==1&&method.GetParameters()[0].ParameterType==typeof(KeyCode)) {
      instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpKey));keys++;
     }
    }else if(method!=null&&method.DeclaringType==typeof(Rigidbody)&&method.Name=="AddForce"&&method.GetParameters().Length==1&&method.GetParameters()[0].ParameterType==typeof(Vector3)) {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpForce));forces++;
    }else if(method!=null&&method.DeclaringType==typeof(global::AlternatePlayerController)&&method.Name=="set_fAngle") {
     instruction.opcode=OpCodes.Call;instruction.operand=AccessTools.Method(typeof(Tracking),nameof(QuestFpSetHeading));headings++;
    }
    yield return instruction;
   }
   if(__originalMethod.Name=="OnUpdate"&&(axes!=4||keys!=1))throw new InvalidOperationException("Unexpected FPv2 update inputs");
   if(__originalMethod.Name=="OnUpdate"&&yaws!=6)throw new InvalidOperationException("Unexpected FPv2 door yaw layout");
   if(__originalMethod.Name=="OnUpdate"&&layouts!=1)throw new InvalidOperationException("Unexpected FPv2 player layout gate");
   if(__originalMethod.Name=="x_movement"&&(keys!=2||forces!=2))throw new InvalidOperationException("Unexpected FPv2 strafe inputs");
   if(__originalMethod.Name=="OnLateUpdate"&&headings!=1)throw new InvalidOperationException("Unexpected FPv2 strafe heading layout");
   MelonLogger.Msg("QUEST FP PATCH: "+__originalMethod.Name+" axes="+axes+" keys="+keys+" forces="+forces+" headings="+headings);
  }
  private static void QuestAnyInputPostfix(ref bool __result) {
   var q=questOwner;
   if(q!=null && q.questNativeAvailable && System.Threading.Thread.CurrentThread.ManagedThreadId==q.questNativeThread && q.QuestAvailableNow())
    __result=__result||q.questFrame.buttons!=0;
  }
  private static void QuestAnyInputUpPostfix(ref bool __result) {
   var q=questOwner;
   if(q!=null && q.questNativeAvailable && System.Threading.Thread.CurrentThread.ManagedThreadId==q.questNativeThread && q.QuestAvailableNow())
    __result=__result||q.questNativeEdges.Up!=0;
  }
  private bool QuestAvailableNow() {
   if(!questPolicy.Armed||questFailed||questInputStopped||stopping||system==null)return false;
   if(questAvailabilityFrame!=Time.frameCount) {
    questAvailabilityValue=QuestHasSceneFocus()&&system.IsInputAvailable()&&(Valve.VR.OpenVR.Overlay==null||!Valve.VR.OpenVR.Overlay.IsDashboardVisible());
    questAvailabilityFrame=Time.frameCount;
   }
   return questAvailabilityValue;
  }
  private bool QuestFirstPersonReady() {
   if(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name=="PEN_Hole")return false;
   if(!questFpPatched||!QuestAvailableNow()||questFpPlayer==null||questFpModel==null||pauseMenuVisible||bookScreenVisible||dialogueScreenVisible)return false;
   var player=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
   var model=questFpModel.GetValue(questFpMod) as GameObject;
   // Same FPv2 model-layout/playing guard used by its own OnUpdate.
   return player!=null&&player.playing&&!player.traversing&&model!=null;
  }
  private void RecordQuestActivity() {
   if(!questPolicy.Armed){questLastActivity=-100f;return;}
   if(questFrame.buttons!=0||questFrame.moveX!=0||questFrame.moveY!=0||questFrame.lookX!=0||questFrame.lookY!=0)questLastActivity=Time.realtimeSinceStartup;
  }
  private static bool DesktopMovementKeys(){return Input.GetKey(KeyCode.W)||Input.GetKey(KeyCode.S)||Input.GetKey(KeyCode.A)||Input.GetKey(KeyCode.D)||Input.GetKey(KeyCode.UpArrow)||Input.GetKey(KeyCode.DownArrow)||Input.GetKey(KeyCode.LeftArrow)||Input.GetKey(KeyCode.RightArrow);}
  private bool QuestOwnsInputMode() {return !DesktopMovementKeys()&&QuestAvailableNow()&&(QuestMenuControl()||questLastActivity>=0f);}
  private void UpdateQuestInputMode() {
   if(DesktopMovementKeys()){questLastActivity=-100f;global::InputControl.usingController=false;return;}
   if(QuestOwnsInputMode())global::InputControl.usingController=true;
  }
  private static bool QuestInputModePrefix(global::InputControl __instance) {
   if(questOwner==null)return true;
   var ev=Event.current;
   if(!questOwner.QuestMenuControl()&&ev!=null&&ev.type==EventType.KeyDown&&ev.isKey) {
    questOwner.questLastActivity=-100f;
    return true;
   }
   if(!questOwner.QuestOwnsInputMode())return true;
   global::InputControl.usingController=true;
   __instance.m_State=global::InputControl.eInputState.Controler;
   // Do not let the original mouse detector notify map/UI consumers before
   // controller mode is restored. A real keyboard event above releases control.
   return false;
  }
  private static bool QuestMouseModePrefix(ref bool __result) {
   if(questOwner==null||!questOwner.QuestOwnsInputMode())return true;
   __result=false;return false;
  }
  private static bool QuestControllerModePrefix(ref bool __result) {
   if(questOwner==null||!questOwner.QuestOwnsInputMode())return true;
   __result=true;return false;
  }
  private static float QuestFpAxis(string name) {
   var q=questOwner;
   if(name=="Mouse X"||name=="Mouse Y") {
    float physical=Input.GetAxis(name);
    if(name=="Mouse Y"||q==null||q.QuestLookBlocker(false)!=null)return physical;
    float sensitivity=(float)q.questFpSensitivity.GetValue(q.questFpMod);
    float axis=QuestInputPolicy.LookAxis(name=="Mouse X"?q.questFrame.lookX:q.questFrame.lookY,Time.unscaledDeltaTime,sensitivity);
    axis*=QuestInputPolicy.TurnMultiplier(q.modTurnSpeed);
    q.QuestLookConsumed("first-person "+name);
    if(name=="Mouse Y"&&q.stereo)q.questStereoPitch=Mathf.Clamp(q.questStereoPitch+axis*sensitivity,-60f,60f);
    return physical+axis;
   }
   if(q!=null&&q.DoorCameraBlocked())return 0f;
   if(q==null||!q.QuestFirstPersonReady())return Input.GetAxis(name);
   if(name=="Horizontal")return Mathf.Clamp(Input.GetAxis(name)+q.questFrame.moveX,-1f,1f);
   if(name=="Vertical")return Mathf.Clamp(Input.GetAxis(name)+q.questFrame.moveY,-1f,1f);
   return Input.GetAxis(name);
  }
  private static bool QuestFpKey(KeyCode key) {
   if(Input.GetKey(key))return true;
   var q=questOwner;if(q==null||!q.QuestFirstPersonReady())return false;
   if(key==KeyCode.A)return q.questFrame.moveX<0;
   if(key==KeyCode.D)return q.questFrame.moveX>0;
   if(key==KeyCode.LeftShift)return (q.questFrame.buttons&(1<<4))!=0;
   return false;
  }
  private static void QuestFpForce(Rigidbody body,Vector3 force) {
   var q=questOwner;
   if(q!=null&&q.QuestFirstPersonReady()&&!Input.GetKey(KeyCode.A)&&!Input.GetKey(KeyCode.D))force*=QuestInputPolicy.StrafeScale(q.questFrame.moveX,Time.deltaTime,Time.fixedDeltaTime);
   body.AddForce(force);
  }
  private static void QuestFpSetHeading(global::AlternatePlayerController player,float original) {
   var q=questOwner;
   if(q!=null&&q.QuestFirstPersonReady()&&q.questFrame.moveX!=0&&!Input.GetKey(KeyCode.A)&&!Input.GetKey(KeyCode.D)) {
    var model=q.questFpModel.GetValue(q.questFpMod) as GameObject;
    if(model!=null)original=(float)q.questFpYaw.GetValue(q.questFpMod);
   }
   // FPv2 supplies Quaternion.y here. Only Quest strafe substitutes degrees;
   // physical keyboard behavior remains under the original mod's control.
   player.fAngle=original;
  }
  private bool QuestUnifiedReady() {
   return active&&stereo&&submitted&&!snowWalkStereo&&!DoorCameraBlocked()&&!recovery.Paused&&camera!=null&&QuestFirstPersonReady()
    &&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput;
  }
  private static bool QuestUnifiedMovement() {
   var q=questOwner;
   if(q!=null&&q.DoorCameraBlocked())return false;
   if(q==null||!q.QuestUnifiedReady())return true;
   // Keyboard movement retains the original mod. Quest movement uses one
   // floor direction through one force path for every stick angle.
   if(Input.GetKey(KeyCode.W)||Input.GetKey(KeyCode.S)||Input.GetKey(KeyCode.A)||Input.GetKey(KeyCode.D))return true;
   q.questFpStrafeActive.SetValue(q.questFpMod,false);
   var model=q.questFpModel.GetValue(q.questFpMod) as GameObject;
   var body=model==null?null:model.GetComponent<Rigidbody>();
   if(body==null)return true;
   Vector3 direction,sideDirection;float nativeForward;
   if(!q.QuestMovementComponents(model,out direction,out sideDirection,out nativeForward))return false;
   float speed=(float)q.questFpSpeed.GetValue(q.questFpMod);
   // One continuous vector drives every angle with the uniform tuning gain.
   // No independent native forward response or extra delta/fixedDelta attenuation.
   float gain=MovementMath.ForceGain((q.questFrame.buttons&(1<<4))!=0);

   body.AddForce(direction*speed*1.3f*gain);
   q.ObserveQuestMovement(body,model.transform.up,direction,speed,direction.magnitude*gain);
   return false;
  }
  private int movementBasisFrame=-1,movementBasisModel;
  private bool movementBasisValid;
  private Vector3 movementBasisDirection,movementBasisSide;
  private float movementBasisForward;
  private bool QuestMovementComponents(GameObject model,out Vector3 direction,out Vector3 sideDirection,out float forwardAmount) {
   int frame=Time.frameCount,id=model.GetInstanceID();
   if(movementBasisFrame!=frame||movementBasisModel!=id) {
    movementBasisValid=ComputeQuestMovementComponents(model,out movementBasisDirection,out movementBasisSide,out movementBasisForward);
    movementBasisFrame=frame;movementBasisModel=id;
   }
   direction=movementBasisDirection;sideDirection=movementBasisSide;forwardAmount=movementBasisForward;
   return movementBasisValid;
  }
  private static void QuestFpStoreYaw(object mod,float proposed) {
   var q=questOwner;
   if(q==null||q.questFpYaw==null)throw new InvalidOperationException("FPv2 yaw adapter unavailable");
   if(q.DoorCameraBlocked()&&q.DoorNativeTraversing())q.doorYaw=proposed;
   q.questFpYaw.SetValue(mod,q.DoorCameraBlocked()&&!q.DoorNativeTraversing()?q.doorYaw:proposed);
  }
  private bool ComputeQuestMovementComponents(GameObject model,out Vector3 direction,out Vector3 sideDirection,out float forwardAmount) {
   direction=sideDirection=Vector3.zero;forwardAmount=0;
   var up=model.transform.up;var view=stereoRotation*Vector3.forward;
   float dx,dy,dz;
   if(!MovementMath.Direction(up.x,up.y,up.z,view.x,view.y,view.z,questFrame.moveX,questFrame.moveY,out dx,out dy,out dz)) {
    view=model.transform.forward;
    if(!MovementMath.Direction(up.x,up.y,up.z,view.x,view.y,view.z,questFrame.moveX,questFrame.moveY,out dx,out dy,out dz))return false;
   }
   direction=new Vector3(dx,dy,dz);var f=model.transform.forward;float side;
   if(!MovementMath.Split(up.x,up.y,up.z,f.x,f.y,f.z,dx,dy,dz,out forwardAmount,out side))return false;
   float rx,ry,rz;
   if(!MovementMath.Direction(up.x,up.y,up.z,f.x,f.y,f.z,1,0,out rx,out ry,out rz))return false;
   sideDirection=new Vector3(rx,ry,rz)*side;return true;
  }
  // Bounded one-line/second movement evidence. No physics writes or global searches.
  private float movementWindowStart=-1f,movementForceSum,movementStickSum,movementDeltaSum;
  private int movementCalls,movementSprintCalls,movementReports,movementBodyId;
  private Vector3 movementStartPosition;
  private void ObserveQuestMovement(Rigidbody body,Vector3 up,Vector3 direction,float speed,float scale) {
   if(movementReports>=120)return;
   try {
    float now=Time.realtimeSinceStartup;
    int id=body.GetInstanceID();
    if(movementWindowStart<0f || movementBodyId!=id || now-movementWindowStart>2f) {
     movementWindowStart=now;movementBodyId=id;movementStartPosition=body.position;
     movementCalls=movementSprintCalls=0;movementForceSum=movementStickSum=movementDeltaSum=0f;
    }
    movementCalls++;if((questFrame.buttons&(1<<4))!=0)movementSprintCalls++;
    movementForceSum+=speed*1.3f*scale;
    movementStickSum+=direction.magnitude;movementDeltaSum+=Time.deltaTime;
    float elapsed=now-movementWindowStart;if(elapsed<1f)return;
    if(movementStickSum<=.001f){movementWindowStart=-1f;return;}
    var normal=up.normalized;
    var velocity=body.velocity;velocity-=normal*Vector3.Dot(velocity,normal);
    var displacement=body.position-movementStartPosition;displacement-=normal*Vector3.Dot(displacement,normal);
    MelonLogger.Msg("QUEST MOTION: calls="+movementCalls+" seconds="+elapsed.ToString("F3")
     +" stickAvg="+(movementStickSum/movementCalls).ToString("F3")+" sprintCalls="+movementSprintCalls
     +" speedSetting="+speed.ToString("F1")+" vectorForcePerSecond="+(movementForceSum/elapsed).ToString("F1")
     +" planarVelocity="+velocity.magnitude.ToString("F3")+" netDistance="+displacement.magnitude.ToString("F3")
     +" mass="+body.mass.ToString("F2")+" drag="+body.drag.ToString("F2")
     +" deltaSum="+movementDeltaSum.ToString("F3")+" fixedDelta="+Time.fixedDeltaTime.ToString("F4")
     +" timeScale="+Time.timeScale.ToString("F2")+" frame="+Time.frameCount);
    movementReports++;movementWindowStart=-1f;
   }catch(Exception ex){movementReports=120;MelonLogger.Warning("Movement observation stopped: "+ex.Message);}
  }
  private static void TraceFpBegin(out long __state){__state=System.Diagnostics.Stopwatch.GetTimestamp();if(questOwner!=null)questOwner.ObserveDoorCamera();}
  private static Exception TraceFpEnd(Exception __exception,long __state){if(questOwner!=null){
   if(questOwner.DoorCameraBlocked()&&!questOwner.DoorNativeTraversing())questOwner.questFpYaw.SetValue(questOwner.questFpMod,questOwner.doorYaw);
   questOwner.TraceOperation(30,__state);
  }return __exception;}
  private static GameObject TraceFindObject(string name) {
   long started=System.Diagnostics.Stopwatch.GetTimestamp();
   try{return GameObject.Find(name);}finally{if(questOwner!=null)questOwner.TraceOperation(31,started);}
  }
  private static UnhollowerBaseLib.Il2CppReferenceArray<GameObject> TraceFindTaggedObjects(string tag) {
   long started=System.Diagnostics.Stopwatch.GetTimestamp();
   try{return GameObject.FindGameObjectsWithTag(tag);}finally{if(questOwner!=null)questOwner.TraceOperation(32,started);}
  }
  private static string fpSettingsPath;
  private static byte[] fpSettingsBytes;
  private static DateTime fpSettingsStamp,fpSettingsCheck;
  private static System.IO.StreamReader OpenFpSettings(string path) {
   var now=DateTime.UtcNow;
   if(fpSettingsBytes==null||fpSettingsPath!=path||now>=fpSettingsCheck) {
    long checkStarted=System.Diagnostics.Stopwatch.GetTimestamp();
      var stamp=System.IO.File.GetLastWriteTimeUtc(path);
    if(fpSettingsBytes==null||fpSettingsPath!=path||stamp!=fpSettingsStamp) {
     fpSettingsBytes=System.IO.File.ReadAllBytes(path);fpSettingsStamp=stamp;fpSettingsPath=path;
    }
    fpSettingsCheck=now.AddSeconds(1);
      if(questOwner!=null)questOwner.TraceOperation(23,checkStarted);
   }
   return new System.IO.StreamReader(new System.IO.MemoryStream(fpSettingsBytes,false));
  }
 }
}












