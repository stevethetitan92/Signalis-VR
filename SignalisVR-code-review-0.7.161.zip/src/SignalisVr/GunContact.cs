using System;
using UnityEngine;
using UnhollowerBaseLib;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Vector3 gunContactOffset,gunContactRawPosition,gunContactPrevious;
 private Quaternion gunContactPreviousRotation;
 private string gunContactKind;
 private int gunContactFrame=-1;
 private bool gunContactSampled;
 private void EnsureContactProbe(){
  if(shoveProbe!=null)return;
  var g=new GameObject("SignalisVR_HandContactProbe");g.layer=2;UnityEngine.Object.DontDestroyOnLoad(g);
  shoveProbe=g.AddComponent<SphereCollider>();shoveProbe.enabled=false;
  shoveHits=new Il2CppStructArray<RaycastHit>(32);shoveOverlaps=new Il2CppReferenceArray<Collider>(32);
 }
 private bool PhysicalContactReady(){return !stopping&&!shoveFailed&&ProdVrMode()&&controllerMotionEnabled&&questAvailabilityValue&&WeaponGameplayReady()
  &&!RadioStationActive()&&!questMenuScene&&!modMenuOpen&&!pauseMenuVisible&&!quickSelect.Open&&!bookScreenVisible&&!dialogueScreenVisible
  &&!global::PlayerState.paused&&!global::PlayerState.cutscene&&!global::PlayerState.eventScreen&&!global::PlayerState.suspendInput&&global::PlayerState.hp>0;}
 private Vector3 BlockContactPoint(Vector3 start,Vector3 desired,float radius,bool sweep){
  var point=desired;var delta=desired-start;
  if(sweep&&delta.sqrMagnitude>1e-10f){
   int n=Physics.SphereCastNonAlloc(start,radius,delta.normalized,shoveHits,delta.magnitude,-1,QueryTriggerInteraction.Collide);
   if(n==32)return start;
   float nearest=delta.magnitude;bool blocked=false;
   for(int i=0;i<n;i++){global::EnemyController enemy;var hit=shoveHits[i];if(ShoveObstacle(hit.collider,out enemy)&&hit.distance<=nearest){nearest=hit.distance;blocked=true;}}
   if(blocked)point=start+delta.normalized*Math.Max(0,nearest-.002f*UnitsPerMetre);
  }
  shoveProbe.radius=radius;
  for(int pass=0;pass<3;pass++){
   int n=Physics.OverlapSphereNonAlloc(point,radius,shoveOverlaps,-1,QueryTriggerInteraction.Collide);if(n==32)return start;
   bool moved=false;
   for(int i=0;i<n;i++){var c=shoveOverlaps[i];global::EnemyController enemy;if(!ShoveObstacle(c,out enemy))continue;Vector3 direction;float depth;
    if(Physics.ComputePenetration(shoveProbe,point,Quaternion.identity,c,c.transform.position,c.transform.rotation,out direction,out depth)){point+=direction*(depth+.002f*UnitsPerMetre);moved=true;}}
   if(!moved)break;
  }
  return point;
 }
 private void ResolvePhysicalGunContact(){
  gunContactRawPosition=rightWeaponPosition;
  if(!PhysicalContactReady()||!PhysicalShoveGun()){gunContactSampled=false;gunContactFrame=-1;gunContactOffset=Vector3.zero;return;}
  if(gunContactFrame==Time.frameCount){rightWeaponPosition+=gunContactOffset;return;}
  try{
   EnsureContactProbe();Vector3 muzzle;if(!ImportedMuzzle(out muzzle))muzzle=Vector3.forward*.3f;
   string kind=WeaponFamily(global::InventoryManager.EquippedWeapon.parentItem._item.ToString());
   bool sweep=gunContactSampled&&gunContactKind==kind&&(rightWeaponPosition-gunContactPrevious).sqrMagnitude<UnitsPerMetre*UnitsPerMetre;
   var raw=rightWeaponPosition;var resolved=raw;
   // Translate the whole gun and its authored gripping hand together. Never
   // change saved grip offsets, model scale, recoil, aim rotation or reload parts.
   for(int pass=0;pass<3;pass++){var before=resolved;for(int i=0;i<5;i++){
    Vector3 local=i<3?muzzle*(i*.5f):new Vector3(0,i==3?-.07f:.035f,0);
    var desired=resolved+rightWeaponRotation*local*UnitsPerMetre;
    var start=sweep?gunContactPrevious+gunContactPreviousRotation*local*UnitsPerMetre:desired;
    resolved+=BlockContactPoint(start,desired,.055f*UnitsPerMetre,sweep&&pass==0)-desired;
   }if((resolved-before).sqrMagnitude<1e-10f)break;}
   gunContactOffset=resolved-raw;rightWeaponPosition=resolved;gunContactFrame=Time.frameCount;
   gunContactPrevious=resolved;gunContactPreviousRotation=rightWeaponRotation;gunContactKind=kind;gunContactSampled=true;
  }catch(Exception ex){gunContactOffset=Vector3.zero;gunContactSampled=false;shoveFailed=true;MelonLoader.MelonLogger.Warning("Gun contact fallback: "+ex.Message);}
 }
}}
