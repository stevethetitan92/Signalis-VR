using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Mesh rifleRoundTipMesh;
  private Mesh RifleRoundTipMesh(){
   if(rifleRoundTipMesh!=null)return rifleRoundTipMesh;
   var v=new List<Vector3>();var t=new List<int>();const int sides=12,rings=4;
   for(int ring=0;ring<rings;ring++){
    float a=ring*(float)Math.PI/(2*rings),radius=.5f*Mathf.Cos(a),y=-.5f+Mathf.Sin(a);
    for(int i=0;i<sides;i++){float b=i*(float)Math.PI*2/sides;v.Add(new Vector3(radius*Mathf.Cos(b),y,radius*Mathf.Sin(b)));}
   }
   for(int ring=0;ring<rings-1;ring++)for(int i=0;i<sides;i++){int a=ring*sides+i,b=ring*sides+(i+1)%sides,c=a+sides,d=b+sides;t.AddRange(new[]{a,c,b,b,c,d});}
   int apex=v.Count;v.Add(new Vector3(0,.5f,0));int bottom=v.Count;v.Add(new Vector3(0,-.5f,0));
   for(int i=0;i<sides;i++){t.AddRange(new[]{(rings-1)*sides+i,apex,(rings-1)*sides+(i+1)%sides,bottom,i,(i+1)%sides});}
   rifleRoundTipMesh=new Mesh();rifleRoundTipMesh.name="RoundedRifleBulletTip";rifleRoundTipMesh.vertices=v.ToArray();rifleRoundTipMesh.triangles=HandSurfaceTopology.DoubleSided(t.ToArray());rifleRoundTipMesh.RecalculateNormals();rifleRoundTipMesh.RecalculateBounds();return rifleRoundTipMesh;
  }
 }
}
