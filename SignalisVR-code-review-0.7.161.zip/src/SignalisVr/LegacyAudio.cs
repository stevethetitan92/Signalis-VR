using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 // Rollback: native FMOD events/listener are not intercepted or spatialized.
 private Vector3 AudioRelative(Vector3 point){return Vector3.zero;}
 private Vector3 GunAudioPoint(){return rightWeaponPosition;}
 private void PlayPackAt(PackAudio clip,Vector3 unused,float volume){clip.Play(volume,false);}
}}
