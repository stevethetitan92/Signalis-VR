using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class MenuEyeScope {
  internal global::EyeBallManager eye;
  internal Transform cursor,idle;
  internal bool tracking;
  internal void Restore(){if(eye==null)return;eye.Cursor=cursor;eye.DefaultLookPoint=idle;eye.tracking=tracking;}
 }
 private static void MenuEyeBegin(global::EyeBallManager __instance,out MenuEyeScope __state){
  __state=null;
  if(__instance==null||__instance.menu==null||!__instance.menu.isActiveAndEnabled)return;
  var selected=__instance.menu.current;
  if(selected==null||!selected.isActiveAndEnabled)return;
  __state=new MenuEyeScope{eye=__instance,cursor=__instance.Cursor,idle=__instance.DefaultLookPoint,tracking=__instance.tracking};
  // Native Update has separate mouse/controller branches. Both now target the
  // selected option while retaining its smoothing, blinking and pupil animation.
  __instance.Cursor=selected.transform;__instance.DefaultLookPoint=selected.transform;__instance.tracking=true;
 }
 private static Exception MenuEyeEnd(Exception __exception,MenuEyeScope __state){if(__state!=null)__state.Restore();return __exception;}
}}
