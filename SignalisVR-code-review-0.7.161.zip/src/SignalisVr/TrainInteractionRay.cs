using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private struct TrainRayState {public Camera camera;public Vector3 position;public Quaternion rotation;public Vector2 cursor;}
 private bool TrainWalkingRayReady(global::EventScreen3DCam control){
  if(!EventViewCursorActive()||!QuestAvailableNow()||!questPolicy.RightArmed||control==null||control.cam!=camera)return false;
  var w=eventWalker;
  if(w==null||!w.isActiveAndEnabled||w.point==null||!w.point._active||w.point._camera!=control||control.path==null||control.depth<0||control.depth>=control.path.Count||control.path[control.depth]!=w.point)return false;
  var origin=w.transform.parent;
  return origin!=null&&origin.name=="CameraOrigin"&&origin.parent!=null&&(origin.parent.name=="MED_TrainEvent"||origin.parent.name=="ROT_School");
 }
 private static void TrainInteractionRay(global::EventScreen3DCam __instance,out TrainRayState __state){
  __state=default(TrainRayState);
  SnowInteractionCursor(__instance);
  var q=questOwner;
  if(q==null||!q.questNativeAvailable||System.Threading.Thread.CurrentThread.ManagedThreadId!=q.questNativeThread||!q.TrainWalkingRayReady(__instance))return;
  var c=__instance.cam;
  __state=new TrainRayState{camera=c,position=c.transform.position,rotation=c.transform.rotation,cursor=global::EventScreen3DCam.cursorPosition};
  // Only the native selection ray uses the current cyclopean pose. Native
  // hit testing, range, interaction availability and A-button trigger remain.
  c.transform.SetPositionAndRotation(q.stereoPosition,q.stereoRotation);
  global::EventScreen3DCam.cursorPosition=new Vector2(.5f,.5f);
 }
 private static Exception RestoreTrainInteractionRay(Exception __exception,TrainRayState __state){
  if(__state.camera!=null){__state.camera.transform.SetPositionAndRotation(__state.position,__state.rotation);global::EventScreen3DCam.cursorPosition=__state.cursor;}
  return __exception;
 }
}}

