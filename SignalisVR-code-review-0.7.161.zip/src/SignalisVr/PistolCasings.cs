using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class PistolCase {internal MeshRenderer Renderer;internal Vector3 Origin,Velocity;internal Quaternion Rotation;internal float Born=-100;}
 private readonly PistolCase[] pistolCases=new PistolCase[12];
 private Mesh pistolCaseMesh;private Material pistolCaseMaterial;private GameObject pistolCaseRoot;private int pistolCaseNext;private bool pistolCaseFailed;
 private bool flareCasePending;private string flareShotAppearance="FlareGun",flareSpentAppearance;
 private Mesh flareSpentMesh;private Material flareSpentMaterial,flareSpentInside;
 private void EnsureFlareSpentCase(){
  if(flareSpentMesh!=null&&flareSpentAppearance==flareShotAppearance)return;
  if(flareSpentMesh!=null){HidePistolCases();foreach(var c in pistolCases)if(c!=null)c.Born=-100;UnityEngine.Object.Destroy(flareSpentMesh);UnityEngine.Object.Destroy(flareSpentMaterial);UnityEngine.Object.Destroy(flareSpentInside);}
  flareSpentAppearance=flareShotAppearance;
  var round=GetHdRound(flareShotAppearance=="Grenade"?"Grenade":"FlareRound");var source=round.Mesh;var vertices=new List<Vector3>(source.vertices);var uv=new List<Vector2>(source.uv);
  var outside=new List<int>();var all=source.GetTriangles(0);
  for(int i=0;i<all.Length;i+=3){if(vertices[all[i]].y>(flareSpentAppearance=="Grenade"?-.0011f:.034f)&&vertices[all[i+1]].y>(flareSpentAppearance=="Grenade"?-.0011f:.034f)&&vertices[all[i+2]].y>(flareSpentAppearance=="Grenade"?-.0011f:.034f))continue;outside.Add(all[i]);outside.Add(all[i+1]);outside.Add(all[i+2]);}
  // Retain the current round's textured casing and rim, remove the sealed cap,
  // and add a recessed dark interior instead of ejecting an enlarged pistol case.
  var inside=new List<int>();int start=vertices.Count;
  for(int ring=0;ring<2;ring++)for(int i=0;i<24;i++){float angle=i*(float)Math.PI/12;vertices.Add(new Vector3((float)Math.Cos(angle)*.0088f,ring==0?(flareSpentAppearance=="Grenade"?-.001f:.0342f):(flareSpentAppearance=="Grenade"?-.02f:.016f),(float)Math.Sin(angle)*.0088f));uv.Add(Vector2.zero);}
  for(int i=0;i<24;i++){int j=(i+1)%24;inside.AddRange(new[]{start+i,start+j,start+24+j,start+i,start+24+j,start+24+i});}
  int center=vertices.Count;vertices.Add(new Vector3(0,flareSpentAppearance=="Grenade"?-.02f:.016f,0));uv.Add(Vector2.zero);for(int i=0;i<24;i++)inside.AddRange(new[]{center,start+24+i,start+24+(i+1)%24});
  flareSpentMesh=new Mesh();flareSpentMesh.vertices=vertices.ToArray();flareSpentMesh.uv=uv.ToArray();flareSpentMesh.subMeshCount=2;flareSpentMesh.SetTriangles(outside.ToArray(),0);flareSpentMesh.SetTriangles(HandSurfaceTopology.DoubleSided(inside.ToArray()),1);flareSpentMesh.RecalculateBounds();
  flareSpentMaterial=new Material(Shader.Find("Unlit/Texture"));flareSpentMaterial.mainTexture=round.Materials[0].mainTexture;
  flareSpentInside=new Material(Shader.Find("Unlit/Color"));flareSpentInside.color=new Color(.045f,.035f,.025f);
 }

 private PistolCase flareSmokeCase;
 private readonly MeshRenderer[] flareCaseSmoke=new MeshRenderer[6];
 private Mesh flareCaseSmokeMesh;private Material flareCaseSmokeMaterial;private Texture2D flareCaseSmokeTexture;private MaterialPropertyBlock flareCaseSmokeColor;private bool flareCaseSmokeFailed;
 private void ShowFlareCaseSmoke(){
  if(flareCaseSmokeFailed||flareSmokeCase==null)return;
  float elapsed=Time.realtimeSinceStartup-flareSmokeCase.Born;if(elapsed<0||elapsed>1.15f)return;
  try{
   if(flareCaseSmokeMesh==null){
    var shader=Shader.Find("Sprites/Default");if(shader==null)return;
    flareCaseSmokeTexture=HdFxTexture("fx-smoke.png");flareCaseSmokeMaterial=new Material(shader);flareCaseSmokeMaterial.mainTexture=flareCaseSmokeTexture;flareCaseSmokeColor=new MaterialPropertyBlock();
    flareCaseSmokeMesh=new Mesh();flareCaseSmokeMesh.vertices=new[]{new Vector3(-.5f,-.5f,0),new Vector3(.5f,-.5f,0),new Vector3(.5f,.5f,0),new Vector3(-.5f,.5f,0)};flareCaseSmokeMesh.uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(1,1),new Vector2(0,1)};flareCaseSmokeMesh.colors=new[]{Color.white,Color.white,Color.white,Color.white};flareCaseSmokeMesh.triangles=new[]{0,1,2,0,2,3};flareCaseSmokeMesh.RecalculateBounds();
    for(int i=0;i<flareCaseSmoke.Length;i++)flareCaseSmoke[i]=CreateControllerPart(pistolCaseRoot,flareCaseSmokeMesh,flareCaseSmokeMaterial,"Flare spent case smoke",Vector3.zero,Vector3.one);
   }
   for(int i=0;i<flareCaseSmoke.Length;i++){
    float emitted=i*.1f,age=elapsed-emitted;if(age<0||age>.65f)continue;
    var c=flareSmokeCase;var up=controllerTrackingToWorld*Vector3.up;var r=flareCaseSmoke[i];
    r.transform.position=c.Origin+c.Velocity*emitted-up*(4.905f*emitted*emitted*UnitsPerMetre)+up*(age*.06f*UnitsPerMetre);
    r.transform.rotation=stereoRotation*Quaternion.AngleAxis(i*61,Vector3.forward);r.transform.localScale=Vector3.one*((.009f+.025f*age)*UnitsPerMetre);
    flareCaseSmokeColor.SetColor("_Color",new Color(.8f,.8f,.8f,.3f*(1-age/.65f)));r.SetPropertyBlock(flareCaseSmokeColor);r.enabled=true;
   }
  }catch(Exception e){flareCaseSmokeFailed=true;foreach(var r in flareCaseSmoke)if(r!=null)r.enabled=false;MelonLoader.MelonLogger.Warning("Flare case smoke unavailable: "+e.Message);}
 }
 private void DestroyFlareCaseSmoke(){foreach(var r in flareCaseSmoke)if(r!=null)UnityEngine.Object.Destroy(r.gameObject);Array.Clear(flareCaseSmoke,0,flareCaseSmoke.Length);if(flareCaseSmokeMesh!=null)UnityEngine.Object.Destroy(flareCaseSmokeMesh);if(flareCaseSmokeMaterial!=null)UnityEngine.Object.Destroy(flareCaseSmokeMaterial);if(flareCaseSmokeTexture!=null)UnityEngine.Object.Destroy(flareCaseSmokeTexture);flareCaseSmokeMesh=null;flareCaseSmokeMaterial=null;flareCaseSmokeTexture=null;flareSmokeCase=null;flareCaseSmokeFailed=false;}

 private void EjectFlareCase(){if(!flareCasePending)return;flareCasePending=false;EmitPistolCase(true);}
 private static class PistolCaseHook {
  internal static void Begin(out int __state){var q=weaponOwner;var w=global::InventoryManager.EquippedWeapon;__state=q!=null&&q.ControllerWeaponReady()&&w!=null&&w.parentItem!=null&&w.parentItem._item==global::Items.itemlist.Pistol?w.magAmmo:-1;}
  internal static void End(int __state){var w=global::InventoryManager.EquippedWeapon;if(weaponOwner!=null&&w!=null&&w.parentItem!=null&&w.parentItem._item==global::Items.itemlist.Pistol&&__state>0&&w.magAmmo<__state)weaponOwner.EmitPistolCase();}
 }
 private void InstallPistolCasings(HarmonyLib.Harmony h){var end=new HarmonyMethod(typeof(PistolCaseHook),nameof(PistolCaseHook.End));end.priority=HarmonyLib.Priority.First;h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"RaycastShot",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(PistolCaseHook),nameof(PistolCaseHook.Begin)),postfix:end);}
 private void EmitPistolCase(){
  EmitPistolCase(false);
 }
 private void EmitPistolCase(bool flare){
  if(pistolCaseFailed)return;
  try{
   if(flare)EnsureFlareSpentCase();
   if(pistolCaseRoot==null){
    pistolCaseRoot=new GameObject("SignalisVR_PistolCases");UnityEngine.Object.DontDestroyOnLoad(pistolCaseRoot);
    var vertices=new List<Vector3>();var triangles=new List<int>();Cartridge(vertices,triangles,new Vector3(0,0,-.0095f),new Vector3(0,0,.0095f),.0048f,.0048f);
    pistolCaseMesh=new Mesh();pistolCaseMesh.vertices=vertices.ToArray();pistolCaseMesh.triangles=triangles.ToArray();pistolCaseMesh.RecalculateNormals();pistolCaseMesh.RecalculateBounds();
    var shader=Shader.Find("Unlit/Color");if(shader==null)throw new InvalidOperationException("Case shader unavailable");pistolCaseMaterial=new Material(shader);pistolCaseMaterial.color=new Color(.65f,.43f,.12f);
    for(int i=0;i<pistolCases.Length;i++)pistolCases[i]=new PistolCase{Renderer=CreateControllerPart(pistolCaseRoot,pistolCaseMesh,pistolCaseMaterial,"Pistol brass case",Vector3.zero,Vector3.one*UnitsPerMetre)};
   }
   HidePistolCases();var c=pistolCases[pistolCaseNext++%pistolCases.Length];if(c==flareSmokeCase)flareSmokeCase=null;c.Born=Time.realtimeSinceStartup;
   c.Origin=rightWeaponPosition+rightWeaponRotation*(HdPistolData.MagazineTop+new Vector3(.012f,.006f,.015f))*UnitsPerMetre;
   c.Velocity=rightWeaponRotation*new Vector3(1.1f,.55f,.12f)*UnitsPerMetre;c.Rotation=rightWeaponRotation;
   c.Renderer.transform.localScale=Vector3.one*UnitsPerMetre;
   c.Renderer.GetComponent<MeshFilter>().sharedMesh=pistolCaseMesh;c.Renderer.sharedMaterial=pistolCaseMaterial;
   if(flare){EnsureFlareSpentCase();c.Renderer.GetComponent<MeshFilter>().sharedMesh=flareSpentMesh;c.Renderer.sharedMaterials=new[]{flareSpentMaterial,flareSpentInside};c.Origin=additionalChamber;c.Velocity=-additionalLoadDirection*.7f*UnitsPerMetre;c.Rotation=Quaternion.FromToRotation(Vector3.up,additionalLoadDirection);flareSmokeCase=c;}
  }catch(Exception e){pistolCaseFailed=true;HidePistolCases();MelonLoader.MelonLogger.Warning("Pistol casing visuals disabled: "+e.Message);}
 }
 private void ShowPistolCases(){ShowFlareCaseSmoke();foreach(var c in pistolCases){if(c==null||c.Renderer==null)continue;float age=Time.realtimeSinceStartup-c.Born;if(age<0||age>1.5f)continue;c.Renderer.transform.SetPositionAndRotation(c.Origin+c.Velocity*age+controllerTrackingToWorld*Vector3.down*(4.905f*age*age*UnitsPerMetre),c.Rotation*Quaternion.Euler(age*430,age*210,age*170));c.Renderer.enabled=true;}}
 private void HidePistolCases(){foreach(var r in flareCaseSmoke)if(r!=null)r.enabled=false;foreach(var c in pistolCases)if(c!=null&&c.Renderer!=null)c.Renderer.enabled=false;}
 private void DestroyPistolCases(){DestroyFlareCaseSmoke();if(flareSpentMesh!=null)UnityEngine.Object.Destroy(flareSpentMesh);if(flareSpentMaterial!=null)UnityEngine.Object.Destroy(flareSpentMaterial);if(flareSpentInside!=null)UnityEngine.Object.Destroy(flareSpentInside);flareSpentMesh=null;flareSpentMaterial=flareSpentInside=null;if(pistolCaseRoot!=null)UnityEngine.Object.Destroy(pistolCaseRoot);if(pistolCaseMesh!=null)UnityEngine.Object.Destroy(pistolCaseMesh);if(pistolCaseMaterial!=null)UnityEngine.Object.Destroy(pistolCaseMaterial);pistolCaseRoot=null;pistolCaseMesh=null;pistolCaseMaterial=null;Array.Clear(pistolCases,0,pistolCases.Length);pistolCaseNext=0;pistolCaseFailed=false;}
}}



