namespace SignalisVrTracking {
 public static class ProdDamage {
  // Native AnEnemyType: regular EULR/STAR/ARAR/STCR only. MNHR,
  // KLBR, KNCR and ADLR retain native damage and stun behavior.
  public static bool NormalType(int type){return type>=0&&type<=3;}
  public static int AfterHit(int current,int maximum) {
   if(current<=0)return 0;
   int damage=maximum>0?maximum/2+maximum%2:current/2+current%2;
   return current>damage?current-damage:0;
  }
 }
}
