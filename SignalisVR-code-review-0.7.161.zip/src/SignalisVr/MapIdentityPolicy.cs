using System;
namespace SignalisVrTracking {
 public static class MapIdentityPolicy {
  // Scene loading removes editor-only ancestors. Match complete path segments,
  // never a loose object-name substring, and require a unique catalogue match.
  public static bool Matches(string stored,string live){
   if(stored==live)return true;
   int a=stored.IndexOf('|'),b=live.IndexOf('|');if(a<0||b<0)return false;
   a=stored.IndexOf('|',a+1);b=live.IndexOf('|',b+1);if(a<0||b<0||stored.Substring(0,a)!=live.Substring(0,b))return false;
   string x=WithoutCloneSuffix(stored.Substring(a+1)),y=WithoutCloneSuffix(live.Substring(b+1));
   return x==y||x.EndsWith("/"+y,StringComparison.Ordinal)||y.EndsWith("/"+x,StringComparison.Ordinal);
  }
  private static string WithoutCloneSuffix(string path){
   var parts=path.Split('/');for(int i=0;i<parts.Length;i++)if(parts[i].EndsWith("(Clone)",StringComparison.Ordinal))parts[i]=parts[i].Substring(0,parts[i].Length-7).TrimEnd();
   return string.Join("/",parts);
  }
 }
}
