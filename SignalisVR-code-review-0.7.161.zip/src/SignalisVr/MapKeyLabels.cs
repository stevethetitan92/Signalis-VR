namespace SignalisVrTracking {public sealed partial class Tracking {
 private static string MapDisplayRequiredKey(string text,int state,int floor,string room,int count,int index){
  if(state!=4)return null;
  if(floor==11&&((room=="Mineshaft Elevator"&&count==1&&index==0)||(room=="Mineshaft Access"&&count==2&&index==0)))return "Administrator's Key";
  return text;
 }
 private static int MapCompletedShutterState(global::MinimapDoor marker,int state,int floor=-1,string room=null,int count=0,int index=-1){
  // Only the authored shutter puzzle: completion records an actual unlock,
  // unlike entering a room or reading a speculative native map color.
  var connection=marker==null||marker.door==null?null:marker.door.connection;
  bool authored=floor==10&&((room=="Rec Room"&&count==1&&index==0)||(room=="7F E Corridor"&&count==3&&index==1));
  return state==4&&(authored||(connection!=null&&connection.customKeyHintMsg=="RES_Shutter"))&&global::SProgress.GetInt("SignalisVR.Map.Completed.v1:RES_Shutter",0)!=0?1:state;
 }
 private static string MapDoorRequiredKey(global::AutoTraverseDoor door){
  try{if(door==null)return null;var item=door.connection==null?null:door.connection.key;
  if(item==null&&door.door!=null){var single=door.door.GetComponentInChildren<global::InteractiveLockSingle>(true);if(single!=null)item=single.key;}
  if(item==null)return null;string label=item.localizedName();return string.IsNullOrWhiteSpace(label)?item._name:label;}catch(System.Exception){return null;}
 }
 private static string MapDoorKeyLabel(global::MinimapDoor marker,string alias,int state){
  if(state!=4)return null;string text=MapDoorRequiredKey(marker.door);
  if(!string.IsNullOrWhiteSpace(text)){
   if(alias!=null&&global::SProgress.GetString(alias+":keyName","")!=text)global::SProgress.SetString(alias+":keyName",text);
   return text;
  }
  if(alias!=null){text=global::SProgress.GetString(alias+":keyName","");if(!string.IsNullOrWhiteSpace(text))return text;}
  string live=MapDoorHistory(marker.door);return live==null?null:global::SProgress.GetString(live+":keyName","");
 }
}}
