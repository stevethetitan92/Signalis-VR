namespace SignalisVrTracking {
 // A report is evidence of missing progress, never a diagnosis or recovery action.
 public sealed class DiagnosticWatchdog {
  private double lastUpdate=-1,lastProgress=-1,nextReport;
  private int previousFrames=-1;
  public string Observe(double now,bool expected,int frames){
   double gap=lastUpdate<0?0:now-lastUpdate;lastUpdate=now;
   if(!expected||frames!=previousFrames||lastProgress<0){lastProgress=now;previousFrames=frames;}
   string reason=gap>=3?"update-gap":expected&&now-lastProgress>=3?"headset-no-progress":null;
   if(reason==null||now<nextReport)return null;
   nextReport=now+60;return reason;
  }
 }
}
