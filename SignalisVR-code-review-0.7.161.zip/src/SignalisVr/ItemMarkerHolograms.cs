using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public static class ItemMarkerSizing {
  public static float Extent(float value,float units){if(float.IsNaN(value)||float.IsInfinity(value)||units<=0)return .12f*Math.Max(1,units);return Math.Max(.035f*units,value*1.08f);}
 }
 public static class ItemMarkerPulse {
  public static float Level(float seconds){return .5f-.5f*(float)Math.Cos(seconds*(2*Math.PI/2.4));}
 }
 public sealed partial class Tracking {
  private sealed class ItemHologram {internal GameObject root;internal SpriteRenderer display,glow;internal MeshRenderer lines;internal Mesh mesh;internal MaterialPropertyBlock colors;}
  private readonly List<ItemHologram> visibleItemHolograms=new List<ItemHologram>();
  private readonly Dictionary<int,ItemHologram> itemHolograms=new Dictionary<int,ItemHologram>();
  private readonly Dictionary<int,global::interactionPopup> markerOwners=new Dictionary<int,global::interactionPopup>();
  private Sprite itemBracketArtwork,ownedItemBracketArtwork;
  private Texture2D ownedItemBracketTexture;
  private readonly Dictionary<int,SpriteRenderer> extraItemMarkers=new Dictionary<int,SpriteRenderer>();
  private readonly Dictionary<int,global::Interaction> extraMarkerOwners=new Dictionary<int,global::Interaction>();
  private int lastMarkerCoverage=-1;
  private static bool IsTravelOrCombatInteraction(global::Interaction inter){
   return inter.GetComponentInParent<global::Ladder>()!=null||inter.GetComponentInParent<global::AutoTraverseDoor>()!=null
    ||inter.GetComponentInParent<global::LoadLevelInteraction>()!=null
    ||inter.GetComponentInParent<global::DoorLockEventInteraction>()!=null||inter.GetComponentInParent<global::Doorway_simple>()!=null
    ||inter.GetComponentInParent<global::LoadLevelZone>()!=null||inter.GetComponentInParent<global::PEN_HoleSnowblind>()!=null
    ||inter.GetComponentInParent<global::EnemyController>()!=null||inter.name=="StompZone";
  }
  private bool IsSupportedItemInteraction(global::Interaction inter){
   foreach(var point in mapObjects)if(point.Inter==inter&&point.Source!=null&&point.Source.gameObject.activeInHierarchy)return true;
   foreach(var ev in mapEvents)if(ev!=null&&ev.EventObject!=null&&inter.transform.IsChildOf(ev.EventObject.transform))return false;
   return inter.GetComponent<global::ItemPickup>()!=null||inter.GetComponent<global::BookScreen>()!=null||inter.GetComponent<global::SavePoint>()!=null||inter.GetComponent<global::StorageBox>()!=null||inter.GetComponent<global::ObservationDialogue>()!=null||inter.GetComponent<global::EventScreenInteraction>()!=null||inter.GetComponent<global::UseItemInteraction>()!=null||inter.GetComponent<global::InteractiveLockSingle>()!=null;
  }
  private void DiscoverUnmarkedInteractions(List<SpriteRenderer> selected){
   var covered=new HashSet<int>();
   foreach(var sr in selected){if(sr==null||sr.sprite==null)continue;
    if(HighlightPolicy.IsBracket(sr.sprite.name))itemBracketArtwork=sr.sprite;
    global::interactionPopup owner;if(markerOwners.TryGetValue(sr.GetInstanceID(),out owner)&&owner!=null&&owner.inter!=null&&(HighlightPolicy.IsBracket(sr.sprite.name)||sr.sprite.name=="Interaction_inspect"))covered.Add(owner.inter.GetInstanceID());
   }
   if(itemBracketArtwork==null){
    if(ownedItemBracketArtwork==null){ownedItemBracketTexture=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(ownedItemBracketTexture,Convert.FromBase64String(HdAsset.Read("item-marker-native.png")),true))return;ownedItemBracketTexture.filterMode=FilterMode.Point;ownedItemBracketArtwork=Sprite.Create(ownedItemBracketTexture,new Rect(0,0,ownedItemBracketTexture.width,ownedItemBracketTexture.height),new Vector2(.5f,.5f),100);ownedItemBracketArtwork.name="interaction";}
    itemBracketArtwork=ownedItemBracketArtwork;
   }
   int discovered=0,added=0;
   foreach(var inter in Resources.FindObjectsOfTypeAll<global::Interaction>()){
    if(inter==null||!inter.gameObject.scene.IsValid()||!inter.gameObject.activeInHierarchy||!inter.enabled)continue;
    var room=inter.GetComponentInParent<global::Room>();if(room!=null&&global::PlayerState.currentRoom!=null&&room!=global::PlayerState.currentRoom)continue;discovered++;
    int id=inter.GetInstanceID();if(covered.Contains(id))continue;
    if(IsTravelOrCombatInteraction(inter)||!IsSupportedItemInteraction(inter))continue;
    SpriteRenderer sr;if(!extraItemMarkers.TryGetValue(id,out sr)||sr==null){var go=new GameObject("SignalisVR_ObjectMarker_"+id);go.layer=23;sr=go.AddComponent<SpriteRenderer>();sr.enabled=false;extraItemMarkers[id]=sr;}
    sr.sprite=itemBracketArtwork;extraMarkerOwners[sr.GetInstanceID()]=inter;selected.Add(sr);added++;
   }
   if(discovered!=lastMarkerCoverage){lastMarkerCoverage=discovered;MelonLoader.MelonLogger.Msg("ITEM MARKER COVERAGE: loaded interactions="+discovered+" existing="+covered.Count+" extra eligible="+added);}
  }
  private Material itemHologramMaterial;
  private bool ObjectMarkerClearSight(global::Interaction interaction,Vector3 target){
   var attack=global::PlayerAttack.instance;if(attack==null)return false;
   Bounds bounds;if(ItemObjectBounds(interaction,out bounds))target=bounds.ClosestPoint(stereoPosition);
   var delta=target-stereoPosition;float length=delta.magnitude;if(length<.001f)return true;
   RaycastHit hit;
   if(!Physics.Raycast(stereoPosition,delta/length,out hit,Mathf.Max(0,length-.015f*UnitsPerMetre),attack.WallMask.value,QueryTriggerInteraction.Ignore))return true;
   // A collider on the object itself is its visible surface, not an obstruction.
   if(hit.collider==null)return false;
   if(hit.collider.GetComponentInParent<global::Interaction>()==interaction)return true;
   var physical=ItemPhysicalRoot(interaction);
   return physical!=null&&(hit.collider.transform==physical||hit.collider.transform.IsChildOf(physical));
  }
  private ItemHologram ItemHologramFor(SpriteRenderer source){
   ItemHologram h;int id=source.GetInstanceID();if(itemHolograms.TryGetValue(id,out h)&&h.root!=null)return h;
   if(itemHologramMaterial==null){var shader=Shader.Find("Sprites/Default");if(shader==null)throw new InvalidOperationException("Item hologram shader missing");itemHologramMaterial=new Material(shader);itemHologramMaterial.mainTexture=Texture2D.whiteTexture;}
   h=new ItemHologram();h.colors=new MaterialPropertyBlock();h.root=new GameObject("SignalisVR_ItemHologram_"+id);h.root.layer=23;h.display=h.root.AddComponent<SpriteRenderer>();h.display.sharedMaterial=itemHologramMaterial;
   var glow=new GameObject("ItemHologramGlow");glow.layer=23;glow.transform.SetParent(h.root.transform,false);glow.transform.localPosition=new Vector3(0,0,.004f);glow.transform.localScale=Vector3.one*1.035f;h.glow=glow.AddComponent<SpriteRenderer>();h.glow.sharedMaterial=itemHologramMaterial;
   var lines=new GameObject("ItemHologramScanlines");lines.layer=23;lines.transform.SetParent(h.root.transform,false);lines.transform.localPosition=new Vector3(0,0,.008f);h.mesh=new Mesh();lines.AddComponent<MeshFilter>().sharedMesh=h.mesh;h.lines=lines.AddComponent<MeshRenderer>();h.lines.sharedMaterial=itemHologramMaterial;h.lines.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;h.lines.receiveShadows=false;
   itemHolograms[id]=h;return h;
  }
  private void ShowItemHologram(SpriteRenderer source,Vector3 position,Quaternion rotation,Vector3 worldScale){
   var h=ItemHologramFor(source);visibleItemHolograms.Add(h);h.root.transform.position=position;h.root.transform.rotation=rotation;h.root.transform.localScale=worldScale;
   var artwork=source.sprite.name=="Interaction_inspect"&&itemBracketArtwork!=null?itemBracketArtwork:source.sprite;
   bool changed=h.display.sprite!=artwork;h.display.sprite=h.glow.sprite=artwork;h.display.sortingLayerID=h.glow.sortingLayerID=h.lines.sortingLayerID=source.sortingLayerID;h.display.sortingOrder=source.sortingOrder;h.glow.sortingOrder=h.lines.sortingOrder=source.sortingOrder-1;
   float pulse=ItemMarkerPulse.Level(Time.time);
   h.display.color=new Color(.35f,.85f,1f,.65f+.3f*pulse);h.glow.color=new Color(.3f,.85f,1f,.06f+.10f*pulse);
   if(changed){var b=artwork.bounds;var v=new List<Vector3>();var t=new List<int>();for(int i=0;i<20;i++){float y=b.min.y+b.size.y*(i+.5f)/20f;float half=b.size.y*.0018f;int n=v.Count;v.Add(new Vector3(b.min.x,y-half,0));v.Add(new Vector3(b.max.x,y-half,0));v.Add(new Vector3(b.max.x,y+half,0));v.Add(new Vector3(b.min.x,y+half,0));t.Add(n);t.Add(n+1);t.Add(n+2);t.Add(n);t.Add(n+2);t.Add(n+3);}h.mesh.Clear();h.mesh.vertices=v.ToArray();h.mesh.SetTriangles(t.ToArray(),0);h.mesh.RecalculateBounds();}
   var block=h.colors;block.SetColor("_Color",new Color(.3f,.85f,1f,.07f));h.lines.SetPropertyBlock(block);h.display.enabled=h.glow.enabled=h.lines.enabled=true;source.enabled=false;
  }
  private sealed class ItemBoundsSample {internal Bounds Bounds;internal bool Found;internal float At;}
  private readonly Dictionary<int,ItemBoundsSample> itemBoundsCache=new Dictionary<int,ItemBoundsSample>();
  private bool ItemObjectBounds(global::Interaction interaction,out Bounds bounds){
   int id=interaction.GetInstanceID();ItemBoundsSample sample;
   if(itemBoundsCache.TryGetValue(id,out sample)&&Time.realtimeSinceStartup-sample.At<1f){bounds=sample.Bounds;return sample.Found;}
   bool found=MeasureItemObjectBounds(interaction,out bounds);
   itemBoundsCache[id]=new ItemBoundsSample{Bounds=bounds,Found=found,At=Time.realtimeSinceStartup};return found;
  }
  private Transform ItemPhysicalRoot(global::Interaction interaction){
   Transform physical=interaction.transform;
   var pickup=interaction.GetComponent<global::ItemPickup>();PickupModelCopy copy;
   if(pickup!=null&&pickupModelCopies.TryGetValue(pickup.GetInstanceID(),out copy)&&copy.Root!=null)return copy.Root.transform;
   // Native map POIs can be separate empty siblings (SafePOI/BoxPOI).
   // Their map coordinates are not the geometry of the world interaction.
   foreach(var point in mapObjects)if(point.Inter==interaction&&point.Source!=null&&point.Source.TryCast<global::MinimapPOIObject>()==null){var owned=point.Source.TryCast<global::ItemPickup>();if(owned!=null&&pickupModelCopies.TryGetValue(owned.GetInstanceID(),out copy)&&copy.Root!=null)return copy.Root.transform;physical=point.Source.transform;break;}
   // This authored puzzle keeps its visible box in a sibling model hierarchy.
   // Resolve that exact relationship; never choose the nearest unrelated prop.
   var puzzle=interaction.GetComponent<global::EventScreenInteraction>();
   if(puzzle!=null&&puzzle.EventObject!=null&&puzzle.EventObject.name=="DET_MysteryBox"&&interaction.name=="ButterflyBoxEvent"&&interaction.transform.parent!=null){
    var box=interaction.transform.parent.Find("Model/MysteryBox");if(box!=null)physical=box;
   }
   return physical;
  }
  private bool MeasureItemObjectBounds(global::Interaction interaction,out Bounds bounds){
   bounds=new Bounds();bool found=false;
   // Union the renderable pieces owned by this interaction, excluding nested interactions.
   Transform physical=ItemPhysicalRoot(interaction);
   var models=physical.GetComponentsInChildren<Renderer>(true);
   bool hasMesh=false;
   foreach(var model in models)if(model!=null&&model.gameObject.activeInHierarchy&&model.gameObject.layer!=23&&model.GetComponentInParent<global::interactionPopup>()==null&&(model.GetComponent<MeshRenderer>()!=null||model.GetComponent<SkinnedMeshRenderer>()!=null)){
    var owner=model.GetComponentInParent<global::Interaction>();if(owner==null||owner==interaction){hasMesh=true;break;}
   }
   foreach(var model in models){
    if(model==null||!model.gameObject.activeInHierarchy||model.gameObject.layer==23||model.GetComponentInParent<global::interactionPopup>()!=null||model.GetComponent<TMPro.TextMeshPro>()!=null)continue;
    var nested=model.GetComponentInParent<global::Interaction>();if(nested!=null&&nested!=interaction)continue;
    if(model.GetComponent<MeshRenderer>()==null&&model.GetComponent<SkinnedMeshRenderer>()==null&&model.GetComponent<SpriteRenderer>()==null)continue;
    // Flat-camera sprite artwork can extend far beyond the actual 3D safe/item.
    if(hasMesh&&model.GetComponent<SpriteRenderer>()!=null)continue;
    var b=model.bounds;if(b.size.sqrMagnitude<.0001f)continue;
    if(found)bounds.Encapsulate(b);else {bounds=b;found=true;}
   }
   // Some authored interactables have no renderer under their interaction component.
   // Use their own collider bounds as a fallback, never arbitrary nearby scenery.
   if(!found)foreach(var collider in interaction.GetComponents<Collider>()){
    if(collider==null||!collider.enabled||collider.isTrigger)continue;var b=collider.bounds;
    if(b.size.sqrMagnitude<.0001f)continue;
    if(found)bounds.Encapsulate(b);else {bounds=b;found=true;}
   }
   return found;
  }
  private void PlaceObjectHologram(SpriteRenderer source,global::Interaction interaction){
   Bounds bounds;bool found=ItemObjectBounds(interaction,out bounds);var center=found?bounds.center:interaction.pointOfInterest!=null?interaction.pointOfInterest.position:interaction.transform.position;
   var toward=(camera.transform.position-center).normalized;
   // Move only the artwork to the object's camera-facing surface, never the object.
   if(found){var e=bounds.extents;float advance=float.MaxValue;if(Math.Abs(toward.x)>.0001f)advance=Math.Min(advance,e.x/Math.Abs(toward.x));if(Math.Abs(toward.y)>.0001f)advance=Math.Min(advance,e.y/Math.Abs(toward.y));if(Math.Abs(toward.z)>.0001f)advance=Math.Min(advance,e.z/Math.Abs(toward.z));if(advance<float.MaxValue)center+=toward*advance;}
   center+=toward*(.025f*UnitsPerMetre);var right=stereoRotation*Vector3.right;var up=stereoRotation*Vector3.up;var size=found?bounds.size:Vector3.one*(.12f*UnitsPerMetre);
   // Object bounds select the centre/surface, never the artwork's size.
   float width=.24f*UnitsPerMetre,height=.24f*UnitsPerMetre;
   var sprite=(source.sprite.name=="Interaction_inspect"&&itemBracketArtwork!=null?itemBracketArtwork:source.sprite).bounds.size;ShowItemHologram(source,center,stereoRotation,new Vector3(width/Math.Max(.01f,sprite.x),height/Math.Max(.01f,sprite.y),1));
  }
  private void HideItemHolograms(){foreach(var h in visibleItemHolograms)if(h.root!=null){h.display.enabled=h.glow.enabled=h.lines.enabled=false;}visibleItemHolograms.Clear();}
  private void ClearItemHolograms(){itemBoundsCache.Clear();foreach(var sr in extraItemMarkers.Values)if(sr!=null)UnityEngine.Object.Destroy(sr.gameObject);extraItemMarkers.Clear();extraMarkerOwners.Clear();itemBracketArtwork=null;if(ownedItemBracketArtwork!=null)UnityEngine.Object.Destroy(ownedItemBracketArtwork);if(ownedItemBracketTexture!=null)UnityEngine.Object.Destroy(ownedItemBracketTexture);ownedItemBracketArtwork=null;ownedItemBracketTexture=null;foreach(var h in itemHolograms.Values){if(h.root!=null)UnityEngine.Object.Destroy(h.root);if(h.mesh!=null)UnityEngine.Object.Destroy(h.mesh);}itemHolograms.Clear();markerOwners.Clear();if(itemHologramMaterial!=null)UnityEngine.Object.Destroy(itemHologramMaterial);itemHologramMaterial=null;}
 }
}

