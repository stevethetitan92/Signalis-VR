using System;
using UnityEngine;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private Mesh thermiteFlameMesh;
 private Texture2D thermiteGlowTexture;
 private Material thermiteFlameOuter,thermiteFlameInner,thermiteSmoke;
 private static float ThermiteFade(ThermiteFlight f,float now){if(f.Expires<=0)return 1;float t=Mathf.Clamp01((f.Expires-now)/1.5f);return t*t*(3-2*t);}
 private void UpdateThermiteAudio(ThermiteFlight f,float now,bool audible){
  if(f.AudioFailed)return;
  try{
   if(!audible||f.NativeBodyBurn||f.Root==null||ThermiteFade(f,now)<=0){if(f.Sound!=null)f.Sound.PauseLoop();return;}
   if(f.Sound==null)f.Sound=new PackAudio(System.Convert.FromBase64String(HdAsset.Read("thermite-burn-loop.pcm")),44100);
   var tip=f.Root.transform.TransformPoint(new Vector3(f.Bounds.center.x,f.Bounds.max.y,f.Bounds.center.z));
   var relative=Quaternion.Inverse(stereoRotation)*(tip-stereoPosition)/UnitsPerMetre;
   f.Sound.SpatialLoop(relative,.8f*ThermiteFade(f,now));
  }catch(System.Exception ex){f.AudioFailed=true;if(f.Sound!=null){f.Sound.Dispose();f.Sound=null;}MelonLoader.MelonLogger.Warning("Thermite tip audio unavailable: "+ex.Message);}
 }
 private void AddThermiteFlame(ThermiteFlight f){
  // Gun projectiles need their own visible flame; thrown thermite overlays remain unchanged.
  if(!f.Projectile&&f.Expires>0){bool initial=true;foreach(var mesh in thermiteMeshes){if(initial){f.Bounds=mesh.bounds;initial=false;}else{f.Bounds.Encapsulate(mesh.bounds.min);f.Bounds.Encapsulate(mesh.bounds.max);}}f.Flames=new MeshRenderer[0];return;}

  if(thermiteFlameMesh==null){
   thermiteFlameMesh=new Mesh();thermiteFlameMesh.vertices=new[]{new Vector3(-.5f,-.5f,0),new Vector3(.5f,-.5f,0),new Vector3(.5f,.5f,0),new Vector3(-.5f,.5f,0)};
   thermiteFlameMesh.colors=new[]{Color.white,Color.white,Color.white,Color.white};
   thermiteFlameMesh.uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(1,1),new Vector2(0,1)};thermiteFlameMesh.triangles=HandSurfaceTopology.DoubleSided(new[]{0,1,2,0,2,3});thermiteFlameMesh.RecalculateBounds();
   thermiteGlowTexture=new Texture2D(32,32,TextureFormat.RGBA32,false);thermiteGlowTexture.wrapMode=TextureWrapMode.Clamp;
   for(int y=0;y<32;y++)for(int x=0;x<32;x++){float dx=(x-15.5f)/15.5f,dy=(y-15.5f)/15.5f;float a=Mathf.Clamp01(1-dx*dx-dy*dy);thermiteGlowTexture.SetPixel(x,y,new Color(1,1,1,a*a));}thermiteGlowTexture.Apply();
   thermiteFlameOuter=new Material(Shader.Find("Sprites/Default"));thermiteFlameOuter.mainTexture=thermiteGlowTexture;thermiteFlameOuter.color=new Color(1,.12f,.3f,.8f);
   thermiteFlameInner=new Material(thermiteFlameOuter);thermiteFlameInner.color=new Color(1,1,.91f,1);
   thermiteSmoke=new Material(thermiteFlameOuter);thermiteSmoke.color=new Color(.76f,.76f,.78f,.24f);
  }
  bool first=true;foreach(var m in thermiteMeshes){if(first){f.Bounds=m.bounds;first=false;}else{f.Bounds.Encapsulate(m.bounds.min);f.Bounds.Encapsulate(m.bounds.max);}}
  // Bounded, script-free visuals. Never clone native flare/projectile behaviours.
  f.EffectFade=new MaterialPropertyBlock();f.Flames=new MeshRenderer[5];for(int i=0;i<f.Flames.Length;i++)f.Flames[i]=CreateControllerPart(f.Root,thermiteFlameMesh,i<2?thermiteFlameOuter:i<5?thermiteFlameInner:i<17?thermiteSmoke:thermiteFlameInner,"Thermite tip effect",Vector3.zero,Vector3.one);
 }
 private void AnimateThermiteFlame(ThermiteFlight f,float now){
  if(f.BurnTarget!=null&&!ProdEnemyValid(f.BurnTarget))f.NativeBodyBurn=true;
  if(f.NativeBodyBurn){if(f.Flames!=null)foreach(var r in f.Flames)if(r!=null)r.enabled=false;return;}
  var up=calibrationRoot!=null?calibrationRoot.transform.up:controllerTrackingToWorld*Vector3.up;
  var tip=f.Root.transform.TransformPoint(new Vector3(f.Bounds.center.x,f.Bounds.max.y,f.Bounds.center.z));
  var view=camera!=null?(camera.transform.position-tip).normalized:controllerTrackingToWorld*Vector3.back;
  var side=Vector3.Cross(up,view).normalized;if(side.sqrMagnitude<.01f)side=controllerTrackingToWorld*Vector3.right;
  var rotation=Quaternion.LookRotation(view,up);
  for(int i=0;i<f.Flames.Length;i++){
   float phase=now*(i<17?.43f:1.7f)+i*.618034f;phase-=Mathf.Floor(phase);
   float flicker=1+.10f*Mathf.Sin(now*27+i*2.1f);Vector3 offset;float width,height;
   if(i<5){width=(i<2?.070f:.021f)*flicker;height=(i<2?.24f:.19f)*flicker;offset=up*(height*.44f)+side*(Mathf.Sin(now*19+i)*.004f);}
   else if(i<17){width=.06f+phase*.20f;height=width;offset=up*(.19f+phase*.60f)+side*(Mathf.Sin(i*7+phase*3)*phase*.065f);}
   else {width=.002f;height=.012f;offset=up*(phase*.42f)+side*(Mathf.Sin(i*9)*phase*.12f);}
   var r=f.Flames[i];r.enabled=true;
   var color=i<2?thermiteFlameOuter.color:i<5?thermiteFlameInner.color:i<17?thermiteSmoke.color:thermiteFlameInner.color;
   if(f.Projectile){if(i<2)color=new Color(1,.25f,.035f,.8f);width*=.55f;height*=.55f;offset*=.55f;}
   float life=ThermiteFade(f,now);
   if(i>=5)color.a*=Mathf.Clamp01(phase*10)*(1-phase);
   color.a*=life;f.EffectFade.SetColor("_Color",color);r.SetPropertyBlock(f.EffectFade);r.transform.SetPositionAndRotation(tip+offset*UnitsPerMetre,rotation);r.transform.localScale=new Vector3(width,height,1);
  }
 }
 private void DestroyThermiteFlame(){if(thermiteFlameMesh!=null)UnityEngine.Object.Destroy(thermiteFlameMesh);if(thermiteGlowTexture!=null)UnityEngine.Object.Destroy(thermiteGlowTexture);foreach(var m in new[]{thermiteFlameOuter,thermiteFlameInner,thermiteSmoke})if(m!=null)UnityEngine.Object.Destroy(m);thermiteFlameMesh=null;thermiteGlowTexture=null;thermiteFlameOuter=thermiteFlameInner=thermiteSmoke=null;}
} }


