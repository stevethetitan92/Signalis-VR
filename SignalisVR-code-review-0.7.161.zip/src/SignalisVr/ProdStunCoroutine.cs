using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
  [return: MarshalAs(UnmanagedType.I1)]
  private delegate bool ProdStunMoveNative(IntPtr self,IntPtr method);
  private ProdStunMoveNative prodStunMoveOriginal;
  private readonly Dictionary<IntPtr,float> prodStunEffects=new Dictionary<IntPtr,float>();
  private void InstallProdStunCoroutine() {
   if(prodStunMoveOriginal!=null)return;
   var address=QuestNativeAddress(typeof(global::PlayerAttack._delayedTaser_d__137),"NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0");
   IntPtr gameBase=IntPtr.Zero;
   foreach(System.Diagnostics.ProcessModule module in System.Diagnostics.Process.GetCurrentProcess().Modules)
    if(string.Equals(module.ModuleName,"GameAssembly.dll",StringComparison.OrdinalIgnoreCase))gameBase=module.BaseAddress;
   if(gameBase==IntPtr.Zero||address.ToInt64()-gameBase.ToInt64()!=0x6EF020)throw new InvalidOperationException("Stun coroutine layout differs from inspected build");
   prodStunMoveOriginal=AttachQuestNative<ProdStunMoveNative>(address,new ProdStunMoveNative(ProdStunMove));
  }
  private void RegisterProdStun(IntPtr pointer) {
   float now=Time.realtimeSinceStartup;
   var expired=new List<IntPtr>();
   foreach(var entry in prodStunEffects)if(now>entry.Value)expired.Add(entry.Key);
   foreach(var key in expired)prodStunEffects.Remove(key);
   prodStunEffects[pointer]=now+1f;
  }
  private bool ProdStunMove(IntPtr self,IntPtr method) {
   float until;
   if(!prodStunEffects.TryGetValue(self,out until))return prodStunMoveOriginal(self,method);
   var settings=global::PlayerState.settings;
   if(settings==null||Time.realtimeSinceStartup>until){prodStunEffects.Remove(self);return prodStunMoveOriginal(self,method);}
   // Only this physical rod's native stun step excludes the idle-enemy bonus.
   // Ordinary weapon damage keeps the game's original bonus.
   int bonus=settings.SneakAttackBonusDamage;
   try {
    settings.SneakAttackBonusDamage=0;
    bool running=prodStunMoveOriginal(self,method);
    if(!running)prodStunEffects.Remove(self);
    return running;
   }finally{settings.SneakAttackBonusDamage=bonus;}
  }
 }
}
