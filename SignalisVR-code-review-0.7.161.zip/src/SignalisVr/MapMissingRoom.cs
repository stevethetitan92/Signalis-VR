using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static bool MapMissingRoomBounds(global::PersistentMinimapFloor floor,Transform basis,global::PersistentMinimapRoom room,out Vector2 low,out Vector2 high){
  low=high=Vector2.zero;
  if(floor==null||(int)floor.FloorID!=11||room==null||room.RoomID==null||room.RoomID.name!="Service Tunnel")return false;
  // Shipped ServiceTunnel artwork and its door duplicate STCR Dorm's cell.
  // Draw an independent schematic cell east of Library Hallway instead.
  var records=new List<global::PersistentMinimapRoom>();
  if(floor.Rooms!=null)foreach(var r in floor.Rooms)if(r!=null&&!records.Contains(r))records.Add(r);
  foreach(var r in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true))if(r!=null&&!records.Contains(r))records.Add(r);
  global::PersistentMinimapRoom hall=null,office=null;
  foreach(var r in records){if(r.RoomID==null)continue;if(r.RoomID.name=="8F S Corridor")hall=r;if(r.RoomID.name=="Falkes Office")office=r;}
  if(hall==null||office==null||hall.Doors==null||hall.Doors.Count==0)return false;
  float width=float.PositiveInfinity,height=float.PositiveInfinity;
  foreach(var shape in office.GetComponentsInChildren<global::MinimapActiveRoom>(true)){
   var sr=shape.SR;if(sr==null)sr=shape.GetComponent<SpriteRenderer>();if(sr==null||sr.sprite==null)continue;
   var rect=MapShapeRect(sr,basis);if(rect.width>.1f)width=Math.Min(width,rect.width);if(rect.height>.1f)height=Math.Min(height,rect.height);
  }
  if(float.IsInfinity(width)||float.IsInfinity(height))return false;
  Vector3 anchor=new Vector3(float.NegativeInfinity,0,0);
  foreach(var door in hall.Doors){if(door==null)continue;var p=basis.InverseTransformPoint(door.transform.position);if(p.x>anchor.x)anchor=p;}
  if(float.IsInfinity(anchor.x))return false;
  // Align to the actual room border rather than the inset door sprite.
  float east=anchor.x;
  foreach(var shape in hall.GetComponentsInChildren<global::MinimapActiveRoom>(true)){
   var sr=shape.SR;if(sr==null)sr=shape.GetComponent<SpriteRenderer>();if(sr==null||sr.sprite==null)continue;
   var rect=MapShapeRect(sr,basis);east=Math.Max(east,rect.xMax);
  }
  low=new Vector2(east,anchor.y-height*.5f);high=new Vector2(east+width,anchor.y+height*.5f);
  return true;
 }
}}
