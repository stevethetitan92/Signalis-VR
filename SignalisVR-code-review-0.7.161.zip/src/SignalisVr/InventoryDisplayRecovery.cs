using System;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static bool inventoryDisplayRepairing;
 private static readonly System.Collections.Generic.Dictionary<int,bool> inventoryDisplayOpen=new System.Collections.Generic.Dictionary<int,bool>();
 private void InstallInventoryDisplayRecovery(){
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"Update",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(RecoverInventoryDisplay)));
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"updateItems",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(RecoverCarriedKeys)));
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"OnDisable",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(InventoryDisplayClosed)));
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::SaveManager),"Load",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(InventoryDisplayLoaded)));
 }
 private static void InventoryDisplayClosed(global::InventoryBase __instance){if(__instance!=null)inventoryDisplayOpen.Remove(__instance.GetInstanceID());}
 private static void InventoryDisplayLoaded(){inventoryDisplayOpen.Clear();}
 private static void RecoverCarriedKeys(global::InventoryBase __instance){
  if(inventoryDisplayRepairing||__instance==null||global::InventoryBase.storeMode||global::InventoryManager.elsterItems==null||global::InventoryBase.currentItems==null)return;
  bool changed=false;
  foreach(var pair in global::InventoryManager.elsterItems){
   var item=pair.Key;if(item==null||pair.Value<=0||(int)item.type!=5)continue;
   // This authored key is visible in the shipped game. Never restore ownership
   // from a historical save: only an actually carried native item qualifies.
   if(item._item==global::Items.itemlist.KolibriKey&&item.hidden){item.hidden=false;changed=true;}
   if(item.hidden)continue;
   if(!global::InventoryBase.currentItems.Contains(item)){global::InventoryBase.currentItems.Add(item);changed=true;MelonLogger.Msg("INVENTORY DISPLAY: restored carried key to menu: "+item._item);}
  }
  if(changed&&__instance.igc!=null){inventoryDisplayRepairing=true;try{__instance.igc.RefreshSlots();}finally{inventoryDisplayRepairing=false;}}
 }
 private static void RecoverInventoryDisplay(global::InventoryBase __instance){
  if(__instance==null||!__instance.gameObject.scene.IsValid())return;
  int id=__instance.GetInstanceID();bool previous;inventoryDisplayOpen.TryGetValue(id,out previous);
  bool open=__instance.inventoryOpen&&__instance.gameObject.activeInHierarchy;
  inventoryDisplayOpen[id]=open;
  if(!open||previous||inventoryDisplayRepairing||global::InventoryBase.storeMode||__instance.combineMode||__instance.inspectMode)return;
  // Refresh this view after native opening/load and other mods' cloned UI
  // initialization, rather than depending on a different inventory's grid.
  __instance.updateItems();
  var all=global::InventoryManager.allItems;
  if(all!=null&&all.ContainsKey(global::Items.itemlist.KolibriKey)){
   var key=all[global::Items.itemlist.KolibriKey];var carried=global::InventoryManager.elsterItems;
   int count=carried!=null&&carried.ContainsKey(key)?carried[key]:0;
   MelonLogger.Msg("INVENTORY DISPLAY: hummingbird carried="+count+" listed="+(global::InventoryBase.currentItems!=null&&global::InventoryBase.currentItems.Contains(key))+" view="+__instance.name);
  }
 }
}}
