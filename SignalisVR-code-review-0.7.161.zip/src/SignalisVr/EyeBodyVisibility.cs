using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Transform eyeBodyOwner;private SkinnedMeshRenderer[] eyeBodySkins;private float nextEyeBodyScan;
 private MirrorVisibilityScope eyeBodyScope;
 private MirrorVisibilityScope HideNativeEyeBody(){
  var scope=new MirrorVisibilityScope();eyeBodyScope=scope;
  if(camera==null||snowWalkStereo)return scope;
  var root=handsModel!=null?handsModel:camera.transform.parent;if(root==null||root.name!="Character Root")return scope;
  if(root!=eyeBodyOwner||Time.realtimeSinceStartup>=nextEyeBodyScan){eyeBodyOwner=root;nextEyeBodyScan=Time.realtimeSinceStartup+1;eyeBodySkins=root.GetComponentsInChildren<SkinnedMeshRenderer>(true);}
  if(eyeBodySkins!=null)foreach(var r in eyeBodySkins)scope.Set(r,false);
  return scope;
 }
}}

