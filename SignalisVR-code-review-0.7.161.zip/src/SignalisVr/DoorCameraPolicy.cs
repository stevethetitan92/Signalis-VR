namespace SignalisVrTracking {
 // Door coroutines may briefly return to play between the two halves of a
 // connected door. Release each handoff as soon as native gameplay is ready.
 public sealed class DoorCameraPolicy {
  public bool Active { get; private set; }
  private float stableSince=-1f;
  public bool Observe(bool traversing,bool ready,float now) {
   if(traversing){Active=true;stableSince=-1f;return true;}
   if(!Active)return false;
   if(!ready){stableSince=-1f;return true;}
   if(stableSince<0f)stableSince=now;
   Active=false;stableSince=-1f;
   return Active;
  }
  public void Reset(){Active=false;stableSince=-1f;}
 }
}

