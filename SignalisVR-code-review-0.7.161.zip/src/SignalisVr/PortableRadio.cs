﻿using System;
using System.IO;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed class RadioPowerButton {
  private bool armed;
  public bool Update(bool active,bool pressed){if(!active){armed=false;return false;}if(!pressed){armed=true;return false;}if(!armed)return false;armed=false;return true;}
 }
 public sealed partial class Tracking {
 private const int RadioItemId=10063;
 private readonly ReceiverGripRepeat radioButtons=new ReceiverGripRepeat();
 private readonly RadioPowerButton radioPowerButton=new RadioPowerButton();
 private Texture2D radioAtlas;
 private GameObject radioPreview;
 private readonly List<Transform> radioUpParts=new List<Transform>(),radioDownParts=new List<Transform>();
 private readonly List<Vector3> radioUpRest=new List<Vector3>(),radioDownRest=new List<Vector3>();
 private readonly List<Mesh> radioTextMeshes=new List<Mesh>();
 private readonly List<string> radioTextValues=new List<string>();
 private readonly List<Transform> radioBars=new List<Transform>();
 private float radioNextDisplay,radioNextInventoryLabels;
 private IntPtr radioVisiblePreview;
 private bool IsReceiver(global::AnItem item){return item!=null&&receiverCatalog!=null&&item.Pointer==receiverCatalog.Pointer;}
 private string WheelItemId(global::AnItem item){return IsReceiver(item)?"Receiver":WeaponFamily(item._item.ToString());}
 private void InstallPortableRadio(){
  var h=new HarmonyLib.Harmony("SignalisVR.PortableRadio");
  h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryManager),"storeItem",new[]{typeof(global::AnItem),typeof(int)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(RadioStorageBegin)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(RadioStorageEnd)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryManager),"unboxItem",new[]{typeof(global::AnItem)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(RadioStorageBegin)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(RadioStorageEnd)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::RadioUI),"Update",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(ReceiverMenuObserved)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::MorseReceiver),"Update",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(HeldRadioTranscription)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::AnItem),"localizedName",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(RadioLocalizedName)));
  foreach(var name in new[]{"updateItems","initializeBox"})h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),name,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(RadioInventoryRefresh)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"Update",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(RadioInventoryDisplay)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::RadioModuleAcquirer),"getRadioModule",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(RadioInventoryRefresh)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::RadioManager),"LoadState",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(RadioLoaded)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"SaveState",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(RadioBeforeSave)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(RadioAfterSave)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"LoadState",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(RadioInventoryRefresh)));
  h.Patch(AccessTools.DeclaredMethod(typeof(global::SaveManager),"Save",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(RadioBeforeSave)),finalizer:new HarmonyMethod(typeof(Tracking),nameof(RadioAfterSave)));
 }
 private static bool RadioLocalizedName(global::AnItem __instance,ref string __result){var q=moduleOwner;if(q==null||!q.IsReceiver(__instance))return true;__result="Receiver";return false;}
 private static void RadioLoaded(){if(moduleOwner!=null){moduleOwner.ClearHeldModules();RadioInventoryRefresh();}}
 private static void RadioInventoryRefresh(){var q=moduleOwner;if(q==null)return;try{q.ReconcileRadioInventory();}catch(Exception e){MelonLoader.MelonLogger.Warning("Radio inventory: "+e.Message);}}
 private void ReconcileRadioInventory(){
  var items=global::InventoryManager.elsterItems;if(items==null||radioSaveDepth>0||radioTransferDepth>0)return;
  if(!ReceiverInstalled()){if(receiverCatalog!=null){items.Remove(receiverCatalog);if(global::InventoryManager.boxItems!=null)global::InventoryManager.boxItems.Remove(receiverCatalog);}return;}
  var item=ReceiverCatalog();EnsureReceiver();
  if(radioPreview==null){radioPreview=UnityEngine.Object.Instantiate(receiverRoot);radioPreview.name="SignalisVR_RadioInventoryModel";UnityEngine.Object.DontDestroyOnLoad(radioPreview);radioPreview.SetActive(false);radioPreview.transform.position=Vector3.zero;radioPreview.transform.localScale=Vector3.one*3f;foreach(var r in radioPreview.GetComponentsInChildren<Renderer>(true)){r.enabled=true;r.gameObject.layer=5;}}
  item.Image3D=radioPreview;
  var box=global::InventoryManager.boxItems;
  bool stored=global::SProgress.GetInt("SignalisVR.RadioStored",0)!=0;
  if(stored&&box!=null){items.Remove(item);box[item]=1;if(heldReceiver)ClearHeldModules();}
  else{items[item]=1;if(box!=null)box.Remove(item);}
 }
 private int radioTransferDepth;
 private static void RadioStorageBegin(global::AnItem __0,out bool __state){var q=moduleOwner;__state=q!=null&&q.IsReceiver(__0);if(__state)q.radioTransferDepth++;}
 private static Exception RadioStorageEnd(global::AnItem __0,bool __state,Exception __exception){
  var q=moduleOwner;if(!__state||q==null)return __exception;
  q.radioTransferDepth=Math.Max(0,q.radioTransferDepth-1);
  if(q.radioTransferDepth==0)RadioStorageChanged(__0);
  return __exception;
 }
 private static void RadioStorageChanged(global::AnItem __0){
  var q=moduleOwner;if(q==null||!q.IsReceiver(__0)||q.radioSaveDepth>0)return;
  var box=global::InventoryManager.boxItems;
  bool stored=box!=null&&box.ContainsKey(__0)&&box[__0]>0;
  global::SProgress.SetInt("SignalisVR.RadioStored",stored?1:0);
  if(stored){q.ClearHeldModules();q.RemoveEmptyWheelSlots();}

 }
 private int radioSaveDepth;
 private static void RadioBeforeSave(){var q=moduleOwner;if(q==null)return;q.radioSaveDepth++;if(q.receiverCatalog==null)return;var items=global::InventoryManager.elsterItems;if(items!=null)items.Remove(q.receiverCatalog);if(global::InventoryManager.boxItems!=null)global::InventoryManager.boxItems.Remove(q.receiverCatalog);}
 private static Exception RadioAfterSave(Exception __exception){var q=moduleOwner;if(q!=null){q.radioSaveDepth=Math.Max(0,q.radioSaveDepth-1);if(q.radioSaveDepth==0)RadioInventoryRefresh();}return __exception;}
 private static void RadioInventoryDisplay(global::InventoryBase __instance){var q=moduleOwner;if(q==null||__instance==null||!__instance.inventoryOpen)return;
  if(Time.realtimeSinceStartup>=q.radioNextInventoryLabels){q.radioNextInventoryLabels=Time.realtimeSinceStartup+.25f;foreach(var label in __instance.GetComponentsInChildren<TMPro.TextMeshProUGUI>(true)){if(label!=null&&label.text!=null&&label.text.Contains("MISSING STRING: 10063"))label.text=label.text.Replace("!MISSING STRING: 10063","RECEIVER").Replace("MISSING STRING: 10063","RECEIVER");}}
  if(!q.IsReceiver(__instance.lastItem)){q.radioVisiblePreview=IntPtr.Zero;return;}
  if(__instance.itemName!=null)__instance.itemName.text="RECEIVER";
  if(__instance.InspectObj!=null&&q.radioVisiblePreview!=__instance.InspectObj.Pointer){q.radioVisiblePreview=__instance.InspectObj.Pointer;__instance.InspectObj.gameObject.SetActive(true);foreach(var r in __instance.InspectObj.GetComponentsInChildren<Renderer>(true)){r.gameObject.layer=5;r.enabled=true;}}
  if(__instance.itemDescription!=null)__instance.itemDescription.text="Portable receiver. Equip in your left hand. Y raises the frequency; X lowers it. Left trigger switches the receiver on or off.";
  if(__instance.intMenuOn&&q.IsReceiver(__instance.intItem)&&__instance.intChoices!=null&&__instance.intChoices.Length>0){__instance.intChoices[0]=q.heldReceiver?"UNEQUIP":"EQUIP";q.DrawInventoryActions(__instance);}
 }
 // Native MorseReceiver gates decoding on the inventory game state. Extend only
 // its character decoder while held; never spoof the global camera/menu state.
 private static bool HeldRadioTranscription(global::MorseReceiver __instance){
  var q=moduleOwner;if(q==null||!q.heldReceiver||!q.ModHudGameplayReady()||global::RadioManager.instance==null||global::RadioManager.instance.Transcriber!=__instance)return true;
  var r=__instance;
  if(!global::RadioManager.tuner||!global::RadioManager.data||r.morseSource==null){r.message="";r.tick=true;r.incomplete=true;if(r.textBox!=null)r.textBox.text="[NO DATA FEED]";return false;}
  char c=r.morseSource.currentLetter;
  if(c=='*'||c=='#')r.tick=false;
  else if(!r.tick){r.tick=true;if(r.incomplete)r.incomplete=false;else{r.letter=c;r.message=(r.message??"")+c;}}
  if(c=='#'&&!r.tick){r.incomplete=false;r.message="";}
  if(r.textBox!=null)r.textBox.text=r.message??"";
  return false;
 }
 private float radioNextWarning;
 private void PollPortableRadio(bool available,QuestSample left,QuestSample right){try{PollPortableRadioCore(available,left,right);}catch(Exception e){if(Time.realtimeSinceStartup>=radioNextWarning){radioNextWarning=Time.realtimeSinceStartup+10;MelonLoader.MelonLogger.Warning("Portable radio input: "+e.Message);}}}
 private void PollPortableRadioCore(bool available,QuestSample left,QuestSample right){
  bool active=available&&heldReceiver&&ReceiverOwned()&&questPolicy.LeftArmed&&questPolicy.RightArmed&&ModHudGameplayReady()&&!quickSelect.Open&&!modMenuOpen&&!global::PlayerState.pauseMenu&&!global::PlayerState.hurt&&!global::PlayerState.grappled;
  int step=radioButtons.Update(active,left.Button(7),left.Button(1),Time.realtimeSinceStartup);
  bool toggle=radioPowerButton.Update(active,left.trigger>.55f);if(!active)return;
  questFrame.buttons&=~((1<<2)|(1<<3));
  var radio=global::RadioManager.instance;
  if(step!=0){radio._frequency=ReceiverTuning.Turn(radio._frequency,step*1.5f,radio.range.x,radio.range.y);receiverArrowDirection=step;receiverPressTime=Time.realtimeSinceStartup;}
  if(toggle){global::RadioManager.tuner=!global::RadioManager.tuner;if(radio.switchFX!=null)radio.switchFX.Play();}
 }
 private void BuildPortableReceiver(){
  receiverRoot=new GameObject("SignalisVR_HandheldReceiver");UnityEngine.Object.DontDestroyOnLoad(receiverRoot);
  radioAtlas=new Texture2D(2,2,TextureFormat.RGBA32,false);ImageConversion.LoadImage(radioAtlas,Convert.FromBase64String(HdAsset.Read("radio-atlas.png")),true);radioAtlas.filterMode=FilterMode.Point;
  var mats=new List<Material>();using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(HdAsset.Read("radio-materials.bin"))))){while(r.BaseStream.Position<r.BaseStream.Length){var c=new Color(r.ReadSingle(),r.ReadSingle(),r.ReadSingle(),r.ReadSingle());var m=new Material(Shader.Find("Sprites/Default"));m.color=c.gamma;m.mainTexture=mats.Count<8?radioAtlas:Texture2D.whiteTexture;if(mats.Count==8)m.color=new Color(.025f,.03f,.03f);mats.Add(m);moduleMaterials.Add(m);}}
  using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(HdAsset.Read("radio-model.bin"))))){int count=r.ReadInt32();for(int k=0;k<count;k++){string name=System.Text.Encoding.UTF8.GetString(r.ReadBytes(r.ReadInt32()));int mat=r.ReadInt32(),nv=r.ReadInt32(),nt=r.ReadInt32();var v=new Vector3[nv];var uv=new Vector2[nv];var t=new int[nt];for(int i=0;i<nv;i++)v[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());for(int i=0;i<nv;i++)uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());for(int i=0;i<nt;i++)t[i]=r.ReadInt32();var mesh=new Mesh{vertices=v,uv=uv,triangles=HandSurfaceTopology.DoubleSided(t)};mesh.RecalculateBounds();moduleMeshes.Add(mesh);var go=new GameObject(name);go.layer=30;go.transform.SetParent(receiverRoot.transform,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var rend=go.AddComponent<MeshRenderer>();rend.sharedMaterial=mats[mat];rend.enabled=false;moduleRenderers.Add(rend);if(name=="Frequency up button"||name=="Up arrow"){radioUpParts.Add(go.transform);radioUpRest.Add(go.transform.localPosition);}if(name=="Frequency down button"||name=="Down arrow"){radioDownParts.Add(go.transform);radioDownRest.Add(go.transform.localPosition);}}}
  RadioText("RECEIVER",.635f,.30f);RadioText("000.000 KHZ",.575f,.42f);RadioText("TUNER",.515f,.23f);
  ModulePart(receiverRoot,PrimitiveType.Cube,RadioPoint(.06875f,.245f,-.096f),new Vector3(.086f,.010f,.001f),new Color(.95f,.25f,.035f));
  RadioText("TRANSCRIPTION",.245f,.26f);for(int i=0;i<5;i++)RadioText("",.207f-i*.025f,.22f);
  for(int i=0;i<16;i++){var bar=ModulePart(receiverRoot,PrimitiveType.Cube,RadioPoint(-.075f+i*.018f,.415f,-.096f),new Vector3(.002f,.015f,.001f),new Color(.5f,.6f,.57f));radioBars.Add(bar.transform);}
 }
 private static Vector3 RadioPoint(float x,float y,float z){return new Vector3((x*.8f+.01375f-.06875f)*.32f,(y-.185f)*.32f,(z-.112f)*.32f);}
 private void RadioText(string text,float y,float scale){var go=new GameObject("Radio live text");go.layer=30;go.transform.SetParent(receiverRoot.transform,false);go.transform.localPosition=RadioPoint(.06875f,y,-.098f);go.transform.localRotation=Quaternion.Euler(0,180,0);go.transform.localScale=Vector3.one*scale/UnitsPerMetre;var mesh=new Mesh();moduleMeshes.Add(mesh);go.AddComponent<MeshFilter>().sharedMesh=mesh;EnsureGlyphAtlas();var mat=new Material(Shader.Find("Sprites/Default")){mainTexture=modGlyphAtlas,color=Color.white};moduleMaterials.Add(mat);var rend=go.AddComponent<MeshRenderer>();rend.sharedMaterial=mat;rend.enabled=false;moduleRenderers.Add(rend);string old=null;UpdateModHudText(mesh,text,ref old);radioTextMeshes.Add(mesh);radioTextValues.Add(text);}
 private void RadioTextValue(int i,string text){string old=radioTextValues[i];UpdateModHudText(radioTextMeshes[i],text,ref old);radioTextValues[i]=old;}
 private void PreparePortableReceiver(){
  float press=TriggerMotion.Amount(Time.realtimeSinceStartup-receiverPressTime);
  for(int i=0;i<radioUpParts.Count;i++)radioUpParts[i].localPosition=radioUpRest[i]+Vector3.left*(receiverArrowDirection>0?.0064f*press:0);
  for(int i=0;i<radioDownParts.Count;i++)radioDownParts[i].localPosition=radioDownRest[i]+Vector3.left*(receiverArrowDirection<0?.0064f*press:0);
  FitHandAroundBox(0,receiverRoot.transform,RadioPoint(.06875f,.20f,0),new Vector3(.1056f,.115f,.055f));
  FitFingerToContact(0,"thumb",receiverRoot.transform.TransformPoint(RadioPoint(.337f-.025f*press,receiverArrowDirection>0?.56f:.425f,-.02f)),8);
  if(Time.realtimeSinceStartup<radioNextDisplay)return;radioNextDisplay=Time.realtimeSinceStartup+.05f;
  var radio=global::RadioManager.instance;if(radio==null)return;
  RadioTextValue(1,radio._frequency.ToString("F3",System.Globalization.CultureInfo.InvariantCulture)+" KHZ");RadioTextValue(2,global::RadioManager.tuner?"TUNER ON":"TUNER OFF");
  string message=global::RadioManager.tuner&&radio.Transcriber!=null&&radio.Transcriber.textBox!=null?radio.Transcriber.textBox.text:"[NO DATA FEED]";
  message=System.Text.RegularExpressions.Regex.Replace(message??"","<[^>]*>","").Replace('\n',' ');if(message.Length>100)message=message.Substring(message.Length-100);
  for(int i=0;i<5;i++){int start=i*20;RadioTextValue(4+i,start<message.Length?message.Substring(start,Math.Min(20,message.Length-start)):"");}
  for(int i=0;i<radioBars.Count;i++){float level=global::RadioManager.tuner&&radio.bandBuffer!=null&&radio.bandBuffer.Length>0?radio.bandBuffer[i%radio.bandBuffer.Length]:0;radioBars[i].localScale=new Vector3(.002f,.002f+Mathf.Clamp01(level)*.028f,.001f);}
 }
 private void DestroyPortableRadio(){radioButtons.Update(false,false,false,0);radioPowerButton.Update(false,false);if(radioPreview!=null)UnityEngine.Object.Destroy(radioPreview);radioPreview=null;if(radioAtlas!=null)UnityEngine.Object.Destroy(radioAtlas);radioAtlas=null;radioUpParts.Clear();radioDownParts.Clear();radioUpRest.Clear();radioDownRest.Clear();radioTextMeshes.Clear();radioTextValues.Clear();radioBars.Clear();}
} }


