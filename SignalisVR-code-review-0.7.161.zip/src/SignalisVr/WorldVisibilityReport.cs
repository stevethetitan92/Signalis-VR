using System;
using System.Text;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static string ReportObjectPath(Transform t){string path=t.name;int depth=0;for(var p=t.parent;p!=null&&depth++<12;p=p.parent)path=p.name+"/"+path;return path;}
 private static void ReportWorldRenderer(StringBuilder b,Renderer r){
  b.AppendLine("# worldRenderer path="+ReportObjectPath(r.transform)+" enabled="+r.enabled+" veto="+r.forceRenderingOff+" active="+r.gameObject.activeInHierarchy+" layer="+r.gameObject.layer+" boundsCenter="+ReportVector(r.bounds.center)+" boundsSize="+ReportVector(r.bounds.size));
  int count=0;foreach(var m in r.sharedMaterials){if(count++>=8)break;if(m!=null)b.AppendLine("# worldMaterial name="+m.name+" shader="+(m.shader==null?"none":m.shader.name)+" texture="+(m.mainTexture==null?"none":m.mainTexture.name)+" queue="+m.renderQueue+" amount="+(m.HasProperty("_Amount")?m.GetFloat("_Amount").ToString():"absent"));}
 }
 private void AppendWorldVisibilityReport(StringBuilder b){
  // Request-time evidence only: never run these global scans in an eye render or every frame.
  try{
   var fx=global::EnemyFXOption.instance;
   b.AppendLine("# enemyFx complex="+global::EnemyFXOption.ComplexEnemyFX+" instance="+(fx!=null));
   if(fx!=null){
    var main=fx.MainCam;
    b.AppendLine("# enemyFx main="+(main==null?"none":ReportObjectPath(main.transform)+" enabled="+main.isActiveAndEnabled+" mask="+main.cullingMask+" isPlayerCamera="+(main==global::PlayerState.cameraMain)));
    if(fx.EnemyCam!=null){b.AppendLine("# enemyFx auxiliary="+ReportObjectPath(fx.EnemyCam.transform)+" active="+fx.EnemyCam.activeInHierarchy);int cams=0;foreach(var c in fx.EnemyCam.GetComponentsInChildren<Camera>(true)){if(cams++>=4)break;b.AppendLine("# enemyFx camera="+c.name+" enabled="+c.isActiveAndEnabled+" mask="+c.cullingMask+" target="+(c.targetTexture==null?"screen":c.targetTexture.name));}}
   }
   int count=0;
   foreach(var p in Resources.FindObjectsOfTypeAll<global::ItemPickup>()){
    if(p==null||!p.gameObject.scene.IsValid())continue;
    // Include loaded inactive rooms: a report taken after leaving the office
    // must still expose its missing pickups. Never activate them for inspection.
    var room=MapOwner(p.transform);
    if(count++>=512){b.AppendLine("# pickup report truncated at512");break;}
    var uid=p.GetComponent<global::UniqueId>();
    b.AppendLine("# pickupSave id="+(uid==null?"none":uid.id)+" exists="+(uid==null||string.IsNullOrEmpty(uid.id)?"unknown":global::SProgress.GetBool("exists: "+uid.id,true).ToString()));
    int ancestry=0;for(var ancestor=p.transform;ancestor!=null&&ancestry++<12;ancestor=ancestor.parent)if(!ancestor.gameObject.activeSelf)b.AppendLine("# pickupInactiveAncestor path="+ReportObjectPath(ancestor));
    b.AppendLine("# pickup path="+ReportObjectPath(p.transform)+" room="+(room==null?"unknown":room.name)+" currentRoom="+(room!=null&&MapSameRoom(room,global::PlayerState.currentRoom))+" position="+ReportVector(p.transform.position)+" item="+(p._item==null?"unresolved (fallback="+p._itemEnum+")":p._item._item.ToString())+" active="+p.gameObject.activeInHierarchy+" localActive="+p.gameObject.activeSelf+" enabled="+p.enabled+" triggered="+p.triggered+" fading="+p.fadingOut+" interaction="+(p.inter==null?"none":p.inter.enabled+":"+p.inter.triggered));
    int parts=0;foreach(var r in p.GetComponentsInChildren<Renderer>(true)){if(parts++>=12)break;if(r!=null)ReportWorldRenderer(b,r);}
   }
   count=0;
   foreach(var e in Resources.FindObjectsOfTypeAll<global::EnemyController>()){
    if(e==null||!e.gameObject.scene.IsValid())continue;
    var room=MapOwner(e.transform);if(room!=null&&global::PlayerState.currentRoom!=null&&!MapSameRoom(room,global::PlayerState.currentRoom))continue;
    if(count++>=32){b.AppendLine("# enemy report truncated at32");break;}
    b.AppendLine("# worldEnemy path="+ReportObjectPath(e.transform)+" active="+e.gameObject.activeInHierarchy+" state="+e.state+" burning="+(e.BurnEffect!=null&&e.BurnEffect.burning));
    int parts=0;foreach(var r in e.GetComponentsInChildren<SkinnedMeshRenderer>(true)){if(parts++>=12)break;if(r==null)continue;ReportWorldRenderer(b,r);b.AppendLine("# skin mesh="+(r.sharedMesh==null?"none":r.sharedMesh.name)+" offscreenUpdate="+r.updateWhenOffscreen);}
   }
   count=0;foreach(var v in Resources.FindObjectsOfTypeAll<global::InventoryBase>()){
    if(v==null||!v.gameObject.scene.IsValid())continue;if(count++>=8)break;
    b.AppendLine("# inventory path="+ReportObjectPath(v.transform)+" active="+v.gameObject.activeInHierarchy+" enabled="+v.enabled+" inventoryOpen="+v.inventoryOpen+" menu="+v.intMenuOn+" store="+global::InventoryBase.storeMode+" eligible="+InventoryWheelEligible(v)+" selected="+(v.lastItem==null?"none":v.lastItem._item.ToString())+" actionItem="+(v.intItem==null?"none":v.intItem._item.ToString())+" text="+(v.IntMenuText==null?"none":v.IntMenuText.text.Replace('\n','|')));
   }
  }catch(Exception ex){b.AppendLine("# world visibility report partial: "+ex.Message);}
 }
}}

