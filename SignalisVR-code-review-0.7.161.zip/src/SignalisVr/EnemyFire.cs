using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private void BeginEnemyFire(global::EnemyController enemy){BeginNativeEnemyFire(enemy);}
 // Native enemy coroutines own burn timing, animation, damage and cleanup.
 private void PollEnemyFire(){PollLivingBurns();}
 private void DestroyEnemyFire(){DestroyLivingBurns();if(flareContactMesh!=null)UnityEngine.Object.Destroy(flareContactMesh);flareContactMesh=null;}
}}

