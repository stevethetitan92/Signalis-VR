namespace SignalisVrTracking {
 public sealed class SprintTogglePolicy {
  private bool held,pending,sprinting;
  public void Reset(){held=pending=sprinting=false;}
  public bool Update(bool eligible,bool left,bool right){
   if(!eligible){Reset();held=left;return false;}
   // Commit on click release so a both-stick menu chord cannot toggle sprint.
   if(left&&!held)pending=!right;
   if(right)pending=false;
   if(!left&&held){if(pending)sprinting=!sprinting;pending=false;}
   held=left;return sprinting;
  }
 }
}
