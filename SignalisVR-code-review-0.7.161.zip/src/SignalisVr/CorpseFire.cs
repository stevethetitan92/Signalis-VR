using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Mesh flareContactMesh;
 private static bool FireEnemyValid(global::EnemyController e){return e!=null&&e.gameObject.activeInHierarchy&&e.hitbox!=null;}
 private float FlareMeshContact(Vector3 from,Vector3 to,Mesh mesh,Transform frame){var v=mesh.vertices;var t=mesh.triangles;var mat=frame.localToWorldMatrix;for(int i=0;i<v.Length;i++)v[i]=mat.MultiplyPoint3x4(v[i]);float best=1;for(int i=0;i+2<t.Length;i+=3)best=Math.Min(best,ProdSurfaceGeometry.Segment(from,to,v[t[i]],v[t[i+1]],v[t[i+2]]));return best;}
 private float FindFlareBodyContact(Vector3 from,Vector3 to,int mask,out global::EnemyController enemy,out Vector3 point){
  enemy=null;point=to;float best=1;var seen=new HashSet<IntPtr>();
  foreach(var c in Physics.OverlapCapsule(from,to,.006f*UnitsPerMetre,mask,QueryTriggerInteraction.Collide)){
   if(c==null)continue;var e=c.GetComponentInParent<global::EnemyController>();if(!FireEnemyValid(e)||!seen.Add(e.Pointer))continue;
   if(OwnsTestEnemy(e)){foreach(var copy in testBodyCopies)if(copy.View!=null&&copy.View.enabled){float f=FlareMeshContact(from,to,copy.Mesh,copy.View.transform);if(f<best){best=f;enemy=e;}}continue;}
   foreach(var skin in e.GetComponentsInChildren<SkinnedMeshRenderer>(true)){
    if(!skin.enabled||!skin.gameObject.activeInHierarchy||skin.sharedMesh==null)continue;
    bool body=false;foreach(var m in skin.sharedMaterials)if(m!=null&&m.shader!=null)body|=TestEnemyMaterialPolicy.Body(m.shader.name,m.GetTag("RenderType",false,""),m.renderQueue,m.mainTexture!=null);if(!body)continue;
    if(flareContactMesh==null)flareContactMesh=new Mesh();skin.BakeMesh(flareContactMesh);
    float fraction=FlareMeshContact(from,to,flareContactMesh,skin.transform);if(fraction<best){best=fraction;enemy=e;}
   }
  }
  point=Vector3.Lerp(from,to,best);return (point-from).magnitude;
 }
}}


