using System;
using System.Reflection;
using HarmonyLib;
using MelonLoader;
namespace SignalisVrTracking {
 internal static class MarkerLifecycle {
  private static HarmonyLib.Harmony hooks;
  private static bool callbackFailed;
  internal static void Install() {
   if(hooks!=null)return;
   try {
    hooks=new HarmonyLib.Harmony("signalis.vr.marker.registry");
    Patch(typeof(global::DoorInteractionPopup),"OnEnable",nameof(DoorReady));
    Patch(typeof(global::DoorInteractionPopup),"Update",nameof(DoorReady));
    Patch(typeof(global::Ladder),"OnEnable",nameof(LadderReady));
    Patch(typeof(global::Ladder),"Update",nameof(LadderReady));
    Patch(typeof(global::interactionPopup),"OnEnable",nameof(PopupReady));
    Patch(typeof(global::interactionPopup),"Start",nameof(PopupReady));
    Patch(typeof(global::interactionPopup),"Update",nameof(PopupReady));
    Patch(typeof(global::DoorInteractionPopup),"OnEnable",nameof(ArtworkReady));
    Patch(typeof(global::Ladder),"OnEnable",nameof(ArtworkReady));
    MarkerSuppression.EnableRegistry(true);
    MelonLogger.Msg("MARKER REGISTRY: all world prompts hidden; cached artwork, lifecycle registration and 5s fallback. Interactions and minimap unchanged.");
   }catch(Exception ex) {
    MarkerSuppression.EnableRegistry(false);
    // Partially installed registration callbacks are harmless with full-scan fallback.
    MelonLogger.Warning("MARKER REGISTRY: retaining per-frame discovery: "+ex.Message);
   }
  }
  private static void Patch(Type type,string method,string callback) {
   var target=AccessTools.DeclaredMethod(type,method,Type.EmptyTypes);
   if(target==null)throw new MissingMethodException(type.FullName,method);
   hooks.Patch(target,postfix:new HarmonyMethod(typeof(MarkerLifecycle),callback));
  }
  private static void DoorReady(global::DoorInteractionPopup __instance) {
   try {MarkerSuppression.RegisterDoor(__instance);}catch(Exception ex) {Fallback(ex);}
  }
  private static void ArtworkReady() {MarkerSuppression.RefreshArtwork();}
  private static void PopupReady(global::interactionPopup __instance) {
   try {MarkerSuppression.RegisterPopup(__instance);}catch(Exception ex) {Fallback(ex);}
  }
  private static void LadderReady(global::Ladder __instance) {
   try {MarkerSuppression.RegisterLadder(__instance);}catch(Exception ex) {Fallback(ex);}
  }
  private static void Fallback(Exception ex) {
   MarkerSuppression.EnableRegistry(false);
   if(!callbackFailed)MelonLogger.Warning("MARKER REGISTRY: callback failed; per-frame discovery restored: "+ex.Message);
   callbackFailed=true;
  }
 }
}
