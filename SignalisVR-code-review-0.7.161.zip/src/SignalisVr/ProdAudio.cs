using System;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private PackAudio prodLoopSound,prodContactSound;private bool prodAudioFailed,prodHitFailed,prodTouchAudio;
 private string prodAudioState;
 private void SetProdContactAudio(bool touching){prodTouchAudio=touching;if(!touching){if(prodContactSound!=null)prodContactSound.Stop();return;}PollProdAudio();}
 private void StopProdAudio(){prodTouchAudio=false;if(prodLoopSound!=null)prodLoopSound.Stop();if(prodContactSound!=null)prodContactSound.Stop();}
 private void PollProdAudio(){
  string state=!ProdPowered()?"not powered":modMenuOpen?"mod menu":pauseMenuVisible?"visible pause":!WeaponGameplayReady()?"inventory/menu":global::PlayerState.pauseMenu?"pause flag":global::PlayerState.paused?"paused":"playing";
  if(state!=prodAudioState){prodAudioState=state;MelonLoader.MelonLogger.Msg("PROD AUDIO: "+state);}
  if(state!="playing"){StopProdAudio();return;}
  if(!prodAudioFailed)try{if(prodLoopSound==null)prodLoopSound=new PackAudio(Convert.FromBase64String(ProdAudioData.Pcm),ProdAudioData.Rate);prodLoopSound.SpatialLoop(AudioRelative(prodRoot!=null?prodRoot.transform.TransformPoint(new UnityEngine.Vector3(0,0,.270f)):rightWeaponPosition),.35f);}
  catch(Exception e){prodAudioFailed=true;MelonLoader.MelonLogger.Warning("Prod equipped FMOD loop: "+e.Message);}
  if(prodTouchAudio&&!prodHitFailed)try{if(prodContactSound==null)prodContactSound=new PackAudio(Convert.FromBase64String(ProdHitData.Pcm),ProdHitData.Rate);prodContactSound.SpatialLoop(AudioRelative(prodRoot!=null?prodRoot.transform.TransformPoint(new UnityEngine.Vector3(0,0,.270f)):rightWeaponPosition),.55f);}
  catch(Exception e){prodHitFailed=true;MelonLoader.MelonLogger.Warning("Prod contact FMOD loop: "+e.Message);}
 }
 private void DestroyProdAudio(){StopProdAudio();if(prodLoopSound!=null)prodLoopSound.Dispose();if(prodContactSound!=null)prodContactSound.Dispose();prodLoopSound=prodContactSound=null;prodAudioFailed=prodHitFailed=false;}
} }


