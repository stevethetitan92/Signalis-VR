using System;
using System.IO;
namespace SignalisVrTracking {
 internal static class HdAsset {
  internal static string Read(string name){
   using(var source=typeof(HdAsset).Assembly.GetManifestResourceStream("SignalisVR.HD."+name)){
    if(source==null)throw new InvalidDataException("Missing HD asset: "+name);
    using(var data=new MemoryStream()){source.CopyTo(data);return Convert.ToBase64String(data.ToArray());}
   }
  }
 }
}
