using System;
using HarmonyLib;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private global::AnWeapon smgReadyWeapon;
  private bool smgStartPending;
  private static bool ManualNativeReloadGuard(){
   var q=weaponOwner;if(q==null||!q.manualReloadEnabled||!q.ProdVrMode())return true;
   var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null)return true;
   return false;
  }
  private static bool TimeForReload(int until){return until>=0&&UnityEngine.Time.frameCount<=until;}
  private static void ApplySmgStats(){ApplyShotgunCapacity();var catalog=global::InventoryManager.allWeapons;if(catalog!=null&&catalog.ContainsKey(global::Items.itemlist.Pistol))catalog[global::Items.itemlist.Pistol].MagSize=12;var pistol=global::InventoryManager.EquippedWeapon;if(pistol!=null&&pistol.parentItem!=null&&pistol.parentItem._item==global::Items.itemlist.Pistol)pistol.MagSize=12;var all=global::InventoryManager.allWeapons;if(all!=null&&all.ContainsKey(global::Items.itemlist.SMG))ConfigureSmg(all[global::Items.itemlist.SMG]);var equipped=global::InventoryManager.EquippedWeapon;if(equipped!=null&&equipped.parentItem!=null&&equipped.parentItem._item==global::Items.itemlist.SMG)ConfigureSmg(equipped);
   var q=weaponOwner;var a=global::PlayerAttack.instance;
   if(a!=null&&a.weapon!=null&&a.weapon.parentItem!=null&&a.weapon.parentItem._item==global::Items.itemlist.SMG)ConfigureSmg(a.weapon);
   if(equipped==null||equipped.parentItem==null||equipped.parentItem._item!=global::Items.itemlist.SMG){if(q!=null){q.smgReadyWeapon=null;q.smgStartPending=false;}return;}
   bool held=false;
   bool ready=q!=null&&q.WeaponGameplayReady()&&!q.modMenuOpen&&a!=null&&a.weapon==equipped&&a.aiming&&!a.melee&&!global::PlayerState.reloading&&!global::PlayerAttack.reloading&&!q.ManualReloadBlocksAttack()&&equipped.magAmmo>0;
   if(ready){
    if(q.smgReadyWeapon!=equipped){q.smgReadyWeapon=equipped;q.smgStartPending=true;}
    if(q.ProdVrMode())held=q.ControllerWeaponReady()&&(q.questFrame.buttons&(1<<6))!=0;
    else {var input=global::PlayerState.input;held=input!=null&&input.player!=null&&input.player.GetButton("Attack");}
   }
   else if(q!=null){q.smgReadyWeapon=null;q.smgStartPending=false;}
   if(held){global::PlayerAttack.burst=1;
    // A held trigger can predate equip/reload completion, so there may be no
    // fresh button-down for ReadyForAttack. Prime the native burst path once
    // when the weapon becomes ready, then leave burstTimer to native cadence.
    if(q.smgStartPending){a.burstTimer=Math.Max(a.burstTimer,equipped.burstSpeed+.001f);q.smgStartPending=false;}
    // Native Update only advances automatic burst fire while this timer is positive.
    // Keep an already-started volley in that path; native burstSpeed still controls shots.
    a.timer=Math.Max(a.timer,Math.Max(.02f,equipped.burstSpeed)+.05f);
   }
   else global::PlayerAttack.burst=0;
  }
  private static void ApplyShotgunCapacity(){
   var all=global::InventoryManager.allWeapons;
   if(all!=null&&all.ContainsKey(global::Items.itemlist.Shotgun))ConfigureShotgunCapacity(all[global::Items.itemlist.Shotgun]);
   ConfigureShotgunCapacity(global::InventoryManager.EquippedWeapon);
   var attack=global::PlayerAttack.instance;if(attack!=null)ConfigureShotgunCapacity(attack.weapon);
  }
  private static void ConfigureShotgunCapacity(global::AnWeapon weapon){
   if(weapon!=null&&weapon.parentItem!=null&&weapon.parentItem._item==global::Items.itemlist.Shotgun)weapon.MagSize=7;
  }
  private static void ConfigureSmg(global::AnWeapon weapon){if(weapon==null)return;weapon.fullAuto=true;weapon.burstSize=1;weapon.MagSize=25;if(weapon.magAmmo>25)weapon.magAmmo=25;}
  private void InstallSmgStats(HarmonyLib.Harmony h){var prefix=new HarmonyMethod(typeof(Tracking),nameof(ApplySmgStats));foreach(string method in new[]{"Update","ReadyForAttack"})h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),method,Type.EmptyTypes),prefix:prefix);}
 }
}



