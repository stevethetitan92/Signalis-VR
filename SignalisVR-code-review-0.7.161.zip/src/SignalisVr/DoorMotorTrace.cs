using System;
using System.Reflection;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private int doorMotorTraceCount;
  private bool doorMotorTracing;
  private float doorMotorNext,doorMotorUntil;
  private static void DoorMotorBefore(global::AlternatePlayerController __instance) {if(questOwner!=null)questOwner.TraceDoorMotor(__instance,"before native motor");}
  private static void DoorMotorAfter(global::AlternatePlayerController __instance) {if(questOwner!=null)questOwner.TraceDoorMotor(__instance,"after native motor");}
  private static void DoorLinkBegin(global::ConnectedDoors __instance) {if(questOwner!=null)questOwner.TraceDoorLink(__instance);}
  private void InstallDoorMotorTrace() {
   // Read-only observers on three unique native bodies inspected in this game.
   // Do not patch folded getters or write traversal/input/physics state.
   try {
    IntPtr gameBase=IntPtr.Zero;
    foreach(System.Diagnostics.ProcessModule m in System.Diagnostics.Process.GetCurrentProcess().Modules)
     if(string.Equals(m.ModuleName,"GameAssembly.dll",StringComparison.OrdinalIgnoreCase))gameBase=m.BaseAddress;
    if(gameBase==IntPtr.Zero)throw new InvalidOperationException("GameAssembly unavailable");
    foreach(var entry in new[]{new object[]{typeof(global::AlternatePlayerController),"Update",0x876FF0L},new object[]{typeof(global::ConnectedDoors),"StartA",0x2D2060L},new object[]{typeof(global::ConnectedDoors),"StartB",0x2D22C0L}}) {
     var type=(Type)entry[0];var name=(string)entry[1];FieldInfo field=null;
     foreach(var f in type.GetFields(BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public))if(f.Name.StartsWith("NativeMethodInfoPtr_"+name+"_")&&f.Name.EndsWith("_Void_0")){if(field!=null)throw new InvalidOperationException("Ambiguous motor method");field=f;}
     if(field==null||QuestNativeAddress(type,field.Name).ToInt64()-gameBase.ToInt64()!=(long)entry[2])throw new InvalidOperationException("Door motor trace layout differs");
    }
    questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::AlternatePlayerController),"Update",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(DoorMotorBefore)),postfix:new HarmonyMethod(typeof(Tracking),nameof(DoorMotorAfter)));
    foreach(var name in new[]{"StartA","StartB"})questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::ConnectedDoors),name,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(DoorLinkBegin)));
    MelonLogger.Msg("DOOR MOTOR TRACE: read-only native before/after and actual endpoint observers installed; diagnostic build, not a verified door fix.");
   }catch(Exception ex){MelonLogger.Warning("Door motor trace unavailable: "+ex.Message);}
  }
  private string DoorPoint(global::AutoTraverseDoor d) {
   if(d==null)return "<none>";
   return d.name+" entry="+(d.A==null?"none":FormatMarkerVector(d.A.position))+" exit="+(d.B==null?"none":FormatMarkerVector(d.B.position))+" traversing="+d.traversing+" BA="+d.BA;
  }
  private void TraceDoorLink(global::ConnectedDoors link) {
   if(!active||!stereo||doorMotorTraceCount>=400||link==null)return;
   try{doorMotorUntil=Time.realtimeSinceStartup+5f;MelonLogger.Msg("DOOR LINK: "+link.name+" A="+DoorPoint(link.A)+" B="+DoorPoint(link.B));}
   catch(Exception ex){MelonLogger.Warning("Door endpoint observation failed: "+ex.Message);}
  }
  private void TraceDoorMotor(global::AlternatePlayerController control,string phase) {
   if(!active||!stereo||doorMotorTraceCount>=400||control==null||questFpMod==null||questFpPlayer==null)return;
   try {
    var owned=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
    if(owned==null||owned.Pointer!=control.Pointer)return;
    float now=Time.realtimeSinceStartup;
    bool traversing=control.traversing||global::PlayerState.gameState==global::PlayerState.gameStates.traversing;
    if(traversing)doorMotorUntil=now+1f;
    bool sample=now<doorMotorUntil;
    // Take a matched before/after pair at most 20 times per second. The first
    // traversal frame and one second after it ends remain observable.
    if(phase=="before native motor") {
     doorMotorTracing=sample&&(now>=doorMotorNext);
     if(!doorMotorTracing)return;doorMotorNext=now+.05f;
    }else if(!doorMotorTracing)return;
    doorMotorTraceCount++;
    var root=global::PlayerState.player;
    var model=questFpModel==null?null:questFpModel.GetValue(questFpMod) as GameObject;
    var body=model==null?null:model.GetComponent<Rigidbody>();
    var character=control.character;
    var animator=character==null?null:character.m_Animator;
    MelonLogger.Msg("DOOR MOTOR: "+phase+" frame="+Time.frameCount+" state="+global::PlayerState.gameState+" traversing="+control.traversing+" playing="+control.playing
     +" root="+(root==null?"none":root.name+FormatMarkerVector(root.transform.position))+" control="+FormatMarkerVector(control.transform.position)+" local="+FormatMarkerVector(control.transform.localPosition)
     +" camera="+(camera==null?"none":FormatMarkerVector(camera.transform.position))+" model="+(model==null?"none":FormatMarkerVector(model.transform.position)+" rotation="+FormatMarkerVector(model.transform.eulerAngles))
     +" body="+(body==null?"none":FormatMarkerVector(body.position)+" velocity="+FormatMarkerVector(body.velocity)+" interpolation="+body.interpolation+" kinematic="+body.isKinematic)
     +" override="+global::PlayerState.overrideInput+" input="+control.input+" lastPos="+control.lastPos+" fAngle="+control.fAngle+" fpYaw="+questFpYaw.GetValue(questFpMod)+" calibration="+(calibrationRoot!=null)
     +" animator="+(animator==null?"none":"enabled="+animator.enabled+" culling="+animator.cullingMode+" delta="+FormatMarkerVector(animator.deltaPosition))
     +" character="+(character==null?"none":"movie="+FormatMarkerVector(character.movie)+" move="+FormatMarkerVector(character._move)+" extraSpeed="+character.extraSpeed+" extraY="+character.extraYSpeed+" rootSpeed="+character.RootSpeed)
     +" stamina="+global::PlayerAttack.Stamina+" dt="+Time.deltaTime);
   }catch(Exception ex){doorMotorTraceCount=400;MelonLogger.Warning("Door motor observation stopped: "+ex.Message);}
  }
 }
}
