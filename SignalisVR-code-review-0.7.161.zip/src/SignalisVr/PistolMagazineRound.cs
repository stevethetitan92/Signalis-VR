using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Mesh selectedLoadedMagazine;private Material selectedRoundBrass,selectedRoundCopper;
  private void EnsurePistolMagazineRound(){
   if(selectedLoadedMagazine!=null)return;
   var mesh=selectedHeldMagazine;var b=mesh.bounds;var vertices=new List<Vector3>();foreach(var p in mesh.vertices)vertices.Add(p);
   var cases=new List<int>();var tips=new List<int>();float z=0;int samples=0;
   foreach(var p in mesh.vertices)if(p.y>b.max.y-.01f){z+=p.z;samples++;}z=samples>0?z/samples:b.center.z;
   var top=HdPistolData.MagazineTop-selectedMagazine.GetComponent<MeshFilter>().sharedMesh.bounds.center;z=top.z;
   float radius=Math.Min(.004f,b.size.x*.32f),y=b.max.y-radius*.6f;
   Cartridge(vertices,cases,new Vector3(b.center.x,y,z-.012f),new Vector3(b.center.x,y,z+.007f),radius,radius);
   Cartridge(vertices,tips,new Vector3(b.center.x,y,z+.007f),new Vector3(b.center.x,y,z+.014f),radius,radius,.35f);
   selectedLoadedMagazine=new Mesh();selectedLoadedMagazine.name="BerettaMagazineWithRound";selectedLoadedMagazine.vertices=vertices.ToArray();
   var uv=new Vector2[vertices.Count];var originalUV=mesh.uv;for(int i=0;i<originalUV.Length;i++)uv[i]=originalUV[i];selectedLoadedMagazine.uv=uv;
   selectedLoadedMagazine.subMeshCount=3;selectedLoadedMagazine.SetTriangles(mesh.triangles,0);selectedLoadedMagazine.SetTriangles(HandSurfaceTopology.DoubleSided(cases.ToArray()),1);selectedLoadedMagazine.SetTriangles(HandSurfaceTopology.DoubleSided(tips.ToArray()),2);selectedLoadedMagazine.RecalculateNormals();selectedLoadedMagazine.RecalculateBounds();
   selectedRoundBrass=new Material(Shader.Find("Unlit/Color"));selectedRoundBrass.color=new Color(.68f,.48f,.19f);selectedRoundCopper=new Material(Shader.Find("Unlit/Color"));selectedRoundCopper.color=new Color(.63f,.31f,.17f);
  }
  private void DestroyPistolMagazineRound(){if(selectedLoadedMagazine!=null)UnityEngine.Object.Destroy(selectedLoadedMagazine);if(selectedRoundBrass!=null)UnityEngine.Object.Destroy(selectedRoundBrass);if(selectedRoundCopper!=null)UnityEngine.Object.Destroy(selectedRoundCopper);selectedLoadedMagazine=null;selectedRoundBrass=selectedRoundCopper=null;}
 }
}

