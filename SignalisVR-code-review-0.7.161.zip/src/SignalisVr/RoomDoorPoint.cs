using System;
namespace SignalisVrTracking {
 public static class RoomDoorPoint {
  // Native door glyph roots may be deliberately outside the room artwork.
  // Anchor the hologram glyph to the nearest wall, retaining its along-wall position.
  public static void Edge(double x,double y,double left,double bottom,double right,double top,out double u,out double v) {
   u=x;v=y;if(right<=left||top<=bottom)return;
   u=Math.Max(left,Math.Min(right,x));v=Math.Max(bottom,Math.Min(top,y));
   if(x<left||x>right||y<bottom||y>top)return;
   double a=Math.Abs(x-left),b=Math.Abs(x-right),c=Math.Abs(y-bottom),d=Math.Abs(y-top);
   double nearest=Math.Min(Math.Min(a,b),Math.Min(c,d));
   if(nearest==a)u=left;else if(nearest==b)u=right;else if(nearest==c)v=bottom;else v=top;
  }
 }
}
