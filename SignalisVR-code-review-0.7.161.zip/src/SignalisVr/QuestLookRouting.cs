using System;
using UnityEngine;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private string questLookGate="not sampled",questLookConsumer="none";
 private float nextQuestLookLog;private int questLookConsumedFrame=-1;
 private string QuestLookBlocker(bool eventCamera) {
  if(!QuestAvailableNow())return "VR focus/input unavailable";
  if(!questPolicy.RightArmed)return "right hand awaiting neutral/reconnect";
  if(modMenuOpen)return "mod menu";
  if(quickSelect.Open)return "item wheel";
  var state=global::PlayerState.gameState;
  if(global::PlayerState.gameOver||global::PlayerState.hp<=0)return "death";
  if(state==global::PlayerState.gameStates.paused||state==global::PlayerState.gameStates.menu||state==global::PlayerState.gameStates.inventory||state==global::PlayerState.gameStates.book||state==global::PlayerState.gameStates.loading)return "native screen: "+state;
  if(state==global::PlayerState.gameStates.dialogue)return "dialogue";
  if(global::BlackSleekGuiSubs.itemView)return "item inspection";
  if(eventCamera)return state==global::PlayerState.gameStates.eventScreen?null:"event camera not active";
  if(state!=global::PlayerState.gameStates.play)return "native state: "+state;
  if(global::PlayerState.cutscene)return "native cutscene";
  if(global::PlayerState.suspendInput)return "native input suspended";
  if(DoorCameraBlocked())return "door camera handoff";
  if(!questFpPatched||questFpMod==null||questFpPlayer==null||questFpModel==null)return "first-person adapter unavailable";
  var player=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
  if(player==null||!player.playing||player.traversing)return "player not ready/traversing";
  if(questFpModel.GetValue(questFpMod) as GameObject==null)return "first-person model unavailable";
  return null;
 }
 private void TraceQuestLook(float rawX,float rawY,bool connected) {
  bool native=global::PlayerState.gameState==global::PlayerState.gameStates.eventScreen;
  string gate=QuestLookBlocker(native)??(native?"accepted: native event Peek":"accepted: first-person mouse axes");
  if(!connected)gate="right controller unavailable";
  if(gate==questLookGate&&Time.realtimeSinceStartup<nextQuestLookLog)return;
  questLookGate=gate;nextQuestLookLog=Time.realtimeSinceStartup+1f;
  MelonLoader.MelonLogger.Msg("VR LOOK: rawXY="+rawX+","+rawY+" routedXY="+questFrame.lookX+","+questFrame.lookY+" gate="+gate+" consumer="+questLookConsumer+" framesSinceConsumed="+(Time.frameCount-questLookConsumedFrame)+" state="+global::PlayerState.gameState+" legacyDialogue="+dialogueScreenVisible+" legacyPause="+pauseMenuVisible+" eventContext="+nativeEventContext+" recoveryPaused="+recovery.Paused+" suspend="+global::PlayerState.suspendInput+" cutscene="+global::PlayerState.cutscene);
 }
 private void QuestLookConsumed(string consumer){questLookConsumer=consumer;questLookConsumedFrame=Time.frameCount;}
}}
