using UnityEngine;
namespace SignalisVrTracking {
 public static class HeadPosition {
  // Metres relative to recenter, mapped through the same basis as head rotation.
  // Never rotate displacement by the live head orientation or modify the player body.
  public static Vector3 Map(Vector3 origin,Quaternion trackingToWorld,Vector3 tracked,Vector3 neutral,float unitsPerMetre) {
   return origin + trackingToWorld * ((tracked-neutral)*unitsPerMetre);
  }
 }
}
