# 0.7.161 code-review snapshot

Current project logic and native bridge source, captured October 9, 2026. Project-owned code is GPL-3.0-only; vendor code retains its notices. See repository LICENSE and THIRD_PARTY_NOTICES.md.

This archive is deliberately incomplete and cannot build standalone. OMITTED-ASSET-SOURCES.txt lists excluded payload/data/artwork sources; the original source-files.txt manifest is preserved for context. No models, texture/audio resources, DLLs, proprietary game assemblies, saves, personal settings or raw runtime logs are included. Tests reported in automated-check-results.json were run against the complete local candidate, not this reduced archive.

See STATUS-2026-10-09.md for user observations, candidate hashes, installation requirements and remaining validation. The 110 automated checks and matching deterministic builds do not establish graphics stability or smooth movement.
