using System;
using System.Text;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {public sealed partial class Tracking {
 internal const string DiagnosticVersion="0.7.26";
 private readonly ReportShortcut reportShortcut=new ReportShortcut();
 private int reportHapticPulses;
 private double nextReportHaptic;
 private void PollReportShortcut(bool available,bool grip,bool y){
  bool report=reportShortcut.Update(available,grip,y);
  if(reportShortcut.Consume)questFrame.buttons&=~(1<<3);
  if(report)RequestProblemReport("manual-Quest-left-grip-Y");
 }
 private void PollReportHaptics(double now){
  if(reportHapticPulses<=0||now<nextReportHaptic)return;
  reportHapticPulses--;nextReportHaptic=now+.18;
  try{if(system==null||!questAvailabilityValue)return;
   foreach(var role in new[]{Valve.VR.ETrackedControllerRole.LeftHand,Valve.VR.ETrackedControllerRole.RightHand}){
    uint id=system.GetTrackedDeviceIndexForControllerRole(role);
    if(id!=Valve.VR.OpenVR.k_unTrackedDeviceIndexInvalid)system.TriggerHapticPulse(id,0,1500);
   }
  }catch(Exception ex){reportHapticPulses=0;MelonLogger.Warning("Report saved but controller feedback unavailable: "+ex.Message);}
 }
 private readonly DiagnosticWatchdog reportWatchdog=new DiagnosticWatchdog();
 private bool reportKeyDown;
 private bool reportObservationFailed,reportDashboard;
 private string announcedReport;
 private double nextReportSample;
 private int reportBridgeFrames=-1,reportBridgeState=-1,reportLeftError,reportRightError;
 private string pendingAutomaticReport;
 private double nextManualReport;
 private void PollProblemReports(){
  if(reportObservationFailed)return;
  try{
   double now=(double)TraceClock()/System.Diagnostics.Stopwatch.Frequency;
   bool down=(GetAsyncKeyState(0x77)&0x8000)!=0;
   if(down&&!reportKeyDown)RequestProblemReport("manual-F8");reportKeyDown=down;
   if(now>=nextReportSample){nextReportSample=now+.73;reportDashboard=Valve.VR.OpenVR.Overlay!=null&&Valve.VR.OpenVR.Overlay.IsDashboardVisible();if(bridgeConfigured){uint thread;GetBridgeStatus(out reportBridgeState,out reportLeftError,out reportRightError,out reportBridgeFrames,out thread);}}
   bool expected=bridgeConfigured&&active&&stereo&&!stopping&&!reportDashboard&&(diagnostic.CanSubmit||questMenuScene);
   string reason=reportWatchdog.Observe(now,expected,reportBridgeFrames);
   if(reason!=null)pendingAutomaticReport=reason;
   if(pendingAutomaticReport!=null&&frameTraceWriter!=null){RequestProblemReport(pendingAutomaticReport);pendingAutomaticReport=null;}
   if(frameTraceWriter!=null&&frameTraceWriter.LastReport!=null&&frameTraceWriter.LastReport!=announcedReport){
    announcedReport=frameTraceWriter.LastReport;testMenuStatus="Problem report saved. See UserData / SignalisVrDiagnostics.";MelonLogger.Msg("VR PROBLEM REPORT SAVED: "+announcedReport);reportHapticPulses=2;nextReportHaptic=now;
   }
   PollReportHaptics(now);
  }catch(Exception ex){reportObservationFailed=true;MelonLogger.Warning("Problem report observation unavailable: "+ex.Message);}
 }
 private void RequestProblemReport(string reason){
  double now=(double)TraceClock()/System.Diagnostics.Stopwatch.Frequency;
  if(now<nextManualReport){testMenuStatus="Please wait five seconds between reports.";return;}nextManualReport=now+5;
  if(frameTraceWriter==null){testMenuStatus="Recorder not ready. Try F8 again shortly.";return;}
  try{
   bool queued=frameTraceWriter.Report("reason="+reason+"\n"+DiagnosticSnapshot(true));
   testMenuStatus=queued?"Problem report queued. Keep playing; saving happens in the background.":"Report unavailable: queue full, writer error, or 20-report session limit. Preserve this session folder.";
   MelonLogger.Msg("VR PROBLEM REPORT: "+testMenuStatus);
  }catch(Exception ex){testMenuStatus="Report unavailable: "+ex.Message;MelonLogger.Warning(testMenuStatus);}
 }
 private static string ReportCamera(Camera c){
  if(c==null)return "absent";
  return "name="+c.name+" id="+c.GetInstanceID()+" enabled="+c.enabled+" active="+c.gameObject.activeInHierarchy+" mask="+c.cullingMask+" orthographic="+c.orthographic+" fov="+c.fieldOfView+" near="+c.nearClipPlane+" far="+c.farClipPlane+" position="+c.transform.position+" rotation="+c.transform.rotation+" parent="+(c.transform.parent==null?"none":c.transform.parent.name)+" target="+(c.targetTexture==null?"desktop":c.targetTexture.name+":"+c.targetTexture.width+"x"+c.targetTexture.height);
 }
 private string DiagnosticSnapshot(bool detailed){
  var b=new StringBuilder(4096);
  b.AppendLine("# snapshot UTC="+DateTime.UtcNow.ToString("o")+" frame="+Time.frameCount+" build="+DiagnosticVersion);
  try{
   b.AppendLine("# route active="+active+" stereo="+stereo+" bridge="+bridgeConfigured+" stopping="+stopping+" questMenu="+questMenuScene+" state="+global::PlayerState.gameState+" cutscene="+global::PlayerState.cutscene+" nativeCameraLatch="+(perspectiveCutsceneReturn!=null)+" inputSuspended="+global::PlayerState.suspendInput+" gameOver="+global::PlayerState.gameOver+" hp="+global::PlayerState.hp+" room="+(global::PlayerState.currentRoom==null?"none":global::PlayerState.currentRoom.name));
   b.AppendLine("# UI pause="+pauseMenuVisible+" book="+bookScreenVisible+" dialogue="+dialogueScreenVisible+" itemView="+global::BlackSleekGuiSubs.itemView+" capture="+(puzzleCapture==null?"absent":puzzleCapture.width+"x"+puzzleCapture.height)+" panel="+(puzzleScreen!=null&&puzzleScreen.activeInHierarchy));
   b.AppendLine("# stereoRouting reason="+stereoRouteReason+" recoveryPaused="+recovery.Paused+" legacyMenu="+global::PlayerState.menu+" legacyPause="+global::PlayerState.pauseMenu+" cinematicVisible="+ModHudCinematicVisible()+" desktopMirrorFrame="+desktopMirrorFrame);
   b.AppendLine("# submissions completed="+reportBridgeFrames+" bridgeState="+reportBridgeState+" leftError="+reportLeftError+" rightError="+reportRightError+" dashboard="+reportDashboard+" observationFailed="+reportObservationFailed);
   var w=global::InventoryManager.EquippedWeapon;
   b.AppendLine("# look XY="+questFrame.lookX+","+questFrame.lookY+" gate="+questLookGate+" consumer="+questLookConsumer+" framesSinceConsumed="+(Time.frameCount-questLookConsumedFrame));
   b.AppendLine("# weapon="+(w==null?"none":w.name)+" ammo="+(w==null?-1:w.magAmmo)+" support="+hdSupportHeld+" supportKind="+hdSupportKind+" controllerVisibility="+controllerVisibility+" reload="+manualReload.Stage+" gameReload="+global::PlayerState.reloading+" leftGrip="+manualLeftGrip+" frozenEnemies="+prodFrozen.Count+" enemyEyeCopies="+enemyEyeCopies.Count);
   b.AppendLine("# source "+ReportCamera(camera));b.AppendLine("# leftEye "+ReportCamera(eyes[0]));b.AppendLine("# rightEye "+ReportCamera(eyes[1]));
   b.AppendLine("# hands left="+(controllerMarkers[0]==null?"absent":controllerMarkers[0].transform.position.ToString())+" right="+rightWeaponPosition+" supportLocal="+hdSupportLocal+" unitsPerMetre="+UnitsPerMetre);
   if(detailed){
    b.AppendLine("# Metadata sampled outside eye rendering; temporary eye scopes are restored. This is NOT proof of visible pixels. No screenshots captured.");
    int count=0;foreach(var c in Camera.allCameras){if(count++>=32){b.AppendLine("# cameras truncated at32");break;}b.AppendLine("# activeCamera "+ReportCamera(c));}
    count=0;if(eyeEnemySkins!=null)foreach(var r in eyeEnemySkins){if(r==null)continue;if(count++>=64){b.AppendLine("# enemy skins truncated at64");break;}b.AppendLine("# enemySkin name="+r.name+" id="+r.GetInstanceID()+" enabled="+r.enabled+" active="+r.gameObject.activeInHierarchy+" layer="+r.gameObject.layer+" mesh="+(r.sharedMesh==null?"none":r.sharedMesh.name));int mcount=0;foreach(var m in r.sharedMaterials){if(mcount++>=8)break;if(m!=null)b.AppendLine("# material="+m.name+" shader="+(m.shader==null?"none":m.shader.name)+" texture="+(m.mainTexture==null?"none":m.mainTexture.name)+" queue="+m.renderQueue);}}
    foreach(var f in prodFrozen){if(f.enemy!=null)b.AppendLine("# stunned enemy="+f.enemy.name+" state="+f.enemy.state+" tracking="+f.enemy.tracking+" agentEnabled="+(f.enemy.agent!=null&&f.enemy.agent.enabled)+" agentStopped="+(f.enemy.agent!=null&&f.enemy.agent.isStopped));}
   }
  }catch(Exception ex){b.AppendLine("# snapshot partial: "+ex.Message);}
  return b.ToString();
 }
}}






