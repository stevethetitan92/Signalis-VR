using System;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public static class TestEnemyMaterialPolicy {
  // Normal cutout body materials qualify; auxiliary FX/burn passes do not veto them.
  public static bool Body(string shader,string renderType,int queue,bool textured){
   if(!textured||String.IsNullOrEmpty(shader))return false;
   shader=shader.ToLowerInvariant();
   return !shader.Contains("refract")&&!shader.Contains("distort")&&!shader.Contains("invisible")&&!shader.Contains("enemyshader_ampli")&&!shader.Contains("burn")&&renderType!="Transparent"&&queue<3000;
  }
  public static bool Overlay(string shader){return String.Equals(shader,"EnemyShader_Ampli",StringComparison.OrdinalIgnoreCase);}
 }
 public sealed partial class Tracking {
  private GameObject testEnemyRoot;private readonly System.Collections.Generic.List<Material> testBodyMaterials=new System.Collections.Generic.List<Material>();
  private global::EnemyController testEnemy,testEnemyTemplate;
  private float testEnemyDeathTime=-1,testEnemyRetry;
  private sealed class TestBodyCopy {public SkinnedMeshRenderer Source;public Mesh Mesh;public MeshRenderer View;public Color[] Colors;public int[][] Triangles;}
  private readonly System.Collections.Generic.List<TestBodyCopy> testBodyCopies=new System.Collections.Generic.List<TestBodyCopy>();
  private void UpdateTestBodyCopies(){
   foreach(var frozen in prodFrozen)if(frozen.enemy==testEnemy)AnimateStunVisual(frozen);
   foreach(var c in testBodyCopies){if(c.Source==null||c.View==null)continue;
    c.Source.BakeMesh(c.Mesh);if(c.Colors==null||c.Colors.Length!=c.Mesh.vertexCount){c.Colors=new Color[c.Mesh.vertexCount];for(int i=0;i<c.Colors.Length;i++)c.Colors[i]=Color.white;}c.Mesh.colors=c.Colors;for(int sub=0;sub<c.Mesh.subMeshCount;sub++)c.Mesh.SetTriangles(c.Triangles[sub],sub);c.Mesh.RecalculateBounds();c.View.transform.SetPositionAndRotation(c.Source.transform.position,c.Source.transform.rotation);c.View.transform.localScale=c.Source.transform.lossyScale;c.View.enabled=true;
   }
  }
  private global::AnEnemy testEnemyPreset;
  private global::Room testEnemyRoom;
  private Vector3 testEnemyPosition;
  private Quaternion testEnemyRotation;
  private bool testHooksReady;
  private string testMenuStatus;
  private bool OwnsTestEnemy(global::EnemyController e){return e!=null&&testEnemy!=null&&e.Pointer==testEnemy.Pointer;}
  private static bool TestEnemyUpdateGuard(global::EnemyController __instance){return weaponOwner==null||!weaponOwner.OwnsTestEnemy(__instance);}
  private static bool TestEnemyPersistenceGuard(global::EnemyController __instance){return weaponOwner==null||!weaponOwner.OwnsTestEnemy(__instance);}
  private static void TestSessionBoundary(){if(weaponOwner!=null){weaponOwner.LeaveCalibrationRoom(true);weaponOwner.DestroyTestEnemy();}}
  private void InstallTestMenu(HarmonyLib.Harmony h){
   try {
    foreach(var method in new[]{"Update","WakeUpfromGunShot","Hit"})h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),method,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(TestEnemyUpdateGuard)));
    foreach(var method in new[]{"Save","Load"})h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),method,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(TestEnemyPersistenceGuard)));
    foreach(var method in new[]{"Save","Load","NewGame"})h.Patch(AccessTools.DeclaredMethod(typeof(global::SaveManager),method,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(TestSessionBoundary)));
    foreach(var method in new[]{"EnterRoom","LeaveRoom"})h.Patch(AccessTools.DeclaredMethod(typeof(global::Room),method,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(CalibrationRoomTransitionGuard)));
    InstallCalibrationStorage(h);testHooksReady=true;
   }catch(Exception ex){testHooksReady=false;MelonLogger.Warning("Test room/target unavailable: "+ex.Message);}
  }
  private void ActivateTestMenu(int index){
   try {
    if(index==0){if(calibrationRoot!=null)LeaveCalibrationRoom(true);else EnterCalibrationRoom();}else if(index==1)RequestProblemReport("manual-menu");else if(index==2)FinishModMenu();
   }catch(Exception ex){testMenuStatus="Unable to complete test action: "+ex.Message;MelonLogger.Warning(testMenuStatus+"\n"+ex);}
  }
  private void SetTestHalfHealth(){
   if(!CheatPlayerReady()||global::PlayerState.hp<=0){testMenuStatus="Load a living character first.";return;}
   infiniteLife=false;global::PlayerState.hp=50;SaveModSettings();testMenuStatus="Health: 50 / 100. Infinite Life is OFF.";
  }
  private int TestTemplateScore(global::EnemyController enemy){
   if(enemy==null||OwnsTestEnemy(enemy)||enemy.Preset==null||(int)enemy.Preset.Type!=0||enemy.Preset.HP<=0)return -1;
   int textured=0;
   foreach(var renderer in enemy.GetComponentsInChildren<SkinnedMeshRenderer>(true)) {
    if(renderer.sharedMesh==null)continue;
    foreach(var material in renderer.sharedMaterials) {
     if(material==null||material.shader==null)continue;
     string shader=material.shader.name.ToLowerInvariant();
     string renderType=material.GetTag("RenderType",false,"");
     MelonLogger.Msg("TEST ENEMY MATERIAL: template="+enemy.name+" mesh="+renderer.name+" material="+material.name+" shader="+material.shader.name+" type="+renderType+" queue="+material.renderQueue+" texture="+(material.mainTexture==null?"none":material.mainTexture.name));
     if(TestEnemyMaterialPolicy.Body(shader,renderType,material.renderQueue,material.mainTexture!=null))textured++;
    }
   }
   return textured>0?textured:-1;
  }
  private void PrepareTestEnemyVisuals(){
   int bodies=0,overlays=0;
   foreach(var renderer in testEnemy.GetComponentsInChildren<SkinnedMeshRenderer>(true)){
    bool body=false,overlay=false,burn=false;
    foreach(var material in renderer.sharedMaterials){
     if(material==null||material.shader==null)continue;
     string shader=material.shader.name;
     body|=TestEnemyMaterialPolicy.Body(shader,material.GetTag("RenderType",false,""),material.renderQueue,material.mainTexture!=null);
     overlay|=TestEnemyMaterialPolicy.Overlay(shader);burn|=shader.IndexOf("burn",StringComparison.OrdinalIgnoreCase)>=0;
    }
    if(body){
     var original=renderer.sharedMaterials;var visible=new Material[original.Length];for(int i=0;i<original.Length;i++){var m=new Material(Shader.Find("Unlit/Texture"));m.mainTexture=original[i].mainTexture;m.mainTextureScale=original[i].mainTextureScale;m.mainTextureOffset=original[i].mainTextureOffset;visible[i]=m;testBodyMaterials.Add(m);}renderer.sharedMaterials=visible;
     // Render a private baked copy: native skin/visibility animation must not hide the test body.
     for(var t=renderer.transform;t!=null&&t!=testEnemyRoot.transform;t=t.parent)t.gameObject.SetActive(true);
     renderer.enabled=true;renderer.allowOcclusionWhenDynamic=false;renderer.updateWhenOffscreen=true;renderer.localBounds=new Bounds(Vector3.zero,Vector3.one*100f);
     var copy=new GameObject("SignalisVR_TestBody_"+renderer.name);copy.layer=0;copy.transform.SetParent(testEnemyRoot.transform,false);
     var baked=new Mesh();copy.AddComponent<MeshFilter>().sharedMesh=baked;var view=copy.AddComponent<MeshRenderer>();view.sharedMaterials=visible;view.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;
     var topology=new int[renderer.sharedMesh.subMeshCount][];for(int sub=0;sub<topology.Length;sub++)topology[sub]=HandSurfaceTopology.DoubleSided(renderer.sharedMesh.GetTriangles(sub));
     testBodyCopies.Add(new TestBodyCopy{Source=renderer,Mesh=baked,View=view,Triangles=topology});renderer.enabled=false;
     bodies++;}
    else if(overlay){renderer.enabled=false;overlays++;}
    else if(burn)renderer.enabled=false; // Native BurnEnemy can enable its own pass when burned.
   }
   foreach(var renderer in testEnemy.GetComponentsInChildren<MeshRenderer>(true)){
    if(!renderer.enabled||renderer.name.StartsWith("SignalisVR_TestBody_"))continue;
    var original=renderer.sharedMaterials;var materials=new Material[original.Length];
    for(int i=0;i<materials.Length;i++){
     var source=original[i];materials[i]=source;
     // Blood and other transparent effects must retain their native blending.
     // Applying the opaque body fallback to their quads exposes the whole texture.
     if(source==null||source.shader==null||!TestEnemyMaterialPolicy.Body(source.shader.name,source.GetTag("RenderType",false,""),source.renderQueue,source.mainTexture!=null))continue;
     var m=new Material(Shader.Find(source.GetTag("RenderType",false,"")=="TransparentCutout"?"Unlit/Transparent Cutout":"Unlit/Texture"));
     m.mainTexture=source.mainTexture;m.mainTextureScale=source.mainTextureScale;m.mainTextureOffset=source.mainTextureOffset;
     if(source.HasProperty("_Cutoff")&&m.HasProperty("_Cutoff"))m.SetFloat("_Cutoff",source.GetFloat("_Cutoff"));
     materials[i]=m;testBodyMaterials.Add(m);
    }renderer.sharedMaterials=materials;
   }
   if(bodies==0)throw new InvalidOperationException("Test clone has no textured body meshes");
   MelonLogger.Msg("TEST ENEMY VISUALS: textured bodies="+bodies+" auxiliary FX disabled="+overlays);
  }
  private global::EnemyController FindTestTemplate(){
   global::EnemyController best=null;int score=-1;
   // Inspect the complete resource set before accepting a resident special variant.
   Resources.LoadAll<GameObject>("");
   foreach(var enemy in Resources.FindObjectsOfTypeAll<global::EnemyController>()) {
    try{int candidate=TestTemplateScore(enemy);if(candidate>score){score=candidate;best=enemy;}}
    catch(Exception ex){MelonLogger.Warning("Skipped unavailable enemy template: "+ex.Message);}
   }
   if(best!=null)MelonLogger.Msg("TEST ENEMY SELECTED: "+best.name+" texturedMaterials="+score);
   return best;
  }
  private Vector3 TestForward(){var f=(active&&stereo?stereoRotation:camera!=null?camera.transform.rotation:global::PlayerState.player.transform.rotation)*Vector3.forward;f.z=0;return f.sqrMagnitude>.001f?f.normalized:Vector3.up;}
  private void SpawnTestEnemy(){
   if(!testHooksReady||!CheatPlayerReady()||global::PlayerState.hp<=0){testMenuStatus="Load a living character first; test hooks must be ready.";return;}
   var template=testEnemyTemplate!=null?testEnemyTemplate:FindTestTemplate();testEnemyTemplate=template;if(template==null){testMenuStatus="No normal textured enemy prefab was found. See the test-enemy material log.";return;}
   var player=global::PlayerState.player.transform;var forward=TestForward();float distance=2f*UnitsPerMetre;
   var attack=global::PlayerAttack.instance;RaycastHit hit;
   if(calibrationRoot==null&&attack!=null&&Physics.SphereCast(player.position+Vector3.back*UnitsPerMetre,.3f*UnitsPerMetre,forward,out hit,distance,attack.WallMask,QueryTriggerInteraction.Ignore))distance=Math.Max(0,hit.distance-.5f*UnitsPerMetre);
   if(distance<.8f*UnitsPerMetre){testMenuStatus="Face an open space before spawning.";return;}
   var position=calibrationRoot!=null?calibrationCentre:player.position+forward*distance;
   if(calibrationRoot!=null){forward=position-player.position;forward.z=0;forward=forward.sqrMagnitude>.001f?forward.normalized:Vector3.up;}
   // Deactivate synchronously; Destroy alone leaves the previous target until end of frame.
   DestroyTestEnemy();
   try {
    testEnemyRoot=new GameObject("SignalisVR_OneTestEnemy");testEnemyRoot.SetActive(false);
    var clone=UnityEngine.Object.Instantiate(template.gameObject,testEnemyRoot.transform);clone.name="SignalisVR_BasicTestEnemy";
    testEnemy=clone.GetComponent<global::EnemyController>();if(testEnemy==null)throw new InvalidOperationException("Basic enemy component missing");
    testEnemyPreset=UnityEngine.Object.Instantiate(template.Preset);testEnemyPreset.damage=0;testEnemyPreset.revives=0;testEnemyPreset.cannotRespawn=true;testEnemy.Preset=testEnemyPreset;
    testEnemyPosition=position;testEnemyRotation=Quaternion.LookRotation(-forward,Vector3.back);clone.transform.SetPositionAndRotation(position,testEnemyRotation);clone.SetActive(true);
    testEnemyRoom=global::PlayerState.currentRoom;testEnemyRoot.SetActive(true);
    if(testEnemy.hitbox==null)throw new InvalidOperationException("Basic enemy hitbox missing");
    testEnemy.StopAllCoroutines();testEnemy.hitbox.HP=testEnemyPreset.HP;testEnemy.oldHP=testEnemy.hitbox.HP;testEnemy.state=global::EnemyController.enemystate.pursuit;testEnemy.behaviour=global::EnemyController.idleBehaviour.idle;testEnemy.staggerType=global::EnemyController.hurtState.none;testEnemy.busy=false;testEnemy.revives=0;
    if(testEnemy.animator!=null){testEnemy.animator.Rebind();testEnemy.animator.SetBool(testEnemy.anim_Sleep,false);testEnemy.animator.SetBool(testEnemy.anim_Dead,false);testEnemy.animator.SetFloat(testEnemy.anim_X,0);testEnemy.animator.SetFloat(testEnemy.anim_Y,0);}
    if(testEnemy._collider!=null)testEnemy._collider.enabled=true;
    foreach(var receiving in testEnemy.hitbox.GetComponentsInChildren<Collider>(true)){receiving.gameObject.SetActive(true);receiving.enabled=true;}
    if(testEnemy.animator!=null){testEnemy.animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;testEnemy.animator.Update(0);}
    PrepareTestEnemyVisuals();HoldTestEnemyStill();UpdateTestBodyCopies();enemyBoxPopups=null;testMenuStatus="Basic enemy spawned in front of you. Previous test enemy removed.";
   }catch{DestroyTestEnemy();throw;}
  }
  private void HoldTestEnemyStill(){
   var e=testEnemy;if(e==null)return;e.tracking=false;e.attacking=false;e.hugging=false;e.canTrackElster=false;e.blind=true;e.deaf=true;e.input=Vector3.zero;
   if(e.agent!=null)e.agent.enabled=false;if(e.character!=null)e.character.enabled=false;
   if(e.WeaponHurtboxObject!=null)e.WeaponHurtboxObject.SetActive(false);if(e.WeaponHurtboxAltObject!=null)e.WeaponHurtboxAltObject.SetActive(false);
   if(e.animator!=null)e.animator.applyRootMotion=false;
   if(e.state!=global::EnemyController.enemystate.dead)e.transform.SetPositionAndRotation(testEnemyPosition,testEnemyRotation);
  }
  private void PollTestEnemy(){
   try{PollCalibrationRoom();}catch(Exception ex){LeaveCalibrationRoom(true);MelonLogger.Warning("Calibration room closed safely: "+ex.Message);}
   if(testEnemy==null){if(calibrationRoot!=null&&Time.time>=testEnemyRetry){testEnemyRetry=Time.time+2;try{SpawnTestEnemy();}catch(Exception ex){MelonLogger.Warning("Calibration respawn: "+ex.Message);}}return;}
   if(!CheatPlayerReady()||testEnemyRoom!=global::PlayerState.currentRoom){DestroyTestEnemy();return;}
   try {
    if(testEnemy.hitbox!=null&&testEnemy.hitbox.HP<=0){
     if(testEnemyDeathTime<0){testEnemyDeathTime=Time.time;if(testEnemy.state!=global::EnemyController.enemystate.dead)testEnemy.Kill();if(testEnemy.animator!=null){testEnemy.animator.SetBool(testEnemy.anim_Hurt,false);testEnemy.animator.SetBool(testEnemy.anim_Dead,true);}}
     float age=Time.time-testEnemyDeathTime;
     HoldTestEnemyStill();UpdateTestBodyCopies();
     float alpha=Mathf.Clamp01((3f-age)/.75f);foreach(var m in testBodyMaterials){m.shader=Shader.Find("Sprites/Default");m.color=new Color(1,1,1,alpha);}
     if(age>=3f){bool respawn=calibrationRoot!=null;DestroyTestEnemy();if(respawn)SpawnTestEnemy();}return;
    }
    HoldTestEnemyStill();UpdateTestBodyCopies();
    // Native weapons change Hitbox.HP. Replace only the suppressed AI Update's damage observation.
    if(testEnemy.hitbox!=null&&testEnemy.state!=global::EnemyController.enemystate.dead&&testEnemy.hitbox.HP<testEnemy.oldHP){testEnemy.oldHP=testEnemy.hitbox.HP;testEnemy.TakeDamage();if(testEnemy.hitbox.HP<=0&&testEnemy.state!=global::EnemyController.enemystate.dead)testEnemy.Kill();}
   }catch(Exception ex){DestroyTestEnemy();MelonLogger.Warning("Test enemy removed: "+ex.Message);}
  }
  private void DestroyTestEnemy(){
   testEnemyDeathTime=-1;
   foreach(var c in testBodyCopies)if(c.Mesh!=null)UnityEngine.Object.Destroy(c.Mesh);testBodyCopies.Clear();
   foreach(var material in testBodyMaterials)if(material!=null)UnityEngine.Object.Destroy(material);testBodyMaterials.Clear();
   if(testEnemyRoot!=null){testEnemyRoot.SetActive(false);UnityEngine.Object.Destroy(testEnemyRoot);}testEnemy=null;testEnemyRoot=null;
   if(testEnemyPreset!=null)UnityEngine.Object.Destroy(testEnemyPreset);testEnemyPreset=null;testEnemyRoom=null;
  }
 }
}




