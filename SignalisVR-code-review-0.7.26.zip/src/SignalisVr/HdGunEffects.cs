using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private MaterialPropertyBlock hdSmokeBlock;private GameObject hdFxRoot;private Mesh hdFxQuad;private Material hdFlashMaterial,hdSmokeMaterial;private Texture2D hdFlashTexture,hdSmokeTexture;
 private readonly MeshRenderer[] hdFlashes=new MeshRenderer[3],hdSmoke=new MeshRenderer[24];
 private readonly Vector3[] hdSmokeOrigins=new Vector3[24];private readonly float[] hdSmokeBirth=new float[24];private int hdSmokeNext;private bool hdFxFailed;
 private Texture2D HdFxTexture(string name){var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(HdAsset.Read(name)),true))throw new InvalidOperationException("HD effect texture");tex.filterMode=FilterMode.Bilinear;return tex;}
 private void EnsureHdFx(){
  if(hdFxRoot!=null)return;hdFxRoot=new GameObject("SignalisVR_HDShotEffects");UnityEngine.Object.DontDestroyOnLoad(hdFxRoot);
  hdFxQuad=new Mesh();hdFxQuad.vertices=new[]{new Vector3(-.5f,-.5f,0),new Vector3(.5f,-.5f,0),new Vector3(.5f,.5f,0),new Vector3(-.5f,.5f,0)};hdFxQuad.uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(1,1),new Vector2(0,1)};hdFxQuad.colors=new[]{Color.white,Color.white,Color.white,Color.white};hdFxQuad.triangles=HandSurfaceTopology.DoubleSided(new[]{0,1,2,0,2,3});hdFxQuad.RecalculateBounds();
  var shader=Shader.Find("Sprites/Default");if(shader==null)throw new InvalidOperationException("HD effect shader");
  hdSmokeBlock=new MaterialPropertyBlock();hdFlashTexture=HdFxTexture("fx-muzzle.png");hdSmokeTexture=HdFxTexture("fx-smoke.png");hdFlashMaterial=new Material(shader);hdFlashMaterial.mainTexture=hdFlashTexture;hdSmokeMaterial=new Material(shader);hdSmokeMaterial.mainTexture=hdSmokeTexture;
  for(int i=0;i<3;i++)hdFlashes[i]=CreateControllerPart(hdFxRoot,hdFxQuad,hdFlashMaterial,"HD muzzle flash",Vector3.zero,Vector3.one);
  for(int i=0;i<24;i++){hdSmoke[i]=CreateControllerPart(hdFxRoot,hdFxQuad,hdSmokeMaterial,"HD muzzle smoke",Vector3.zero,Vector3.one);hdSmokeBirth[i]=-100;}
 }
 private void EmitHdShotSmoke(){if(hdFxFailed)return;try{EnsureHdFx();}catch(Exception){hdFxFailed=true;return;}Vector3 local;if(!ImportedMuzzle(out local))return;var origin=rightWeaponPosition+rightWeaponRotation*local*UnitsPerMetre;for(int i=0;i<3;i++){int slot=hdSmokeNext++%24;hdSmokeBirth[slot]=Time.realtimeSinceStartup+i*.025f;hdSmokeOrigins[slot]=origin;}}
 private void PrepareHdGunEffects(){
  HideHdGunEffects();if(!handsScoped||hdFxFailed)return;
  try{
   EnsureHdFx();ShowPistolCases();var w=global::InventoryManager.EquippedWeapon;Vector3 local;

   float age=Time.realtimeSinceStartup-heldShotTime;
   if(w!=null&&w.parentItem!=null&&w.parentItem._item!=global::Items.itemlist.FlareGun&&w.Pointer==heldShotWeapon&&age>=0&&age<.045f&&ImportedMuzzle(out local))for(int i=0;i<3;i++){var r=hdFlashes[i];r.transform.position=rightWeaponPosition+rightWeaponRotation*(local+Vector3.forward*.015f)*UnitsPerMetre;r.transform.rotation=rightWeaponRotation*Quaternion.Euler(i==2?90:0,i==1?90:0,0);r.transform.localScale=Vector3.one*(.065f*UnitsPerMetre);r.enabled=true;}
   for(int i=0;i<24;i++){float a=Time.realtimeSinceStartup-hdSmokeBirth[i];if(a<0||a>.6f)continue;var r=hdSmoke[i];r.transform.position=hdSmokeOrigins[i]+controllerTrackingToWorld*new Vector3(Mathf.Sin(i*2.4f)*a*.018f,a*.06f,0)*UnitsPerMetre;r.transform.rotation=stereoRotation*Quaternion.AngleAxis(i*53,Vector3.forward);r.transform.localScale=Vector3.one*(.014f+.07f*a)*UnitsPerMetre;var block=hdSmokeBlock;block.SetColor("_Color",new Color(.8f,.8f,.8f,.28f*(1-a/.6f)));r.SetPropertyBlock(block);r.enabled=true;}
  }catch(Exception ex){hdFxFailed=true;HideHdGunEffects();MelonLoader.MelonLogger.Warning("HD shot effects unavailable: "+ex.Message);}
 }
 private void HideHdGunEffects(){HidePistolCases();foreach(var r in hdFlashes)if(r!=null)r.enabled=false;foreach(var r in hdSmoke)if(r!=null)r.enabled=false;}
 private void DestroyHdGunEffects(){DestroyPistolCases();if(hdFxRoot!=null)UnityEngine.Object.Destroy(hdFxRoot);foreach(var o in new UnityEngine.Object[]{hdFxQuad,hdFlashMaterial,hdSmokeMaterial,hdFlashTexture,hdSmokeTexture})if(o!=null)UnityEngine.Object.Destroy(o);hdFxRoot=null;hdFxFailed=false;}
} }

