$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'MapDiscoveryPolicy.cs')
foreach($distance in @(0,.8,1.0,1.49,1.5,1.501,2,[double]::NaN)){
 $expected= ![double]::IsNaN($distance) -and $distance -le 1.5
 if([SignalisVrTracking.MapDiscoveryPolicy]::Discover($false,$true,$true,$distance) -ne $expected){throw "Radius wrong: $distance"}
 if([SignalisVrTracking.MapDiscoveryPolicy]::Discover($false,$false,$true,$distance)){throw 'Adjacent room revealed'}
 if([SignalisVrTracking.MapDiscoveryPolicy]::Discover($false,$true,$false,$distance)){throw 'Inactive hidden pickup revealed'}
 if(![SignalisVrTracking.MapDiscoveryPolicy]::Discover($true,$false,$false,$distance)){throw 'Interaction did not reveal'}
}
foreach($complete in $true,$false){foreach($known in $true,$false){
 if([SignalisVrTracking.MapDiscoveryPolicy]::Visible($complete,$known,$true)){throw 'Collected object resurrected'}
 if([SignalisVrTracking.MapDiscoveryPolicy]::Visible($complete,$known,$false) -ne ($complete -or $known)){throw 'Discovery/cheat visibility wrong'}
 if([SignalisVrTracking.MapDiscoveryPolicy]::DoorVisible($complete,$known) -ne $true){throw 'Door discovery wrong'}
}}
'PASS discovery 1.5m boundary, interaction, inactive/adjacent room exclusion, Map Complete override, collected removal and unchecked door visibility.'
