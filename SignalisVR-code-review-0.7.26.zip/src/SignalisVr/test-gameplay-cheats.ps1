$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'GameplayCheats.cs') -Raw
$harness=@'
namespace UnityEngine { public struct Vector2 {} }
namespace MelonLoader { public static class MelonLogger { public static void Msg(string s){} public static void Warning(string s){} } }
namespace HarmonyLib {
 public class Harmony { public Harmony(string s){} public void Patch(System.Reflection.MethodInfo m,HarmonyMethod prefix=null,HarmonyMethod postfix=null){} }
 public class HarmonyMethod { public HarmonyMethod(System.Type t,string s){} }
 public static class AccessTools { public static System.Reflection.MethodInfo DeclaredMethod(System.Type t,string s,System.Type[] a){return null;} }
}
public static class PlayerState { public static object player=new object(); public static bool noplayer,gameOver,cutscene; public static int hp=100; }
public class PlayerAttack {public static float Stamina;}
public class Hitbox { public int HP; } public class EnemyController { public Hitbox hitbox; }
public static class Items { public enum itemlist {Pistol,Revolver,Shotgun,Rifle,FlareGun,SMG,Machete} }
public class AnItem { public Items.itemlist _item; }
public class AnWeapon { public AnItem parentItem; public int MagSize,magAmmo; }
public static class InventoryManager { public static AnWeapon EquippedWeapon; }
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  // Reload behavior is exercised separately by test-shotgun-reload.
  private static void ShotgunFired(){}
  private static Tracking weaponOwner;private bool manualReloadEnabled;private bool ProdVrMode(){return true;}
  private static bool calibration; private static bool CalibrationInventoryActive(){return calibration;}
  private static void Check(bool b,string m){if(!b)throw new System.Exception(m);}
  public static void RunCheatChecks(){
   gameplayCheatHooksReady=true;infiniteLife=false;infiniteAmmo=false;
   Check(BlockCheatDamage(1000),"OFF blocked native damage");
   infiniteLife=true;PlayerState.hp=1;ApplyGameplayCheats();Check(PlayerState.hp==100,"Enable did not heal");
   for(int i=0;i<1000;i++){if(BlockCheatDamage(1000))PlayerState.hp-=1000;}
   Check(PlayerState.hp==100,"Lethal damage leaked through guard");
   Check(BlockCheatDamage(-5),"Negative/healing input blocked");
   var enemy=new EnemyController{hitbox=new Hitbox{HP=5000}};instantKill=false;InstantKillEnemy(enemy);Check(enemy.hitbox.HP==5000,"OFF killed enemy");instantKill=true;InstantKillEnemy(enemy);Check(enemy.hitbox.HP==0,"Instant kill failed");
   infiniteLife=false;Check(BlockCheatDamage(10),"Disable did not restore damage");
   infiniteAmmo=true;
   foreach(Items.itemlist type in new[]{Items.itemlist.Pistol,Items.itemlist.Revolver,Items.itemlist.Shotgun,Items.itemlist.Rifle,Items.itemlist.FlareGun,Items.itemlist.SMG}) {
    var w=new AnWeapon{parentItem=new AnItem{_item=type},MagSize=6,magAmmo=0};InventoryManager.EquippedWeapon=w;
    FillCheatMagazine();Check(w.magAmmo==6,"Empty magazine not primed");
    for(int i=0;i<1000;i++){w.magAmmo--;FillCheatMagazine();Check(w.magAmmo==6,"Ammo depleted");}
   }
   calibration=true;InventoryManager.EquippedWeapon.magAmmo=0;FillCheatMagazine();Check(InventoryManager.EquippedWeapon.magAmmo==0,"Calibration must allow empty magazines");calibration=false;
   weaponOwner=new Tracking{manualReloadEnabled=true};InventoryManager.EquippedWeapon.magAmmo=0;FillCheatMagazine();Check(InventoryManager.EquippedWeapon.magAmmo==0,"Manual reload mode silently refilled gun");weaponOwner=null;
   infiniteAmmo=false;InventoryManager.EquippedWeapon.magAmmo=2;FillCheatMagazine();Check(InventoryManager.EquippedWeapon.magAmmo==2,"OFF granted ammo");
   infiniteAmmo=true;InventoryManager.EquippedWeapon.parentItem._item=Items.itemlist.Machete;FillCheatMagazine();Check(InventoryManager.EquippedWeapon.magAmmo==2,"Non-firearm changed");
   PlayerAttack.Stamina=.42f;ApplyGameplayCheats();Check(PlayerAttack.Stamina==.42f,"Gameplay cheats wrote stamina");
   infiniteLife=true;PlayerState.gameOver=true;PlayerState.hp=0;ApplyGameplayCheats();Check(PlayerState.hp==0,"Game over resurrected");
  }
 }
}
'@
Add-Type -TypeDefinition ($source+[Environment]::NewLine+$harness) -IgnoreWarnings -WarningAction SilentlyContinue
[SignalisVrTracking.Tracking]::RunCheatChecks()
'PASS actual cheat guard/fill source under controlled game stubs: lethal damage, empty magazines, 1000 shots per firearm, OFF, unsupported weapons and game over. Native hook delivery remains unverified.'



