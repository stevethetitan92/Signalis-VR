using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private GameObject xiphiasRoot;
  private readonly List<MeshRenderer> xiphiasParts=new List<MeshRenderer>();
  private readonly List<Mesh> xiphiasMeshes=new List<Mesh>();
  private readonly List<Material> xiphiasMaterials=new List<Material>();
  private readonly List<Texture2D> xiphiasTextures=new List<Texture2D>();
  private MeshRenderer xiphiasMagazine,xiphiasHandle,xiphiasTrigger;
  private Vector3 xiphiasHandlePoint;
  private bool xiphiasFailed;
  private bool IsXiphias(){var w=global::InventoryManager.EquippedWeapon;return w!=null&&w.parentItem!=null&&w.parentItem._item==global::Items.itemlist.SMG&&!xiphiasFailed;}
  private void EnsureXiphias(){
   if(xiphiasRoot!=null)return;
   var shader=Shader.Find("Unlit/Texture");if(shader==null)throw new InvalidOperationException("Xiphias texture shader unavailable");
   foreach(var encoded in XiphiasData.Textures){var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);xiphiasTextures.Add(tex);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(encoded),true))throw new InvalidOperationException("Xiphias texture decode failed");tex.filterMode=FilterMode.Point;var mat=new Material(shader);mat.mainTexture=tex;xiphiasMaterials.Add(mat);}
   xiphiasRoot=new GameObject("SignalisVR_Xiphias");UnityEngine.Object.DontDestroyOnLoad(xiphiasRoot);
   using(var reader=new BinaryReader(new MemoryStream(Convert.FromBase64String(XiphiasData.Geometry)))){
    int count=reader.ReadInt32();for(int part=0;part<count;part++){
     int role=reader.ReadInt32(),material=reader.ReadInt32(),nv=reader.ReadInt32(),nt=reader.ReadInt32();var vertices=new Vector3[nv];var uv=new Vector2[nv];var triangles=new int[nt];
     for(int i=0;i<nv;i++)vertices[i]=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle());for(int i=0;i<nv;i++)uv[i]=new Vector2(reader.ReadSingle(),reader.ReadSingle());for(int i=0;i<nt;i++)triangles[i]=reader.ReadInt32();
     var mesh=new Mesh();mesh.name=role==1?"SMG_Mag":role==2?"SMG_Action":"XiphiasBody";mesh.vertices=vertices;mesh.uv=uv;mesh.triangles=HandSurfaceTopology.DoubleSided(triangles);mesh.RecalculateNormals();mesh.RecalculateBounds();xiphiasMeshes.Add(mesh);
     var r=CreateControllerPart(xiphiasRoot,mesh,xiphiasMaterials[material],mesh.name,Vector3.zero,Vector3.one);r.enabled=false;xiphiasParts.Add(r);if(role==3)xiphiasTrigger=r;if(role==1)xiphiasMagazine=r;if(role==2)xiphiasHandle=r;
    }
   }
   if(xiphiasMagazine==null||xiphiasHandle==null)throw new InvalidOperationException("Xiphias moving parts missing");
   var handleMesh=xiphiasHandle.GetComponent<MeshFilter>().sharedMesh;float outside=handleMesh.bounds.min.x+.008f;var sum=Vector3.zero;int samples=0;foreach(var p in handleMesh.vertices)if(p.x<=outside){sum+=p;samples++;}if(samples==0)throw new InvalidOperationException("Xiphias handle contact missing");xiphiasHandlePoint=sum/samples;
  }
  private void PrepareXiphias(){
   HideXiphias();if(!IsXiphias())return;
   try{EnsureXiphias();xiphiasRoot.transform.position=rightWeaponPosition;xiphiasRoot.transform.rotation=rightWeaponRotation;xiphiasRoot.transform.localScale=Vector3.one*UnitsPerMetre;
    foreach(var part in xiphiasParts){part.transform.localPosition=Vector3.zero;part.transform.localRotation=Quaternion.identity;part.enabled=true;}
    foreach(var part in equippedCopies)if(part!=null)part.enabled=false;
   }catch(Exception ex){DestroyXiphias();xiphiasFailed=true;MelonLogger.Warning("Xiphias unavailable; native SMG retained: "+ex.Message);}
  }
  private void HideXiphias(){foreach(var r in xiphiasParts)if(r!=null)r.enabled=false;}
  private void DestroyXiphias(){HideXiphias();if(xiphiasRoot!=null)UnityEngine.Object.Destroy(xiphiasRoot);foreach(var m in xiphiasMeshes)if(m!=null)UnityEngine.Object.Destroy(m);foreach(var m in xiphiasMaterials)if(m!=null)UnityEngine.Object.Destroy(m);foreach(var t in xiphiasTextures)if(t!=null)UnityEngine.Object.Destroy(t);xiphiasRoot=null;xiphiasMagazine=xiphiasHandle=xiphiasTrigger=null;xiphiasParts.Clear();xiphiasMeshes.Clear();xiphiasMaterials.Clear();xiphiasTextures.Clear();}
  private Vector3 XiphiasHandleContact(){
   // The side tab projects out of the receiver; target its outer end, not the rod center.
   return xiphiasHandle.transform.TransformPoint(xiphiasHandlePoint);
  }
 }
}
