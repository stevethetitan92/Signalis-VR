$ErrorActionPreference='Stop'
Add-Type -Path @((Join-Path $PSScriptRoot 'ShotgunReloadPolicy.cs'),(Join-Path $PSScriptRoot 'HingedReloadPolicy.cs'))
$rounds=Get-Content (Join-Path $PSScriptRoot 'reload-fixtures/Bullets.json') -Raw | ConvertFrom-Json
$drum=Get-Content (Join-Path $PSScriptRoot 'reload-fixtures/Drum.json') -Raw | ConvertFrom-Json
function Check($value,$why){if(-not $value){throw $why}}
Check ($rounds.v.Count -eq 144) 'Native round topology changed'
$counts=@(0,0,0,0,0,0)
foreach($tri in $rounds.tris[0]){
 $group=[SignalisVrTracking.RevolverRoundLayout]::RoundForVertex($tri[0])
 Check ($group -lt 6) 'Unknown round'
 foreach($index in $tri){Check ([SignalisVrTracking.RevolverRoundLayout]::RoundForVertex($index) -eq $group) 'Triangle cut across rounds'}
 $counts[$group]++
}
foreach($count in $counts){Check ($count -eq 12) 'Partial load cuts away a round face'}
foreach($v in $rounds.v){
 # Native X is the cartridge feed axis; Y/Z define chamber spacing.
 Check ($v[1] -ge $drum.min[1] -and $v[1] -le $drum.max[1]) 'Round extends beyond cylinder height'
 Check ($v[2] -ge $drum.min[2] -and $v[2] -le $drum.max[2]) 'Round extends beyond cylinder width'
 # Held layout is the exact cyclic axis permutation (Z,X,Y), with no resized rounds.
 $held=@($v[2],$v[0],$v[1]);$restored=@($held[1],$held[2],$held[0])
 for($axis=0;$axis -lt 3;$axis++){Check ($restored[$axis] -eq $v[$axis]) 'Held-to-cylinder round layout changed dimensions'}
}
foreach($count in 0..6){$faces=0;foreach($tri in $rounds.tris[0]){if([SignalisVrTracking.RevolverRoundLayout]::RoundForVertex($tri[0]) -lt $count){$faces++}};Check ($faces -eq 12*$count) 'Partial loader contains sliced or extra rounds'}
foreach($loaded in 0..6){foreach($amount in 0..(6-$loaded)){$faces=0;foreach($tri in $rounds.tris[0]){if([SignalisVrTracking.RevolverRoundLayout]::InLoader($tri[0],$loaded,$amount)){$faces++;if([SignalisVrTracking.RevolverRoundLayout]::RoundForVertex($tri[0]) -lt $loaded){throw 'Loader aimed at an occupied chamber'}}};Check ($faces -eq 12*$amount) 'Loader does not match empty chambers'}}
Write-Host 'PASS: six intact native rounds, original chamber spacing/radial bounds and reversible held axis mapping. This does not establish live hand/weapon collision clearance.'
