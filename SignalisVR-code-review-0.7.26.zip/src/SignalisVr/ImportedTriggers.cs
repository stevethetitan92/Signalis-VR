using System;
using System.IO;
using UnityEngine;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private readonly Vector3[][] importedIndexRest=new Vector3[8][];
 private float[] importedIndexWeights;
 private Vector3 ImportedTriggerPivot(){
  if(IsXiphias())return new Vector3(0,.0212f,.0251f);
  if(SelectedActive("Pistol"))return new Vector3(0,.0382f,.062f);
  if(SelectedActive("Shotgun"))return HdShotgunData.TriggerPivot;
  for(int i=0;i<selectedParts.Count;i++)if(selectedRoles[i]==4){var b=selectedMeshes[i].bounds;return new Vector3(b.center.x,b.max.y,b.center.z);}
  return Vector3.zero;
 }
 private void MoveImportedTrigger(Transform t,Vector3 pivot){var q=Quaternion.AngleAxis(18*GunSqueeze(),Vector3.right);t.localRotation=q;t.localPosition=pivot-q*pivot;}
 private void PrepareImportedTriggers(){
  var pivot=ImportedTriggerPivot();
  if(IsXiphias()&&xiphiasTrigger!=null){MoveImportedTrigger(xiphiasTrigger.transform,pivot);return;}
  if(SelectedActive("Revolver"))return;
  for(int i=0;i<selectedParts.Count;i++){
   if(selectedRoles[i]==4)MoveImportedTrigger(selectedParts[i].transform,pivot);
   if(selectedRoles[i]==3){var b=selectedMeshes[i].bounds;var hp=new Vector3(b.center.x,b.min.y,b.center.z);float age=Time.realtimeSinceStartup-heldShotTime;var w=global::InventoryManager.EquippedWeapon;float angle=w!=null&&w.Pointer==heldShotWeapon&&age>=0&&age<.08f?0:20*GunSqueeze();var q=Quaternion.AngleAxis(-angle,Vector3.right);selectedParts[i].transform.localRotation=q;selectedParts[i].transform.localPosition=hp-q*hp;}
  }
 }
 private void FitImportedTriggerFinger(){
  if(!SelectedActive("Shotgun")&&!SelectedActive("Rifle")){if(!IsXiphias()&&selectedRoot==null)PrepareGunTrigger();return;}
  // Imported grips are authored around this frame, not the native weapon's wrist offset.
  var hand=handsObjects[1].transform;bool rifle=SelectedActive("Rifle");
  var center=rifle?new Vector3(0,-.025f,-.040f):new Vector3(0,-.021f,-.003f);
  var palm=center+new Vector3(.027f,0,-.008f);
  hand.position+=selectedRoot.transform.TransformPoint(palm)-hand.TransformPoint(handPalmCenters[1]);
  FitHandAroundBox(1,selectedRoot.transform,center,new Vector3(.026f,.066f,.037f));
  var pivot=ImportedTriggerPivot();var q=Quaternion.AngleAxis(18*GunSqueeze(),Vector3.right);
  var contact=pivot+q*new Vector3(.004f,-.017f,.007f);
  FitFingerToContact(1,"index",rightWeaponPosition+rightWeaponRotation*contact*UnitsPerMetre,8);
 }
 private void AnimateImportedIndex(int pose,Vector3 pivot){
  var mesh=approvedPoseMeshes[pose];if(importedIndexRest[pose]==null)importedIndexRest[pose]=mesh.vertices;
  var rest=importedIndexRest[pose];
  if(importedIndexWeights==null){using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(AglModelData.IndexWeights)))){importedIndexWeights=new float[r.BaseStream.Length/4];for(int i=0;i<importedIndexWeights.Length;i++)importedIndexWeights[i]=r.ReadSingle();}}
  if(rest.Length!=importedIndexWeights.Length)throw new InvalidOperationException("Approved index topology mismatch");
  var vertices=new Vector3[rest.Length];float pull=GunSqueeze();
  for(int i=0;i<rest.Length;i++)vertices[i]=pivot+Quaternion.AngleAxis(18*pull*importedIndexWeights[i],Vector3.right)*(rest[i]-pivot);
  mesh.vertices=vertices;mesh.RecalculateNormals();mesh.RecalculateBounds();
 }
} }
