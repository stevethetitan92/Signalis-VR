using UnityEngine;
namespace SignalisVrTracking {
 public sealed class PauseHoldPolicy {
  private float started=-1;private bool latched,blocked;
  public bool Consuming {get{return latched;}}
  public bool Update(bool available,bool held,float now){
   if(!held){started=-1;latched=false;blocked=false;return false;}
   if(latched)return false;
   if(!available){started=-1;blocked=true;return false;}
   if(blocked)return false;
   if(started<0){started=now;return false;}
   if(now-started<3f)return false;
   latched=true;return true;
  }
 }
 public sealed partial class Tracking {
  private readonly PauseHoldPolicy pauseHold=new PauseHoldPolicy();
  private void PollPauseHold(bool inputAvailable,bool held){
   var pause=global::PauseMenu.instance;
   bool ready=inputAvailable&&questPolicy.RightArmed&&!modMenuOpen&&inventoryWheelView==null&&WeaponGameplayReady()&&!global::PlayerState.paused&&!global::PlayerState.pauseMenu&&!global::PlayerState.eventScreen&&!global::PlayerState.cutscene&&pause!=null;
   if(pauseHold.Update(ready,held,Time.realtimeSinceStartup))pause.setPause(true);
   // The triggering hold must not also cancel the newly opened pause menu.
   if(pauseHold.Consuming)questFrame.buttons&=~((1<<1)|(1<<7));
  }
 }
}
