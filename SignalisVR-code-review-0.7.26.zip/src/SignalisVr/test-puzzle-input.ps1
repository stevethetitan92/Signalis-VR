$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'QuestPuzzleInput.cs') -Raw
$body=$source.Substring($source.IndexOf('  private struct QuestPuzzleState'))
$harness=@"
using System;
using UnityEngine;
namespace UnityEngine { public struct Vector2 { public float x,y; public Vector2(float x,float y){this.x=x;this.y=y;} } }
public class EventScreen3DCam {public void Update(){}}
public class ROT_Cursor {public void Update(){}}
public class CharacterAction { public enum inputDevice {Keyboard,Controller} public Vector2 Move,Peek; public inputDevice lastActiveController; }
public static class PlayerState { public static CharacterAction input; }
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static Tracking questOwner;
  private void CenterSnowCursorBeforeInput(){}
  private bool questNativeAvailable=true,owns=true;
  private int questNativeThread=System.Threading.Thread.CurrentThread.ManagedThreadId;
  private Frame questFrame;
  private struct Frame {public float uiX,uiY,lookX,lookY;}
  private bool QuestOwnsInputMode(){return owns;}
  private string lookBlocked;
  private string QuestLookBlocker(bool eventCamera){return lookBlocked;}
  private void QuestLookConsumed(string consumer){}
  private static void Check(bool b,string why){if(!b)throw new Exception(why);}
  public static void RunPuzzleChecks(){
   var q=new Tracking();questOwner=q;
   foreach(var v in new[]{new Vector2(-1,0),new Vector2(1,0),new Vector2(0,-1),new Vector2(0,1),new Vector2(0,0)}) {
    PlayerState.input=new CharacterAction();q.questFrame=new Frame{uiX=v.x,uiY=v.y,lookX=-v.y,lookY=v.x};
    QuestPuzzleState s;QuestPuzzlePrefix(typeof(EventScreen3DCam).GetMethod("Update"),out s);
    Check(PlayerState.input.Move.x==v.x&&PlayerState.input.Move.y==v.y,"direction");
    Check(PlayerState.input.Peek.x==-v.y&&PlayerState.input.Peek.y==0,"horizontal right-stick look only");
    Check(PlayerState.input.lastActiveController==CharacterAction.inputDevice.Controller,"native controller branch");
    var error=new Exception("original");Check(object.ReferenceEquals(error,QuestPuzzleFinalizer(error,s)),"exception preserved");
    Check(PlayerState.input.Move.x==0&&PlayerState.input.Move.y==0&&PlayerState.input.lastActiveController==CharacterAction.inputDevice.Keyboard,"restore");
    Check(PlayerState.input.Peek.x==0&&PlayerState.input.Peek.y==0,"look restore after exception");
   }
   PlayerState.input.Move=new Vector2(-1,.8f);PlayerState.input.Peek=new Vector2(-.9f,.2f);q.questFrame=new Frame{uiX=.5f,uiY=.4f,lookX=.5f,lookY=-.8f};
   q.lookBlocked="dialogue";QuestPuzzleState blocked;QuestPuzzlePrefix(typeof(EventScreen3DCam).GetMethod("Update"),out blocked);
   Check(!blocked.restorePeek&&PlayerState.input.Peek.x==-.9f&&PlayerState.input.Peek.y==.2f,"blocked event preserves physical look");QuestPuzzleFinalizer(null,blocked);q.lookBlocked=null;
   QuestPuzzleState outer;QuestPuzzlePrefix(typeof(EventScreen3DCam).GetMethod("Update"),out outer);
   Check(PlayerState.input.Move.x==-1&&PlayerState.input.Move.y==.8f,"stronger physical input");
   Check(PlayerState.input.Peek.x==-.9f&&PlayerState.input.Peek.y==.2f,"look physical precedence per axis");
   QuestPuzzleState inner;QuestPuzzlePrefix(typeof(EventScreen3DCam).GetMethod("Update"),out inner);QuestPuzzleFinalizer(null,inner);
   Check(PlayerState.input.lastActiveController==CharacterAction.inputDevice.Controller,"nested restore");
   Check(PlayerState.input.Peek.y==.2f,"nested look restore");
   QuestPuzzleFinalizer(null,outer);
   Check(PlayerState.input.lastActiveController==CharacterAction.inputDevice.Keyboard,"outer restore");
   Check(PlayerState.input.Peek.x==-.9f&&PlayerState.input.Peek.y==.2f,"outer look restore");
   QuestPuzzleState cursor;QuestPuzzlePrefix(typeof(ROT_Cursor).GetMethod("Update"),out cursor);
   Check(!cursor.restorePeek&&PlayerState.input.Peek.y==.2f,"puzzle cursor must not receive look override");
   PlayerState.input.Peek=new Vector2(.1f,.3f);QuestPuzzleFinalizer(null,cursor);
   Check(PlayerState.input.Peek.x==.1f&&PlayerState.input.Peek.y==.3f,"cursor must not restore unrelated look");
   for(int i=0;i<3;i++){
    q.owns=i!=0;q.questNativeAvailable=i!=1;q.questNativeThread=i==2?-1:System.Threading.Thread.CurrentThread.ManagedThreadId;
    QuestPuzzleState s;QuestPuzzlePrefix(typeof(EventScreen3DCam).GetMethod("Update"),out s);Check(s.input==null,"unavailable/focus/thread guard");QuestPuzzleFinalizer(null,s);
   }
   q.owns=true;q.questNativeAvailable=true;q.questNativeThread=System.Threading.Thread.CurrentThread.ManagedThreadId;
   PlayerState.input=null;QuestPuzzleState none;QuestPuzzlePrefix(typeof(EventScreen3DCam).GetMethod("Update"),out none);QuestPuzzleFinalizer(null,none);
  }
"@
Add-Type -TypeDefinition ($harness+$body)
[SignalisVrTracking.Tracking]::RunPuzzleChecks()
'PASS actual scoped prefix/finalizer: four directions, neutral, physical precedence, nested restoration, original exception, focus/availability/thread/null guards. Harness does not exercise native detour or headset.'

