$ErrorActionPreference='Stop'
Add-Type -Path "$PSScriptRoot/MapDiscoveryPolicy.cs"
$p=[SignalisVrTracking.MapDiscoveryPolicy]
for($mask=0;$mask -lt 16;$mask++){
 $active=($mask-band 1)-ne 0;$room=($mask-band 2)-ne 0;$view=($mask-band 4)-ne 0;$clear=($mask-band 8)-ne 0
 if($p::Sight($active,$room,$view,$clear) -ne ($mask-eq 15)){throw "Sight gate failed: $mask"}
}
[Reflection.Assembly]::LoadFrom((Resolve-Path 'work/quest-native-lab/MelonLoader/Mono.Cecil.dll'))|Out-Null
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try{
 $t=$a.MainModule.Types|Where-Object FullName -eq 'SignalisVrTracking.Tracking'
 function Calls($name){@(($t.Methods|Where-Object Name -eq $name).Body.Instructions|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference]}|ForEach-Object {$_.Operand.Name})}
 foreach($name in @('PrepareVrMapSymbols','VrMapStroke','MapInteractionTriggered')){if((Calls $name)-contains 'FindObjectsOfTypeAll'){throw "Unexpected full object scan in $name"}}
 foreach($name in @('RememberMapDoorInteraction','PollMapDiscovery')){if((Calls 'MapInteractionTriggered')-notcontains $name){throw "Missing interaction update $name"}}
 foreach($name in @('ObjectMarkerClearSight','Sight')){if((Calls 'PollMapDiscovery')-notcontains $name){throw "Discovery bypasses $name"}}
 foreach($name in @('HideXiphias','HideSelected','HideSwingProd','HideHeldModules')){if((Calls 'ClearWheelOcclusion')-notcontains $name){throw "Wheel obstruction not hidden: $name"}}
 if((Calls 'RenderStereo')-notcontains 'ClearWheelOcclusion'){throw 'Wheel occlusion pass missing'}
 if((Calls 'FinishMapStrokeMesh')-notcontains 'set_triangles'){throw 'Batched map mesh missing'}
}finally{$a.Dispose()}
'PASS 16 sight eligibility combinations; compiled map discovery ray/gate integration, interaction refresh, wheel obstruction coverage and batched mesh. Does not simulate Unity collision or headset rendering.'
