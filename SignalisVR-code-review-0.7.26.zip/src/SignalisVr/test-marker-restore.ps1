$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
$begin=$source.IndexOf('private void RestoreMarkerRotations()')
$end=$source.IndexOf('private void RenderStereo()', $begin)
if($begin -lt 0 -or $end -lt 0){throw 'Restore method not found'}
$method=$source.Substring($begin,$end-$begin)
$stub=@'
using System;
class Transform { public int rotation,position,localScale; }
class Renderer { public int sprite,color; public bool enabled,forceRenderingOff; }
public class RestoreTest {
 System.Collections.Generic.Dictionary<Renderer,bool> storageLabelStates=new System.Collections.Generic.Dictionary<Renderer,bool>();
 Renderer[] markerSprites;
 Transform[] markerTransforms;
 bool[] markerPrepared,markerEnabled,markerRenderVetoes;
 int[] savedMarkerArtwork,markerColors,markerRotations,markerPositions,markerScales;
 int rotatedMarkerCount;
 void HideBookBrackets() {} void HideItemHolograms() {}
'@
$test=@'
 public static string Run() {
  var q=new RestoreTest();var label=new Renderer{enabled=false};q.storageLabelStates[label]=true;
  var untouched=new Renderer{sprite=99,color=99,enabled=true,forceRenderingOff=true};
  var changed=new Renderer{sprite=88,color=88,enabled=true,forceRenderingOff=false};
  q.markerSprites=new[]{untouched,changed,null};
  q.markerTransforms=new[]{new Transform{rotation=99,position=99,localScale=99},new Transform{rotation=88,position=88,localScale=88},null};
  q.markerPrepared=new[]{false,true,true};q.markerEnabled=new[]{false,false,false};q.markerRenderVetoes=new[]{false,true,false};
  q.savedMarkerArtwork=new[]{0,1,0};q.markerColors=new[]{0,2,0};q.markerRotations=new[]{0,3,0};q.markerPositions=new[]{0,4,0};q.markerScales=new[]{0,5,0};q.rotatedMarkerCount=3;
  q.RestoreMarkerRotations();
  if(untouched.sprite!=99||untouched.color!=99||!untouched.enabled||!untouched.forceRenderingOff||q.markerTransforms[0].position!=99)throw new Exception("Skipped marker overwritten with stale snapshot");
  if(changed.sprite!=1||changed.color!=2||changed.enabled||!changed.forceRenderingOff||q.markerTransforms[1].rotation!=3||q.markerTransforms[1].position!=4||q.markerTransforms[1].localScale!=5)throw new Exception("Prepared marker not restored");
  if(!label.enabled||q.storageLabelStates.Count!=0)throw new Exception("Storage label state not restored");
  if(q.rotatedMarkerCount!=0||q.markerPrepared[1]||q.markerPrepared[2])throw new Exception("Cleanup flags not cleared");
  changed.sprite=77;q.RestoreMarkerRotations();if(changed.sprite!=77)throw new Exception("Repeated cleanup overwrote native state");
  return "PASS actual production restore method: skipped stale snapshots, prepared state, destroyed marker and repeated cleanup. Software harness only.";
 }
}
'@
Add-Type -TypeDefinition ($stub+$method+$test)
[RestoreTest]::Run()

