using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool mapComplete;
 private sealed class MapPoint {public Component Source;public global::Interaction Inter;public global::Room Room;public Transform Target;public string Id,NativeId;public int Kind;public global::ItemPickup Pickup;public global::UseItemInteraction Puzzle;}
 private readonly List<MapPoint> mapObjects=new List<MapPoint>();
 private readonly List<Vector2> mapPointPositions=new List<Vector2>();
 private readonly List<int> mapPointKinds=new List<int>();
 private int mapObjectsHandle=-1;private string mapObjectsScene;private float nextMapDiscovery,nextMapScan;
 private readonly HashSet<string> rejectedMapIds=new HashSet<string>();
 private global::Room lastMapScanRoom;
 private global::Room[] mapRooms=new global::Room[0];
 private global::EventScreenInteraction[] mapEvents=new global::EventScreenInteraction[0];
 private static string MapObjectId(Transform t,global::Room room){
  var id=t.GetComponent<global::UniqueId>();if(id!=null&&!string.IsNullOrEmpty(id.id))return id.id;
  string path="";for(var p=t;p!=null;p=p.parent)path=p.name+(path.Length==0?"":"/"+path);
  return (int)room.floor+"|"+(room.minimapRoom==null?room.name:room.minimapRoom.name)+"|"+path;
 }
 private global::Room MapOwner(Transform t){
  var direct=t.GetComponentInParent<global::Room>();if(direct!=null)return direct;
  foreach(var room in mapRooms){
   if(room==null||!room.gameObject.scene.IsValid())continue;
   if((room.chunk!=null&&t.IsChildOf(room.chunk.transform))||(room.Cell!=null&&t.IsChildOf(room.Cell.transform))||(room.instantChunk!=null&&t.IsChildOf(room.instantChunk.transform)))return room;
  }return null;
 }
 private void AddMapObject(Component source,global::Interaction inter,int kind){
  if(source==null||!source.gameObject.scene.IsValid())return;
  foreach(var prior in mapObjects)if(prior.Source==source)return;
  // CollapsedPOI is the native ground/traversal observation, not a solvable puzzle.
  if(kind==0&&source.name=="CollapsedPOI")return;
  if(kind==0&&inter!=null&&IsTravelOrCombatInteraction(inter))return;
  if(kind==0&&(source.GetComponentInParent<global::AutoTraverseDoor>()!=null||source.GetComponentInParent<global::Doorway_Double>()!=null||source.GetComponent<global::DoorLockEventInteraction>()!=null))return;
  var target=inter!=null?inter.transform:source.transform;
  var room=MapOwner(source.transform);if(room==null&&inter!=null)room=MapOwner(inter.transform);
  foreach(var ev in mapEvents){
   if(ev==null||ev.EventObject==null||!source.transform.IsChildOf(ev.EventObject.transform))continue;
   // Close-up screen children are not physical objects in the owning room.
   var uid=source.GetComponent<global::UniqueId>();if(uid!=null&&!string.IsNullOrEmpty(uid.id))rejectedMapIds.Add(MapDiscoveryPrefix+uid.id);
   return;
  }
  if(room==null)return;
  var native=source.GetComponent<global::MinimapPOIObject>();if(native==null&&inter!=null)native=inter.GetComponent<global::MinimapPOIObject>();
  var point=new MapPoint{Source=source,Inter=inter,Room=room,Target=target,Id=MapCanonicalId(MapObjectId(source.transform,room),kind,room),NativeId=native==null?null:native.id,Kind=kind,Pickup=source.TryCast<global::ItemPickup>(),Puzzle=source.TryCast<global::UseItemInteraction>()};
  foreach(var prior in mapObjects)if(prior.Id==point.Id||(inter!=null&&prior.Inter==inter))return;
  mapObjects.Add(point);highlightContexts.Clear();
 }
 private void PollMapDiscovery(){
  if(global::PlayerState.player==null)return;
  if(Time.realtimeSinceStartup<nextMapDiscovery)return;nextMapDiscovery=Time.realtimeSinceStartup+.25f;
  var activeScene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();string scene=activeScene.name;
  if(mapObjectsHandle!=activeScene.handle){mapObjectsHandle=activeScene.handle;mapObjectsScene=scene;mapObjects.Clear();rejectedMapIds.Clear();lastMapScanRoom=null;nextMapScan=0;}
  if(lastMapScanRoom!=global::PlayerState.currentRoom){lastMapScanRoom=global::PlayerState.currentRoom;nextMapScan=0;nextMarkerSpriteSearch=0;}
  if(Time.realtimeSinceStartup>=nextMapScan){
   nextMapScan=Time.realtimeSinceStartup+30;
   var scan=System.Diagnostics.Stopwatch.StartNew();
   // Room ownership and serialized interaction owners may become available after the first marker scan.
   highlightContexts.Clear();
   var rooms=new List<global::Room>();foreach(var room in Resources.FindObjectsOfTypeAll<global::Room>())if(room!=null&&room.gameObject.scene.IsValid())rooms.Add(room);mapRooms=rooms.ToArray();
   var events=new List<global::EventScreenInteraction>();foreach(var ev in Resources.FindObjectsOfTypeAll<global::EventScreenInteraction>())if(ev!=null&&ev.gameObject.scene.IsValid())events.Add(ev);mapEvents=events.ToArray();
   foreach(var p in Resources.FindObjectsOfTypeAll<global::SavePoint>())AddMapObject(p,p.inter,1);
   foreach(var p in Resources.FindObjectsOfTypeAll<global::StorageBox>())AddMapObject(p,p.inter,2);
   // Generic use-item actions include passages and ground triggers; native POIs own puzzle classification.
   foreach(var p in Resources.FindObjectsOfTypeAll<global::ItemPickup>()){var item=p._item;if(item==null&&global::InventoryManager.allItems!=null&&global::InventoryManager.allItems.ContainsKey(p._itemEnum))item=global::InventoryManager.allItems[p._itemEnum];if(item!=null)AddMapObject(p,p.inter,MapItemKind(item));}
   foreach(var p in Resources.FindObjectsOfTypeAll<global::BookScreen>())if(p.book!=null)AddMapObject(p,p.inter,4);
   foreach(var p in Resources.FindObjectsOfTypeAll<global::ObservationDialogue>())AddMapObject(p,p.inter,4);
   foreach(var p in Resources.FindObjectsOfTypeAll<global::MinimapPOIObject>()){
    bool exists=false;foreach(var prior in mapObjects)if(prior.NativeId==p.id){exists=true;break;}
    if(!exists)AddMapObject(p,p.inter,0);
   }
   MelonLoader.MelonLogger.Msg("MAP POINTS: scene="+scene+" classified="+mapObjects.Count+" scanMs="+scan.Elapsed.TotalMilliseconds.ToString("F2"));
  }
  var player=global::PlayerState.player;if(player==null)return;
  MapMarkVisited();
  foreach(var point in mapObjects){
   if(point.Kind>2||point.Source==null||point.Target==null||!point.Source.gameObject.activeInHierarchy)continue;
   if(point.Puzzle!=null&&point.Puzzle.unlocked)global::SProgress.SetInt(point.Id+":gone",1);
   if(global::SProgress.GetInt(point.Id,0)!=0)continue;
   bool interacted=point.Inter!=null&&point.Inter.triggered;
   bool discover=MapDiscoveryPolicy.Discover(interacted,MapSameRoom(point.Room,global::PlayerState.currentRoom),point.Target.gameObject.activeInHierarchy,MapDiscoveryDistance(point,player.transform.position));
   if(!discover&&point.Inter!=null&&MapSameRoom(point.Room,global::PlayerState.currentRoom)&&camera!=null){Bounds visibleBounds;var origin=ItemObjectBounds(point.Inter,out visibleBounds)?visibleBounds.center:point.Inter.pointOfInterest!=null?point.Inter.pointOfInterest.position:point.Target.position;var view=Quaternion.Inverse(stereoRotation)*(origin-stereoPosition);discover=MapDiscoveryPolicy.Sight(point.Source.gameObject.activeInHierarchy,true,view.z>0&&Mathf.Abs(view.x)<=view.z*1.2f&&Mathf.Abs(view.y)<=view.z,ObjectMarkerClearSight(point.Inter,origin));}
   if(discover)DiscoverMapPoint(point,interacted?"interaction":"nearby");
  }
 }
 private void DiscoverMapPoint(MapPoint point,string via){
  global::SProgress.SetInt(point.Id,1);if(!string.IsNullOrEmpty(point.NativeId))global::SProgress.SetInt("SignalisVR.Map.Native:"+point.NativeId,1);
  nextModMapRefresh=0;MelonLoader.MelonLogger.Msg("MAP DISCOVERY: "+point.Id+" kind="+point.Kind+" via="+via);
 }
 private void InstallMapDiscovery(){
  InstallStorageStereo();
  questHarmony.Patch(HarmonyLib.AccessTools.Method(typeof(global::Interaction),"trigger"),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(MapInteractionTriggered)));
 }
 private static void MapInteractionTriggered(global::Interaction __instance){
  var q=questOwner;if(q==null)return;
  try{q.RememberMapDoorInteraction(__instance);q.nextModMapRefresh=0;q.nextMapDiscovery=0;q.PollMapDiscovery();foreach(var point in q.mapObjects)if(point.Kind<=2&&point.Inter==__instance&&global::SProgress.GetInt(point.Id,0)==0)q.DiscoverMapPoint(point,"interaction");}catch(Exception ex){MelonLoader.MelonLogger.Warning("MAP interaction observer: "+ex.Message);}
 }
 private static bool MapPointGone(string id){const string prefix="SignalisVR.Map.Discovered.v2:";string native=id.StartsWith(prefix,StringComparison.Ordinal)?id.Substring(prefix.Length):id;return global::SProgress.GetInt(id+":gone",0)!=0||!global::SProgress.GetBool("exists: "+native,true);}
 private static int MapItemKind(global::AnItem item){
  string name=item._item.ToString();
  switch(name){case "PistolAmmo":return 5;case "ShotgunAmmo":return 6;case "SmgAmmo":return 7;case "RifleAmmo":return 8;case "FlareGunAmmo":return 9;}
  if(item.type==global::AnItem.AnItemType.Key||item.type==global::AnItem.AnItemType.Object)return 3;
  return 100+(int)item._item;
 }
 private void CompleteAllMaps(){
  var manager=global::PersistentMinimapManager.instance;if(manager==null||manager.FloorManagers==null)return;
  foreach(var floor in manager.FloorManagers){
   if(floor==null||!floor.gameObject.scene.IsValid())continue;
   if(manager.discoveredFloorManagers!=null&&!manager.discoveredFloorManagers.Contains(floor))manager.discoveredFloorManagers.Add(floor);
   foreach(var room in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true))room.discovered=true;
   if(floor.Rooms!=null)foreach(var room in floor.Rooms)if(room!=null){room.discovered=true;if(room.children!=null)foreach(var child in room.children)if(child!=null)child.discovered=true;}
  }
 }
 private void RefreshMapPoints(global::PersistentMinimapFloor floor,Transform basis){
  mapPointPositions.Clear();mapPointKinds.Clear();mapLabelPoints.Clear();mapLabelTexts.Clear();MapRoomLabels(floor,basis);var ids=new HashSet<string>();
  foreach(var poi in floor.GetComponentsInChildren<global::MinimapPOI>(true)){
   MapPoint match=null;foreach(var item in mapObjects)if(!string.IsNullOrEmpty(item.NativeId)&&item.NativeId==poi.id){match=item;break;}
   if(match==null||match.Kind>2||poi.dim||MapPointGone(match.Id))continue;
   bool discovered=global::SProgress.GetInt("SignalisVR.Map.Native:"+poi.id,0)!=0||(match!=null&&global::SProgress.GetInt(match.Id,0)!=0);
   if(!mapComplete&&!discovered)continue;
   var p=basis.InverseTransformPoint(poi.transform.position);
   mapPointPositions.Add((new Vector2(p.x,p.y)-modMapCenter)*modMapScale);mapPointKinds.Add(match==null?0:match.Kind);MapPuzzleLabel(poi,basis);ids.Add(poi.id??"");if(match!=null)ids.Add(match.Id);
  }
  var placed=new HashSet<string>();
  foreach(var item in mapObjects){
   if(item.Kind>2||item.Source==null||item.Target==null||!MapSameRoom(item.Room,global::PlayerState.currentRoom)||(!string.IsNullOrEmpty(item.NativeId)&&ids.Contains(item.NativeId)))continue;
   if(!item.Source.gameObject.activeInHierarchy||ids.Contains(item.Id)||placed.Contains(item.Id)||MapPointGone(item.Id)||(!mapComplete&&global::SProgress.GetInt(item.Id,0)==0))continue;
   Vector2 p;if(MapPlayerPoint(item.Target.position,out p)){mapPointPositions.Add(p);mapPointKinds.Add(item.Kind);placed.Add(item.Id);MapRememberPosition(item,p,floor,basis);}
  }
  var boundsCache=new Dictionary<string,Vector2[]>();
  foreach(var entry in mapCatalogue){
   if(entry.Kind>2||entry.Floor!=(int)floor.FloorID||entry.Id.Contains("|Events/"))continue;
   if(entry.Kind==0){bool known=false;foreach(var live in mapObjects)if(live.Kind==0&&live.Id==MapDiscoveryPrefix+entry.Id){known=true;break;}if(!known)continue;}
   string id="SignalisVR.Map.Discovered.v2:"+entry.Id;
   if(rejectedMapIds.Contains(id)||ids.Contains(id)||placed.Contains(id)||!MapDiscoveryPolicy.Visible(mapComplete,global::SProgress.GetInt(id,0)!=0,MapPointGone(id)))continue;
   Vector2[] cached;if(!boundsCache.TryGetValue(entry.Room,out cached)){Vector2 lo,hi;cached=MapCatalogueBounds(floor,basis,entry.Room,out lo,out hi)?new[]{lo,hi}:null;boundsCache[entry.Room]=cached;}
   if(cached==null)continue;var low=cached[0];var high=cached[1];
   float nx=entry.X,ny=entry.Y;if(global::SProgress.GetInt(id+":position",0)!=0){nx=global::SProgress.GetInt(id+":x",0)/100000f;ny=global::SProgress.GetInt(id+":y",0)/100000f;}
   var p=new Vector2(Mathf.Lerp(low.x,high.x,Mathf.Clamp01(nx)),Mathf.Lerp(low.y,high.y,Mathf.Clamp01(ny)));
   mapPointPositions.Add((p-modMapCenter)*modMapScale);mapPointKinds.Add(entry.Kind);
  }
 }
 private static bool MapCatalogueBounds(global::PersistentMinimapFloor floor,Transform basis,string name,out Vector2 low,out Vector2 high){
  low=new Vector2(float.PositiveInfinity,float.PositiveInfinity);high=new Vector2(float.NegativeInfinity,float.NegativeInfinity);bool found=false;
  if(floor.Rooms==null)return false;
  foreach(var room in floor.Rooms){
   if(room==null||room.RoomID==null||room.RoomID.name!=name)continue;
   foreach(var shape in room.GetComponentsInChildren<global::MinimapActiveRoom>(true)){
    var sr=shape.SR;if(sr==null)sr=shape.GetComponent<SpriteRenderer>();if(sr==null||sr.sprite==null)continue;
    var b=MapSpriteBounds(sr);for(int k=0;k<8;k++){var p=basis.InverseTransformPoint(sr.transform.TransformPoint(b.center+Vector3.Scale(b.extents,new Vector3((k&1)==0?-1:1,(k&2)==0?-1:1,(k&4)==0?-1:1))));low=Vector2.Min(low,new Vector2(p.x,p.y));high=Vector2.Max(high,new Vector2(p.x,p.y));found=true;}
   }
  }return found;
 }
}}







