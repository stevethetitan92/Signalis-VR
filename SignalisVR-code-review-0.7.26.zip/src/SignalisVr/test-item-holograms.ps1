$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'ItemMarkerHolograms.cs') -Raw
$begin=$s.IndexOf(' public static class ItemMarkerSizing')
$end=$s.IndexOf(' public sealed partial class Tracking')
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$s.Substring($begin,$end-$begin)+'}')
foreach($units in 1,18,100){
 foreach($size in 0,.001,.1,1,100,[float]::NaN,[float]::PositiveInfinity){
  $result=[SignalisVrTracking.ItemMarkerSizing]::Extent($size,$units)
  if([float]::IsNaN($result) -or $result -lt .0349*$units){throw 'Item marker escaped readable physical-size bounds'}
 }
}
$placement=Get-Content (Join-Path $PSScriptRoot 'HeadsetObjectHighlights.cs') -Raw
foreach($required in @('interaction.pointOfInterest','PlaceObjectHologram','markerOwners.TryGetValue','pickup.triggered || pickup.fadingOut','context.travel')){if(!$placement.Contains($required)){throw "Missing marker ownership/state guard $required"}}
if($s -match 'interaction\.(enabled|triggered)\s*=' -or $s -match 'SetActive\('){throw 'Hologram mutates interaction or object activity'}
foreach($required in @('ClearItemHolograms','HideItemHolograms','Sprites/Default','ItemHologramScanlines','ItemHologramGlow')){if(!$s.Contains($required)){throw "Missing hologram resource/scope $required"}}
'PASS readable marker sizing across world scales, native interaction ownership/state guards and private hologram cleanup. Screenshot alignment and headset graphics remain unverified.'
