namespace SignalisVrTracking { internal static class HdPistolData {
public static readonly string Geometry=HdAsset.Read("Pistol-0.bin");
public static readonly string[] Textures={HdAsset.Read("Pistol-1.bin"),HdAsset.Read("Pistol-2.bin"),HdAsset.Read("Pistol-3.bin"),HdAsset.Read("Pistol-mag.png")};
public static readonly float[] Colors={1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,0.0f,0.0276792049407959f,1.0f,1.0f};
public static readonly UnityEngine.Vector3 Support=new UnityEngine.Vector3(0.00000000f,0.02830000f,0.02570000f);
public static readonly UnityEngine.Vector3 MagazineTop=new UnityEngine.Vector3(-0.00030000f,0.06162900f,0.02615700f);
public static readonly UnityEngine.Vector3 Muzzle=new UnityEngine.Vector3(0.00000000f,0.06549000f,0.17294000f);
} }
