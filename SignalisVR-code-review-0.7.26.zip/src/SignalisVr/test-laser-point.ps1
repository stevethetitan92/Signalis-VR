$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'ModLasers.cs') -Raw
foreach($guard in @('new Color(1,1,1,pixels[i].a)','RenderTexture.active=previous','RenderTexture.ReleaseTemporary(rt)','state.Renderer.sprite=state.Sprite','point.color=tint','laser.decalPoint','neutralLaserSprites.TryGetValue','DestroyLaserPointTextures()')){if(!$s.Contains($guard)){throw "Missing native-dot conversion/restoration $guard"}}
if($s.IndexOf('TintNativeLaserPoint(a,tint)') -lt $s.IndexOf('modPointColor[i]=a.laserPointSR.color')){throw 'Native original dot color captured after tint'}
'PASS source integration: retain native sprite alpha, neutralize baked RGB, selected tint, cache, render-target/state restoration and cleanup. GPU colors unverified.'

# Compile the actual visibility-scope methods against renderer/scene stand-ins.
$start=$s.IndexOf('  private sealed class LaserEndpointState')
$end=$s.IndexOf('  private Sprite NeutralLaserSprite', $start)
$methods=$s.Substring($start,$end-$start)
$fixture=@'
using System;using System.Collections.Generic;
namespace UnityEngine {
 public static class Time {public static float unscaledTime;}
 public class Renderer {public bool enabled;}
 public class SpriteRenderer:Renderer {}
 public class CanvasRenderer {public bool cull;}
 public class MeshRenderer:Renderer {}
 public class GameObject {public bool activeInHierarchy=true;public Renderer[] children=new Renderer[0];public CanvasRenderer[] canvases=new CanvasRenderer[0];public T[] GetComponentsInChildren<T>(bool includeInactive){if(typeof(T)==typeof(CanvasRenderer))return Array.ConvertAll(canvases,r=>(T)(object)r);return Array.ConvertAll(children,r=>(T)(object)r);}}
 public class Transform:GameObject {public GameObject gameObject {get{return this;}}}
 public static class Resources {public static global::AimAssistPopup[] Popups;public static global::PersistentAimCursor[] Cursors=new global::PersistentAimCursor[0];public static global::PlayerAim[] Aims=new global::PlayerAim[0];public static T[] FindObjectsOfTypeAll<T>(){if(typeof(T)==typeof(global::PersistentAimCursor))return Array.ConvertAll(Cursors,r=>(T)(object)r);if(typeof(T)==typeof(global::PlayerAim))return Array.ConvertAll(Aims,r=>(T)(object)r);return Array.ConvertAll(Popups,r=>(T)(object)r);}}
}
namespace UnityEngine.SceneManagement {public struct Scene {public int handle;} public static class SceneManager {public static int Handle;public static Scene GetActiveScene(){return new Scene{handle=Handle};}}}
public class PersistentAimCursor {public UnityEngine.SpriteRenderer sr;}
public class PlayerAim {public UnityEngine.GameObject crosshairBlocked;public UnityEngine.Transform crosshair;public UnityEngine.SpriteRenderer crosshairSR;}
public class AimLaser {public UnityEngine.SpriteRenderer laserPointSR;public UnityEngine.Transform laserPoint;public UnityEngine.GameObject decalPoint;}
public class AimAssistPopup {public UnityEngine.GameObject gameObject=new UnityEngine.GameObject();public UnityEngine.GameObject Pivot;public T[] GetComponentsInChildren<T>(bool includeInactive){return Pivot.GetComponentsInChildren<T>(includeInactive);}}
namespace SignalisVrTracking {using UnityEngine;public sealed partial class Tracking {
 private bool modLasersOn;
'@
$checks=@'
 public static void TestVisibility(){
  var q=new Tracking();var sprite=new SpriteRenderer{enabled=true};var decal=new MeshRenderer{enabled=true};var hidden=new MeshRenderer{enabled=false};var unrelated=new MeshRenderer{enabled=true};
  var laser=new global::AimLaser{laserPointSR=sprite,laserPoint=new Transform{children=new Renderer[]{sprite}},decalPoint=new GameObject{children=new Renderer[]{decal,hidden}}};
  q.modLasersOn=false;q.CaptureNativeLaserEndpoints(laser);
  if(sprite.enabled||decal.enabled||hidden.enabled||!unrelated.enabled||q.laserEndpointStates.Count!=3)throw new Exception("OFF left dot/decal visible or changed unrelated artwork");
  q.RestoreLaserEndpoints();if(!sprite.enabled||!decal.enabled||hidden.enabled||q.laserEndpointStates.Count!=0)throw new Exception("Endpoint flags did not restore");
  q.modLasersOn=true;q.CaptureNativeLaserEndpoints(laser);if(!sprite.enabled||!decal.enabled||hidden.enabled)throw new Exception("ON forced inactive endpoint visible");q.RestoreLaserEndpoints();
  var enemyBox=new SpriteRenderer{enabled=true};var enemyBoxBlack=new MeshRenderer{enabled=true};var enemyMesh=new MeshRenderer{enabled=true};
  Resources.Popups=new[]{new global::AimAssistPopup{Pivot=new GameObject{children=new Renderer[]{enemyBox,enemyBoxBlack}}}};
  var canvas=new CanvasRenderer{cull=false};var alreadyCulled=new CanvasRenderer{cull=true};Resources.Popups[0].gameObject.activeInHierarchy=false;Resources.Popups[0].Pivot.canvases=new[]{canvas,alreadyCulled};
  var cross=new SpriteRenderer{enabled=true};var blocked=new MeshRenderer{enabled=true};Resources.Aims=new[]{new PlayerAim{crosshairSR=cross,crosshairBlocked=new GameObject{children=new Renderer[]{blocked}}}};var cursor=new SpriteRenderer{enabled=true};Resources.Cursors=new[]{new PersistentAimCursor{sr=cursor}};
  q.PrepareEnemyTargetBoxes();if(!canvas.cull||!alreadyCulled.cull||blocked.enabled||cursor.enabled||cross.enabled)throw new Exception("Canvas/cursor/blocked artwork escaped eye scope");q.RestoreEnemyTargetBoxes();if(canvas.cull||!alreadyCulled.cull||!blocked.enabled||!cursor.enabled||!cross.enabled)throw new Exception("Overlay restoration incorrect");
  try{q.PrepareEnemyTargetBoxes();if(enemyBox.enabled||enemyBoxBlack.enabled||!enemyMesh.enabled)throw new Exception("Enemy targeting artwork/model isolation failed");}finally{q.RestoreEnemyTargetBoxes();}
  if(!enemyBox.enabled||!enemyBoxBlack.enabled||q.enemyBoxStates.Count!=0)throw new Exception("Targeting artwork did not restore");
  var newBox=new SpriteRenderer{enabled=true};Resources.Popups=new[]{new global::AimAssistPopup{Pivot=new GameObject{children=new Renderer[]{newBox}}}};UnityEngine.SceneManagement.SceneManager.Handle=2;q.PrepareEnemyTargetBoxes();if(newBox.enabled)throw new Exception("New room targeting popup missed");q.RestoreEnemyTargetBoxes();
 }
}}
'@
Add-Type -TypeDefinition ($fixture+$methods+$checks)
[SignalisVrTracking.Tracking]::TestVisibility()
'PASS actual scope behavior: OFF hides sprite and mesh decal endpoints; ON preserves inactive state; targeting popup artwork isolated from enemy models; flags restore and scene cache refreshes. Headset appearance unverified.'

