param([string]$GamePath='E:/SteamLibrary/steamapps/common/SIGNALIS',[string]$AudioSourcePath='')
$ErrorActionPreference='Stop'
$scratch=Join-Path $PSScriptRoot 'flare-hook-harness'
New-Item -ItemType Directory -Force $scratch | Out-Null
foreach($name in '0Harmony.dll','MonoMod.RuntimeDetour.dll','MonoMod.Utils.dll','Mono.Cecil.dll'){
 Copy-Item (Join-Path "$GamePath/MelonLoader" $name) $scratch -Force
}
$raw=Get-Content (Join-Path $PSScriptRoot 'FlareProjectile.cs') -Raw
$a=$raw.IndexOf(' private static class FlareProjectilePatch');$b=$raw.IndexOf(' private bool LaunchManualFlare')
$source='using System;using HarmonyLib;using UnityEngine;namespace SignalisVrTracking {public sealed partial class Tracking {'+$raw.Substring($a,$b-$a)+'}}'
$stub=@'
namespace UnityEngine {public static class Time {public static float realtimeSinceStartup;}public class Transform {public bool IsChildOf(Transform other){return this==other;}}public class GameObject {public Transform transform=new Transform();}}
public class AimLaser {public UnityEngine.Transform transform=new UnityEngine.Transform();public bool flare=true;public int Misses;[System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]public void miss(){Misses++;}}
public class TestOwner {public UnityEngine.GameObject FlareGun=new UnityEngine.GameObject();}
public class Items {public enum itemlist {FlareGun,Pistol,SMG}}
public class AnItem {public Items.itemlist _item;}
public class AnWeapon {public AnItem parentItem=new AnItem();public int magAmmo=6;}
public static class InventoryManager {public static AnWeapon EquippedWeapon;}
public class PlayerAttack {
 public static PlayerAttack instance;public AnWeapon weapon=new AnWeapon();public int NativeShots;
 [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)] public void RaycastShot(){NativeShots++;if(weapon.magAmmo>0)weapon.magAmmo--;}
}
namespace SignalisVrTracking {public sealed partial class Tracking {
 private float manualFlareShotTime=-100;private TestOwner owner=new TestOwner();private TestOwner FindRifleOwner(PlayerAttack a){return owner;}private static Tracking weaponOwner=new Tracking();private bool Ready=true,Fail;private int Projectiles;
 private bool ProdVrMode(){return Ready;} private bool ControllerWeaponVisualReady(){return false;}
 private bool LaunchManualFlare(PlayerAttack a,AnWeapon w){if(Fail)return false;Projectiles++;w.magAmmo--;manualFlareShotTime=UnityEngine.Time.realtimeSinceStartup;return true;}
 private sealed class Scope{} private static int Restores;
 private static void Begin(out Scope __state){__state=new Scope();}
 private static Exception End(Exception __exception,Scope __state){if(__state==null)throw new Exception("Missing scoped pose");Restores++;return __exception;}
 public static void Main(){
  var h=new HarmonyLib.Harmony("signalis.flare-composition-test");var method=HarmonyLib.AccessTools.DeclaredMethod(typeof(PlayerAttack),"RaycastShot");
  h.Patch(method,prefix:new HarmonyLib.HarmonyMethod(typeof(Tracking),"Begin"),finalizer:new HarmonyLib.HarmonyMethod(typeof(Tracking),"End"));weaponOwner.InstallFlareProjectile(h);
  var a=new PlayerAttack();PlayerAttack.instance=a;InventoryManager.EquippedWeapon=a.weapon;for(int i=0;i<6;i++)a.RaycastShot();
  if(a.weapon.magAmmo!=0||a.NativeShots!=0||weaponOwner.Projectiles!=6||Restores!=6)throw new Exception("Duplicate shot/ammo/pose failure");
  var laser=new AimLaser();laser.transform=weaponOwner.owner.FlareGun.transform;laser.miss();if(laser.Misses!=0)throw new Exception("Duplicate native flare not suppressed");UnityEngine.Time.realtimeSinceStartup=1;laser.miss();if(laser.Misses!=0)throw new Exception("Delayed duplicate leaked");laser.flare=false;laser.miss();if(laser.Misses!=0)throw new Exception("Player flare laser leaked despite unset flag");laser.transform=new UnityEngine.Transform();laser.miss();if(laser.Misses!=1)throw new Exception("Unrelated laser suppressed");
  a.RaycastShot();if(a.NativeShots!=0||weaponOwner.Projectiles!=6||a.weapon.magAmmo!=0)throw new Exception("Empty gun fired");
  a.weapon.magAmmo=2;weaponOwner.Fail=true;a.RaycastShot();if(a.NativeShots!=0||a.weapon.magAmmo!=2)throw new Exception("Failure fired native projectile or consumed ammo");
  weaponOwner.Fail=false;a.weapon.parentItem._item=Items.itemlist.Pistol;a.RaycastShot();if(a.NativeShots!=1||a.weapon.magAmmo!=1)throw new Exception("Pistol intercepted");
  a.weapon.magAmmo=1;a.weapon.parentItem._item=Items.itemlist.FlareGun;weaponOwner.Ready=false;a.RaycastShot();if(a.NativeShots!=2||a.weapon.magAmmo!=0)throw new Exception("Non-VR flare intercepted");
  Console.WriteLine("PASS actual flare prefix registration with scoped pose restoration: six shots/empty/failure cancellation/pistol/non-VR; projectile physics and visuals require headset test.");
 }
}}
'@
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.dll')) | Out-Null
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.CSharp.dll')) | Out-Null
$framework=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319'
$refs=[System.Collections.Generic.List[Microsoft.CodeAnalysis.MetadataReference]]::new()
foreach($path in @("$scratch/0Harmony.dll","$framework/mscorlib.dll","$framework/System.dll","$framework/System.Core.dll")){$refs.Add([Microsoft.CodeAnalysis.MetadataReference]::CreateFromFile($path))}
$options=[Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions]::new([Microsoft.CodeAnalysis.OutputKind]::ConsoleApplication)
$trees=[Microsoft.CodeAnalysis.SyntaxTree[]]@([Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($source+$stub))
$c=[Microsoft.CodeAnalysis.CSharp.CSharpCompilation]::Create('FlareHookHarness',$trees,$refs,$options)
$exe=Join-Path $scratch 'FlareHookHarness.exe';$stream=[IO.File]::Create($exe)
try{$result=$c.Emit($stream)}finally{$stream.Dispose()}
if(!$result.Success){$result.Diagnostics | ForEach-Object ToString;throw 'Shot hook harness compile failed'}
& $exe
if($LASTEXITCODE -ne 0){throw 'Actual Harmony hook composition failed'}



