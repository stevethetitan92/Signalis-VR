using System;
namespace SignalisVrTracking {
 public sealed class PistolSlideVisualPolicy {
  public static float ShotAmount(float age,bool hasShot,bool empty){
   if(!hasShot||float.IsNaN(age)||float.IsInfinity(age)||age<0)return empty?1:0;
   if(age<.035f){float t=age/.035f;return t*t*(3-2*t);}
   if(empty)return 1;
   if(age>=.14f)return 0;
   float release=(age-.035f)/.105f;return 1-release*release*(3-2*release);
  }
  public static float RackReleaseWeight(float age){return age<0?0:Math.Max(0,1-age/.18f);}
  public static float PullExtension(float distance){return Math.Max(0,Math.Min(1,distance/.02f))*.25f;}
  public float Amount {get;private set;}
  public bool Override {get;private set;}
  private float last=-1f;
  public void Reset(){Amount=0;Override=false;last=-1f;}
  public void Update(float now,bool eligible,bool holdOpen,bool sequenceActive) {
   if(!eligible){Reset();return;}
   float dt=last<0?0:Math.Max(0,Math.Min(.1f,now-last));last=now;
   Amount=holdOpen?Math.Min(1,Amount+dt/.10f):Math.Max(0,Amount-dt/.12f);
   Override=holdOpen||sequenceActive||Amount>0;
  }
 }
}
