using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly RifleHingePolicy rifleHinge=new RifleHingePolicy();
  private bool rifleBarrelHeld,rifleGripPrevious,rifleMotionSample;private Quaternion rifleMotionPrevious,rifleHandRelative;
  private float rifleGripAngleOffset;
  private static readonly Vector3 RiflePivot=HdRifleData.Pivot,RifleGrip=HdRifleData.Support;
  private Vector3 BarrelGripPivot {get{return SelectedActive("FlareGun")?HdFlareGunData.Pivot:RiflePivot;}}
  private Vector3 BarrelGripPoint {get{return SelectedActive("FlareGun")?new Vector3(0,.03093f,.120f):RifleGrip;}}
  private Vector3 BarrelPalmPoint {get{return SelectedActive("FlareGun")?new Vector3(0,.01693f,.120f):new Vector3(RifleGrip.x,-.0162f,RifleGrip.z);}}
  private void ResetRifleBarrelGrip(){rifleBarrelHeld=rifleGripPrevious=rifleMotionSample=false;rifleHinge.Reset();}
  private Quaternion RifleBarrelRotation(){return rightWeaponRotation*Quaternion.AngleAxis(rifleHinge.Angle,Vector3.right);}
  private Vector3 RifleGripWorld(){var pivot=BarrelGripPivot;return rightWeaponPosition+rightWeaponRotation*(pivot+Quaternion.AngleAxis(rifleHinge.Angle,Vector3.right)*(BarrelGripPoint-pivot))*UnitsPerMetre;}
  private Vector3 RiflePalmWorld(){var pivot=BarrelGripPivot;return rightWeaponPosition+rightWeaponRotation*(pivot+Quaternion.AngleAxis(rifleHinge.Angle,Vector3.right)*(BarrelPalmPoint-pivot))*UnitsPerMetre;}
  private float UpdateRifleBarrelGrip(){
   rifleHinge.TravelLimit=SelectedActive("FlareGun")?40f:RifleHingePolicy.MaxAngle;
   bool down=manualLeftGrip&&!rifleGripPrevious;rifleGripPrevious=manualLeftGrip;
   bool open=hingedReload.Active,available=hingedReload.Stage==HingedReloadPolicy.Step.Open&&!additionalInsert;
   var left=controllerMarkers[0];float desired=rifleHinge.Angle;
   if(!manualLeftGrip||hdSupportHeld||left==null||AdditionalHoldingAmmo())rifleBarrelHeld=false;
   if(left!=null){
    var local=Quaternion.Inverse(rightWeaponRotation)*(left.transform.position-rightWeaponPosition)/UnitsPerMetre-BarrelGripPivot;
    float polar=-Mathf.Atan2(local.y,local.z)*57.29578f;
    if(!hdSupportHeld&&!rifleBarrelHeld&&down&&!AdditionalHoldingAmmo()&&available&&Vector3.Distance(left.transform.position,RifleGripWorld())<.085f*UnitsPerMetre){
     rifleBarrelHeld=true;rifleGripAngleOffset=rifleHinge.Angle-polar;
     rifleHandRelative=Quaternion.Inverse(RifleBarrelRotation())*(left.transform.rotation*Quaternion.Euler(0,0,90)*Quaternion.Euler(0,-40,0)*handsCorrections[0]);
    }
    if(rifleBarrelHeld)desired=polar+rifleGripAngleOffset;
   }
   float pitch=0;if(rifleMotionSample){var delta=Quaternion.Inverse(rifleMotionPrevious)*rightWeaponRotation;float angle;Vector3 axis;delta.ToAngleAxis(out angle,out axis);if(angle>180)angle-=360;pitch=angle*axis.x;}
   rifleMotionPrevious=rightWeaponRotation;rifleMotionSample=true;
   var gravity=Quaternion.Inverse(rightWeaponRotation)*(controllerTrackingToWorld*Vector3.down);
   if(rifleBarrelHeld&&open&&desired<=5f&&rifleHinge.Angle>5f){hingedReload.PressB();open=false;}
   return rifleHinge.Tick(Time.unscaledDeltaTime,open,rifleBarrelHeld&&open,desired,gravity.y,gravity.z,pitch)/rifleHinge.TravelLimit;
  }
  private void FitRifleBarrelHand(){
   if(!rifleBarrelHeld||!handsScoped||!SelectedActive("Rifle"))return;
   var hand=handsObjects[0].transform;var rotation=RifleBarrelRotation();
   hand.rotation=rotation*rifleHandRelative;hand.position+=RifleGripWorld()-hand.TransformPoint(handPalmCenters[0]);
   string[] fingers={"index","middle","ring","pinky","thumb"};float[] stations={.033f,.011f,-.011f,-.032f,.035f};
   for(int i=0;i<5;i++){
    // Glove pad clearance around the actual 33.5mm-wide fore-end.
    var target=RifleGrip+new Vector3(i==4?-.025f:.025f,i==4?.033f:.037f,stations[i]);
    var point=rightWeaponPosition+rightWeaponRotation*RiflePivot*UnitsPerMetre+rotation*(target-RiflePivot)*UnitsPerMetre;
    FitFingerToContact(0,fingers[i],point,12);
   }
  }
 }
}


