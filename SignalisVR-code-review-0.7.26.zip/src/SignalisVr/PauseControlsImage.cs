using System;
using UnityEngine;
using UnityEngine.UI;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private GameObject pauseControlsRoot;
 private Canvas pauseControlsCanvas;
 private RawImage pauseControlsImage;
 private void DestroyPauseControlsImage(){if(pauseControlsRoot!=null)UnityEngine.Object.Destroy(pauseControlsRoot);pauseControlsRoot=null;pauseControlsCanvas=null;pauseControlsImage=null;}
 private void UpdatePauseControlsImage(global::PauseMenuShowControls legend){
  var pause=global::PauseMenu.instance;
  if(pauseControlsRoot!=null&&(pause==null||pause.BaseMenu==null||pauseControlsRoot.transform.parent!=pause.BaseMenu.transform||pauseControlsCanvas==null||pauseControlsCanvas.worldCamera==null))DestroyPauseControlsImage();
  bool show=pause!=null&&pause.BaseMenu!=null&&pause.BaseMenu.activeInHierarchy&&!modMenuOpen&&!pause.cutscenePause&&(pause.OptionsMenu==null||!pause.OptionsMenu.activeInHierarchy)&&(pause.manual==null||!pause.manual.activeInHierarchy)&&(pause.areYouSure==null||!pause.areYouSure.activeInHierarchy);
  if(pauseControlsRoot!=null)pauseControlsRoot.SetActive(show);
  if(!show||legend==null||legend.KBLeft==null)return;
  if(pauseControlsRoot==null){
   Camera camera=null;float best=-100000;
   foreach(var c in Camera.allCameras){if(c==null||!c.enabled||c.name.StartsWith("SignalisVR",StringComparison.Ordinal)||(c.cullingMask&(1<<legend.KBLeft.gameObject.layer))==0)continue;var v=c.WorldToViewportPoint(legend.KBLeft.transform.position);if(v.z<=0||v.x<0||v.x>1||v.y<0||v.y>1)continue;if(c.depth>best){camera=c;best=c.depth;}}
   if(camera==null)return;
   if(controlsDiagram==null){controlsDiagram=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(controlsDiagram,Convert.FromBase64String(ControlsArtwork.Png),true))throw new InvalidOperationException("Controls artwork decode failed");controlsDiagram.filterMode=FilterMode.Point;controlsDiagram.wrapMode=TextureWrapMode.Clamp;}
   pauseControlsRoot=new GameObject("SignalisVR_PauseControls");pauseControlsRoot.layer=legend.KBLeft.gameObject.layer;pauseControlsRoot.transform.SetParent(pause.BaseMenu.transform,false);
   pauseControlsCanvas=pauseControlsRoot.AddComponent<Canvas>();pauseControlsCanvas.renderMode=RenderMode.ScreenSpaceCamera;pauseControlsCanvas.worldCamera=camera;pauseControlsCanvas.planeDistance=Math.Max(camera.nearClipPlane+.01f,1f);pauseControlsCanvas.sortingOrder=5;
   var go=new GameObject("ControlsDiagram");go.layer=pauseControlsRoot.layer;var rect=go.AddComponent<RectTransform>();rect.SetParent(pauseControlsRoot.transform,false);pauseControlsImage=go.AddComponent<RawImage>();pauseControlsImage.raycastTarget=false;pauseControlsImage.texture=controlsDiagram;
   // Preserve the original artwork; select only the controller panel, excluding old tabs/Done.
   pauseControlsImage.uvRect=new Rect(14f/1672f,142f/941f,1644f/1672f,674f/941f);
   MelonLoader.MelonLogger.Msg("PAUSE CONTROLS: diagram attached to native camera "+camera.name);
  }
  var r=pauseControlsImage.rectTransform;var cam=pauseControlsCanvas.worldCamera;if(cam==null)return;
  float width=.65f,height=.4f,aspect=cam.aspect;float fittedWidth=Math.Min(width,height*(1644f/674f)/aspect);float fittedHeight=fittedWidth*aspect/(1644f/674f);
  r.anchorMin=new Vector2(.505f-fittedWidth/2,.235f-fittedHeight/2);r.anchorMax=new Vector2(.505f+fittedWidth/2,.235f+fittedHeight/2);r.offsetMin=Vector2.zero;r.offsetMax=Vector2.zero;
 }
}}
