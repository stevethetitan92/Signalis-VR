using System;
namespace SignalisVrTracking {
 // Positive pitch means muzzle-up in weapon-local space. No game-state writes.
 public sealed class RifleCloseGesturePolicy {
  private float previous=-1,started=-1,total;
  private bool latched;
  public void Reset(){previous=started=-1;total=0;latched=false;}
  public bool Tick(float now,float upwardDegrees,bool enabled){
   if(!enabled||float.IsNaN(now)||float.IsInfinity(now)||float.IsNaN(upwardDegrees)||float.IsInfinity(upwardDegrees)){Reset();return false;}
   if(latched)return false;
   if(previous<0){previous=now;return false;}
   float dt=now-previous;previous=now;
   if(dt<=0||dt>.1f||Math.Abs(upwardDegrees)>45){started=-1;total=0;return false;}
   // Downward, slow, or paused movement cannot accumulate into a flick.
   if(upwardDegrees/dt<180){started=-1;total=0;return false;}
   if(started<0||now-started>.18f){started=now-dt;total=0;}
   total+=upwardDegrees;
   if(total<32)return false;
   latched=true;return true;
  }
 }
}
