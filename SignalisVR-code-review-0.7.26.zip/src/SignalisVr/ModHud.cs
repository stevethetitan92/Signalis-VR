using System;
using System.Collections.Generic;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private GameObject modHudRoot,modMapRoot;
  private Mesh modHudText,modAmmoText;
  private string modHealthCaption,modAmmoCaption;
  private readonly List<Renderer> modHudRenderers=new List<Renderer>();
  private readonly List<Material> modHudMaterials=new List<Material>();
  private Transform modHealthFill,modHealthGlow;
  private Transform modAmmoPlacement;
  private readonly List<SpriteRenderer> modMapCopies=new List<SpriteRenderer>();
  private readonly List<SpriteRenderer> modMapGlow=new List<SpriteRenderer>();
  private readonly List<LineRenderer> modMapLines=new List<LineRenderer>();
  private Material modMapLineMaterial;
  private int modMapLineCount;
  private float nextModHudText,nextModMapRefresh;
  private bool modHudFailed;
  private readonly MapRevealPolicy modMapReveal=new MapRevealPolicy();
  private string modMapStatus="Map data not loaded";
  private string lastModMapReport;
  private int modMapReports;
  private readonly List<Vector2> modDoorPoints=new List<Vector2>();
  private readonly List<float> modDoorRotations=new List<float>();
  private readonly List<int> modDoorStates=new List<int>();
  private readonly List<Vector2> modDoorWorld=new List<Vector2>(),modDoorMap=new List<Vector2>();
  private Vector2 modCurrentLow,modCurrentHigh,modMapCenter;
  private float modMapScale;
  private Bounds modRoomBounds;
  private bool modRoomBoundsValid;
  private global::Room boundsRoom;private Bounds cachedRoomBounds;private bool cachedRoomBoundsValid;
  private global::Room modMappedRoom;
  private readonly RoomMapProjection modRoomProjection=new RoomMapProjection();
  private bool modRoomProjectionValid;
  private int modMapMappingReports;
  private int modMapPositionReports;
  private float nextModMapPositionReport;
  private static string MapVector(Vector2 p){return p.x.ToString("F3",System.Globalization.CultureInfo.InvariantCulture)+","+p.y.ToString("F3",System.Globalization.CultureInfo.InvariantCulture);}
  private void ReportModMap(string status){modMapStatus=status;if(status!=lastModMapReport&&modMapReports<16){lastModMapReport=status;modMapReports++;MelonLogger.Msg("MINI MAP: "+(status.Length==0?"live room artwork available":status));}}
  private UnhollowerBaseLib.Il2CppReferenceArray<Camera> modHudCameraBuffer=new UnhollowerBaseLib.Il2CppReferenceArray<Camera>(32);
  private int modHudCameraFrame=-1;
  private bool modHudCinematicVisible;
  private bool ModHudCinematicVisible() {
   if(modHudCameraFrame==Time.frameCount)return modHudCinematicVisible;
   modHudCameraFrame=Time.frameCount;modHudCinematicVisible=false;
   int needed=Camera.allCamerasCount;
   if(needed>modHudCameraBuffer.Length)modHudCameraBuffer=new UnhollowerBaseLib.Il2CppReferenceArray<Camera>(needed+8);
   int count=Camera.GetAllCameras(modHudCameraBuffer);
   for(int i=0;i<count;i++) {
    var c=modHudCameraBuffer[i];if(c==null||!c.isActiveAndEnabled)continue;
    if(c.gameObject.scene.name=="Cutscenes"){modHudCinematicVisible=true;break;}
    for(var t=c.transform;t!=null;t=t.parent)if(t.name=="Cutscenes"){modHudCinematicVisible=true;break;}
    if(modHudCinematicVisible)break;
   }
   return modHudCinematicVisible;
  }
  private bool ModHudGameplayReady() {
   // The separate intro cinematic scene retains a live player and play flags.
   // Its own scene identity must exclude it before consulting those flags.
   if(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name=="Cutscenes"||ModHudCinematicVisible())return false;
   // Intro scenes can retain play state and default health without a playable
   // character. Require the live controller, not just the broad game-state flag.
   if(modMenuOpen||!WeaponGameplayReady()||global::PlayerState.paused
    ||global::PlayerState.cutscene||global::PlayerState.eventScreen
    ||global::PlayerState.suspendInput||global::PlayerState.noplayer
    ||global::PlayerState.gameOver)return false;
   var player=global::PlayerState.player;
   var control=global::PlayerState.pcs;
   return player!=null&&player.activeInHierarchy&&control!=null
    &&control.isActiveAndEnabled&&control.playing&&!control.traversing;
  }
  private void PrepareModHud(Camera desktopCamera=null) {
   HideModHud();if(modHudFailed||!ModHudGameplayReady()||(desktopCamera==null&&!handsScoped)){modMapReveal.Reset();return;}
   var hudRotation=desktopCamera==null?stereoRotation:desktopCamera.transform.rotation;
   var hudPosition=desktopCamera==null?stereoPosition:desktopCamera.transform.position;
   try {
    if(modHudRoot==null) {
     modHudRoot=new GameObject("SignalisVR_HealthAmmo");modHudRoot.layer=30;UnityEngine.Object.DontDestroyOnLoad(modHudRoot);
     modHudText=CreateModHudText("Health",.026f);
     modAmmoText=CreateModHudText("Ammo",-.027f);
     modAmmoPlacement=modHudRoot.transform.Find("Ammo");
     CreateModHudBar("HealthBorder",.146f,.014f,.001f,new Color(.45f,.83f,1f,.22f));
     CreateModHudBar("HealthBackground",.14f,.009f,0f,new Color(.035f,.06f,.08f,.15f));
     modHealthFill=CreateModHudBar("HealthFill",.14f,.009f,-.001f,new Color(.45f,.83f,1f,.82f));
     modHealthGlow=CreateModHudBar("HealthGlow",.14f,.02f,.004f,new Color(.3f,.8f,1f,.14f));
     EnsureModMapRoot();
    }
    if(Time.realtimeSinceStartup>=nextModHudText) {
     nextModHudText=Time.realtimeSinceStartup+.1f;
     var w=global::InventoryManager.EquippedWeapon;
     var hp=global::PlayerState.hp;
     UpdateModHudText(modHudText,hp+"/100",ref modHealthCaption);
     UpdateModHudText(modAmmoText,(ProdSelected()&&!ProdHandOccupied())?"STUN "+ProdUses()+" / 6":w==null?"AMMO --":"AMMO "+w.magAmmo+" / "+w.MagSize,ref modAmmoCaption);
     modAmmoPlacement.localPosition=new Vector3(0,(ProdSelected()&&!ProdHandOccupied())?-.04f:-.027f,-.002f)*UnitsPerMetre;
     float fill=Mathf.Clamp01(hp/100f);
     modHealthFill.localScale=new Vector3(.14f*fill,.009f,1f)*UnitsPerMetre;
     modHealthFill.localPosition=new Vector3(-.07f*(1f-fill),0f,-.001f)*UnitsPerMetre;
     modHealthGlow.localScale=new Vector3(.14f*fill,.02f,1f)*UnitsPerMetre;
     modHealthGlow.localPosition=new Vector3(-.07f*(1f-fill),0f,.004f)*UnitsPerMetre;
    }
    modHudRoot.transform.rotation=hudRotation;
    // Viewer-right offset keeps the panel beside the accepted grip anchor;
    // turning the wrist must not rotate the panel through the gun or hand.
    modHudRoot.transform.position=desktopCamera!=null
     ?hudPosition+hudRotation*(new Vector3(modHudRight?.34f:-.34f,-.27f,.9f)*UnitsPerMetre)
     :controllerMarkers[modHudRight?1:0].transform.position+hudRotation*(new Vector3(modHudRight?.15f:-.15f,.025f,0f)*UnitsPerMetre);
    modHudRoot.transform.localScale=Vector3.one;
    if(desktopCamera==null&&handsObjects[modHudRight?1:0]!=null) {
     // Follow the rendered wrist position, including equipped grip. Keep the
     // panel viewer-facing so wrist roll cannot turn its text edge-on.
     var wrist=handsObjects[modHudRight?1:0].transform;
     modHudRoot.transform.position=wrist.position+hudRotation*(new Vector3(modHudRight?.055f:-.055f,.015f,-.015f)*UnitsPerMetre);
     modHudRoot.transform.rotation=hudRotation;
     modHudRoot.transform.localScale=Vector3.one*.55f;
    }
    if(modHudForearm&&desktopCamera==null&&elsterBones!=null&&elsterRoot!=null) {
     // Follow the solved arm rather than extrapolating the controller's wrist angle.
     var wrist=elsterBones[EB("hand.r")];var elbow=elsterBones[EB("forearm.r")];
     if(wrist!=null&&elbow!=null)modHudRoot.transform.position=Vector3.Lerp(wrist.position,elbow.position,.35f)+hudRotation*(new Vector3(0,.035f,-.015f)*UnitsPerMetre);
    }
    modHudRoot.transform.position+=hudRotation*((modHudForearm?hudPlacementForearmOffset:(modHudRight?hudPlacementOffset:hudPlacementLeftOffset))*UnitsPerMetre);
    foreach(var r in modHudRenderers)if(r!=null)r.enabled=modHudOn;
    PrepareProdHud();
    if(!modMiniMap||(desktopCamera==null&&(manualReload.Active||shotgunReload.Active||AdditionalReloadActive())&&manualLeftGrip)){modMapReveal.Reset();return;}
    modMapRoot.transform.position=hudPosition+hudRotation*(new Vector3(-.34f,.22f,.9f)*UnitsPerMetre);
    modMapRoot.transform.rotation=hudRotation;
    // Scale the complete VR board, including doors, arrow and glow together.
    modMapRoot.transform.localScale=Vector3.one*(desktopCamera==null?.75f:1f);
    if(desktopCamera==null) {
     if(handsObjects[0]==null){modMapReveal.Reset();return;}
     var hand=handsObjects[0].transform;
     var basis=hand.rotation*Quaternion.Inverse(handsCorrections[0]);
     // Tracking-space vertical remains gravity-aligned even when the head tilts.
     var up=controllerTrackingToWorld*Vector3.up;
     var forward=Vector3.ProjectOnPlane(hudRotation*Vector3.forward,up).normalized;
     var palm=controllerMarkers[0].transform.position;
     var delta=(palm-hudPosition)/UnitsPerMetre;
     if(!modMapReveal.Update(true,Vector3.Dot(basis*Vector3.up,up),Vector3.Dot(delta,forward),Vector3.Dot(delta,up),Time.realtimeSinceStartup))return;
     // The board remains centered above the back of the hand after scaling.
     modMapRoot.transform.position=palm+up*(.17f*UnitsPerMetre);
    }
    if(Time.realtimeSinceStartup>=nextModMapRefresh||modMappedRoom!=global::PlayerState.currentRoom){nextModMapRefresh=Time.realtimeSinceStartup+.5f;RefreshModMiniMap();}
    foreach(var r in modMapCopies)if(r!=null&&r.sprite!=null)r.enabled=true;
    foreach(var r in modMapGlow)if(r!=null&&r.sprite!=null)r.enabled=true;
    PrepareVrMapSymbols();PrepareMapLabels();
   }catch(Exception ex){modHudFailed=true;HideModHud();MelonLogger.Warning("Mod HUD disabled: "+ex.Message);}
  }
  private Mesh CreateModHudText(string name,float y) {
   var go=new GameObject(name);go.layer=30;go.transform.SetParent(modHudRoot.transform,false);
   go.transform.localPosition=new Vector3(0f,y,-.002f)*UnitsPerMetre;
   EnsureGlyphAtlas();
   var shader=Shader.Find("Sprites/Default");if(shader==null)throw new InvalidOperationException("HUD glyph shader unavailable");
   var material=new Material(shader);material.mainTexture=modGlyphAtlas;material.color=new Color(1f,1f,1f,.95f);modHudMaterials.Add(material);
   var mesh=new Mesh();mesh.name="HUD "+name+" glyphs";go.AddComponent<MeshFilter>().sharedMesh=mesh;
   var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=material;r.sortingOrder=5;r.enabled=false;modHudRenderers.Add(r);
   var glowMaterial=new Material(shader);glowMaterial.mainTexture=modGlyphAtlas;glowMaterial.color=new Color(.35f,.85f,1f,.14f);modHudMaterials.Add(glowMaterial);
   for(int side=-1;side<=1&&!name.StartsWith("MapLabel",StringComparison.Ordinal);side+=2){var glow=new GameObject(name+"Glow");glow.layer=30;glow.transform.SetParent(go.transform,false);glow.transform.localPosition=new Vector3(side*.0006f,0,.001f)*UnitsPerMetre;glow.AddComponent<MeshFilter>().sharedMesh=mesh;var gr=glow.AddComponent<MeshRenderer>();gr.sharedMaterial=glowMaterial;gr.sortingOrder=4;gr.enabled=false;modHudRenderers.Add(gr);}
   return mesh;
  }
  private void UpdateModHudText(Mesh mesh,string caption,ref string previous) {
   if(caption==previous)return;
   // Direct atlas quads avoid the unsupported IL2CPP CharacterInfo array.
   float s=.014f*UnitsPerMetre/32f,x=-PixelTextWidth(caption)*s*.5f;
   var vertices=new List<Vector3>();var uv=new List<Vector2>();var triangles=new List<int>();var colors=new List<Color>();
   foreach(char c in caption){int i=c>=32&&c<=126?c-32:31;
    if(c!=' '){int n=vertices.Count;Rect rect=GlyphUv(i);
     vertices.Add(new Vector3(x,-20*s,0));vertices.Add(new Vector3(x+64*s,-20*s,0));vertices.Add(new Vector3(x+64*s,20*s,0));vertices.Add(new Vector3(x,20*s,0));
     uv.Add(new Vector2(rect.xMin,rect.yMin));uv.Add(new Vector2(rect.xMax,rect.yMin));uv.Add(new Vector2(rect.xMax,rect.yMax));uv.Add(new Vector2(rect.xMin,rect.yMax));
     for(int k=0;k<4;k++)colors.Add(Color.white);
     triangles.Add(n);triangles.Add(n+2);triangles.Add(n+1);triangles.Add(n);triangles.Add(n+3);triangles.Add(n+2);
    }x+=glyphWidths[i]*s;
   }
   mesh.Clear();mesh.vertices=vertices.ToArray();mesh.uv=uv.ToArray();mesh.colors=colors.ToArray();mesh.triangles=triangles.ToArray();mesh.RecalculateBounds();previous=caption;
  }
  private Transform CreateModHudBar(string name,float width,float height,float z,Color color) {
   var go=GameObject.CreatePrimitive(PrimitiveType.Quad);go.name=name;go.layer=30;go.transform.SetParent(modHudRoot.transform,false);
   var collider=go.GetComponent<Collider>();if(collider!=null){collider.enabled=false;UnityEngine.Object.Destroy(collider);}
   go.transform.localPosition=new Vector3(0f,0f,z)*UnitsPerMetre;go.transform.localScale=new Vector3(width,height,1f)*UnitsPerMetre;
   var shader=Shader.Find("Sprites/Default");if(shader==null)throw new InvalidOperationException("HUD color shader unavailable");
   var material=new Material(shader);material.mainTexture=Texture2D.whiteTexture;material.color=color;modHudMaterials.Add(material);
   var renderer=go.GetComponent<Renderer>();renderer.sharedMaterial=material;renderer.enabled=false;modHudRenderers.Add(renderer);return go.transform;
  }
  // Read only discovered room artwork. Do not activate native map objects or
  // undiscovered rooms, or change the native map camera/state.
  private void RefreshModMiniMap() {
   mapSymbolsDirty=true;mapLabelsDirty=true;
   // Clear presentation before any unavailable-manager/floor early return.
   mapPointPositions.Clear();mapPointKinds.Clear();mapLabelPoints.Clear();mapLabelTexts.Clear();
   if(mapLabelsView!=null)mapLabelsView.enabled=false;
   if(mapComplete)CompleteAllMaps();
   modDoorRotations.Clear();modDoorPoints.Clear();modDoorStates.Clear();modDoorWorld.Clear();modDoorMap.Clear();modRoomBoundsValid=false;
   modCurrentLow=new Vector2(float.PositiveInfinity,float.PositiveInfinity);modCurrentHigh=new Vector2(float.NegativeInfinity,float.NegativeInfinity);
   EnsureModMapRoot();modMapStatus="Map data not loaded";
   foreach(var r in modMapCopies){r.enabled=false;r.sprite=null;}foreach(var r in modMapGlow){r.enabled=false;r.sprite=null;}
   var manager=global::PersistentMinimapManager.instance;
   if(manager==null){ReportModMap("Room-map manager unavailable");return;}
   var floor=manager.currentFloorManager;
   if(floor==null&&manager.currentRoom!=null)floor=manager.currentRoom.GetComponentInParent<global::PersistentMinimapFloor>();
   if(floor==null){ReportModMap("Current floor unavailable");return;}
   // Use the native map camera's orientation when available, otherwise the
   // floor's coordinate space. Neither requires the native map to be active.
   Camera cam=manager._camera==null?null:manager._camera.GetComponent<Camera>();
   if(cam==null&&manager._camera!=null)cam=manager._camera.GetComponentInChildren<Camera>(true);
   Transform basis=cam==null?floor.transform:cam.transform;
   var roomList=new List<global::PersistentMinimapRoom>();
   if(floor.Rooms!=null)for(int n=0;n<floor.Rooms.Count;n++)if(floor.Rooms[n]!=null)roomList.Add(floor.Rooms[n]);
   if(roomList.Count==0)foreach(var room in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true))if(room!=null)roomList.Add(room);
   var rooms=roomList;
   var liveRoom=global::PlayerState.currentRoom;modMappedRoom=liveRoom;modRoomProjectionValid=false;
   global::PersistentMinimapRoom current=null;
   foreach(var room in rooms)if(room!=null&&liveRoom!=null&&(room.room==liveRoom||room.RoomID==liveRoom.minimapRoom)){current=room;break;}
   var drawnDoors=new HashSet<string>();
   var sources=new List<SpriteRenderer>();var currents=new List<bool>();
   Vector2 low=new Vector2(float.PositiveInfinity,float.PositiveInfinity),high=new Vector2(float.NegativeInfinity,float.NegativeInfinity);
   for(int i=0;i<rooms.Count;i++) {
    var room=rooms[i];if(room==null||(!room.discovered&&room!=current))continue;
    Vector2 roomLow=new Vector2(float.PositiveInfinity,float.PositiveInfinity),roomHigh=new Vector2(float.NegativeInfinity,float.NegativeInfinity);
    var shapes=new List<global::MinimapActiveRoom>();
    if(room.shapes!=null)for(int j=0;j<room.shapes.Count;j++)if(room.shapes[j]!=null)shapes.Add(room.shapes[j]);
    if(shapes.Count==0)foreach(var shape in room.GetComponentsInChildren<global::MinimapActiveRoom>(true))if(shape!=null)shapes.Add(shape);
    for(int j=0;j<shapes.Count;j++) {
     var shape=shapes[j];var sr=shape.SR;if(sr==null)sr=shape.GetComponent<SpriteRenderer>();if(sr==null||sr.sprite==null)continue;
     sources.Add(sr);currents.Add(room==current);
     var b=MapSpriteBounds(sr);for(int k=0;k<8;k++){var p=basis.InverseTransformPoint(sr.transform.TransformPoint(b.center+Vector3.Scale(b.extents,new Vector3((k&1)==0?-1:1,(k&2)==0?-1:1,(k&4)==0?-1:1))));var point=new Vector2(p.x,p.y);low=Vector2.Min(low,point);high=Vector2.Max(high,point);roomLow=Vector2.Min(roomLow,point);roomHigh=Vector2.Max(roomHigh,point);if(room==current){modCurrentLow=Vector2.Min(modCurrentLow,point);modCurrentHigh=Vector2.Max(modCurrentHigh,point);}}
    }
    var doors=new List<global::MinimapDoor>();foreach(var d in room.GetComponentsInChildren<global::MinimapDoor>(true))if(d!=null&&!doors.Contains(d))doors.Add(d);if(room.Doors!=null)foreach(var d in room.Doors)if(d!=null&&!doors.Contains(d))doors.Add(d);
    foreach(var door in doors){if(door==null)continue;var point=basis.InverseTransformPoint(door.transform.position);var xy=new Vector2(point.x,point.y);Vector2 doorLow=roomLow,doorHigh=roomHigh;float nearest=float.PositiveInfinity;foreach(var shape in shapes){var sr=shape.SR;if(sr==null)sr=shape.GetComponent<SpriteRenderer>();if(sr==null||sr.sprite==null)continue;var sb=MapSpriteBounds(sr);var sl=new Vector2(float.PositiveInfinity,float.PositiveInfinity);var sh=new Vector2(float.NegativeInfinity,float.NegativeInfinity);for(int k=0;k<4;k++){var sp=basis.InverseTransformPoint(sr.transform.TransformPoint(sb.center+Vector3.Scale(sb.extents,new Vector3((k&1)==0?-1:1,(k&2)==0?-1:1,0))));sl=Vector2.Min(sl,new Vector2(sp.x,sp.y));sh=Vector2.Max(sh,new Vector2(sp.x,sp.y));}double ex,ey;RoomDoorPoint.Edge(xy.x,xy.y,sl.x,sl.y,sh.x,sh.y,out ex,out ey);float distance=(xy-new Vector2((float)ex,(float)ey)).sqrMagnitude;if(distance<nearest){nearest=distance;doorLow=sl;doorHigh=sh;}}double edgeX,edgeY;RoomDoorPoint.Edge(xy.x,xy.y,doorLow.x,doorLow.y,doorHigh.x,doorHigh.y,out edgeX,out edgeY);xy=new Vector2((float)edgeX,(float)edgeY);if(MapDiscoveryPolicy.DoorVisible(mapComplete,MapDoorTried(door))&&drawnDoors.Add(Mathf.RoundToInt(xy.x*1000)+"|"+Mathf.RoundToInt(xy.y*1000))){modDoorPoints.Add(xy);float dx=Mathf.Min(Mathf.Abs(xy.x-doorLow.x),Mathf.Abs(xy.x-doorHigh.x)),dy=Mathf.Min(Mathf.Abs(xy.y-doorLow.y),Mathf.Abs(xy.y-doorHigh.y));modDoorRotations.Add(dx<dy?(float)Math.PI/2:0);modDoorStates.Add(mapComplete||MapDoorTried(door)?LiveMapDoorState(door):0);}
     if(room==current&&door.door!=null){var traversal=door.door;var world=traversal.A!=null&&traversal.B!=null?(traversal.A.position+traversal.B.position)*.5f:traversal.transform.position;
      if(liveRoom!=null&&liveRoom.name=="Maintenance (Start)"&&UnityEngine.SceneManagement.SceneManager.GetActiveScene().name=="PEN_Wreck"&&traversal.A!=null)world=traversal.A.position;
      var anchor=new Vector2(world.x,world.y);if(!modDoorWorld.Contains(anchor)){modDoorWorld.Add(anchor);modDoorMap.Add(xy);}}
    }
   }
   if(sources.Count==0){ReportModMap("No discovered artwork ("+rooms.Count+" room records)");return;}
   ReportModMap("");
   float scale=.25f*UnitsPerMetre/Math.Max(.01f,Math.Max(high.x-low.x,high.y-low.y));var center=(low+high)*.5f;
   modMapCenter=center;modMapScale=scale;
   var geometry=liveRoom==null?null:liveRoom.Tilesystem!=null?liveRoom.Tilesystem:liveRoom.Cell;
   if(boundsRoom==liveRoom){modRoomBounds=cachedRoomBounds;modRoomBoundsValid=cachedRoomBoundsValid;}
   else if(geometry!=null){int count=0;foreach(var r in geometry.GetComponentsInChildren<Renderer>(true)){if(r==null||count++>=512)continue;if(!modRoomBoundsValid){modRoomBounds=r.bounds;modRoomBoundsValid=true;}else modRoomBounds.Encapsulate(r.bounds);}}
   boundsRoom=liveRoom;cachedRoomBounds=modRoomBounds;cachedRoomBoundsValid=modRoomBoundsValid;
   var pairs=new double[modDoorWorld.Count,4];for(int i=0;i<modDoorWorld.Count;i++){pairs[i,0]=modDoorWorld[i].x;pairs[i,1]=modDoorWorld[i].y;pairs[i,2]=modDoorMap[i].x;pairs[i,3]=modDoorMap[i].y;}
   modRoomProjectionValid=modRoomProjection.Fit(pairs);
   if(modMapMappingReports<16&&liveRoom!=null&&lastModMappingRoom!=liveRoom){lastModMappingRoom=liveRoom;modMapMappingReports++;MelonLogger.Msg("MINI MAP mapping: room="+liveRoom.name+" matched="+(current!=null)+" doors="+modDoorWorld.Count+" affine="+modRoomProjectionValid+" bounds="+modRoomBoundsValid);for(int i=0;i<modDoorWorld.Count&&i<12;i++)MelonLogger.Msg("MINI MAP anchor: world="+MapVector(modDoorWorld[i])+" map="+MapVector(modDoorMap[i]));}
   RefreshMapPoints(floor,basis);
   for(int i=0;i<sources.Count;i++) {
    if(i>=modMapCopies.Count){var go=new GameObject("DiscoveredRoom");go.layer=30;go.transform.SetParent(modMapRoot.transform,false);modMapCopies.Add(go.AddComponent<SpriteRenderer>());}
    var src=sources[i];var dst=modMapCopies[i];var pos=basis.InverseTransformPoint(src.transform.position);
    dst.enabled=false;dst.sprite=src.sprite;dst.drawMode=src.drawMode;dst.size=src.size;dst.tileMode=src.tileMode;dst.color=currents[i]?new Color(1f,.12f,.12f,.8f):new Color(.35f,.85f,1f,.65f);dst.sortingOrder=currents[i]?1:0;dst.flipX=src.flipX;dst.flipY=src.flipY;
    dst.transform.localPosition=new Vector3((pos.x-center.x)*scale,(pos.y-center.y)*scale,0f);
    dst.transform.localRotation=Quaternion.Inverse(basis.rotation)*src.transform.rotation;
    var nativeScale=src.transform.lossyScale;var basisScale=basis.lossyScale;dst.transform.localScale=new Vector3(nativeScale.x/basisScale.x,nativeScale.y/basisScale.y,nativeScale.z/basisScale.z)*scale;
    if(i>=modMapGlow.Count){var go=new GameObject("RoomHologramGlow");go.layer=30;go.transform.SetParent(modMapRoot.transform,false);modMapGlow.Add(go.AddComponent<SpriteRenderer>());}
    var glow=modMapGlow[i];glow.enabled=false;glow.sprite=dst.sprite;glow.drawMode=dst.drawMode;glow.size=dst.size;glow.tileMode=dst.tileMode;glow.flipX=dst.flipX;glow.flipY=dst.flipY;var tint=dst.color;tint.a=.12f;glow.color=tint;glow.sortingOrder=-1;glow.transform.localPosition=dst.transform.localPosition+new Vector3(0,0,.004f*UnitsPerMetre);glow.transform.localRotation=dst.transform.localRotation;glow.transform.localScale=dst.transform.localScale*1.012f;
   }
  }
  private static Bounds MapSpriteBounds(SpriteRenderer source){
   if(source.drawMode==SpriteDrawMode.Simple)return source.sprite.bounds;
   var size=source.size;var rect=source.sprite.rect;var pivot=source.sprite.pivot;
   return new Bounds(new Vector3((.5f-pivot.x/rect.width)*size.x,(.5f-pivot.y/rect.height)*size.y,0),new Vector3(size.x,size.y,0));
  }
  private static string MapDoorHistory(global::AutoTraverseDoor door){return door==null||door.room==null?null:"SignalisVR.Map.DoorInteracted.v2:"+MapObjectId(door.transform,door.room);}
  private void RememberMapDoorInteraction(global::Interaction inter){
   foreach(var room in mapRooms){if(room==null||room.Doors==null)continue;foreach(var door in room.Doors){if(door==null||door.door==null||door.door.inter!=inter)continue;var key=MapDoorHistory(door);if(key!=null)global::SProgress.SetInt(key,1);}}
  }
  private static bool MapDoorTried(global::MinimapDoor marker){
   var door=marker.door;var key=MapDoorHistory(door);
   return key!=null&&global::SProgress.GetInt(key,0)!=0;
  }
  private static int LiveMapDoorState(global::MinimapDoor marker){
   var traversal=marker.door;
   if(traversal!=null){
    var connection=traversal.connection;var physical=traversal.door;
    if(connection!=null){
     if((int)connection.minimapState==3)return 2; // Permanently blocked, not passable.
     if(connection.locked||(physical!=null&&physical.locked))return connection.key!=null||connection.externalUnlocker?4:2;
     return 1;
    }
    if(physical!=null)return physical.locked?2:1;
   }
   return (int)marker.state;
  }
  private bool MapPlayerPoint(Vector3 world,out Vector2 mapped){
   mapped=Vector2.zero;var p=new Vector2(world.x,world.y);
   if(modMappedRoom!=global::PlayerState.currentRoom||float.IsInfinity(modCurrentLow.x))return false;
   if(modRoomProjectionValid){double u,v;modRoomProjection.Point(world.x,world.y,out u,out v);mapped=(new Vector2((float)u,(float)v)-modMapCenter)*modMapScale;return true;}
   int a=-1,b=-1;float longest=.01f;for(int i=0;i<modDoorWorld.Count;i++)for(int j=i+1;j<modDoorWorld.Count;j++){float length=(modDoorWorld[j]-modDoorWorld[i]).sqrMagnitude;if(length>longest&&(modDoorMap[j]-modDoorMap[i]).sqrMagnitude>.0001f){a=i;b=j;longest=length;}}
   if(a>=0){var w=modDoorWorld[b]-modDoorWorld[a];var m=modDoorMap[b]-modDoorMap[a];var d=p-modDoorWorld[a];float along=Vector2.Dot(d,w)/longest,across=(w.x*d.y-w.y*d.x)/longest;float sign=1;
    // Resolve reflection from which side of the door baseline the room lies.
    if(modRoomBoundsValid){var wc=new Vector2(modRoomBounds.center.x,modRoomBounds.center.y)-modDoorWorld[a];var mc=(modCurrentLow+modCurrentHigh)*.5f-modDoorMap[a];float ws=w.x*wc.y-w.y*wc.x,ms=m.x*mc.y-m.y*mc.x;if(Math.Abs(ws)>.001f&&Math.Abs(ms)>.001f)sign=ws*ms<0?-1:1;}
    mapped=modDoorMap[a]+m*along+new Vector2(-m.y,m.x)*(across*sign);}
   else if(modRoomBoundsValid&&modRoomBounds.size.x>.01f&&modRoomBounds.size.y>.01f){
    var extent=modCurrentHigh-modCurrentLow;
    // This room's decorative renderer bounds extend beyond its exit. Anchor
    // its one-door estimate to the actual doorway instead of that rectangle.
    if(modDoorWorld.Count==1){
     var delta=p-modDoorWorld[0];mapped=modDoorMap[0]+Vector2.Scale(extent,new Vector2(delta.x/modRoomBounds.size.x,delta.y/modRoomBounds.size.y));
    }else{float x=(world.x-modRoomBounds.min.x)/modRoomBounds.size.x,y=(world.y-modRoomBounds.min.y)/modRoomBounds.size.y;mapped=modCurrentLow+Vector2.Scale(extent,new Vector2(x,y));}
   }
   else return false;
   mapped=(mapped-modMapCenter)*modMapScale;return true;
  }
  private global::Room lastModMappingRoom;
  private void ReportMapPosition(Vector3 world,Vector2 mapped) {
   if(modMapPositionReports>=48||Time.realtimeSinceStartup<nextModMapPositionReport)return;
   nextModMapPositionReport=Time.realtimeSinceStartup+1f;modMapPositionReports++;
   MelonLogger.Msg("MINI MAP position: scene="+UnityEngine.SceneManagement.SceneManager.GetActiveScene().name+" room="+(modMappedRoom==null?"none":modMappedRoom.name)+" worldXY="+MapVector(new Vector2(world.x,world.y))+" mapped="+MapVector(mapped)+" affine="+modRoomProjectionValid+" doors="+modDoorWorld.Count+" boundsMin="+MapVector(new Vector2(modRoomBounds.min.x,modRoomBounds.min.y))+" boundsMax="+MapVector(new Vector2(modRoomBounds.max.x,modRoomBounds.max.y))+" roomMapMin="+MapVector(modCurrentLow)+" roomMapMax="+MapVector(modCurrentHigh)+" mapCenter="+MapVector(modMapCenter)+" scale="+modMapScale.ToString("F5",System.Globalization.CultureInfo.InvariantCulture));
  }
  private void EnsureModMapRoot(){if(modMapRoot==null){modMapRoot=new GameObject("SignalisVR_LiveMiniMap");modMapRoot.layer=30;UnityEngine.Object.DontDestroyOnLoad(modMapRoot);}}
  private void HideModHud(){if(mapLabelsView!=null)mapLabelsView.enabled=false;if(mapSymbolRenderer!=null)mapSymbolRenderer.enabled=false;if(mapPlayerRenderer!=null)mapPlayerRenderer.enabled=false;foreach(var icon in mapIconRenderers)if(icon!=null)icon.enabled=false;foreach(var r in modHudRenderers)if(r!=null)r.enabled=false;foreach(var r in modMapCopies)if(r!=null)r.enabled=false;foreach(var r in modMapLines)if(r!=null)r.enabled=false;foreach(var r in modMapGlow)if(r!=null)r.enabled=false;}
  private void DestroyModHud(){HideModHud();if(mapLabelsBatch!=null)UnityEngine.Object.Destroy(mapLabelsBatch);mapLabelsBatch=null;mapLabelsView=null;mapLabelsDirty=true;boundsRoom=null;if(mapSymbolMesh!=null)UnityEngine.Object.Destroy(mapSymbolMesh);if(mapPlayerMesh!=null)UnityEngine.Object.Destroy(mapPlayerMesh);mapSymbolMesh=mapPlayerMesh=null;mapSymbolRenderer=mapPlayerRenderer=null;mapSymbolsDirty=true;foreach(var m in mapLabelMeshes)if(m!=null)UnityEngine.Object.Destroy(m);mapLabelMeshes.Clear();mapLabelTransforms.Clear();mapLabelPrevious.Clear();mapLabelRenderers.Clear();mapLabelPoints.Clear();mapLabelTexts.Clear();if(modHudText!=null)UnityEngine.Object.Destroy(modHudText);if(modAmmoText!=null)UnityEngine.Object.Destroy(modAmmoText);modHealthCaption=null;modAmmoCaption=null;if(modHudRoot!=null)UnityEngine.Object.Destroy(modHudRoot);if(modMapRoot!=null)UnityEngine.Object.Destroy(modMapRoot);foreach(var m in modHudMaterials)if(m!=null)UnityEngine.Object.Destroy(m);modHudMaterials.Clear();modHudRenderers.Clear();modHudRoot=null;modMapRoot=null;modHudText=null;modAmmoText=null;modHealthFill=null;modHealthGlow=null;modMapCopies.Clear();modMapGlow.Clear();modMapLines.Clear();mapIconRenderers.Clear();modMapReveal.Reset();if(modMapLineMaterial!=null)UnityEngine.Object.Destroy(modMapLineMaterial);modMapLineMaterial=null;modHudFailed=false;nextModMapRefresh=0;nextModHudText=0;}
 }
}

















