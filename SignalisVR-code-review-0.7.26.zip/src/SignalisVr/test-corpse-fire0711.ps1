$ErrorActionPreference='Stop'
$s=Get-Content "$PSScriptRoot/CorpseFire.cs" -Raw
$s=$s.Substring($s.IndexOf(' private static bool FireEnemyValid'))
$s=$s.Substring(0,$s.IndexOf(' private float FlareMeshContact'))
$stub=@'
using System;
public class EnemyController {public Obj gameObject=new Obj();public Hit hitbox=new Hit();public bool permadeath;public Anim animator=new Anim();public Burn BurnEffect=new Burn();public int anim_Fire=42;}
public class Obj {public bool activeInHierarchy=true;public void SetActive(bool v){activeInHierarchy=v;}}public class Hit {public int HP=15;}
public class Anim {public float speed;public bool fire;public void SetBool(int id,bool v){if(id!=42)throw new Exception("wrong native animation");fire=v;}}
public class Burn {public bool burning;public int calls;public void Burn(){burning=true;calls++;}}
namespace MelonLoader {public static class MelonLogger {public static void Msg(string s){}}}
public class Harness {public class EnemyFire {public bool Corpse;public float Age;public int DamageTicks;public IntPtr Id;public EnemyController Enemy;public Obj Root;}
void EndBurnReaction(IntPtr id){}
public static void Run(){var h=new Harness();var e=new EnemyController();var f=new EnemyFire{Enemy=e,Root=new Obj()};h.BeginCorpseFire(f);if(!f.Corpse||!e.permadeath||e.hitbox.HP!=0||!e.animator.fire||e.animator.speed!=1)throw new Exception("corpse not incinerated");if(f.Root.activeInHierarchy||e.BurnEffect.calls!=1)throw new Exception("Native burn not immediate or custom flames still visible");h.FinishCorpseFire(f);h.FinishCorpseFire(f);if(e.animator.fire||e.BurnEffect.calls!=1)throw new Exception("native burn finalization repeated");}
'@
$stub=$stub.Replace('class Burn {','class BurnFx {').Replace('public Burn BurnEffect=new Burn()','public BurnFx BurnEffect=new BurnFx()')
Add-Type -TypeDefinition ($stub+$s+'}')
[Harness]::Run()
'PASS corpse HP stays zero, permadeath set, exact native fire parameter used, native BurnEffect starts immediately once, custom root disabled, cleanup clears animation. Headset animation unverified.'

