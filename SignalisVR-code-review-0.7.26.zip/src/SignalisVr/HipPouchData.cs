using System.IO;
namespace SignalisVrTracking { internal static class HipPouchData {
 internal static byte[] Geometry {get{return Read("HipPouchGeometry.bin");}}
 internal static byte[] Texture {get{return Read("HipPouchTexture.png");}}
 private static byte[] Read(string name){using(var s=typeof(HipPouchData).Assembly.GetManifestResourceStream("SignalisVR."+name)){if(s==null)throw new InvalidDataException("Missing pouch resource "+name);using(var b=new MemoryStream()){s.CopyTo(b);return b.ToArray();}}}
} }