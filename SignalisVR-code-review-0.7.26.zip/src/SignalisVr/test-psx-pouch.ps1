$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'CylinderFlickPolicy.cs')
function Check($v,$why){if(-not $v){throw $why}}
foreach($hz in @(30,72,90,120,144)){
 $motion=[SignalisVrTracking.CylinderSwingMotion]::new()
 for($i=0;$i -lt $hz;$i++){$a=$motion.Tick($true,1.0/$hz)}
 Check ($a -eq 1) 'Cylinder failed to fully open'
 $first=$motion.Tick($false,1.0/$hz);Check ($first -gt .95 -and $first -lt 1) 'Close must begin with resistance, not snap'
 $prior=$first
 for($i=0;$i -lt $hz;$i++){$a=$motion.Tick($false,1.0/$hz);Check ($a -le $prior -and $a -ge 0) 'Closing overshoot';$prior=$a}
 Check ($a -eq 0) 'Cylinder failed to latch'
 $motion.Reset();Check ($motion.Tick($false,.02) -eq 0) 'Reset retained motion'
}
$s=Get-Content (Join-Path $PSScriptRoot 'PsxModelData.cs') -Raw
function Vec($name){$m=[regex]::Match($s,($name+'=new UnityEngine.Vector3\(([^)]+)\)'));return @($m.Groups[1].Value.Split(',')|ForEach-Object{[double]($_.TrimEnd('f'))})}
$pivot=Vec 'CylinderPivot';$ch=Vec 'Chamber';$lc=Vec 'LoaderCenter';$open=Vec 'OpenLoaderCenter'
# Independent runtime-axis check: forward=+Z, up=+Y, left=-X.
$openCh=@(($pivot[0]-($ch[1]-$pivot[1])),($pivot[1]+($ch[0]-$pivot[0])),$ch[2])
Check ($openCh[0] -lt -.03) 'Cylinder is not on the LEFT'
foreach($yaw in @(-2.0,0,1.3)){foreach($pitch in @(-.7,0,.8)){foreach($roll in @(-1.0,0,.9)){
 $q=[System.Numerics.Quaternion]::CreateFromYawPitchRoll($yaw,$pitch,$roll)
 $delta=[System.Numerics.Vector3]::new(($openCh[0]-$ch[0]),($openCh[1]-$ch[1]),($openCh[2]-$ch[2]))
 $world=[System.Numerics.Vector3]::Transform($delta,$q);$right=[System.Numerics.Vector3]::Transform([System.Numerics.Vector3]::UnitX,$q)
 Check ([System.Numerics.Vector3]::Dot($world,$right) -lt -.03) 'Cylinder changed sides with gun orientation'
}}}
Check ([Math]::Abs($open[0]-$openCh[0]) -lt .00001 -and [Math]::Abs($open[1]-$openCh[1]) -lt .00001) 'Loader center misses open cylinder'
$mechanism=Get-Content (Join-Path $PSScriptRoot 'AglRevolver.cs') -Raw
Check ($mechanism.Contains('Quaternion.AngleAxis(90*open,Vector3.forward)')) 'Runtime swing disagrees with tested left rotation'
Check ($mechanism.Contains('Quaternion.AngleAxis(90,Vector3.forward)')) 'Loader layout disagrees with open cylinder'
$blob=[Convert]::FromBase64String([regex]::Match($s,'Geometry="([^"]+)"').Groups[1].Value)
$r=[IO.BinaryReader]::new([IO.MemoryStream]::new($blob));$count=$r.ReadInt32();$roles=@{};$roundVertices=@{}
for($part=0;$part -lt $count;$part++){
 $role=$r.ReadInt32();$mat=$r.ReadInt32();$nv=$r.ReadInt32();$nt=$r.ReadInt32();$roles[$role]++
 $verts=@();for($i=0;$i -lt $nv;$i++){$v=@($r.ReadSingle(),$r.ReadSingle(),$r.ReadSingle());foreach($f in $v){Check (-not [float]::IsNaN($f) -and -not [float]::IsInfinity($f)) 'Nonfinite geometry'};$verts+=,$v}
 for($i=0;$i -lt $nv*2;$i++){$null=$r.ReadSingle()}
 for($i=0;$i -lt $nt;$i++){$index=$r.ReadInt32();Check ($index -ge 0 -and $index -lt $nv) 'Invalid triangle index'}
 if($role -ge 10){if(-not $roundVertices.ContainsKey($role)){$roundVertices[$role]=@()};$roundVertices[$role]+=$verts}
}
Check ($r.BaseStream.Position -eq $r.BaseStream.Length) 'Geometry trailing bytes';$r.Dispose()
foreach($role in 10..15){Check ($roles[$role] -eq 2) 'Missing case or tip'}
foreach($loaded in 0..6){foreach($amount in 0..(6-$loaded)){
 $chosen=@(10..15|Where-Object{$_-10 -ge $loaded -and $_-10 -lt $loaded+$amount});Check ($chosen.Count -eq $amount) 'Partial loader round count'
 foreach($role in $chosen){Check ($role-10 -ge $loaded) 'Loader overlaps retained round'
 foreach($v in $roundVertices[$role]){
  $ox=$pivot[0]-($v[1]-$pivot[1]);$oy=$pivot[1]+($v[0]-$pivot[0]);$oz=$v[2]
  # Runtime forward->loader up conversion and its inverse must preserve every vertex.
  $held=@(($ox-$open[0]),($oz-$open[2]),(-($oy-$open[1])))
  Check ([Math]::Abs($held[0]+$open[0]-$ox) -lt .000001 -and [Math]::Abs(-$held[2]+$open[1]-$oy) -lt .000001) 'Partial loader alignment lost'
 }
 }
}}
foreach($name in @('Right','Left')){$b=[Convert]::FromBase64String([regex]::Match($s,($name+'="([^"]+)"')).Groups[1].Value);$nv=[BitConverter]::ToInt32($b,0);$nt=[BitConverter]::ToInt32($b,4);Check ($b.Length -eq 8+$nv*12+$nt*4) 'Grip record malformed'}
$hip=Get-Content (Join-Path $PSScriptRoot 'HipAmmo.cs') -Raw
Check (-not $hip.Contains('EnsureHipPouch')) 'Removed pouch still active'
$files=Get-Content (Join-Path $PSScriptRoot 'source-files.txt')
Check (-not ($files -contains 'HipPouch.cs') -and -not ($files -contains 'HipPouchData.cs')) 'Removed pouch still compiled'
'PASS: cylinder LEFT in27orientations, six complete rounds, all partial loads, loader alignment, both grips, weighty close at30-144Hz; pouch excluded. Headset feel/clearance unverified.'
