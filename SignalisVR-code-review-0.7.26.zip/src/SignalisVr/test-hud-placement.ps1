$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'HudPlacement.cs') -Raw
$policy=$source.Substring($source.IndexOf(' public static class HudPlacementPolicy'),$source.IndexOf(' public sealed partial class Tracking')-$source.IndexOf(' public static class HudPlacementPolicy'))
function Method($name){$start=$source.IndexOf('  private void '+$name+'(');if($start -lt 0){throw $name};$open=$source.IndexOf('{',$start);$depth=1;$end=$open+1;while($depth -gt 0){if($source[$end] -eq '{'){$depth++};if($source[$end] -eq '}'){$depth--};$end++};return $source.Substring($start,$end-$start).Replace('private void','public void')}
$methods=(Method CycleHudMode)+(Method OpenHudPlacement)+(Method EditHudPlacement)+(Method SaveHudPlacement)+(Method MoveHudPlacement)
Add-Type -TypeDefinition (@'
using System;
public struct Vector3 { public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;} }
public static class Time {public static float unscaledDeltaTime;}
namespace MelonLoader {public static class MelonLogger {public static void Warning(string s){}}}
namespace SignalisVrTracking {
'@+$policy+@'
public class PlacementTest {
 public Vector3 hudPlacementOffset,hudPlacementLeftOffset,hudPlacementForearmOffset,hudPlacementDraft;
 public bool hudPlacementEditing,hudPlacementChoosing,modHudRight=true,modHudForearm,modHudOn=true,failSave;
 public int hudPlacementHand,saves;public string modSettingsError;
 private void SaveModSettings(){if(failSave)throw new Exception();saves++;}
'@+$methods+'}}')
function Check($value,$message){if(!$value){throw $message}}
$q=[SignalisVrTracking.PlacementTest]::new()
$q.OpenHudPlacement();Check ($q.hudPlacementChoosing -and !$q.hudPlacementEditing -and $q.hudPlacementHand -eq 1) 'Chooser initial right'
$q.hudPlacementHand=0;$q.EditHudPlacement();[Time]::unscaledDeltaTime=.02;$q.MoveHudPlacement(1,1,1,0)
Check ($q.hudPlacementDraft.x -gt 0 -and $q.hudPlacementDraft.y -gt 0 -and $q.hudPlacementDraft.z -gt 0) 'Up/right/away signs'
$q.SaveHudPlacement();Check (!$q.modHudRight -and $q.modHudOn -and $q.saves -eq 1 -and $q.hudPlacementOffset.x -eq 0) 'Left save or independent right failed'
$q.modHudOn=$false;$q.OpenHudPlacement();$q.hudPlacementHand=1;$q.EditHudPlacement();$q.MoveHudPlacement(-1,-1,0,1);$q.SaveHudPlacement()
Check (!$q.modHudOn -and $q.modHudRight -and $q.hudPlacementOffset.z -lt 0) 'OFF preserved / towards sign'
$q.OpenHudPlacement();$q.hudPlacementHand=0;$q.EditHudPlacement();$old=$q.hudPlacementLeftOffset.x;$q.MoveHudPlacement(1,0,0,0);$q.failSave=$true;$q.SaveHudPlacement()
Check ($q.hudPlacementEditing -and $q.modHudRight -and $q.hudPlacementLeftOffset.x -eq $old) 'Failed save rollback'
$q.CycleHudMode(1);Check ($q.modHudOn -and !$q.modHudRight) 'OFF to LEFT';$q.CycleHudMode(1);Check $q.modHudRight 'LEFT to RIGHT';$q.CycleHudMode(1);Check (!$q.modHudOn -and !$q.modHudForearm) 'RIGHT to OFF'
foreach($fps in @(30,72,90,120)){$v=[float]0;for($i=0;$i -lt $fps;$i++){$v=[SignalisVrTracking.HudPlacementPolicy]::Move($v,1,(1.0/$fps),.25)};Check ([Math]::Abs($v-.08) -lt .00001) "Frame rate $fps"}
Check ([SignalisVrTracking.HudPlacementPolicy]::Move(.25,1,.05,.25) -eq .25) 'Bounds';Check ([SignalisVrTracking.HudPlacementPolicy]::Move(0,.1,.05,.25) -eq 0) 'Deadzone'
Add-Type -Path (Join-Path $PSScriptRoot 'ModSettingsFile.cs')
$path=Join-Path $PSScriptRoot 'settings-test-data/hud-placement.settings';$s=[SignalisVrTracking.ModSettingsFile]::new();$s.HudRightX=.12;$s.HudRightY=-.05;$s.HudRightZ=.08;$s.HudLeftX=-.08;$s.HudLeftY=.07;$s.HudLeftZ=-.09;$s.HudRight=$false;$s.Save($path)
$r=[SignalisVrTracking.ModSettingsFile]::Load($path);foreach($key in @('HudRightX','HudRightY','HudRightZ','HudLeftX','HudLeftY','HudLeftZ','HudRight')){Check ($r.$key -eq $s.$key) "Roundtrip $key"}
[IO.File]::WriteAllLines($path,@('HudRightX=NaN','HudLeftY=Infinity','HudRightZ=900'))
$r=[SignalisVrTracking.ModSettingsFile]::Load($path);Check ($r.HudRightX -eq 0 -and $r.HudLeftY -eq 0 -and $r.HudRightZ -eq 0) 'Invalid persisted offsets'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
$p=[SignalisVrTracking.QuestInputPolicy]::new();$l=[SignalisVrTracking.QuestSample]::new();$r=[SignalisVrTracking.QuestSample]::new();$null=$p.Update($true,$l,$r);$l.trigger=1
Check (($p.Update($true,$l,$r).buttons -band 2) -eq 0) 'Left trigger still cancels';$r.buttons=2;Check (($p.Update($true,$l,$r).buttons -band 2) -ne 0) 'B no longer cancels'
Add-Type -Path (Join-Path $PSScriptRoot 'ModMenuInput.cs');$edges=[SignalisVrTracking.ModMenuInput]::new();Check ($edges.Confirm($true)) 'A entry';Check (!$edges.Confirm($true)) 'Held A double activation';$null=$edges.Confirm($false);Check ($edges.Confirm($true)) 'Second A save'
'PASS actual placement methods: chooser/edit/save, independent hands, OFF preserved, failed-save rollback, mode cycle, XYZ signs, bounds, deadzone, four frame rates, settings roundtrip/invalid data, left trigger no cancel, B retained and A edges. Native UI/headset unverified.'

