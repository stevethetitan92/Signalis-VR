using System;
using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public static class SnapshotNames {public static string Caption(int number){return "snapshot "+Math.Max(1,number).ToString("D3");}}
 public sealed partial class Tracking {
  private const string SnapshotSaveKey="SignalisVR.SnapshotFiles.v1";
  private readonly Dictionary<string,global::Book> snapshotBooks=new Dictionary<string,global::Book>();
  private readonly Dictionary<string,string> snapshotBookFiles=new Dictionary<string,string>();
  private readonly List<UnityEngine.Object> snapshotObjects=new List<UnityEngine.Object>();
  private string snapshotSaveSignature;
  private static Tracking moduleOwner;
  private static string SnapshotDirectory(){return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"SignalisVR","Snapshots");}
  private void InstallHeldModules() {
   try {moduleOwner=this;var h=new HarmonyLib.Harmony("SignalisVR.NoMarkers.HeldModules");
   h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"RefreshItemName",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(HeldItemDescription)));
   h.Patch(AccessTools.DeclaredMethod(typeof(global::BookManager),"CreateBooks",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(AttachSnapshotMemory)));
   h.Patch(AccessTools.DeclaredMethod(typeof(global::Book),"Title",new[]{typeof(string)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(SnapshotTitle)));
   h.Patch(AccessTools.DeclaredMethod(typeof(global::BookScreen),"OpenBook",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(SnapshotBookOpening)),postfix:new HarmonyMethod(typeof(Tracking),nameof(SnapshotBookOpened)));
   h.Patch(AccessTools.DeclaredMethod(typeof(global::Book),"getBook",new[]{typeof(string)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(SnapshotContent)));
   // Native EQUIP also provides a route outside of the item wheel.
   h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"EquipTool",new[]{typeof(global::AnItem)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(EquipEideticNative)));
   }catch(Exception ex){MelonLogger.Warning("Held module hooks unavailable: "+ex.Message);}
  }
  private static void HeldItemDescription(global::InventoryBase __instance) {
   try{if(moduleOwner==null||!moduleOwner.ProdVrMode()||__instance.itemDescription==null)return;var item=global::InventoryManager.CurrentItem;if(item==null)return;string id=item._item.ToString();string hint=id=="PhotoModule"?"When equipped, press right trigger to take a picture":id.StartsWith("Health",StringComparison.Ordinal)?"When equipped, press right trigger to use":null;if(hint==null)return;string text=__instance.itemDescription.text??"";if(!text.Contains(hint))__instance.itemDescription.text=text+"\n\n<color=#66CCE5>"+hint+"</color>";}catch(Exception ex){MelonLogger.Warning("Held-item description: "+ex.Message);}
  }
  private static bool EquipEideticNative(global::InventoryBase __instance,global::AnItem __0) {
   var q=moduleOwner;if(q==null||!q.ProdVrMode()||__0==null||__0._item!=global::Items.itemlist.PhotoModule)return true;
   try{if(q.heldEidetic){q.ClearHeldModules();return false;}q.quickInventory=__instance;q.EquipHeldModule("PhotoModule");return false;}catch(Exception ex){MelonLogger.Warning("Eidetic equip: "+ex.Message);return true;}
  }
  private void CaptureQueuedSnapshot(Camera gaze) {
   if(!snapshotQueued||!heldEidetic||gaze==null)return;snapshotQueued=false;
   RenderTexture target=null;Texture2D pixels=null;GameObject root=null;var active=RenderTexture.active;
   try {
    Directory.CreateDirectory(SnapshotDirectory());root=new GameObject("SignalisVR_SnapshotCamera");var capture=root.AddComponent<Camera>();capture.enabled=false;capture.CopyFrom(gaze);capture.enabled=false;capture.stereoTargetEye=StereoTargetEyeMask.None;capture.transform.SetPositionAndRotation(gaze.transform.position,gaze.transform.rotation);capture.ResetProjectionMatrix();
    target=new RenderTexture(1280,720,24);target.Create();capture.targetTexture=target;capture.aspect=1280f/720f;capture.Render();RenderTexture.active=target;pixels=new Texture2D(1280,720,TextureFormat.RGB24,false);pixels.ReadPixels(new Rect(0,0,1280,720),0,0);pixels.Apply();
    string file=Guid.NewGuid().ToString("N")+".png";File.WriteAllBytes(Path.Combine(SnapshotDirectory(),file),ImageConversion.EncodeToPNG(pixels));string old=global::SProgress.GetString(SnapshotSaveKey,"")??"";var entries=old.Split(new[]{'\n'},StringSplitOptions.RemoveEmptyEntries);global::SProgress.SetString(SnapshotSaveKey,old+(old.Length>0?"\n":"")+file);quickStatus=SnapshotNames.Caption(entries.Length+1);quickFlashUntil=Time.realtimeSinceStartup+1.5f;MelonLogger.Msg("EIDETIC: "+quickStatus+" captured; archive reference will persist with the next game save.");
    var manager=global::BookManager.instance;if(manager!=null){manager.needInit=true;}
   }catch(Exception ex){quickStatus="Snapshot failed";MelonLogger.Warning("Snapshot capture failed: "+ex.Message);}
   finally {RenderTexture.active=active;if(pixels!=null)UnityEngine.Object.Destroy(pixels);if(target!=null){target.Release();UnityEngine.Object.Destroy(target);}if(root!=null)UnityEngine.Object.Destroy(root);}
  }
  private static void AttachSnapshotMemory() {var q=moduleOwner;if(q==null)return;try{q.RefreshSnapshotBooks();}catch(Exception ex){MelonLogger.Warning("Snapshot Memory entries: "+ex.Message);}}
  private void RefreshSnapshotBooks() {
   string signature=global::SProgress.GetString(SnapshotSaveKey,"")??"";
   var read=global::BookManager.readBooks;var all=global::BookManager.allBooks;if(read==null||all==null)return;
   // Save changes, including a new game, cannot leak a previous save's pictures.
   if(signature!=snapshotSaveSignature){foreach(var pair in snapshotBooks){read.Remove(pair.Value);all.Remove(pair.Value);}foreach(var o in snapshotObjects)UnityEngine.Object.Destroy(o);snapshotObjects.Clear();snapshotBooks.Clear();snapshotBookFiles.Clear();snapshotSaveSignature=signature;}
   var files=signature.Split(new[]{'\n'},StringSplitOptions.RemoveEmptyEntries);global::Book template=null;foreach(var b in all)if(b!=null&&b.book!=null&&!b.name.StartsWith("SignalisVR_Snapshot_",StringComparison.Ordinal)){template=b;break;}if(template==null)return;
   for(int i=0;i<files.Length;i++){string file=files[i];if(file.Length!=36||!file.EndsWith(".png",StringComparison.Ordinal)||Path.GetFileName(file)!=file||!File.Exists(Path.Combine(SnapshotDirectory(),file)))continue;string name="SignalisVR_Snapshot_"+(i+1).ToString("D3");global::Book book;
    if(!snapshotBooks.TryGetValue(name,out book)){book=UnityEngine.Object.Instantiate(template);book.name=name;book.addMemory=false;book.showPageNumbers=false;book.BackgroundImage=null;snapshotBooks.Add(name,book);snapshotBookFiles[name]=file;snapshotObjects.Add(book);}if(!all.Contains(book))all.Add(book);if(!read.Contains(book))read.Add(book);
   }
  }
  private static bool SnapshotContent(global::Book __instance,ref TextAsset __result){if(__instance!=null&&moduleOwner!=null&&moduleOwner.snapshotBooks.ContainsKey(__instance.name)){__result=__instance.book;return false;}return true;}
  private static bool SnapshotTitle(global::Book __instance,ref string __result){if(__instance!=null&&moduleOwner!=null&&moduleOwner.snapshotBooks.ContainsKey(__instance.name)){__result="snapshot "+__instance.name.Substring("SignalisVR_Snapshot_".Length);return false;}return true;}
  private static void SnapshotBookOpening(global::BookScreen __instance){LoadSnapshotImage(__instance.book);}
  private static void SnapshotBookOpened(global::BookScreen __instance){SnapshotOpened(__instance,__instance.book);}
  private static void LoadSnapshotImage(global::Book __0) {
   var q=moduleOwner;if(q==null||__0==null||__0.BackgroundImage!=null)return;string file;if(!q.snapshotBookFiles.TryGetValue(__0.name,out file))return;
   try{var texture=new Texture2D(2,2,TextureFormat.RGB24,false);if(!ImageConversion.LoadImage(texture,File.ReadAllBytes(Path.Combine(SnapshotDirectory(),file)))){UnityEngine.Object.Destroy(texture);return;}var sprite=Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f),100);__0.BackgroundImage=sprite;q.snapshotObjects.Add(texture);q.snapshotObjects.Add(sprite);}catch(Exception ex){MelonLogger.Warning("Snapshot image load: "+ex.Message);}
  }
  private static void SnapshotOpened(global::BookScreen __instance,global::Book __0) {
   var q=moduleOwner;if(q==null||__0==null||!q.snapshotBooks.ContainsKey(__0.name))return;
   __instance.TextContent=" ";var manager=global::BookManager.instance;if(manager!=null){if(manager.TextBox!=null)manager.TextBox.text=" ";if(manager.BG!=null){manager.BG.sprite=__0.BackgroundImage;manager.BG.preserveAspect=true;}}
  }
 }
}

