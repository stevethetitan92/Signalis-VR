$ErrorActionPreference='Stop'
$target=Get-Content (Join-Path $PSScriptRoot 'TestMenuActions.cs') -Raw
$storage=Get-Content (Join-Path $PSScriptRoot 'CalibrationStorage.cs') -Raw
$room=Get-Content (Join-Path $PSScriptRoot 'CalibrationRoom.cs') -Raw
function Extract($source,$name){$match=[regex]::Match($source,'(?m)^  private (?:static )?(?:void|bool) '+$name+'\(');if(!$match.Success){throw "Method declaration missing $name"};$line=$match.Index;$at=$line;$open=$source.IndexOf('{',$at);$depth=1;$i=$open+1;while($depth -gt 0){if($source[$i] -eq '{'){$depth++};if($source[$i] -eq '}'){$depth--};$i++};$source.Substring($line,$i-$line)}
$methods=(Extract $target 'SetTestHalfHealth')+(Extract $target 'DestroyTestEnemy')+(Extract $target 'OwnsTestEnemy')+(Extract $target 'TestEnemyUpdateGuard')+(Extract $storage 'RefillCalibrationStorage')+(Extract $storage 'RestoreCalibrationStorage')
# Supply lists are copied from the actual source, not reimplemented in the fixture.
$supplies=[regex]::Match($storage,'private static readonly global::Items.itemlist\[\] CalibrationSupplies=.*?;').Value
$ammo=[regex]::Match((Get-Content (Join-Path $PSScriptRoot 'GrantWeaponsCheat.cs') -Raw),'private static readonly global::Items.itemlist\[\] StorageAmmo=.*?;').Value
$fixture=@"
using System;using System.Collections.Generic;
namespace UnityEngine {public class Object {public static void Destroy(Object value){var root=value as GameObject;if(root!=null&&root.Active)throw new Exception("Destroy before immediate deactivate");}}public class Material:Object {}public class GameObject:Object {public bool Active=true;public void SetActive(bool value){Active=value;}}}
public class Room {}
public class AnEnemy:UnityEngine.Object {}
public class EnemyController {public long Pointer;}
public class AnItem {public enum AnItemType {Health,Tool,Ammo,Weapon}public AnItemType type;public int maxNumber=100;}
public static class Items {public enum itemlist {Pistol,Revolver,Shotgun,Rifle,FlareGun,SMG,Machete,Taser,SignalFlare,Health25,Health50,Health100,HealthFast,Flashlight,PhotoModule,PistolAmmo,RevolverAmmo,ShotgunAmmo,RifleAmmo,FlareGunAmmo,SmgAmmo}}
public static class PlayerState {public static int hp;public static Settings settings=new Settings();}
public class Settings {public int maxInventorySlots=6;} public class AnWeapon {public int magAmmo;}
public static class RadioManager {public static bool moduleInstalled;}
public static class InventoryManager {public static int maxSlots,modules;public static AnWeapon EquippedWeapon;public static AnItem EquippedTool,EquippedAmmo,CurrentItem;public static Dictionary<Items.itemlist,AnItem> allItems;public static Dictionary<AnItem,int> boxItems,elsterItems;}
namespace SignalisVrTracking {public sealed partial class Tracking {
 private readonly List<UnityEngine.Material> testBodyMaterials=new List<UnityEngine.Material>();
 private static Tracking weaponOwner;private static bool infiniteLife;private static bool ready=true;
 private float testEnemyDeathTime;private UnityEngine.GameObject testEnemyRoot,calibrationRoot;private EnemyController testEnemy;private AnEnemy testEnemyPreset;private Room testEnemyRoom;
 private Dictionary<AnItem,int> calibrationOriginalInventory;private Dictionary<AnItem,int> calibrationInventoryCounts=new Dictionary<AnItem,int>();private int calibrationOriginalHealth;private bool calibrationOriginalInfiniteLife;private int calibrationOriginalSlots=6,calibrationOriginalSettingsSlots=6,calibrationOriginalModules;private AnWeapon calibrationOriginalWeapon;private AnItem calibrationOriginalTool,calibrationOriginalAmmo,calibrationOriginalCurrent;private Dictionary<AnWeapon,int> calibrationMagazines=new Dictionary<AnWeapon,int>();private void CancelManualReload(){}private bool calibrationRadioInstalled;private AnItem receiverCatalog=new AnItem();private string testMenuStatus;private int saves;private bool modulesCleared;
 private class TestBodyCopy {public UnityEngine.GameObject Mesh;} private System.Collections.Generic.List<TestBodyCopy> testBodyCopies=new System.Collections.Generic.List<TestBodyCopy>();private static bool CheatPlayerReady(){return ready;}private void SaveModSettings(){saves++;}private AnItem ReceiverCatalog(){return receiverCatalog;}private void ClearHeldModules(){modulesCleared=true;}
 $supplies
 $ammo
 $methods
 public static void Test(){
  var q=new Tracking();weaponOwner=q;ready=true;
  foreach(int hp in new[]{1,50,100}){PlayerState.hp=hp;infiniteLife=true;q.SetTestHalfHealth();if(PlayerState.hp!=50||infiniteLife)throw new Exception("Half health/infinite-life override failed");}
  int saves=q.saves;PlayerState.hp=0;q.SetTestHalfHealth();if(PlayerState.hp!=0||q.saves!=saves)throw new Exception("Dead character revived");ready=false;PlayerState.hp=80;q.SetTestHalfHealth();if(PlayerState.hp!=80)throw new Exception("Unavailable character changed");ready=true;
  q.testEnemy=new EnemyController{Pointer=7};if(TestEnemyUpdateGuard(new EnemyController{Pointer=7})||!TestEnemyUpdateGuard(new EnemyController{Pointer=8}))throw new Exception("Real enemy AI affected");
  var old=new UnityEngine.GameObject();q.testEnemyRoot=old;q.testEnemyPreset=new AnEnemy();q.DestroyTestEnemy();if(old.Active||q.testEnemy!=null||q.testEnemyRoot!=null||q.testEnemyPreset!=null)throw new Exception("Old enemy not immediately removed");q.DestroyTestEnemy();
  InventoryManager.allItems=new Dictionary<Items.itemlist,AnItem>();foreach(Items.itemlist id in Enum.GetValues(typeof(Items.itemlist)))InventoryManager.allItems[id]=new AnItem{type=id.ToString().StartsWith("Health")?AnItem.AnItemType.Health:id.ToString().Contains("Ammo")?AnItem.AnItemType.Ammo:AnItem.AnItemType.Tool};
  var original=new Dictionary<AnItem,int>();var originalItem=new AnItem();original[originalItem]=17;q.calibrationOriginalInventory=original;q.calibrationInventoryCounts[originalItem]=17;q.calibrationRoot=new UnityEngine.GameObject();InventoryManager.boxItems=new Dictionary<AnItem,int>();InventoryManager.elsterItems=new Dictionary<AnItem,int>();q.RefillCalibrationStorage();
  if(InventoryManager.maxSlots!=50||PlayerState.settings.maxInventorySlots!=50)throw new Exception("Calibration not 50 slots");foreach(var id in StorageAmmo)if(InventoryManager.elsterItems[InventoryManager.allItems[id]]!=100)throw new Exception("Ammo not stocked at 100");foreach(var id in CalibrationSupplies)if(!InventoryManager.elsterItems.ContainsKey(InventoryManager.allItems[id]))throw new Exception("Missing supply "+id);
  var health=InventoryManager.allItems[Items.itemlist.Health50];var ammoItem=InventoryManager.allItems[Items.itemlist.RifleAmmo];InventoryManager.elsterItems[health]=0;InventoryManager.elsterItems[ammoItem]=3;q.RefillCalibrationStorage();if(InventoryManager.elsterItems[health]!=100||InventoryManager.elsterItems[ammoItem]!=100)throw new Exception("Carried inventory did not replenish");
  InventoryManager.elsterItems[q.receiverCatalog]=1;RadioManager.moduleInstalled=true;q.calibrationRadioInstalled=false;q.RestoreCalibrationStorage();if(InventoryManager.maxSlots!=6||PlayerState.settings.maxInventorySlots!=6)throw new Exception("Capacity not restored");if(!Object.ReferenceEquals(InventoryManager.elsterItems,original)||original[originalItem]!=17||RadioManager.moduleInstalled||InventoryManager.elsterItems.ContainsKey(q.receiverCatalog)||!q.modulesCleared)throw new Exception("Story storage/module restoration failed");q.RestoreCalibrationStorage();
 }
}}
"@
Add-Type -TypeDefinition $fixture -IgnoreWarnings -WarningAction SilentlyContinue
[SignalisVrTracking.Tracking]::Test()
foreach($needle in @('DestroyTestEnemy();','testEnemyRoot.SetActive(false)','testEnemy.TakeDamage()','testEnemy.Kill()','testEnemyPreset.damage=0','e.agent.enabled=false','e.WeaponHurtboxObject.SetActive(false)','"Save","Load","NewGame"')){if(!$target.Contains($needle)){throw "Missing target integration $needle"}}
if($target.IndexOf('DestroyTestEnemy();', $target.IndexOf('private void SpawnTestEnemy')) -gt $target.IndexOf('UnityEngine.Object.Instantiate(template.gameObject')){throw 'Old target removed after new clone creation'}
foreach($needle in @('new Vector3(12,.3f,12)','new Vector3(12.3f,4.5f,.3f)','calibrationReturnPosition=calibrationPlayer.position','MoveCalibrationPlayer(calibrationReturnPosition,calibrationReturnRotation)','CreateCalibrationStorage();','ResetDoorCamera();','Physics.SyncTransforms();')){if(!$room.Contains($needle)){throw "Missing room integration $needle"}}
if($storage.Contains('AddComponent<global::StorageBox>') -or $storage.Contains('InventoryManager.boxItems=')){throw 'Calibration still creates or replaces storage'}
'PASS half-health, target isolation, replenishing carried supplies, 50-slot capacity and original inventory restore. Runtime/headset behavior unverified.'
