using System;
using UnityEngine;
namespace SignalisVrTracking {
 public static class AmmoGuidePolicy {
  public const float RevolverScale=1f;
  public static bool LoaderCapture(float distance,float axial,float alignment){return distance<=.045f&&axial<=.012f&&alignment>=.5f;}

  public static bool Capture(float tipDistance,float centerDistance,float axial){return !float.IsNaN(axial)&&axial<.045f&&(tipDistance<.10f||centerDistance<.12f);}
  public static float Progress(float age){float t=Math.Max(0,Math.Min(1,age/.20f));return t*t*(3-2*t);}
  public static bool MagazineSeated(float alignment,float travel){return !float.IsNaN(travel)&&!float.IsInfinity(travel)&&alignment>=1&&travel>=-.015f;}
  public static bool Seated(float alignment,float travel){return !float.IsNaN(travel)&&!float.IsInfinity(travel)&&alignment>=1&&travel>=-.006f;}
 }
 public sealed partial class Tracking {
  private string ammoGuideKind;private int ammoGuideChamber=-1;private float ammoGuideStart;
  private Vector3 ammoGuideOffset;private Quaternion ammoGuideRotation;
  private void ResetAmmoGuide(){ammoGuideKind=null;ammoGuideChamber=-1;}
  // Preserve the native wrist and curled fingers as one rigid grip. Do not solve
  // fingertips independently against whichever box face happens to be nearest.
  private void FollowAmmoWithHand(Vector3 rawCenter,Quaternion rawRotation,Vector3 center,Quaternion rotation){
   if(!handsScoped||(handPreparedMask&1)==0||handsObjects[0]==null)return;
   var hand=handsObjects[0].transform;var inverse=Quaternion.Inverse(rawRotation);
   var offset=inverse*(hand.position-rawCenter);var relative=inverse*hand.rotation;
   hand.SetPositionAndRotation(center+rotation*offset,rotation*relative);
  }
  private bool GuideAdditionalAmmo(string kind,Vector3 rawCenter,Quaternion rawRotation,float halfTip,ref Vector3 center,ref Quaternion rotation,ref Vector3 tip){
   if(!AdditionalHoldingAmmo()){ResetAmmoGuide();return false;}
   bool rifle=kind=="Rifle",revolver=kind=="Revolver",smg=kind=="SMG",flare=kind=="FlareGun";
   if(!rifle&&!revolver&&!smg&&!flare)return false;
   if(!smg&&additionalOpen<(rifle?25f/RifleHingePolicy.MaxAngle:flare?.75f:.95f)){ResetAmmoGuide();return false;}
   var axis=additionalLoadDirection.normalized;var target=additionalChamber;int chamber=0;
   if(rifle){
    chamber=-1;float distance=float.MaxValue;
    for(int c=0;c<2;c++)if(rifleChambers.Empty(c)){float d=Vector3.Distance(tip,rifleChamberWorld[c]);if(d<distance){distance=d;chamber=c;}}
    if(ammoGuideKind==kind&&ammoGuideChamber>=0&&rifleChambers.Empty(ammoGuideChamber))chamber=ammoGuideChamber;
    if(chamber<0){ResetAmmoGuide();return false;}target=rifleChamberWorld[chamber];
   }
   Quaternion seatRotation=smg?rightWeaponRotation:revolver?rightWeaponRotation*Quaternion.Euler(90,0,0):Quaternion.FromToRotation(Vector3.up,axis);
   Vector3 seatCenter=target-axis*halfTip;
   if(rifle||flare)seatCenter=target+axis*halfTip;
   if(smg){var native=ReloadCopy("SMG_Mag");if(native!=null){seatCenter=native.transform.TransformPoint(native.GetComponent<MeshFilter>().sharedMesh.bounds.center);seatRotation=native.transform.rotation;tip=rawCenter+rawRotation*(Quaternion.Inverse(seatRotation)*(target-seatCenter));}}
   if(revolver&&SelectedActive("Revolver"))seatCenter=selectedRoot.transform.TransformPoint(HdRevolverData.OpenLoaderCenter);
   if(revolver){
    if(SelectedActive("Revolver")){
     var swing=Quaternion.AngleAxis(90*additionalOpen,Vector3.forward);
     seatCenter=selectedRoot.transform.TransformPoint(HdRevolverData.Pivot+swing*(HdRevolverData.LoaderCenter-HdRevolverData.Pivot));
     seatRotation=rightWeaponRotation*Quaternion.AngleAxis(90*(additionalOpen-1),Vector3.forward)*Quaternion.Euler(90,0,0);
    }
    var error=rawCenter-seatCenter;float distance=error.magnitude/UnitsPerMetre;
    if(ammoGuideKind==kind&&distance>.085f)ResetAmmoGuide();
    if(ammoGuideKind!=kind&&AmmoGuidePolicy.LoaderCapture(distance,Vector3.Dot(error,axis)/UnitsPerMetre,Vector3.Dot(rawRotation*Vector3.up,axis))){
     ammoGuideKind=kind;ammoGuideStart=Time.realtimeSinceStartup;
     ammoGuideOffset=Quaternion.Inverse(seatRotation)*error;ammoGuideRotation=Quaternion.Inverse(seatRotation)*rawRotation;
    }
    if(ammoGuideKind!=kind)return false;
    float snap=AmmoGuidePolicy.Progress(Time.realtimeSinceStartup-ammoGuideStart);
    center=seatCenter+seatRotation*ammoGuideOffset*(1-snap);
    rotation=seatRotation*Quaternion.Slerp(ammoGuideRotation,Quaternion.identity,snap);
    tip=center+rotation*Vector3.up*halfTip;
    return snap>=1;
   }
   float separation=Vector3.Distance(rawCenter,target)/UnitsPerMetre;
   // Rounds and the revolver loader transfer at the mouth. Keep the controller-driven
   // hand and authored grip unchanged rather than steering its wrist to the bore.
   if(flare){
    var flareDelta=(tip-target)/UnitsPerMetre;float depth=Vector3.Dot(flareDelta,axis);
    float lateral=(flareDelta-axis*depth).magnitude;
    if(ammoGuideKind==kind&&(lateral>.07f||depth<-.08f||depth>.14f))ResetAmmoGuide();
    if(ammoGuideKind!=kind&&lateral<=.04f&&depth>=-.04f&&depth<=.06f&&Vector3.Dot(rotation*Vector3.up,axis)>=.5f){ammoGuideKind=kind;ammoGuideStart=Time.realtimeSinceStartup;ammoGuideOffset=Quaternion.Inverse(seatRotation)*(rawCenter-seatCenter);ammoGuideRotation=Quaternion.Inverse(seatRotation)*rawRotation;}
    if(ammoGuideKind!=kind)return false;
    float snap=AmmoGuidePolicy.Progress(Time.realtimeSinceStartup-ammoGuideStart);
    center=seatCenter+seatRotation*ammoGuideOffset*(1-snap);
    rotation=seatRotation*Quaternion.Slerp(ammoGuideRotation,Quaternion.identity,snap);
    tip=center+rotation*Vector3.up*halfTip;
    return snap>=1;
   }
   if(rifle){
    ResetAmmoGuide();bool captured=AmmoGuidePolicy.Capture(Vector3.Distance(tip,target)/UnitsPerMetre,separation,Vector3.Dot(rawCenter-target,axis)/UnitsPerMetre);
    if(rifle&&captured){rifleCandidate=chamber;additionalChamber=target;tip=target;}
    return captured;
   }
   if(ammoGuideKind==kind&&separation>.23f)ResetAmmoGuide();
   if(ammoGuideKind!=kind&&AmmoGuidePolicy.Capture(Vector3.Distance(tip,target)/UnitsPerMetre,separation,Vector3.Dot(rawCenter-target,axis)/UnitsPerMetre)){
    ammoGuideKind=kind;ammoGuideChamber=chamber;ammoGuideStart=Time.realtimeSinceStartup;
    MelonLoader.MelonLogger.Msg("AMMO GUIDE: "+kind+" chamber="+chamber+" captured; distance="+separation.ToString("F3"));
    ammoGuideOffset=Quaternion.Inverse(seatRotation)*(rawCenter-seatCenter);ammoGuideRotation=Quaternion.Inverse(seatRotation)*rawRotation;
   }
   if(ammoGuideKind!=kind)return false;
   float blend=AmmoGuidePolicy.Progress(Time.realtimeSinceStartup-ammoGuideStart);
   rotation=seatRotation*Quaternion.Slerp(ammoGuideRotation,Quaternion.identity,blend);
   // Time only aligns the item to the mouth. Forward hand travel seats it.
   var delta=rawCenter-seatCenter;float along=Vector3.Dot(delta,axis);
   center=seatCenter+axis*Mathf.Min(0,along)+(delta-axis*along)*(1-blend);
   tip=center+rotation*Vector3.up*halfTip;
   bool seated=smg?AmmoGuidePolicy.MagazineSeated(blend,along/UnitsPerMetre):AmmoGuidePolicy.Seated(blend,along/UnitsPerMetre);
   if(rifle&&seated){tip=target;rifleCandidate=chamber;additionalChamber=target;}
   return seated;
  }
 }
}


