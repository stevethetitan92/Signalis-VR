$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'RepairPatchPose.cs') -Raw
$p=$s.Substring($s.IndexOf(' public static class RepairPatchMotion'));$p=$p.Substring(0,$p.IndexOf(' public sealed partial class Tracking'))
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$p+'}')
$t=[SignalisVrTracking.RepairPatchMotion]
foreach($age in @(-1,0,.58,2)){if($t::Amount($age) -ne 0){throw 'Rest endpoint incorrect'}}
foreach($age in @(.20,.25,.30)){if([Math]::Abs($t::Amount($age)-1) -gt .00001){throw 'Hold incorrect'}}
foreach($fps in @(30,72,90,120)) { $last=0;for($i=0;$i -lt $fps*.20;$i++){$a=$t::Amount($i/[float]$fps);if($a -lt $last -or $a -gt 1){throw 'Closure not monotone'};$last=$a};$last=1;for($i=0;$i -lt $fps*.28;$i++){$a=$t::Amount(.30+$i/[float]$fps);if($a -gt $last+.00001 -or $a -lt 0){throw 'Release not monotone'};$last=$a} }
if(!$t::PacketVisible($false,2) -or !$t::PacketVisible($true,.1) -or $t::PacketVisible($true,.2)){throw 'Packet visibility incorrect'}
$raw=Get-Content (Join-Path $PSScriptRoot 'RepairPatchPoseData.cs') -Raw
$b=[Convert]::FromBase64String([regex]::Match($raw,'Mesh="([^"]+)').Groups[1].Value)
$nv=[BitConverter]::ToInt32($b,0);$nt=[BitConverter]::ToInt32($b,4)
if($b.Length -ne 8+$nv*24+$nt*4){throw 'Pose length mismatch'}
for($i=0;$i -lt $nv*6;$i++){ $v=[BitConverter]::ToSingle($b,8+$i*4);if([float]::IsNaN($v) -or [float]::IsInfinity($v)){throw 'Nonfinite pose'} }
for($i=0;$i -lt $nt;$i++){ $v=[BitConverter]::ToInt32($b,8+$nv*24+$i*4);if($v -lt 0 -or $v -ge $nv){throw 'Invalid topology'} }
'PASS smooth rest/closure/hold/release at30/72/90/120Hz, packet timing, native pose endpoints and topology. Headset fit unverified.'
