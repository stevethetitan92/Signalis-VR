using System;
using System.Collections.Generic;
using System.Globalization;
namespace SignalisVrTracking {
 public static class HandSurfaceTopology {
  public static List<int[]> BoundaryLoops(float[] xyz,int[] triangles) {
   var welded=new Dictionary<string,int>();var ids=new int[xyz.Length/3];
   for(int i=0;i<ids.Length;i++) {
    string key=Math.Round(xyz[i*3],4).ToString(CultureInfo.InvariantCulture)+","+Math.Round(xyz[i*3+1],4).ToString(CultureInfo.InvariantCulture)+","+Math.Round(xyz[i*3+2],4).ToString(CultureInfo.InvariantCulture);
    int id;if(!welded.TryGetValue(key,out id)){id=i;welded[key]=id;}ids[i]=id;
   }
   var edges=new Dictionary<long,int>();
   for(int i=0;i<triangles.Length;i+=3)for(int j=0;j<3;j++) {
    int a=ids[triangles[i+j]],b=ids[triangles[i+(j+1)%3]];if(a==b)continue;
    long key=((long)Math.Min(a,b)<<32)|(uint)Math.Max(a,b);int n;edges.TryGetValue(key,out n);edges[key]=n+1;
   }
   var neighbors=new Dictionary<int,List<int>>();
   foreach(var e in edges)if(e.Value==1) {
    int a=(int)(e.Key>>32),b=(int)e.Key;
    if(!neighbors.ContainsKey(a))neighbors[a]=new List<int>();if(!neighbors.ContainsKey(b))neighbors[b]=new List<int>();
    neighbors[a].Add(b);neighbors[b].Add(a);
   }
   var loops=new List<int[]>();var seen=new HashSet<int>();
   foreach(int start in neighbors.Keys) {
    if(seen.Contains(start))continue;
    var component=new List<int>();var pending=new Stack<int>();pending.Push(start);bool closed=true;
    while(pending.Count>0){int a=pending.Pop();if(!seen.Add(a))continue;component.Add(a);if(neighbors[a].Count!=2)closed=false;foreach(int b in neighbors[a])if(!seen.Contains(b))pending.Push(b);}
    if(!closed||component.Count<3||component.Count>128)continue;
    var ring=new List<int>();int previous=-1,current=start;
    do {ring.Add(current);var ns=neighbors[current];int next=ns[0]==previous?ns[1]:ns[0];previous=current;current=next;}while(current!=start&&ring.Count<=component.Count);
    if(current==start&&ring.Count==component.Count)loops.Add(ring.ToArray());
   }
   return loops;
  }
  public static int[] DoubleSided(int[] front) {
   var result=new int[front.Length*2];Array.Copy(front,result,front.Length);
   for(int i=0;i<front.Length;i+=3){result[front.Length+i]=front[i];result[front.Length+i+1]=front[i+2];result[front.Length+i+2]=front[i+1];}
   return result;
  }
 }
}
