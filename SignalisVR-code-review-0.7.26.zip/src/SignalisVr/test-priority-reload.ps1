$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'PhysicalMagazineTransfer.cs') -Raw
$stubs=@'
namespace MelonLoader {public static class MelonLogger {public static void Msg(string s){}}}
public class AnItem {public string _item="Pistol";}
public class AnWeapon {public AnItem parentItem=new AnItem(),ammoItem=new AnItem();public int MagSize=10;private int loaded;public bool fail;public int magAmmo{get{return loaded;}set{if(fail)throw new System.Exception("setter failure");loaded=value;}}}
public static class InventoryManager {public static int reserve;public static void SetCount(AnItem i,int count){if(count<0)throw new System.Exception("Negative reserve");reserve=count;}}
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool infiniteAmmo;private int ShotgunReserve(AnWeapon w){return InventoryManager.reserve;}
 public static void Test(){var q=new Tracking();
 foreach(int capacity in new[]{2,6,10,40})for(int loaded=0;loaded<=capacity;loaded++)for(int reserve=0;reserve<=45;reserve++){
 var w=new AnWeapon{MagSize=capacity,magAmmo=loaded};InventoryManager.reserve=reserve;q.CommitPhysicalMagazine(w);int amount=System.Math.Min(capacity-loaded,reserve);
 if(w.magAmmo!=loaded+amount||InventoryManager.reserve!=reserve-amount)throw new System.Exception("Physical transfer mismatch");q.CommitPhysicalMagazine(w);if(w.magAmmo!=loaded+amount||InventoryManager.reserve!=reserve-amount)throw new System.Exception("Repeated completion duplicated ammo");}
 var broken=new AnWeapon();InventoryManager.reserve=12;broken.fail=true;try{q.CommitPhysicalMagazine(broken);throw new System.Exception("Failure not exercised");}catch(System.Exception e){if(e.Message!="setter failure")throw;}if(InventoryManager.reserve!=12)throw new System.Exception("Reserve lost on failed commit");
 var infinite=new AnWeapon();q.infiniteAmmo=true;InventoryManager.reserve=0;q.CommitPhysicalMagazine(infinite);if(infinite.magAmmo!=10||InventoryManager.reserve!=0)throw new System.Exception("Infinite magazine transfer failed");
 }
}}
'@
Add-Type -TypeDefinition ($s+$stubs)
[SignalisVrTracking.Tracking]::Test()
Add-Type -Path (Join-Path $PSScriptRoot 'ManualReloadPolicy.cs'),(Join-Path $PSScriptRoot 'HingedReloadPolicy.cs'),(Join-Path $PSScriptRoot 'ShotgunReloadPolicy.cs')
foreach($rack in $true,$false){$p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.PressB(0,$false,$true,$rack)|Out-Null;$p.Tick(.1,$true,$true,$true,$false)|Out-Null;$ready=$p.Seat(.11);if($ready -eq $rack){throw 'Seated release rack requirement wrong'};if($p.Seat(.12)){throw 'Repeated seat duplicated commit'};if($rack -and $p.Stage -ne 'Inserted'){throw 'Empty magazine bypassed cocking'}}
$p=[SignalisVrTracking.HingedReloadPolicy]::new();$p.PressB();$p.Tick(0,$true,$true,$false,0,2,4)|Out-Null;$p.Tick(.1,$true,$false,$true,0,2,4)|Out-Null;if(!$p.Tick(.12,$false,$false,$true,0,2,4)){throw 'Releasing aligned round lost contact'};if($p.Tick(.13,$false,$false,$true,0,2,4)){throw 'Round repeated transfer'}
foreach($hz in 30,72,90,120){$p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.BeginRack(0);for($i=1;$i -le $hz;$i++){$pull=if($i -lt $hz/2){.06*$i/($hz/2)}else{.06*(1-($i-$hz/2)/($hz/2))};$p.Tick($i/$hz,$true,$true,$false,$false,$false,$pull)|Out-Null};if(!$p.Tick(1.1,$true,$false,$false,$false,$false,0)){throw "SMG stroke lost at $hz Hz"}}
'PASS physical magazine transactions at 2/6/10/40 capacity, repeat, rollback, infinite reserve; seated release; chamber release; handle return at 30/72/90/120Hz.'
# Short deliberate handle strokes count; jitter, forward pushes and tracking jumps do not.
foreach($pull in @(-.04,0,.005,.011,.013,.03,.06,.4)){
 $p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.MinimumPull=.012;$p.MaximumPull=.06;$p.BeginRack(0)
 $p.Tick(.1,$true,$true,$false,$false,$false,$pull)|Out-Null
 $accepted=$p.Tick(.2,$true,$false,$false,$false,$false,0)
 $expected=$pull -ge .012 -and $pull -le .35
 if($accepted -ne $expected){throw "Handle threshold failure at $pull"}
}
Add-Type -Path (Join-Path $PSScriptRoot 'ReloadContactPolicy.cs')
if([SignalisVrTracking.ReloadContactPolicy]::PistolCapture(.06,-.05)){throw 'Wide approach captured without contact'}
if(![SignalisVrTracking.ReloadContactPolicy]::PistolRetain(.06,-.05)){throw 'Captured magazine lost on lateral jitter'}
foreach($pair in @(@(.081,-.05),@(.01,-.19),@(.01,.13),@([float]::NaN,0))){if([SignalisVrTracking.ReloadContactPolicy]::PistolRetain($pair[0],$pair[1])){throw 'Withdrawal or invalid sample retained'}}
'PASS short SMG strokes, jitter/forward/jump rejection, pistol guide hysteresis and withdrawal.'
