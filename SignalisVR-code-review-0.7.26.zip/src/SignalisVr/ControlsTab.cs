using System;
using UnityEngine;
namespace SignalisVrTracking {
 public static class ModMenuSections {
  public static readonly string[] Names={"SETTINGS","CHEATS","TEST"};
  public static int Next(int page,int direction){return Math.Max(0,Math.Min(Names.Length-1,page+direction));}
 }
 public sealed partial class Tracking {
  private Texture2D controlsDiagram;
  private int CurrentModSection(){return modMenuTest?2:modMenuCheats?1:0;}
  private void SelectModSection(int page){wheelPickSlot=-1;wheelPendingChoice=-1;modMenuControls=false;modMenuWheel=false;modMenuCheats=page==1;modMenuTest=page==2;modMenuSelection=0;if(modMenuWheel)OpenWheelPicker(-1);}
  private void DrawControlsTab(float x,float y,float width,float s) {
   if(controlsDiagram==null) {
    controlsDiagram=new Texture2D(2,2,TextureFormat.RGBA32,false);
    if(!ImageConversion.LoadImage(controlsDiagram,Convert.FromBase64String(ControlsArtwork.Png),true))throw new InvalidOperationException("Controls artwork decode failed");
    controlsDiagram.filterMode=FilterMode.Point;controlsDiagram.wrapMode=TextureWrapMode.Clamp;
   }
   float fit=width/ControlsArtwork.Width;
   GUI.color=Color.white;
   GUI.DrawTexture(new Rect(x,y,width,ControlsArtwork.Height*fit),controlsDiagram);
   // Cover the four baked tabs so the same live five-tab row is used everywhere.
   PaintMenuRect(new Rect(x,y+63*fit,width,52*fit),Color.black);
   if(DrawModTabs(x,y+63*fit-50*s,width,s))return;
   var done=new Rect(x+41*fit,y+829*fit,248*fit,60*fit);
   if(MenuClicked(done)){FinishModMenu();return;}
   if(modSettingsError!=null) {
    PaintMenuRect(new Rect(x,y+ControlsArtwork.Height*fit,width,36*s),Color.black);
    MenuText(new Rect(x,y+ControlsArtwork.Height*fit,width,36*s),modSettingsError,Color.white,modMenuHelp);
   }
  }
  private void DrawTestTab(float x,float y,float width,float s){
   string[] labels={calibrationRoot!=null?"Leave Calibration Room":"Enter Calibration Room","Report Problem"};
   string[] descriptions={"Start at 50% health with Infinite Life OFF. A spacious 12 x 12 metre room with a metre grid. Leaving returns you to your original location. 50 inventory slots with all weapons and modules, replenishing healing items and ammo for every gun. Your original inventory returns when you leave. Saving or loading exits the room.","Save recent diagnostic history and current camera, UI, weapon and enemy information. Press LEFT GRIP + Y to report from gameplay or dialogue. Two pulses confirm saved. F8 also works."};
   var cyan=new Color(.15f,.85f,.95f);
   for(int i=0;i<labels.Length;i++){
    var row=new Rect(x,y+(120+i*70)*s,width,58*s);if(i==modMenuSelection)PaintMenuRect(row,new Color(.13f,.23f,.22f));
    MenuText(new Rect(row.x,row.y,width*.64f,row.height),labels[i],Color.white,modMenuStyle);
    MenuText(new Rect(row.x+width*.65f,row.y,width*.35f,row.height),"A: SELECT",cyan,modMenuStyle);
    if(MenuClicked(row)){modMenuSelection=i;ActivateTestMenu(i);return;}
   }
   MenuText(new Rect(x,y+370*s,width,100*s),modMenuSelection<labels.Length?descriptions[modMenuSelection]:"Save settings and return to the game.",Color.white,modMenuHelp);
   if(testMenuStatus!=null)MenuText(new Rect(x,y+510*s,width,100*s),testMenuStatus,cyan,modMenuHelp);
   var done=new Rect(x,y+750*s,430*s,52*s);PaintMenuRect(done,modMenuSelection==2?Color.gray:new Color(.88f,.12f,.055f));
   MenuText(done,"D O N E",Color.white,modMenuStyle);if(MenuClicked(done))FinishModMenu();
   MenuText(new Rect(x+470*s,y+750*s,width-470*s,52*s),"LEFT JOYSTICK: SELECT   A: ACTIVATE   GRIPS: TABS",Color.white,modMenuHelp);
  }
  private void DestroyControlsTab(){DestroyPauseControlsImage();foreach(var texture in hudPlacementArms)if(texture!=null)UnityEngine.Object.Destroy(texture);hudPlacementArms[0]=hudPlacementArms[1]=null;if(controlsDiagram!=null)UnityEngine.Object.Destroy(controlsDiagram);controlsDiagram=null;}
 }
}


