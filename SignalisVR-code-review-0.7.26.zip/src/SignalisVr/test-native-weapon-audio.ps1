$ErrorActionPreference='Stop'
$compiled=Get-Content (Join-Path $PSScriptRoot 'source-files.txt')
if($compiled -contains 'HdGunAudio.cs'){throw 'HD shot replacement still compiled'}
foreach($name in $compiled){
 if(!$name.EndsWith('.cs')){continue}
 $path=Join-Path $PSScriptRoot $name
 $s=[IO.File]::ReadAllText($path)
 if($s.Contains('InstallHdGunAudio(') -or $s.Contains('EnsureHdGunAudio(') -or $s.Contains('ReplaceHdShotAudio(')){throw "HD audio entry point remains: $name"}
}
& (Join-Path $PSHOME 'pwsh.exe') -NoProfile -File (Join-Path $PSScriptRoot 'test-reload-audio0658.ps1')
if($LASTEXITCODE -ne 0){throw 'Native continuing-shot audio regression'}
'PASS compiled mod excludes HD audio interception; native SMG continuing-shot event retained. Audible headset playback unverified.'
