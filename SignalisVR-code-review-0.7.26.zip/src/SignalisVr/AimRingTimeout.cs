using UnityEngine;
namespace SignalisVrTracking {
 public sealed class AimRingTimer {
  private float started=-1;
  public void Shot(float now){if(started<0)started=now;}
  public bool Hidden(float now){return started>=0&&now-started>=2f;}
  public float Alpha(float now){if(started<0)return 1;return RingFade.Alpha(now-started);}
  public void Reset(){started=-1;}
 }
 public static class RingFade {public static float Alpha(float age){if(age<=1.25f)return 1;if(age>=2f||float.IsNaN(age))return 0;float t=(age-1.25f)/.75f;return 1-t*t*(3-2*t);}}
 public sealed partial class Tracking {
  private readonly AimRingTimer aimRingTimer=new AimRingTimer();
  private global::PlayerAim aimRingOwner;
  private global::AnItem aimRingWeapon;
  private float aimRingSearch;
  private readonly System.Collections.Generic.Dictionary<SpriteRenderer,Color> aimRingColors=new System.Collections.Generic.Dictionary<SpriteRenderer,Color>();
  private void RecordAimRingShot(){if(active&&stereo)aimRingTimer.Shot(Time.realtimeSinceStartup);}
  private void PrepareAimRings() {
   var attack=global::PlayerAttack.instance;
   var weapon=global::InventoryManager.EquippedWeapon;
   var item=weapon==null?null:weapon.parentItem;
   if(!active||!stereo||!WeaponGameplayReady()||attack==null||!attack.aiming||item==null||item!=aimRingWeapon){aimRingTimer.Reset();aimRingWeapon=item;return;}
   float alpha=aimRingTimer.Alpha(Time.realtimeSinceStartup);if(alpha>=1)return;
   if(aimRingOwner==null||!aimRingOwner.gameObject.activeInHierarchy) {
    if(Time.realtimeSinceStartup<aimRingSearch)return;
    aimRingSearch=Time.realtimeSinceStartup+.5f;
    foreach(var candidate in Resources.FindObjectsOfTypeAll<global::PlayerAim>())
     if(candidate!=null&&candidate.gameObject.activeInHierarchy){aimRingOwner=candidate;break;}
   }
   if(aimRingOwner==null)return;
   FadeAimRing(aimRingOwner.crosshairSR,alpha);
   if(aimRingOwner.crosshair!=null)foreach(var renderer in aimRingOwner.crosshair.GetComponentsInChildren<SpriteRenderer>(true))FadeAimRing(renderer,alpha);
  }
  private void FadeAimRing(SpriteRenderer renderer,float alpha){if(renderer==null||aimRingColors.ContainsKey(renderer))return;var color=renderer.color;aimRingColors.Add(renderer,color);color.a*=alpha;renderer.color=color;}
  private void RestoreAimRings(){foreach(var pair in aimRingColors)if(pair.Key!=null)pair.Key.color=pair.Value;aimRingColors.Clear();}
 }
}
