using System;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private void VrMapLine(Vector2 a,Vector2 b,Color color,float width) {
   var halo=color;halo.a=.08f;VrMapStroke(a,b,halo,width*1.6f,3,.004f);
   color.a=.95f;VrMapStroke(a,b,color,width,5,.006f);
  }
  private bool mapSymbolsDirty=true;
  private Mesh mapSymbolMesh,mapPlayerMesh;
  private MeshRenderer mapSymbolRenderer,mapPlayerRenderer;
  private readonly System.Collections.Generic.List<Vector3> mapStrokeVertices=new System.Collections.Generic.List<Vector3>();
  private readonly System.Collections.Generic.List<int> mapStrokeTriangles=new System.Collections.Generic.List<int>();
  private readonly System.Collections.Generic.List<Color> mapStrokeColors=new System.Collections.Generic.List<Color>();
  private void VrMapStroke(Vector2 a,Vector2 b,Color color,float width,int order,float depth) {
   var d=b-a;if(d.sqrMagnitude<.00000001f)return;var n=new Vector2(-d.y,d.x).normalized*(width*.5f);int start=mapStrokeVertices.Count;
   foreach(var p in new[]{a-n,a+n,b+n,b-n}){mapStrokeVertices.Add(new Vector3(p.x,p.y,-depth*UnitsPerMetre));mapStrokeColors.Add(color);}
   mapStrokeTriangles.Add(start);mapStrokeTriangles.Add(start+1);mapStrokeTriangles.Add(start+2);mapStrokeTriangles.Add(start);mapStrokeTriangles.Add(start+2);mapStrokeTriangles.Add(start+3);
  }
  private void BeginMapStrokeMesh(){mapStrokeVertices.Clear();mapStrokeTriangles.Clear();mapStrokeColors.Clear();}
  private void FinishMapStrokeMesh(ref Mesh mesh,ref MeshRenderer renderer,string name){
   if(modMapLineMaterial==null){var shader=Shader.Find("Sprites/Default");if(shader==null)throw new InvalidOperationException("Map symbol shader unavailable");modMapLineMaterial=new Material(shader);modMapLineMaterial.mainTexture=Texture2D.whiteTexture;}
   if(mesh==null){var go=new GameObject(name);go.layer=30;go.transform.SetParent(modMapRoot.transform,false);mesh=new Mesh();mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;go.AddComponent<MeshFilter>().sharedMesh=mesh;renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=modMapLineMaterial;renderer.sortingOrder=5;renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;renderer.receiveShadows=false;}
   mesh.Clear();mesh.vertices=mapStrokeVertices.ToArray();mesh.colors=mapStrokeColors.ToArray();mesh.triangles=mapStrokeTriangles.ToArray();mesh.RecalculateBounds();renderer.enabled=true;
  }
  private void PrepareVrMapSymbols() {
   float s=UnitsPerMetre*.001f;
   if(mapSymbolsDirty){BeginMapStrokeMesh();mapIconCount=0;foreach(var icon in mapIconRenderers)if(icon!=null)icon.enabled=false;
   for(int i=0;i<modDoorPoints.Count;i++){
    var p=(modDoorPoints[i]-modMapCenter)*modMapScale;int state=modDoorStates[i];
    MapDoorLines(p,state,s,modDoorRotations[i],VrMapLine);
   }

   for(int i=0;i<mapPointPositions.Count;i++){MapPointLines(mapPointPositions[i],mapPointKinds[i],s,VrMapLine);MapNativeVr(mapPointPositions[i],mapPointKinds[i],s);}
   FinishMapStrokeMesh(ref mapSymbolMesh,ref mapSymbolRenderer,"MapSymbolsBatched");mapSymbolsDirty=false;}
   if(mapSymbolRenderer!=null)mapSymbolRenderer.enabled=true;for(int i=0;i<mapIconCount;i++)mapIconRenderers[i].enabled=true;
   BeginMapStrokeMesh();var player=global::PlayerState.player;Vector2 location,facing;
   if(player==null||!MapPlayerPoint(player.transform.position,out location)||!MapPlayerPoint(player.transform.position+stereoRotation*Vector3.forward,out facing))return;
   var direction=(facing-location).normalized;if(direction.sqrMagnitude<.001f)return;var side=new Vector2(-direction.y,direction.x);var tip=location+direction*4.8f*s;var left=location-direction*3*s+side*2.4f*s;var right=location-direction*3*s-side*2.4f*s;var cyan=new Color(.4f,1f,1f);
   VrMapLine(tip,left,cyan,1.5f*s);VrMapLine(left,right,cyan,1.5f*s);VrMapLine(right,tip,cyan,1.5f*s);
   FinishMapStrokeMesh(ref mapPlayerMesh,ref mapPlayerRenderer,"MapPlayerBatched");
  }
 }
}

