namespace SignalisVrTracking { internal static class HdFlareGunData {
public static readonly string Geometry=HdAsset.Read("FlareGun-0.bin");
public static readonly string[] Textures={"",HdAsset.Read("FlareGun-1.bin")};
public static readonly float[] Colors={1.0f,0.0f,0.0f,1.0f,1.0f,1.0f,1.0f,1.0f};
public static readonly UnityEngine.Vector3 Support=new UnityEngine.Vector3(0.00000000f,0.02830000f,0.02570000f);
public static readonly UnityEngine.Vector3 Pivot=new UnityEngine.Vector3(0.00023000f,0.02940000f,0.10930000f);
public static readonly UnityEngine.Vector3 Muzzle=new UnityEngine.Vector3(0.00022500f,0.06956400f,0.15450700f);
public static readonly UnityEngine.Vector3 Chamber=new UnityEngine.Vector3(0.00023000f,0.06880000f,0.00900000f);
} }
