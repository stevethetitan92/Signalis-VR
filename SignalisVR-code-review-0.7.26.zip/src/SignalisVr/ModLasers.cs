using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private bool modLasersOn=true,manualReloadEnabled,modHudRight=true,modHudOn=true,modMiniMap;
  private int modLaserColor;
  private static readonly string[] modLaserNames={"RED","GREEN","BLUE","ORANGE","WHITE"};
  private static readonly Color[] modLaserColors={Color.red,Color.green,Color.blue,new Color(1f,.45f,0f),Color.white};
  private Transform modLaserModel;
  private global::AimLaser[] modLaserObjects;
  private bool[] modLineEnabled,modPointEnabled;
  private Color[] modLineStart,modLineEnd,modPointColor;
  private Material[] modLineMaterials,modPointMaterials;
  private Material modLineMaterial,modDotMaterial;
  private bool modLasersScoped;
  private sealed class LaserPointState {public SpriteRenderer Renderer;public Sprite Sprite;public Material Material;public Color Color;public bool Enabled;}
  private readonly List<LaserPointState> laserPointStates=new List<LaserPointState>();
  private readonly Dictionary<int,Sprite> neutralLaserSprites=new Dictionary<int,Sprite>();
  private readonly List<Texture2D> neutralLaserTextures=new List<Texture2D>();
  private bool laserPointWarning;
  private sealed class LaserMeshTint {public Renderer Renderer;public Material[] Materials;}
  private readonly List<LaserMeshTint> laserMeshTints=new List<LaserMeshTint>();
  private readonly Dictionary<int,Material> neutralLaserMeshMaterials=new Dictionary<int,Material>();
  private Material NeutralLaserMeshMaterial(Material source,Color tint){
   Material result;
   if(!neutralLaserMeshMaterials.TryGetValue(source.GetInstanceID(),out result)){
    var shader=Shader.Find("Sprites/Default");if(shader==null)return source;
    result=new Material(shader);
    var tex=source.mainTexture;
    if(tex!=null){
     var rt=RenderTexture.GetTemporary(tex.width,tex.height,0,RenderTextureFormat.ARGB32);var previous=RenderTexture.active;Texture2D copy=null;
     try{Graphics.Blit(tex,rt);RenderTexture.active=rt;copy=new Texture2D(tex.width,tex.height,TextureFormat.RGBA32,false);copy.ReadPixels(new Rect(0,0,tex.width,tex.height),0,0);copy.Apply();var pixels=copy.GetPixels();for(int i=0;i<pixels.Length;i++)pixels[i]=new Color(1,1,1,pixels[i].a);copy.SetPixels(pixels);copy.Apply();result.mainTexture=copy;neutralLaserTextures.Add(copy);copy=null;}
     finally{RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);if(copy!=null)UnityEngine.Object.Destroy(copy);}
    }else result.mainTexture=Texture2D.whiteTexture;
    result.mainTextureScale=source.mainTextureScale;result.mainTextureOffset=source.mainTextureOffset;neutralLaserMeshMaterials.Add(source.GetInstanceID(),result);
   }
   result.color=tint;return result;
  }
  private void TintLaserMeshEndpoints(Color tint){
   foreach(var state in laserEndpointStates){var r=state.Renderer;if(r==null||r.TryCast<SpriteRenderer>()!=null)continue;
    var original=r.sharedMaterials;laserMeshTints.Add(new LaserMeshTint{Renderer=r,Materials=original});var changed=new Material[original.Length];for(int i=0;i<original.Length;i++)changed[i]=original[i]==null?null:NeutralLaserMeshMaterial(original[i],tint);r.sharedMaterials=changed;
   }
  }
  private void RestoreLaserMeshTints(){foreach(var s in laserMeshTints)if(s.Renderer!=null)s.Renderer.sharedMaterials=s.Materials;laserMeshTints.Clear();}
  private sealed class LaserEndpointState {public Renderer Renderer;public bool Enabled;}
  private readonly List<LaserEndpointState> laserEndpointStates=new List<LaserEndpointState>();
  private readonly List<LaserEndpointState> enemyBoxStates=new List<LaserEndpointState>();
  private global::PersistentAimCursor[] enemyAimCursors;private global::PlayerAim[] enemyAimOwners;
  private sealed class EnemyCanvasState {public CanvasRenderer Renderer;public bool Cull;}
  private readonly List<EnemyCanvasState> enemyCanvasStates=new List<EnemyCanvasState>();
  private void HideEnemyBoxCanvas(GameObject root){if(root==null)return;foreach(var r in root.GetComponentsInChildren<CanvasRenderer>(true)){bool found=false;foreach(var old in enemyCanvasStates)if(old.Renderer==r){found=true;break;}if(!found){enemyCanvasStates.Add(new EnemyCanvasState{Renderer=r,Cull=r.cull});r.cull=true;}}}
  private global::AimAssistPopup[] enemyBoxPopups;private int enemyBoxScene=-1;private float enemyBoxRefresh;
  // Decal endpoints can use a MeshRenderer rather than a SpriteRenderer.
  // Capture all endpoint artwork before the tint scope changes any flags.
  private void CaptureLaserEndpoint(Renderer renderer){
   if(renderer==null)return;foreach(var state in laserEndpointStates)if(state.Renderer==renderer)return;
   laserEndpointStates.Add(new LaserEndpointState{Renderer=renderer,Enabled=renderer.enabled});
   if(!modLasersOn)renderer.enabled=false;
  }
  private void CaptureNativeLaserEndpoints(global::AimLaser laser){
   CaptureLaserEndpoint(laser.laserPointSR);
   if(laser.laserPoint!=null)foreach(var renderer in laser.laserPoint.GetComponentsInChildren<Renderer>(true))CaptureLaserEndpoint(renderer);
   if(laser.decalPoint!=null)foreach(var renderer in laser.decalPoint.GetComponentsInChildren<Renderer>(true))CaptureLaserEndpoint(renderer);
  }
  private void RestoreLaserEndpoints(){foreach(var state in laserEndpointStates)if(state.Renderer!=null)state.Renderer.enabled=state.Enabled;laserEndpointStates.Clear();}
  private void HideEnemyBoxRenderer(Renderer renderer){
   if(renderer==null)return;foreach(var state in enemyBoxStates)if(state.Renderer==renderer)return;
   enemyBoxStates.Add(new LaserEndpointState{Renderer=renderer,Enabled=renderer.enabled});renderer.enabled=false;
  }
  private void PrepareEnemyTargetBoxes(){
   int scene=UnityEngine.SceneManagement.SceneManager.GetActiveScene().handle;
   if(enemyBoxPopups==null||scene!=enemyBoxScene||Time.unscaledTime>=enemyBoxRefresh){enemyBoxRefresh=Time.unscaledTime+1f;enemyBoxScene=scene;enemyBoxPopups=Resources.FindObjectsOfTypeAll<global::AimAssistPopup>();enemyAimCursors=Resources.FindObjectsOfTypeAll<global::PersistentAimCursor>();enemyAimOwners=Resources.FindObjectsOfTypeAll<global::PlayerAim>();}
   foreach(var popup in enemyBoxPopups)if(popup!=null)
    {HideEnemyBoxCanvas(popup.gameObject);HideEnemyBoxCanvas(popup.Pivot);foreach(var renderer in popup.GetComponentsInChildren<Renderer>(true))HideEnemyBoxRenderer(renderer);
    if(popup.Pivot!=null)foreach(var renderer in popup.Pivot.GetComponentsInChildren<Renderer>(true))HideEnemyBoxRenderer(renderer);}
   if(enemyAimOwners!=null)foreach(var aim in enemyAimOwners)if(aim!=null){HideEnemyBoxRenderer(aim.crosshairSR);if(aim.crosshair!=null){HideEnemyBoxCanvas(aim.crosshair.gameObject);foreach(var renderer in aim.crosshair.GetComponentsInChildren<Renderer>(true))HideEnemyBoxRenderer(renderer);}if(aim.crosshairBlocked!=null){HideEnemyBoxCanvas(aim.crosshairBlocked);foreach(var renderer in aim.crosshairBlocked.GetComponentsInChildren<Renderer>(true))HideEnemyBoxRenderer(renderer);}}
   if(enemyAimCursors!=null)foreach(var cursor in enemyAimCursors)if(cursor!=null)HideEnemyBoxRenderer(cursor.sr);
  }
  private void RestoreEnemyTargetBoxes(){foreach(var state in enemyCanvasStates)if(state.Renderer!=null)state.Renderer.cull=state.Cull;enemyCanvasStates.Clear();foreach(var state in enemyBoxStates)if(state.Renderer!=null)state.Renderer.enabled=state.Enabled;enemyBoxStates.Clear();}


  private Sprite NeutralLaserSprite(Sprite source) {
   if(source==null)return null;Sprite cached;if(neutralLaserSprites.TryGetValue(source.GetInstanceID(),out cached))return cached;
   var tex=source.texture;var rt=RenderTexture.GetTemporary(tex.width,tex.height,0,RenderTextureFormat.ARGB32);
   var previous=RenderTexture.active;Texture2D copy=null;
   try {
    Graphics.Blit(tex,rt);RenderTexture.active=rt;
    copy=new Texture2D(tex.width,tex.height,TextureFormat.RGBA32,false);
    copy.ReadPixels(new Rect(0,0,tex.width,tex.height),0,0);copy.Apply();
    var pixels=copy.GetPixels();for(int i=0;i<pixels.Length;i++)pixels[i]=new Color(1,1,1,pixels[i].a);
    copy.SetPixels(pixels);copy.Apply();copy.filterMode=tex.filterMode;copy.wrapMode=TextureWrapMode.Clamp;
    var rect=source.textureRect;var size=source.rect;var pivot=source.pivot;
    cached=Sprite.Create(copy,rect,new Vector2(pivot.x/size.width,pivot.y/size.height),source.pixelsPerUnit);
    neutralLaserSprites.Add(source.GetInstanceID(),cached);neutralLaserTextures.Add(copy);copy=null;return cached;
   } finally {RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);if(copy!=null)UnityEngine.Object.Destroy(copy);}
  }
  private void TintNativeLaserPoint(global::AimLaser laser,Color tint) {
   var points=new List<SpriteRenderer>();if(laser.laserPointSR!=null)points.Add(laser.laserPointSR);
   if(laser.laserPoint!=null)points.AddRange(laser.laserPoint.GetComponentsInChildren<SpriteRenderer>(true));
   if(laser.decalPoint!=null)points.AddRange(laser.decalPoint.GetComponentsInChildren<SpriteRenderer>(true));
   foreach(var point in points){bool seen=false;foreach(var previousState in laserPointStates)if(previousState.Renderer==point){seen=true;break;}if(seen||point==null)continue;
    var state=new LaserPointState{Renderer=point,Sprite=point.sprite,Material=point.sharedMaterial,Color=point.color,Enabled=point.enabled};
    laserPointStates.Add(state);
    try{var sprite=NeutralLaserSprite(point.sprite);if(sprite!=null)point.sprite=sprite;}catch(Exception ex){if(!laserPointWarning){laserPointWarning=true;MelonLoader.MelonLogger.Warning("Laser endpoint texture conversion failed: "+ex.Message);}}
    if(modDotMaterial!=null)point.sharedMaterial=modDotMaterial;point.color=tint;point.enabled=modLasersOn&&state.Enabled;
   }
  }
  private void RestoreNativeLaserPoints(){foreach(var state in laserPointStates)if(state.Renderer!=null){state.Renderer.sprite=state.Sprite;state.Renderer.sharedMaterial=state.Material;state.Renderer.color=state.Color;state.Renderer.enabled=state.Enabled;}laserPointStates.Clear();}
  private void DestroyLaserPointTextures(){DestroyImportedLaser();RestoreNativeLaserPoints();RestoreLaserMeshTints();RestoreLaserEndpoints();foreach(var m in neutralLaserMeshMaterials.Values)if(m!=null)UnityEngine.Object.Destroy(m);neutralLaserMeshMaterials.Clear();foreach(var sprite in neutralLaserSprites.Values)if(sprite!=null)UnityEngine.Object.Destroy(sprite);foreach(var texture in neutralLaserTextures)if(texture!=null)UnityEngine.Object.Destroy(texture);neutralLaserSprites.Clear();neutralLaserTextures.Clear();}
  private void PrepareModLasers(Transform desktopModel=null) {
   var model=desktopModel==null?handGripModel:desktopModel;
   if(model==null||(desktopModel==null&&!handsScoped))return;
   if(modLaserModel!=model) {
    modLaserModel=model;modLaserObjects=model.GetComponentsInChildren<global::AimLaser>(true);
    int n=modLaserObjects.Length;modLineEnabled=new bool[n];modPointEnabled=new bool[n];modLineStart=new Color[n];modLineEnd=new Color[n];modPointColor=new Color[n];modLineMaterials=new Material[n];modPointMaterials=new Material[n];
   }
   if(modLineMaterial==null){var shader=Shader.Find("Sprites/Default");if(shader!=null)modLineMaterial=new Material(shader);}
   if(modDotMaterial==null){var shader=Shader.Find("Sprites/Default");if(shader!=null)modDotMaterial=new Material(shader);}
   // Alpha-blended vertex color, applied once (not multiplied by a tinted material).
   Color tint=modLaserColors[modLaserColor];tint.r*=.8f;tint.g*=.8f;tint.b*=.8f;tint.a=.7f;
   if(modLineMaterial!=null){modLineMaterial.color=Color.white;modLineMaterial.mainTexture=Texture2D.whiteTexture;}
   if(modDotMaterial!=null)modDotMaterial.color=Color.white;
   modLasersScoped=true;
   for(int i=0;i<modLaserObjects.Length;i++) {
    var a=modLaserObjects[i];if(a==null)continue;
    CaptureNativeLaserEndpoints(a);
    if(a.line!=null){modLineMaterials[i]=a.line.sharedMaterial;if(modLineMaterial!=null)a.line.sharedMaterial=modLineMaterial;}
    if(a.laserPointSR!=null){modPointMaterials[i]=a.laserPointSR.sharedMaterial;if(modDotMaterial!=null)a.laserPointSR.sharedMaterial=modDotMaterial;}
    if(a.line!=null){modLineEnabled[i]=a.line.enabled;modLineStart[i]=a.line.startColor;modLineEnd[i]=a.line.endColor;a.line.enabled=modLasersOn&&modLineEnabled[i];a.line.startColor=a.line.endColor=tint;}
    if(a.laserPointSR!=null){modPointEnabled[i]=a.laserPointSR.enabled;modPointColor[i]=a.laserPointSR.color;a.laserPointSR.enabled=modLasersOn&&modPointEnabled[i];a.laserPointSR.color=tint;}
    TintNativeLaserPoint(a,tint);
   }
   TintLaserMeshEndpoints(tint);if(desktopModel==null)PrepareImportedLaser();
  }
  private void RestoreModLasers() {
   HideImportedLaser();
   if(!modLasersScoped)return;modLasersScoped=false;
   RestoreNativeLaserPoints();RestoreLaserMeshTints();
   for(int i=0;i<modLaserObjects.Length;i++) {
    var a=modLaserObjects[i];if(a==null)continue;
    if(a.line!=null)a.line.sharedMaterial=modLineMaterials[i];
    if(a.laserPointSR!=null)a.laserPointSR.sharedMaterial=modPointMaterials[i];
    if(a.line!=null){a.line.enabled=modLineEnabled[i];a.line.startColor=modLineStart[i];a.line.endColor=modLineEnd[i];}
    if(a.laserPointSR!=null){a.laserPointSR.enabled=modPointEnabled[i];a.laserPointSR.color=modPointColor[i];}
   }
   RestoreLaserEndpoints();
  }
 }
}
