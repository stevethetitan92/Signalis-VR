$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'ThrowableThermite.cs') -Raw
$policy=$s.Substring($s.IndexOf(' public sealed class FlareThrowPolicy'));$policy=$policy.Substring(0,$policy.IndexOf(' public sealed partial class Tracking'))
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$policy+'}')
$p=[SignalisVrTracking.FlareThrowPolicy]::new()
if($p.Release($true,$true) -or $p.Release($true,$false)){throw 'Equipping with held grip threw flare'}
if($p.Release($true,$true) -or !$p.Release($true,$false) -or $p.Release($true,$false)){throw 'Grip press/release did not throw exactly once'}
$p.Release($true,$true)|Out-Null;$p.Release($false,$true)|Out-Null;if($p.Release($true,$false)){throw 'Tracking/menu loss generated throw'}
if([SignalisVrTracking.FlareThrowPolicy]::Speed(0) -ne 1.5 -or [SignalisVrTracking.FlareThrowPolicy]::Speed(25) -ne 8){throw 'Throw speed limits wrong'}
foreach($guard in @('maxNumber=3','RemoveItem(item)','flight.Burned.Contains','BeginEnemyFire(enemy)','PlayFireHit(fireHitPoint,enemy)','attack.WallMask','step=Math.Min(.02f','Room=global::PlayerState.currentRoom')){if(!$s.Contains($guard)){throw "Missing safety/integration $guard"}}
$q=Get-Content (Join-Path $PSScriptRoot 'QuickSelect.cs') -Raw
if(!$q.Contains('"SignalFlare"') -or !$q.Contains('id=="SignalFlare")&&!PrepareProdHand')){throw 'Flare wheel/holster integration missing'}
'PASS actual throw edge/fresh-grip/tracking-loss/speed bounds; six-second burn dispatch/capacity/consumption/wheel/source integration. Runtime throws and persistent burns unverified.'
