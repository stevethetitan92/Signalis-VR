using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly List<Texture2D> hdMeleeTextures=new List<Texture2D>();
  private readonly List<Mesh> hdProdMeshes=new List<Mesh>();
  private void LoadHdMelee(GameObject root,string geometry,string[] textures,float[] colors,List<MeshRenderer> parts,List<Material> materials,List<Mesh> meshes){
   int first=materials.Count;
   for(int i=0;i<textures.Length;i++){
    var shader=Shader.Find("Standard");if(shader==null)shader=Shader.Find(textures[i].Length>0?"Unlit/Texture":"Unlit/Color");
    if(shader==null)throw new InvalidOperationException("HD melee shader missing");
    var mat=new Material(shader);materials.Add(mat);
    if(textures[i].Length>0){var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);hdMeleeTextures.Add(tex);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(textures[i]),true))throw new InvalidDataException("HD melee texture");tex.filterMode=FilterMode.Bilinear;mat.mainTexture=tex;}
    else mat.color=new Color(colors[i*4],colors[i*4+1],colors[i*4+2],colors[i*4+3]);
   }
   using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(geometry)))){
    int count=r.ReadInt32();for(int k=0;k<count;k++){
     r.ReadInt32();int mi=r.ReadInt32(),nv=r.ReadInt32(),ni=r.ReadInt32();
     var v=new Vector3[nv];var uv=new Vector2[nv];var tri=new int[ni];
     for(int i=0;i<nv;i++)v[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
     for(int i=0;i<nv;i++)uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());
     for(int i=0;i<ni;i++)tri[i]=r.ReadInt32();
     var mesh=new Mesh();meshes.Add(mesh);mesh.vertices=v;mesh.uv=uv;mesh.triangles=tri;mesh.RecalculateNormals();mesh.triangles=HandSurfaceTopology.DoubleSided(tri);mesh.RecalculateBounds();
     parts.Add(CreateControllerPart(root,mesh,materials[first+mi],"HDMelee_"+k,Vector3.zero,Vector3.one));
    }
   }
  }
  private void DestroyHdMeleeTextures(){foreach(var t in hdMeleeTextures)if(t!=null)UnityEngine.Object.Destroy(t);hdMeleeTextures.Clear();}
 }
}
