$ErrorActionPreference='Stop'
foreach($name in 'HdProdData'){
 $s=Get-Content (Join-Path $PSScriptRoot ($name+'.cs')) -Raw
 $bytes=[Convert]::FromBase64String([regex]::Match($s,'Geometry="([^"]+)"').Groups[1].Value)
 $r=[IO.BinaryReader]::new([IO.MemoryStream]::new($bytes));$parts=$r.ReadInt32();$total=0;$lo=[double]::PositiveInfinity;$hi=[double]::NegativeInfinity
 for($p=0;$p -lt $parts;$p++){
  $role=$r.ReadInt32();$mat=$r.ReadInt32();$nv=$r.ReadInt32();$ni=$r.ReadInt32()
  if($nv -lt 3 -or $ni%3 -ne 0){throw 'Invalid HD topology'}
  for($i=0;$i -lt $nv;$i++){for($j=0;$j -lt 3;$j++){$v=$r.ReadSingle();if([float]::IsNaN($v) -or [float]::IsInfinity($v)){throw 'Nonfinite vertex'};if($j -eq 2){$lo=[Math]::Min($lo,$v);$hi=[Math]::Max($hi,$v)}}}
  for($i=0;$i -lt $nv*2;$i++){$v=$r.ReadSingle();if([float]::IsNaN($v)){throw 'Invalid UV'}}
  for($i=0;$i -lt $ni;$i++){$idx=$r.ReadInt32();if($idx -lt 0 -or $idx -ge $nv){throw 'Invalid triangle index'}}
  $total+=$nv
 }
 if($r.BaseStream.Position -ne $r.BaseStream.Length -or $hi-$lo -lt .2 -or $hi-$lo -gt .9){throw 'Invalid HD tool extent or unread geometry'}
 $r.Dispose();Write-Host "PASS $name : $parts parts, $total vertices; finite geometry, UVs, indices and metre extent"
}
