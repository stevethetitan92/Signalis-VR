using System;
using HarmonyLib;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static bool ManualNativeReloadGuard(){
   var q=weaponOwner;if(q==null||!q.manualReloadEnabled||!q.ProdVrMode())return true;
   var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null)return true;
   return false;
  }
  private static bool TimeForReload(int until){return until>=0&&UnityEngine.Time.frameCount<=until;}
  private static void ApplySmgStats(){var all=global::InventoryManager.allWeapons;if(all!=null&&all.ContainsKey(global::Items.itemlist.SMG))ConfigureSmg(all[global::Items.itemlist.SMG]);var equipped=global::InventoryManager.EquippedWeapon;if(equipped!=null&&equipped.parentItem!=null&&equipped.parentItem._item==global::Items.itemlist.SMG)ConfigureSmg(equipped);
   var q=weaponOwner;var a=global::PlayerAttack.instance;
   if(a!=null&&a.weapon!=null&&a.weapon.parentItem!=null&&a.weapon.parentItem._item==global::Items.itemlist.SMG)ConfigureSmg(a.weapon);
   if(q!=null&&q.ControllerWeaponReady()&&a!=null&&equipped!=null&&equipped.parentItem!=null&&equipped.parentItem._item==global::Items.itemlist.SMG&&a.aiming&&!q.ManualReloadBlocksAttack()&&(q.questFrame.buttons&(1<<6))!=0&&equipped.magAmmo>0){global::PlayerAttack.burst=1;
    // Native Update only advances automatic burst fire while this timer is positive.
    // Keep an already-started volley in that path; native burstSpeed still controls shots.
    if(a.timer>0)a.timer=Math.Max(a.timer,Math.Max(.02f,equipped.burstSpeed)+.05f);
   }
   else if(q!=null&&q.ProdVrMode()&&equipped!=null&&equipped.parentItem!=null&&equipped.parentItem._item==global::Items.itemlist.SMG)global::PlayerAttack.burst=0;
  }
  private static void ConfigureSmg(global::AnWeapon weapon){if(weapon==null)return;weapon.fullAuto=true;weapon.burstSize=1;weapon.MagSize=25;if(weapon.magAmmo>25)weapon.magAmmo=25;}
  private void InstallSmgStats(HarmonyLib.Harmony h){var prefix=new HarmonyMethod(typeof(Tracking),nameof(ApplySmgStats));foreach(string method in new[]{"Update","ReadyForAttack"})h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),method,Type.EmptyTypes),prefix:prefix);}
 }
}

