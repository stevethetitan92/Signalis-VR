using System;
using System.IO;
using System.Globalization;
namespace SignalisVrTracking {
 public sealed class ModSettingsFile {
  public bool FullBodyIk=true;
  public bool EnhancedResolutionMod=true,FlashlightMod=true;
  public bool Lasers=true,ManualReload,HudOn=true,HudRight=true,HudForearm,MiniMap,Inventory14Slots,InfiniteLife,InfiniteAmmo,InfiniteStunProd,AllWeapons,InstantKill,MapComplete;
  public int LaserColor,FlashlightPlacement;
  public float HudRightX,HudRightY,HudRightZ,HudLeftX,HudLeftY,HudLeftZ,HudForearmX,HudForearmY,HudForearmZ;
  public bool AlyxWheel;
  public string[] WheelSlots={"None","None","None","None"};
  public static ModSettingsFile Load(string path){
   var s=new ModSettingsFile();if(!File.Exists(path))return s;
   foreach(string line in File.ReadAllLines(path)){
    int split=line.IndexOf('=');if(split<0)continue;
    string key=line.Substring(0,split).Trim(),value=line.Substring(split+1).Trim();bool b;int n;
    if(key=="FlashlightPlacement"){if(int.TryParse(value,NumberStyles.Integer,CultureInfo.InvariantCulture,out n)&&n>=0&&n<3)s.FlashlightPlacement=n;continue;}
    if(key=="LaserColor"){if(int.TryParse(value,NumberStyles.Integer,CultureInfo.InvariantCulture,out n)&&n>=0&&n<5)s.LaserColor=n;continue;}
    if(key.StartsWith("WheelSlot",StringComparison.Ordinal)&&int.TryParse(key.Substring(9),out n)&&n>=0&&n<4){if(value.Length<40&&System.Text.RegularExpressions.Regex.IsMatch(value,"^[A-Za-z0-9]+$"))s.WheelSlots[n]=value;continue;}
    if(key=="HudRightX"||key=="HudRightY"||key=="HudRightZ"||key=="HudLeftX"||key=="HudLeftY"||key=="HudLeftZ"||key=="HudForearmX"||key=="HudForearmY"||key=="HudForearmZ"){
     float f;float limit=key.EndsWith("Z",StringComparison.Ordinal)?.2f:.25f;
     if(float.TryParse(value,NumberStyles.Float,CultureInfo.InvariantCulture,out f)&&!float.IsNaN(f)&&!float.IsInfinity(f)&&Math.Abs(f)<=limit){switch(key){case "HudRightX":s.HudRightX=f;break;case "HudRightY":s.HudRightY=f;break;case "HudRightZ":s.HudRightZ=f;break;case "HudLeftX":s.HudLeftX=f;break;case "HudLeftY":s.HudLeftY=f;break;case "HudLeftZ":s.HudLeftZ=f;break;case "HudForearmX":s.HudForearmX=f;break;case "HudForearmY":s.HudForearmY=f;break;case "HudForearmZ":s.HudForearmZ=f;break;}}continue;
    }
    if(!bool.TryParse(value,out b))continue;
    switch(key){case "EnhancedResolutionMod":s.EnhancedResolutionMod=b;break;case "FlashlightMod":s.FlashlightMod=b;break;case "MapComplete":s.MapComplete=b;break;case "FullBodyIk":s.FullBodyIk=b;break;case "AlyxWheel":s.AlyxWheel=b;break;case "Lasers":s.Lasers=b;break;case "ManualReload":s.ManualReload=b;break;case "HudOn":s.HudOn=b;break;case "HudRight":s.HudRight=b;break;case "HudForearm":s.HudForearm=b;break;case "MiniMap":s.MiniMap=b;break;case "AllWeapons":s.AllWeapons=b;break;case "InstantKill":s.InstantKill=b;break;case "InfiniteStunProd":s.InfiniteStunProd=b;break;case "InfiniteLife":s.InfiniteLife=b;break;case "InfiniteAmmo":s.InfiniteAmmo=b;break;case "Inventory14Slots":s.Inventory14Slots=b;break;}
   }return s;
  }
  public void Save(string path){
   if(LaserColor<0||LaserColor>=5)throw new InvalidDataException("Unknown laser color");
   if(FlashlightPlacement<0||FlashlightPlacement>=3)throw new InvalidDataException("Unknown flashlight placement");
   var offsets=new[]{HudRightX,HudRightY,HudRightZ,HudLeftX,HudLeftY,HudLeftZ,HudForearmX,HudForearmY,HudForearmZ};
   for(int i=0;i<offsets.Length;i++)if(float.IsNaN(offsets[i])||float.IsInfinity(offsets[i])||Math.Abs(offsets[i])>(i%3==2?.2f:.25f))throw new InvalidDataException("Invalid HUD position");
   Directory.CreateDirectory(Path.GetDirectoryName(path));
   string temp=path+".tmp";
   File.WriteAllLines(temp,new[]{"# SIGNALIS VR no-markers mod settings","FullBodyIk="+FullBodyIk,"EnhancedResolutionMod="+EnhancedResolutionMod,"FlashlightMod="+FlashlightMod,"FlashlightPlacement="+FlashlightPlacement.ToString(CultureInfo.InvariantCulture),"Lasers="+Lasers,"LaserColor="+LaserColor.ToString(CultureInfo.InvariantCulture),"ManualReload="+ManualReload,"HudOn="+HudOn,"HudRight="+HudRight,"HudForearm="+HudForearm,"MiniMap="+MiniMap,"Inventory14Slots="+Inventory14Slots,"InfiniteLife="+InfiniteLife,"InfiniteAmmo="+InfiniteAmmo,"InfiniteStunProd="+InfiniteStunProd,"AllWeapons="+AllWeapons,"InstantKill="+InstantKill,"MapComplete="+MapComplete,"AlyxWheel="+AlyxWheel,"WheelSlot0="+WheelSlots[0],"WheelSlot1="+WheelSlots[1],"WheelSlot2="+WheelSlots[2],"WheelSlot3="+WheelSlots[3]});
   string[] keys={"HudRightX","HudRightY","HudRightZ","HudLeftX","HudLeftY","HudLeftZ","HudForearmX","HudForearmY","HudForearmZ"};
   using(var writer=File.AppendText(temp))for(int i=0;i<keys.Length;i++)writer.WriteLine(keys[i]+"="+offsets[i].ToString("R",CultureInfo.InvariantCulture));
   if(File.Exists(path))File.Replace(temp,path,path+".bak");else File.Move(temp,path);
  }
 }
}



