using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class PistolCase {internal MeshRenderer Renderer;internal Vector3 Origin,Velocity;internal Quaternion Rotation;internal float Born=-100;}
 private readonly PistolCase[] pistolCases=new PistolCase[12];
 private Mesh pistolCaseMesh;private Material pistolCaseMaterial;private GameObject pistolCaseRoot;private int pistolCaseNext;private bool pistolCaseFailed;
 private bool flareCasePending;
 private void EjectFlareCase(){if(!flareCasePending)return;flareCasePending=false;EmitPistolCase(true);}
 private static class PistolCaseHook {
  internal static void Begin(out int __state){var q=weaponOwner;var w=global::InventoryManager.EquippedWeapon;__state=q!=null&&q.ControllerWeaponReady()&&w!=null&&w.parentItem!=null&&w.parentItem._item==global::Items.itemlist.Pistol?w.magAmmo:-1;}
  internal static void End(int __state){var w=global::InventoryManager.EquippedWeapon;if(weaponOwner!=null&&w!=null&&w.parentItem!=null&&w.parentItem._item==global::Items.itemlist.Pistol&&__state>0&&w.magAmmo<__state)weaponOwner.EmitPistolCase();}
 }
 private void InstallPistolCasings(HarmonyLib.Harmony h){var end=new HarmonyMethod(typeof(PistolCaseHook),nameof(PistolCaseHook.End));end.priority=HarmonyLib.Priority.First;h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"RaycastShot",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(PistolCaseHook),nameof(PistolCaseHook.Begin)),postfix:end);}
 private void EmitPistolCase(){
  EmitPistolCase(false);
 }
 private void EmitPistolCase(bool flare){
  if(pistolCaseFailed)return;
  try{
   if(pistolCaseRoot==null){
    pistolCaseRoot=new GameObject("SignalisVR_PistolCases");UnityEngine.Object.DontDestroyOnLoad(pistolCaseRoot);
    var vertices=new List<Vector3>();var triangles=new List<int>();Cartridge(vertices,triangles,new Vector3(0,0,-.0095f),new Vector3(0,0,.0095f),.0048f,.0048f);
    pistolCaseMesh=new Mesh();pistolCaseMesh.vertices=vertices.ToArray();pistolCaseMesh.triangles=triangles.ToArray();pistolCaseMesh.RecalculateNormals();pistolCaseMesh.RecalculateBounds();
    var shader=Shader.Find("Unlit/Color");if(shader==null)throw new InvalidOperationException("Case shader unavailable");pistolCaseMaterial=new Material(shader);pistolCaseMaterial.color=new Color(.65f,.43f,.12f);
    for(int i=0;i<pistolCases.Length;i++)pistolCases[i]=new PistolCase{Renderer=CreateControllerPart(pistolCaseRoot,pistolCaseMesh,pistolCaseMaterial,"Pistol brass case",Vector3.zero,Vector3.one*UnitsPerMetre)};
   }
   HidePistolCases();var c=pistolCases[pistolCaseNext++%pistolCases.Length];c.Born=Time.realtimeSinceStartup;
   c.Origin=rightWeaponPosition+rightWeaponRotation*(HdPistolData.MagazineTop+new Vector3(.012f,.006f,.015f))*UnitsPerMetre;
   c.Velocity=rightWeaponRotation*new Vector3(1.1f,.55f,.12f)*UnitsPerMetre;c.Rotation=rightWeaponRotation;
   c.Renderer.transform.localScale=(flare?new Vector3(2.7f,2.7f,3.1f):Vector3.one)*UnitsPerMetre;
   c.Renderer.GetComponent<MeshFilter>().sharedMesh=pistolCaseMesh;c.Renderer.sharedMaterial=pistolCaseMaterial;
   if(flare){var round=GetHdRound("FlareGun");c.Renderer.GetComponent<MeshFilter>().sharedMesh=round.Mesh;c.Renderer.sharedMaterials=round.Materials;c.Renderer.transform.localScale=Vector3.one*UnitsPerMetre;c.Origin=additionalChamber;c.Velocity=-additionalLoadDirection*.7f*UnitsPerMetre;c.Rotation=Quaternion.FromToRotation(Vector3.up,additionalLoadDirection);}
  }catch(Exception e){pistolCaseFailed=true;HidePistolCases();MelonLoader.MelonLogger.Warning("Pistol casing visuals disabled: "+e.Message);}
 }
 private void ShowPistolCases(){foreach(var c in pistolCases){if(c==null||c.Renderer==null)continue;float age=Time.realtimeSinceStartup-c.Born;if(age<0||age>1.5f)continue;c.Renderer.transform.SetPositionAndRotation(c.Origin+c.Velocity*age+controllerTrackingToWorld*Vector3.down*(4.905f*age*age*UnitsPerMetre),c.Rotation*Quaternion.Euler(age*430,age*210,age*170));c.Renderer.enabled=true;}}
 private void HidePistolCases(){foreach(var c in pistolCases)if(c!=null&&c.Renderer!=null)c.Renderer.enabled=false;}
 private void DestroyPistolCases(){if(pistolCaseRoot!=null)UnityEngine.Object.Destroy(pistolCaseRoot);if(pistolCaseMesh!=null)UnityEngine.Object.Destroy(pistolCaseMesh);if(pistolCaseMaterial!=null)UnityEngine.Object.Destroy(pistolCaseMaterial);pistolCaseRoot=null;pistolCaseMesh=null;pistolCaseMaterial=null;Array.Clear(pistolCases,0,pistolCases.Length);pistolCaseNext=0;pistolCaseFailed=false;}
}}


