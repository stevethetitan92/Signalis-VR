$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'RoomMapProjection.cs')
foreach($mirror in @(-1,1)) {
 $p=[SignalisVrTracking.RoomMapProjection]::new()
 $points=New-Object 'double[,]' 4,4
 $i=0
 foreach($pair in @(@(-5,0),@(5,0),@(0,8),@(0,-8))) {
  $x=$pair[0]+1000;$z=$pair[1]-2000
  $points[$i,0]=$x;$points[$i,1]=$z;$points[$i,2]=2*$x+.3*$z+7;$points[$i,3]=$mirror*(-.2*$x+4*$z)-8;$i++
 }
 if(-not $p.Fit($points)){throw 'Noncollinear fit failed'}
 foreach($pair in @(@(1000,-2000),@(1002,-1997),@(995,-2000),@(1005,-2000))) {
  [double]$u=0;[double]$v=0;$p.Point($pair[0],$pair[1],[ref]$u,[ref]$v)
  if([Math]::Abs($u-(2*$pair[0]+.3*$pair[1]+7)) -gt 0.00001 -or [Math]::Abs($v-($mirror*(-.2*$pair[0]+4*$pair[1])-8)) -gt .00001){throw 'Position/door/heading transform wrong'}
 }
}
$p=[SignalisVrTracking.RoomMapProjection]::new();$line=New-Object 'double[,]' 3,4
for($i=0;$i -lt 3;$i++){$line[$i,0]=$i;$line[$i,1]=$i;$line[$i,2]=$i;$line[$i,3]=$i}
if($p.Fit($line)){throw 'Collinear anchors accepted'}
'PASS affine mapping: reflected axes, unequal scales, translated rooms, doorway anchors, interior points and collinear rejection. Runtime mapping unverified.'
