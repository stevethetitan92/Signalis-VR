using System;
using System.Reflection;
using HarmonyLib;
using MelonLoader;
namespace SignalisVrTracking {
 internal static class MarkerLifecycle {
  private static HarmonyLib.Harmony hooks;
  private static bool callbackFailed;
  internal static void Install() {
   if(hooks!=null)return;
   try {
    hooks=new HarmonyLib.Harmony("signalis.vr.marker.registry");
    Patch(typeof(global::DoorInteractionPopup),"OnEnable",nameof(DoorReady));
    Patch(typeof(global::DoorInteractionPopup),"Update",nameof(DoorReady));
    Patch(typeof(global::Ladder),"OnEnable",nameof(LadderReady));
    Patch(typeof(global::Ladder),"Update",nameof(LadderReady));
    MarkerSuppression.EnableRegistry(true);
    MelonLogger.Msg("MARKER REGISTRY: lifecycle registration active; full fallback discovery every 1s, hierarchy checks every frame.");
   }catch(Exception ex) {
    MarkerSuppression.EnableRegistry(false);
    // Partially installed registration callbacks are harmless with full-scan fallback.
    MelonLogger.Warning("MARKER REGISTRY: retaining per-frame discovery: "+ex.Message);
   }
  }
  private static void Patch(Type type,string method,string callback) {
   var target=AccessTools.DeclaredMethod(type,method,Type.EmptyTypes);
   if(target==null)throw new MissingMethodException(type.FullName,method);
   hooks.Patch(target,postfix:new HarmonyMethod(typeof(MarkerLifecycle),callback));
  }
  private static void DoorReady(global::DoorInteractionPopup __instance) {
   try {MarkerSuppression.RegisterDoor(__instance);}catch(Exception ex) {Fallback(ex);}
  }
  private static void LadderReady(global::Ladder __instance) {
   try {MarkerSuppression.RegisterLadder(__instance);}catch(Exception ex) {Fallback(ex);}
  }
  private static void Fallback(Exception ex) {
   MarkerSuppression.EnableRegistry(false);
   if(!callbackFailed)MelonLogger.Warning("MARKER REGISTRY: callback failed; per-frame discovery restored: "+ex.Message);
   callbackFailed=true;
  }
 }
}
