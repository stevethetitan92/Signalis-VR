$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'ElsterPlayer.cs') -Raw
$policy=$source.Substring($source.IndexOf(' internal static class ElsterPosePolicy'),$source.IndexOf(' public sealed partial class Tracking')-$source.IndexOf(' internal static class ElsterPosePolicy'))
Add-Type -TypeDefinition ('using System;namespace SignalisVrTracking {'+$policy+@'
public static class ElsterTests {
 public static string Run(){
  int n=0;
  foreach(float upper in new[]{.22f,.3f,.38f})foreach(float lower in new[]{.2f,.27f,.35f})foreach(float d in new[]{0f,.001f,.1f,.3f,.5f,.7f,1.2f}){
   float a,h;ElsterPosePolicy.Elbow(upper,lower,d,out a,out h);
   if(float.IsNaN(a)||float.IsInfinity(a)||float.IsNaN(h)||h<0)throw new Exception("Nonfinite elbow");
   if(Math.Abs(a*a+h*h-upper*upper)>.0001f)throw new Exception("Upper arm length changed");
   float clamp=Math.Max(.0001f,Math.Min(upper+lower-.0001f,Math.Max(Math.Abs(upper-lower)+.0001f,d)));
   if(Math.Abs((clamp-a)*(clamp-a)+h*h-lower*lower)>.0001f)throw new Exception("Forearm length changed");n++;
  }
  bool rejected=false;try{float a,h;ElsterPosePolicy.Elbow(.3f,.3f,float.NaN,out a,out h);}catch(ArgumentException){rejected=true;}if(!rejected)throw new Exception("Invalid tracking accepted");
  return "PASS: "+n+" arm reach cases including folded, equal/unequal segments, unreachable and invalid tracking. Runtime visual fit not established.";
 }
}}
'@)
[SignalisVrTracking.ElsterTests]::Run()
if($source.Contains('AddComponent<Rigidbody>') -or $source.Contains('AddComponent<Collider>')){throw 'Avatar must not change gameplay collision'}
if(!$source.Contains('HideElsterPlayer();DestroyElsterPlayer();HideLegacyHandVisuals();elsterFailed=true')){throw 'Missing legacy-hand suppression on failure'}
'PASS: visual-only avatar guard and failure restoration'
