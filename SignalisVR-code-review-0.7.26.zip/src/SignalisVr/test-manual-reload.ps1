$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ManualReloadPolicy.cs')
function Check($v,$m){if(-not $v){throw $m}}
$p=[SignalisVrTracking.ManualReloadPolicy]::new()
$p.PressB(0,$false,$true)|Out-Null
Check ($p.Stage.ToString() -eq 'Ejected') 'B did not eject'
$p.Tick(.1,$true,$true,$false,$false,$false,0)|Out-Null
Check ($p.Stage.ToString() -eq 'Ejected') 'Grab outside pouch'
$p.Tick(.2,$true,$false,$true,$false,$false,0)|Out-Null
$p.Tick(.3,$true,$true,$true,$false,$false,0)|Out-Null
Check ($p.Stage.ToString() -eq 'Holding') 'No magazine grab'
$p.Tick(.4,$true,$true,$false,$true,$false,0)|Out-Null
Check ($p.Stage.ToString() -eq 'Holding') 'Insertion skipped dwell'
$p.Tick(.6,$true,$true,$false,$true,$false,0)|Out-Null
Check ($p.Stage.ToString() -eq 'Inserted') 'No insertion'
Check (-not $p.PressB(.7,$true,$true)) 'B racked'
Check ($p.Stage.ToString() -eq 'Inserted') 'B changed inserted stage'
$p.Tick(.8,$true,$true,$false,$false,$false,0)|Out-Null
Check ($p.Stage.ToString() -eq 'Inserted') 'Rack grip outside slide'
$p.Tick(.9,$true,$true,$false,$false,$true,1)|Out-Null
Check ($p.Stage.ToString() -eq 'RackHolding') 'Slide not grabbed'
Check (-not $p.Tick(1,$true,$false,$false,$false,$true,1.005)) 'Release without pull racked'
Check ($p.Stage.ToString() -eq 'Inserted') 'Short pull cannot retry'
$p.Tick(1.1,$true,$true,$false,$false,$true,1)|Out-Null
Check (-not $p.Tick(1.2,$true,$true,$false,$false,$true,.97)) 'Forward push racked'
Check ($p.RackPull -eq 0) 'Forward push counted as backward'
$p.Tick(1.3,$true,$true,$false,$false,$true,1.03)|Out-Null
Check ($p.Stage.ToString() -eq 'RackHolding') 'Pull without release committed'
Check ($p.Tick(1.4,$true,$false,$false,$false,$true,1.025)) 'Pull-release did not rack'
Check ($p.Stage.ToString() -eq 'AwaitingGame') 'Not waiting for native acknowledgement'
Check (-not $p.Tick(1.5,$true,$false,$false,$false,$true,1.03)) 'Repeated release duplicated request'
Check (-not $p.ObserveGame(1.6,$true,$false)) 'Completed during native reload'
Check ($p.ObserveGame(2,$false,$true)) 'Native completion missed'
# Pre-held grip cannot spawn magazine and interruption cancels all stages.
$p.PressB(3,$true,$true)|Out-Null
$p.Tick(3.1,$true,$true,$true,$false,$false,0)|Out-Null
Check ($p.Stage.ToString() -eq 'Ejected') 'Pre-held grip grabbed magazine'
$p.Tick(3.2,$false,$true,$true,$true,$true,1)|Out-Null
Check (-not $p.Active) 'Interruption failed'
$p.PressB(4,$false,$true)|Out-Null
$p.Tick(4.1,$true,$true,$true,$false,$false,0)|Out-Null
$p.Tick(4.2,$true,$true,$false,$true,$false,0)|Out-Null
$p.Tick(4.4,$true,$true,$false,$true,$false,0)|Out-Null
$p.Tick(4.5,$true,$true,$false,$false,$true,0)|Out-Null
$p.Tick(4.6,$true,$true,$false,$false,$true,.03)|Out-Null
$p.Tick(4.7,$true,$false,$false,$false,$true,.03)|Out-Null
Check (-not $p.ObserveGame(8,$false,$false)) 'Refused native reload reported success'
Check ($p.Stage.ToString() -eq 'Inserted') 'Refused reload did not permit grip retry'
# Releasing during insertion dwell must drop, even if the tip is still in well.
$p.Cancel()
$p.PressB(10,$false,$true)|Out-Null
$p.Tick(10.1,$true,$true,$true,$false)|Out-Null
$p.Tick(10.2,$true,$true,$false,$true)|Out-Null
$p.Tick(10.4,$true,$false,$false,$true)|Out-Null
Check ($p.Stage.ToString() -eq 'Ejected') 'Released magazine inserted instead of dropping'
$p.Tick(10.5,$true,$false,$true,$true)|Out-Null
Check ($p.Stage.ToString() -eq 'Ejected') 'Released grip respawned magazine'
$p.Tick(10.6,$true,$true,$true,$false)|Out-Null
Check ($p.Stage.ToString() -eq 'Holding') 'Fresh held grip cannot reacquire dropped magazine'
$p.Tick(10.7,$true,$false,$false,$false)|Out-Null
Check ($p.Stage.ToString() -eq 'Ejected') 'Release outside well did not drop'
'PASS B eject only; held-grip magazine/drop including release inside well; insertion dwell; slide contact; minimum rearward pull; release-only commit; acknowledgement/refusal and interruption. Runtime fit unverified.'
$p.Cancel();$p.PressB(20,$false,$true,$false)|Out-Null
Check (-not $p.RequiresRack) 'Partial reload lost chambered round'
$p.Tick(20.1,$true,$true,$true,$false)|Out-Null
$p.Tick(20.2,$true,$true,$false,$true)|Out-Null
Check ($p.Tick(20.4,$true,$true,$false,$true)) 'Partial insertion did not request reload'
Check ($p.Stage -eq 'AwaitingGame') 'Partial reload requires slide'
Check (-not $p.Tick(20.5,$true,$true,$false,$true)) 'Partial insertion duplicated transfer'
Check ($p.ObserveGame(20.6,$false,$true)) 'Partial native completion missed'
$p.PressB(21,$false,$true,$true)|Out-Null
Check ($p.RequiresRack) 'Empty reload reused chambered state'
$p.Tick(21.1,$true,$true,$true,$false)|Out-Null
$p.Tick(21.2,$true,$true,$false,$true)|Out-Null
Check (-not $p.Tick(21.4,$true,$true,$false,$true)) 'Empty insertion bypassed slide'
$p.Tick(21.5,$true,$true,$false,$false,$true,0)|Out-Null
$p.Tick(21.6,$true,$true,$false,$false,$true,.03)|Out-Null
$p.Tick(21.7,$true,$true,$false,$false,$true,.01)|Out-Null
Check ([Math]::Abs($p.RackPull-.01) -lt .0001) 'Slide did not follow forward hand motion'
Check ($p.Tick(21.8,$true,$false,$false,$false,$true,.01)) 'Valid pull then release lost stroke'
'PASS chambered topoff versus empty reload, single transfer, reset and hand-following slide'
