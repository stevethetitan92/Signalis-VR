$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'SceneRecovery.cs') -Raw
$s=$s.Replace("`r`n","`n")
$start=$s.IndexOf('  private void RestoreRedPitCamera()')
$end=$s.IndexOf("`n }`n}", $start)
$method=$s.Substring($start,$end-$start).Replace('private void RestoreRedPitCamera','public void RestoreRedPitCamera')
$stub=@'
using System;
class Transform {public string name; public Transform parent;public int localPosition,localRotation,localScale;public void SetParent(Transform p,bool keep){parent=p;}}
class Control {public bool enabled;}
class Camera {public Transform transform=new Transform();public bool orthographic,enabled=false;public float fieldOfView,orthographicSize;}
static class MelonLogger {public static void Msg(string s){}}
public class RestoreTest {
Camera redPitNativeCamera;Transform redPitNativeParent;Control redPitNativeControl;Camera redPitUiCamera;bool redPitControlEnabled=true,redPitUiOrtho=true;
int redPitNativePosition=7,redPitNativeRotation=8,redPitNativeScale=9;
bool redPitNativeOrtho=true;float redPitNativeFov=40,redPitNativeSize=6;
'@
$tail=@'
public static void Test(){
var q=new RestoreTest();var rig=new Transform{name="LocalSpace"};var c=new Camera();c.transform.parent=new Transform{name="Character Root"};q.redPitNativeCamera=c;q.redPitNativeParent=rig;
var control=new Control();var ui=new Camera();q.redPitNativeControl=control;q.redPitUiCamera=ui;
q.RestoreRedPitCamera();
if(!control.enabled||!ui.orthographic)throw new Exception("native component restoration");
if(c.transform.parent!=rig||c.transform.localPosition!=7||c.transform.localRotation!=8||c.transform.localScale!=9||!c.orthographic||c.fieldOfView!=40||c.orthographicSize!=6||c.enabled)throw new Exception("restoration or native enable state");
if(q.redPitNativeCamera!=null||q.redPitNativeParent!=null)throw new Exception("snapshot retained");
q.RestoreRedPitCamera();
var native=new Transform{name="TunnelCameraOwner"};c.transform.parent=native;q.redPitNativeCamera=c;q.redPitNativeParent=rig;q.RestoreRedPitCamera();if(c.transform.parent!=native)throw new Exception("native reparent overwritten");
q.redPitNativeCamera=c;q.redPitNativeParent=null;q.RestoreRedPitCamera();if(c.transform.parent!=native)throw new Exception("destroyed parent");
}}
'@
Add-Type ($stub+$method+$tail)
[RestoreTest]::Test()
'PASS extracted restoration: parent/local pose/projection restored, disabled state preserved, native ownership respected, repeated/null cleanup safe. Unity runtime unverified.'
