$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'HeldTriggerMotion.cs') -Raw
$start=$s.IndexOf(' public static class TriggerMotion');$end=$s.IndexOf(' public sealed partial class Tracking')
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$s.Substring($start,$end-$start)+'}')
$t=[SignalisVrTracking.TriggerMotion]
foreach($hz in @(30,72,90,120,144)){
 for($frame=0;$frame -lt $hz*10;$frame++){if($t::Pressure(1,$true) -ne 1){throw 'Held automatic trigger released itself'}}
 if($t::Pressure(0,$true) -ne 0){throw 'Release did not reset'}
}
foreach($v in @([float]::NaN,[float]::PositiveInfinity,-1)){if($t::Pressure($v,$true) -ne 0){throw 'Invalid pressure accepted'}}
if($t::Pressure(.5,$true) -ne .5 -or $t::Pressure(1,$false) -ne 0){throw 'Analog pressure or gate failed'}
foreach($name in @('SmgRight','PistolRight')){
 $raw=Get-Content (Join-Path $PSScriptRoot 'ApprovedGunPoseData.cs') -Raw
 $b=[Convert]::FromBase64String([regex]::Match($raw,($name+'="([^"]+)"')).Groups[1].Value)
 $nv=[BitConverter]::ToInt32($b,0)
 $agl=Get-Content (Join-Path $PSScriptRoot 'AglModelData.cs') -Raw
 $w=[Convert]::FromBase64String([regex]::Match($agl,'IndexWeights="([^"]+)"').Groups[1].Value)
 if($w.Length -ne $nv*4){throw 'Index pose topology differs'}
 for($i=0;$i -lt $nv;$i++){$f=[BitConverter]::ToSingle($w,4*$i);if($f -lt 0 -or $f -gt 1){throw 'Invalid finger weight'}}
}
'PASS ten-second held trigger at 30-144 Hz, release, blocked/invalid input, analog pressure and approved index topology. Headset motion not verified.'
