$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'TestMenuActions.cs') -Raw
$start=$s.IndexOf('  private void PollTestEnemy()');$end=$s.IndexOf('  private void DestroyTestEnemy()', $start)
$poll=$s.Substring($start,$end-$start)
$fixture=@"
using System;using System.Collections.Generic;using MelonLoader;using UnityEngine;
public static class Mathf {public static float Clamp01(float f){return Math.Max(0,Math.Min(1,f));}}
namespace UnityEngine {public static class Time {public static float time;}public struct Color {public float a;public Color(float r,float g,float b,float alpha){a=alpha;}}public class Shader {public static Shader Find(string s){return new Shader();}} public class Material {public Shader shader;public Color color;}}
namespace MelonLoader {public static class MelonLogger {public static void Warning(string s){throw new Exception(s);}}}
public class Room {} public static class PlayerState {public static Room currentRoom;}
public class Hitbox {public float HP=100;}
public class Animator {public void SetBool(int key,bool value){}}
public class EnemyController {public Animator animator=new Animator();public int anim_Hurt,anim_Dead;public enum enemystate {pursuit,dead}public enemystate state;public Hitbox hitbox=new Hitbox();public float oldHP=100;public int kills,hurt;public void Kill(){kills++;state=enemystate.dead;}public void TakeDamage(){hurt++;}}
namespace SignalisVrTracking {public class Tracking {
object calibrationRoot=new object();EnemyController testEnemy;Room testEnemyRoom;float testEnemyDeathTime=-1,testEnemyRetry;int spawns,updates;bool ready=true;
List<UnityEngine.Material> testBodyMaterials=new List<UnityEngine.Material>{new UnityEngine.Material()};
void PollCalibrationRoom(){}void LeaveCalibrationRoom(bool restore){calibrationRoot=null;}bool CheatPlayerReady(){return ready;}
void SpawnTestEnemy(){spawns++;testEnemy=new EnemyController();testEnemyRoom=PlayerState.currentRoom;testEnemyDeathTime=-1;}
void DestroyTestEnemy(){testEnemy=null;testEnemyDeathTime=-1;}void HoldTestEnemyStill(){}void UpdateTestBodyCopies(){updates++;}
using_placeholder
public static void Test(){
var q=new Tracking();PlayerState.currentRoom=new Room();UnityEngine.Time.time=0;q.PollTestEnemy();if(q.spawns!=1)throw new Exception("Missing automatic spawn");
q.testEnemy.hitbox.HP=75;q.PollTestEnemy();q.PollTestEnemy();if(q.testEnemy.hurt!=1)throw new Exception("Damage observation repeats or is missing");
var dead=q.testEnemy;dead.hitbox.HP=0;q.PollTestEnemy();
foreach(float t in new[]{.1f,1f,2.25f,2.5f,2.99f}){UnityEngine.Time.time=t;q.PollTestEnemy();if(q.testEnemy!=dead||dead.kills!=1)throw new Exception("Death destroyed early or replayed");}
if(q.testBodyMaterials[0].color.a>=.1f||q.testBodyMaterials[0].color.a<=0)throw new Exception("Missing end-of-life fade");
UnityEngine.Time.time=3;q.PollTestEnemy();if(q.spawns!=2||q.testEnemy==dead||q.testEnemy.hitbox.HP!=100)throw new Exception("Respawn failed");
q.calibrationRoot=null;q.testEnemy.hitbox.HP=0;q.PollTestEnemy();UnityEngine.Time.time=6;q.PollTestEnemy();if(q.testEnemy!=null||q.spawns!=2)throw new Exception("Outside-room automatic respawn");
q.calibrationRoot=new object();UnityEngine.Time.time=7;q.PollTestEnemy();PlayerState.currentRoom=new Room();q.PollTestEnemy();if(q.testEnemy!=null)throw new Exception("Target survived room transition");
}
}}
"@
$fixture=$fixture.Replace('using_placeholder',$poll.Replace('Time.time','UnityEngine.Time.time').Replace('new Color(','new UnityEngine.Color('))
Add-Type -TypeDefinition $fixture -IgnoreWarnings -WarningAction SilentlyContinue
[SignalisVrTracking.Tracking]::Test()
$thermite=Get-Content (Join-Path $PSScriptRoot 'ThrowableThermite.cs') -Raw
$physics=Get-Content (Join-Path $PSScriptRoot 'ThermitePhysics.cs') -Raw
if(!$thermite.Contains('Expires=Time.time+6f') -or $thermite.Contains('Landed=true') -or !$physics.Contains('ComputePenetration') -or !$physics.Contains('BoxCastAll')){throw 'Flare lifetime/rotation collision integration missing'}
'PASS actual calibration target polling: single hurt, death once, retained animation window, fade, three-second respawn, outside-room cleanup; thermite collision/lifetime integration. Live physics and animations unverified.'

