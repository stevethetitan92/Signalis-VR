$ErrorActionPreference='Stop'
$s=Get-Content "$PSScriptRoot/SceneRecovery.cs" -Raw
$a=$s.IndexOf('  private void UpdateSceneRecovery()')
$b=$s.IndexOf('  // A hidden perspective camera',$a)
$method=$s.Substring($a,$b-$a)
$stub=@'
#pragma warning disable 0649,0414
using System;
static class MelonLogger {public static void Msg(string s){}}
static class Time {public static float realtimeSinceStartup;}
class Scene {public string name="Bathroom";}
static class SceneManager {public static Scene scene=new Scene();public static Scene GetActiveScene(){return scene;}}
static class PlayerState {public static int gameState;public static bool cutscene;}
class Transform {public Transform parent;public string name="Character Root";public int localRotation;}
class Camera {public static Camera[] allCameras=new Camera[0];public string name="Main Camera";public bool orthographic;public Camera targetTexture;public Transform transform=new Transform{parent=new Transform()};public int id=1;public int GetInstanceID(){return id;}}
class Recovery {public void Reset(){}}
class Diagnostic {public bool CanSubmit;public void Connected(){}public void RenderReady(){}public bool BeginSubmit(float t){CanSubmit=true;return true;}}
public class Handoff {
 bool immersiveRequested=true,questMenuScene=true,sceneRecoveryDraining,sceneRecoveryInstalled=true,sceneRecoveryRequest,bridgeConfigured=true,snowWalkStereo,waitingForGameplay,menuCaptureReady,recenterPending;
 float nextSnowReport,sceneStableSince=-1,nextSceneRecovery;int sceneCandidateId,sceneRecoveryAttempts,originalRotation,diagnosticFrames;
 Camera camera,candidate=new Camera();Recovery recovery=new Recovery();Diagnostic diagnostic=new Diagnostic();bool eligible=true,needs=true;int bridge=2;
 Camera RedPitEntryView(){return null;}
 bool CanRecoverScene(){return eligible;}Camera FindSnowWalkCamera(){return SceneManager.scene.name=="PEN_Hole"?candidate:null;}Camera FindGameplayCamera(){return candidate;}bool NeedsScenePerspective(){return needs;}bool IsSnowWalkCamera(Camera c){return SceneManager.scene.name=="PEN_Hole";}void CenterSnowEntry(Camera c){}int CancelPreparedPose(){if(bridge==2)return 0;bridge=1;return 1;}
'@
$tail=@'
 public static void Test(){
 foreach(string scene in new[]{"PEN_Hole","RedPit","Bathroom"}){SceneManager.scene.name=scene;Time.realtimeSinceStartup=0;var t=new Handoff();t.UpdateSceneRecovery();if(t.sceneRecoveryDraining||!t.questMenuScene)throw new Exception("camera switched before stabilization");Time.realtimeSinceStartup=.26f;t.UpdateSceneRecovery();if(!t.sceneRecoveryDraining||!t.questMenuScene)throw new Exception("pending callback not drained");t.bridge=5;t.UpdateSceneRecovery();if(t.sceneRecoveryDraining||t.questMenuScene||!t.diagnostic.CanSubmit)throw new Exception("handoff did not finish");}
 Time.realtimeSinceStartup=0;var q=new Handoff();q.UpdateSceneRecovery();Time.realtimeSinceStartup=.26f;q.UpdateSceneRecovery();q.candidate.id=2;q.bridge=5;q.UpdateSceneRecovery();if(!q.questMenuScene||q.sceneRecoveryDraining)throw new Exception("replacement skipped stabilization");q.eligible=false;q.UpdateSceneRecovery();if(q.sceneRecoveryDraining)throw new Exception("cutscene held drain");
 q=new Handoff();q.candidate=null;q.needs=false;q.UpdateSceneRecovery();if(q.sceneRecoveryRequest)throw new Exception("hidden converted camera toggled");q.needs=true;for(int i=0;i<6;i++){Time.realtimeSinceStartup=i*4;q.UpdateSceneRecovery();}if(q.sceneRecoveryAttempts!=6)throw new Exception("retry stopped at three");
 }
}
'@
Add-Type ($stub+$method+$tail)
[Handoff]::Test()
$main=Get-Content "$PSScriptRoot/SignalisVrTracking.cs" -Raw
$menu=Get-Content "$PSScriptRoot/QuestMenuScene.cs" -Raw
if($main -notmatch 'if \(sceneRecoveryDraining \|\| !active' -or $menu -notmatch 'if\(sceneRecoveryDraining\)return;'){throw 'Queue/render drain guard missing'}
'PASS production recovery method: pending callback then stereo handoff, eligibility loss releases drain, hidden converted camera not toggled, retry beyond three; queue/render guards present. Simulated bridge, not headset verification.'

