$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'SprintTogglePolicy.cs')
$p=[SignalisVrTracking.SprintTogglePolicy]::new()
if($p.Update($true,$true,$false)){throw 'Toggled before release/chord resolution'}
if(-not $p.Update($true,$false,$false)){throw 'First click did not start sprint'}
if(-not $p.Update($true,$false,$false)){throw 'Sprint was not latched'}
$p.Update($true,$true,$false)|Out-Null
if($p.Update($true,$false,$false)){throw 'Second click did not stop'}
$p.Update($true,$true,$false)|Out-Null
$p.Update($true,$true,$true)|Out-Null
if($p.Update($true,$false,$false)){throw 'Staggered menu chord toggled sprint'}
$p.Update($true,$true,$true)|Out-Null
if($p.Update($true,$false,$false)){throw 'Simultaneous chord toggled sprint'}
$p.Update($true,$true,$false)|Out-Null
$p.Update($true,$false,$false)|Out-Null
if($p.Update($false,$true,$false)){throw 'Ineligible sprint stuck'}
if($p.Update($true,$false,$false)){throw 'Release after interruption toggled'}
'PASS click toggles, hold persistence, chord priority and interruption reset; physical headset input remains unverified.'
