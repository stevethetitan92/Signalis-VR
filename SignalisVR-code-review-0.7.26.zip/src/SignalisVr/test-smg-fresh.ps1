$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'SmgHandleStroke.cs'),(Join-Path $PSScriptRoot 'ManualReloadPolicy.cs')
foreach($hz in @(30,72,90,120)){
 foreach($approach in @(0,.02,.08)){
  foreach($distance in @(0,.003,.015,.03)){
   $s=[SignalisVrTracking.SmgHandleStroke]::new()
   if($s.Sample($true,$true,$true,.1) -or $s.Held){throw 'Required release bypassed'}
   $s.Sample($true,$true,$false,.1)|Out-Null;$s.Sample($true,$true,$true,.1)|Out-Null
   if(!$s.Held){throw 'Grab missed'}
   for($i=1;$i -le $hz;$i++){$s.Sample($true,$true,$true,.1+$approach*$i/$hz)|Out-Null}
   for($i=1;$i -le $hz;$i++){$s.Sample($true,$false,$true,.1+$approach-$distance*$i/$hz)|Out-Null}
   for($i=1;$i -le $hz;$i++){$s.Sample($true,$false,$true,.1+$approach-$distance*(1-$i/$hz))|Out-Null}
   if($s.Sample($true,$false,$false,.1+$approach) -ne ($distance -ge .006)){throw 'Stroke/return acceptance failed'}
   if($s.Sample($true,$false,$false,.1+$approach)){throw 'Duplicate completion'}
  }
 }
}
foreach($bad in @([float]::NaN,[float]::PositiveInfinity,1)){
 $s=[SignalisVrTracking.SmgHandleStroke]::new();$s.Sample($true,$true,$false,.1)|Out-Null;$s.Sample($true,$true,$true,.1)|Out-Null
 if($s.Sample($true,$true,$true,$bad) -or $s.Held){throw 'Tracking loss retained grab'}
 if($s.Sample($true,$true,$false,.1)){throw 'Tracking loss committed reload'}
}
$p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.PressB(0,$false,$true,$true)|Out-Null;$p.Tick(.1,$true,$true,$true,$false)|Out-Null;$p.Seat(.2)|Out-Null
$p.BeginRack(0);$p.PresentExternalRack(.03,.03);$p.FinishExternalRack($true,.3)
if($p.Stage -ne 'AwaitingGame' -or [Math]::Abs($p.RackPull-.03) -gt .0001){throw 'External completion bridge lost stroke'}
$p.Cancel();if($p.Active){throw 'Commit cleanup failed'}
$source=Get-Content (Join-Path $PSScriptRoot 'AdditionalGunReload.cs') -Raw
if($source.Contains('smgGripTravel') -or !$source.Contains('old!=ManualReloadPolicy.Step.RackHolding&&smgReload.Tick')){throw 'Legacy SMG detector still drives stroke'}
'PASS independent SMG detector:48 approach/pull/return sequences at30/72/90/120Hz; required release, latched grab, one completion, tracking loss/jump cancellation, policy commit bridge; no legacy rack Tick.'
