param([Parameter(Mandatory=$true)][string]$GamePath)
$ErrorActionPreference = 'Stop'
# Local development only: installed files are read-only backup sources.
$workspace = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
if (-not (Test-Path (Join-Path $workspace 'outputs/SignalisVrNoMarkersDevelopmentLog.md'))) {
    throw 'Backup script must run from a build folder in this development workspace.'
}
$source = Join-Path $GamePath 'Mods/SignalisVrTracking.dll'
if (-not (Test-Path -LiteralPath $source)) {
    Write-Output 'No installed tracking DLL to back up.'
    return
}
$hash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$destination = Join-Path $workspace (Join-Path 'backups/installed-tracking' $hash)
$copy = Join-Path $destination 'SignalisVrTracking.dll'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
if (-not (Test-Path -LiteralPath $copy)) {
    Copy-Item -LiteralPath $source -Destination $copy -ErrorAction Stop
}
if ((Get-FileHash -LiteralPath $copy -Algorithm SHA256).Hash -ne $hash) {
    throw 'Backup verification failed; existing backup was not overwritten.'
}
$manifest = Join-Path $destination 'backup.json'
if (-not (Test-Path -LiteralPath $manifest)) {
    [ordered]@{
        savedAtUtc = [DateTime]::UtcNow.ToString('o')
        source = $source
        sha256 = $hash
        size = (Get-Item -LiteralPath $copy).Length
        scope = 'Tracking DLL only; native dependencies unchanged. Restore manually with game closed.'
    } | ConvertTo-Json | Set-Content -LiteralPath $manifest
}
Write-Output "Verified installed-DLL backup: $copy"
