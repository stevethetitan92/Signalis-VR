$ErrorActionPreference='Stop'
Add-Type -Path @((Join-Path $PSScriptRoot 'MovementMath.cs'),(Join-Path $PSScriptRoot 'QuestInputPolicy.cs'))
function Direction($up,$forward,$stick,$expected){
 [single]$x=0;[single]$y=0;[single]$z=0
 $ok=[SignalisVrTracking.MovementMath]::Direction($up[0],$up[1],$up[2],$forward[0],$forward[1],$forward[2],$stick[0],$stick[1],[ref]$x,[ref]$y,[ref]$z)
 if(!$ok -or [Math]::Abs($x-$expected[0])+[Math]::Abs($y-$expected[1])+[Math]::Abs($z-$expected[2]) -gt .0001){throw "Movement basis mismatch: $x,$y,$z expected $expected"}
}
Direction @(0,0,-1) @(0,1,0) @(0,1) @(0,1,0)
Direction @(0,0,-1) @(0,1,0) @(0,-1) @(0,-1,0)
Direction @(0,0,-1) @(0,1,0) @(1,0) @(1,0,0)
Direction @(0,0,-1) @(0,1,0) @(-1,0) @(-1,0,0)
Direction @(0,1,0) @(1,0,0) @(0,1) @(1,0,0)
Direction @(0,1,0) @(1,0,0) @(1,0) @(0,0,-1)
Direction @(0,0,-1) @(0,1,5) @(0,1) @(0,1,0)
Direction @(0,0,-1) @(0,1,0) @(1,1) @(.70710678,.70710678,0)
Direction @(0,0,-1) @(0,1,0) @(0,0) @(0,0,0)
$f=[SignalisVrTracking.QuestFrame]::new();$f.moveX=1;$f.moveY=1;$f.uiY=1
if([SignalisVrTracking.QuestNativeRouting]::Axis('Move Vertical',0,$f,$true,$true) -ne 0){throw 'Double forward movement'}
if([SignalisVrTracking.QuestNativeRouting]::Axis('Move Horizontal',0,$f,$true,$true) -ne 0){throw 'Double strafe movement'}
if([SignalisVrTracking.QuestNativeRouting]::Axis('UIVertical',0,$f,$true,$true) -ne 1){throw 'Puzzle/UI movement suppressed'}
if([Math]::Abs([SignalisVrTracking.QuestNativeRouting]::Axis('Move Vertical',-.8,$f,$true,$true) + .8) -gt .00001){throw 'Physical movement lost'}
if([SignalisVrTracking.QuestNativeRouting]::Axis('Move Vertical',0,$f,$true,$false) -ne 1){throw 'Non-unified forward lost'}
'PASS: rotated floor/view, four directions, pitch rejection, analog diagonals, neutral, native duplication and UI/physical preservation. No physics/headset claim.'
# Reconstruct the same world vector from native forward + camera-mod strafe,
# across cardinal/diagonal/circular inputs and different player/view headings.
foreach($yaw in @(0,35,90,180,270)) {
 $rad=$yaw*[Math]::PI/180;$f=@([Math]::Sin($rad),[Math]::Cos($rad),0)
 foreach($angle in (0..23)) {
  $a=$angle*[Math]::PI/12
  [single]$dx=0;[single]$dy=0;[single]$dz=0
  [void][SignalisVrTracking.MovementMath]::Direction(0,0,-1,0,1,0,[Math]::Sin($a)*.7,[Math]::Cos($a)*.7,[ref]$dx,[ref]$dy,[ref]$dz)
  [single]$fw=0;[single]$side=0
  if(![SignalisVrTracking.MovementMath]::Split(0,0,-1,$f[0],$f[1],0,$dx,$dy,$dz,[ref]$fw,[ref]$side)){throw 'Split failed'}
  $rx=$f[1];$ry=-$f[0]
  if([Math]::Abs($fw*$f[0]+$side*$rx-$dx)+[Math]::Abs($fw*$f[1]+$side*$ry-$dy) -gt .00001){throw 'World direction changed by split'}
  if([Math]::Abs($fw*$fw+$side*$side-.49) -gt .00001){throw 'Analog/circular magnitude changed'}
 }
}
$testFrame=[SignalisVrTracking.QuestFrame]::new()
if([SignalisVrTracking.QuestNativeRouting]::Axis('Move Vertical',0,$testFrame,$true,$true,.75) -ne .75){throw 'Native projected forward lost'}
'PASS: 120 rotated world-direction reconstructions, analog circle preservation and restored native forward.'

if([Math]::Abs([SignalisVrTracking.MovementMath]::ForceGain($false)-1.65) -gt .0001){throw 'Walk gain incorrect'}
if([Math]::Abs([SignalisVrTracking.MovementMath]::ForceGain($true)-1.725) -gt .0001){throw 'Sprint gain incorrect'}
'PASS walk and sprint tuning gains'
