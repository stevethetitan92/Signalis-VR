$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'HeldTriggerMotion.cs') -Raw
$policy=$s.Substring($s.IndexOf(' public static class TriggerMotion'));$policy=$policy.Substring(0,$policy.IndexOf(' public sealed partial class Tracking'))
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$policy+'}')
$p=[SignalisVrTracking.TriggerMotion]
if($p::Amount(-1) -ne 0 -or $p::Amount(0) -ne 0 -or $p::Amount(.3) -ne 0 -or $p::Amount([float]::NaN) -ne 0){throw 'Invalid/rest envelope'}
$last=0
foreach($i in 0..55){$a=$p::Amount($i/1000.0);if($a -lt $last-.00001 -or $a -gt 1){throw 'Opening movement discontinuity'};$last=$a}
$last=1
foreach($i in 90..240){$a=$p::Amount($i/1000.0);if($a -gt $last+.00001 -or $a -lt 0){throw 'Returning movement discontinuity'};$last=$a}
foreach($initial in @(0,.35,.75,1)){if([Math]::Abs($p::Amount(0,$initial)-$initial) -gt .00001){throw 'Automatic fire retrigger jumped forward'};if($p::Amount(.055,$initial) -ne 1){throw 'Retrigger never seated'}}
if($p::Blend(0) -ne 0 -or $p::Blend(.016) -le 0 -or $p::Blend(.016) -ge 1){throw 'Hand smoothing has no intermediate pose'}
$gun=Get-Content (Join-Path $PSScriptRoot 'ControllerWeapon.cs') -Raw
if(!$gun.Contains('__exception==null&&__state!=null&&__state.shot') -or !$gun.Contains('RecordHeldTriggerShot()')){throw 'Trigger follows input rather than successful native shot'}
'PASS bounded eased squeeze/return, sustained-fire continuous retrigger, hand intermediate poses and successful-shot ownership. Actual hand clearance requires runtime verification.'
