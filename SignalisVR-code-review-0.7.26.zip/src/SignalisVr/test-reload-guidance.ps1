$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'AmmoGuidance.cs') -Raw
$a=$s.IndexOf(' public static class AmmoGuidePolicy');$b=$s.IndexOf(' public sealed partial class Tracking')
Add-Type -TypeDefinition ('using System;namespace SignalisVrTracking {'+$s.Substring($a,$b-$a)+'}')
$policy=[SignalisVrTracking.AmmoGuidePolicy]
foreach($hz in 30,72,90,120){
 $last=0
 for($i=0;$i -le $hz;$i++){$t=$policy::Progress($i/$hz);if($t -lt $last -or $t -gt 1){throw 'Guide overshoot/reversal'};$last=$t}
 if($last -ne 1 -or $policy::Progress(0) -ne 0 -or $policy::Progress(.1) -le 0 -or $policy::Progress(.1) -ge 1){throw 'Guide failed to interpolate and seat'}
}
if(!$policy::Capture(.09,.14,-.07) -or !$policy::Capture(.14,.10,-.07)){throw 'Tip/hand approach rejected'}
if($policy::Capture(.4,.4,0) -or $policy::Capture(.01,.01,.2) -or $policy::Capture(.01,.01,[float]::NaN)){throw 'Remote/front-side/invalid capture'}
if([Math]::Abs($policy::RevolverScale-1) -gt .00001){throw 'HD revolver must retain authored metre scale'}
foreach($age in .2,1,10){if($policy::Seated($policy::Progress($age),-.08)){throw 'Waiting alone seated ammunition'}}
if($policy::Seated(.5,0) -or $policy::Seated(1,-.007) -or $policy::Seated(1,[float]::NaN) -or $policy::Seated(1,[float]::PositiveInfinity)){throw 'Invalid or incomplete insertion accepted'}
if(!$policy::Seated(1,-.005) -or !$policy::Seated(1,0)){throw 'Completed physical insertion rejected'}
# Check every imported round vertex against its cylinder-space counterpart at
# the actual seated loader origin, including the new common scale.
$raw=Get-Content (Join-Path $PSScriptRoot 'HdRevolverData.cs') -Raw
function Vec($name){$m=[regex]::Match($raw,($name+'=new UnityEngine.Vector3\(([^)]+)\)'));return @($m.Groups[1].Value.Split(',')|ForEach-Object{[double]($_.TrimEnd('f'))})}
$pivot=Vec 'Pivot';$origin=Vec 'OpenLoaderCenter'
$blob=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'embedded-hd/Revolver-0.bin'))
$r=[IO.BinaryReader]::new([IO.MemoryStream]::new($blob));$parts=$r.ReadInt32();$checked=0
for($p=0;$p -lt $parts;$p++){
 $role=$r.ReadInt32();$material=$r.ReadInt32();$nv=$r.ReadInt32();$nt=$r.ReadInt32()
 for($v=0;$v -lt $nv;$v++){
  $x=$r.ReadSingle();$y=$r.ReadSingle();$z=$r.ReadSingle()
  if($role -ge 10){
   $opened=@(($pivot[0]-($y-$pivot[1])),($pivot[1]+($x-$pivot[0])),$z)
   $loader=@(($opened[0]-$origin[0]),($opened[2]-$origin[2]),(-($opened[1]-$origin[1])))
   $seated=@(($origin[0]+$loader[0]),($origin[1]-$loader[2]),($origin[2]+$loader[1]))
   for($axis=0;$axis -lt 3;$axis++){if([Math]::Abs(($seated[$axis]-$opened[$axis])*$policy::RevolverScale) -gt .000001){throw 'Loader/cylinder round gap'}}
   $checked++
  }
 }
 $r.BaseStream.Position+=($nv*8+$nt*4)
}
$r.Dispose();if($checked -eq 0){throw 'No round geometry tested'}
# Integration guards complement the numerical tests; these do not establish
# headset collision/pose quality.
foreach($guard in 'rifleChambers.Empty(c)','rifleChambers.Empty(ammoGuideChamber)','seatCenter=selectedRoot.transform.TransformPoint(HdRevolverData.OpenLoaderCenter)','FollowAmmoWithHand','AmmoGuidePolicy.Seated(blend,along/UnitsPerMetre)'){
 if(!$s.Contains($guard)){throw "Missing guide integration: $guard"}
}
'PASS guide timing at four frame rates, nearby approach versus remote/front-side rejection, authored HD scale and all imported round vertices at the cylinder seat. Runtime fit unverified.'
foreach($travel in @(-.016,-.015,-.006,0,.02)){
 if($policy::MagazineSeated(1,$travel) -ne ($travel -ge -.015)){throw "Magazine lip tolerance failed: $travel"}
 if($policy::MagazineSeated(.9,$travel)){throw 'Magazine seated before alignment'}
}
if($policy::MagazineSeated(1,[single]::NaN) -or $policy::MagazineSeated(1,[single]::PositiveInfinity)){throw 'Invalid magazine pose accepted'}
'PASS SMG final 15mm seat tolerance, alignment gate, non-finite rejection.'
