using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using HarmonyLib;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private static readonly List<Mesh> inventorySmgMeshes=new List<Mesh>();
 private static readonly List<Material> inventorySmgMaterials=new List<Material>();
 private static readonly List<int> inventorySmgSlots=new List<int>();
 private static bool inventorySmgFailed;
 private static Sprite inventorySmgIcon,inventorySmgOldIcon,inventorySmgOldImage;
 private static bool inventorySmgIconFailed;
 private void InstallInventorySmg(){
  var h=new HarmonyLib.Harmony("signalis.vr.inventory.smg");
  h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"Update",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(ReplaceInventorySmg)));
  foreach(var method in new[]{"updateItems","initializeBox"})h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),method,Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(ApplyInventorySmgIcon)));
 }
 private static void ApplyInventorySmgIcon(global::InventoryBase __instance){
  if(inventorySmgIconFailed)return;
  try{
   var catalog=global::InventoryManager.allItems;if(catalog==null||!catalog.ContainsKey(global::Items.itemlist.SMG))return;
   var item=catalog[global::Items.itemlist.SMG];if(item==null)return;
   if(inventorySmgIcon==null){
    var texture=new Texture2D(2,2,TextureFormat.RGBA32,false);
    if(!ImageConversion.LoadImage(texture,Convert.FromBase64String(HdAsset.Read("smg-inventory-icon.png")),true))throw new InvalidOperationException("SMG icon decode failed");
    texture.filterMode=FilterMode.Point;texture.wrapMode=TextureWrapMode.Clamp;
    inventorySmgIcon=Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f),100);
    inventorySmgOldIcon=item.Icon;inventorySmgOldImage=item.Image;
   }
   item.Icon=inventorySmgIcon;item.Image=inventorySmgIcon;
   if(__instance!=null)foreach(var image in __instance.GetComponentsInChildren<UnityEngine.UI.Image>(true).ToArray()){
    var sprite=image.sprite;
    if(sprite!=null&&((inventorySmgOldIcon!=null&&sprite==inventorySmgOldIcon)||(inventorySmgOldImage!=null&&sprite==inventorySmgOldImage)))image.sprite=inventorySmgIcon;
   }
  }catch(Exception ex){inventorySmgIconFailed=true;MelonLoader.MelonLogger.Warning("Inventory SMG icon retained original: "+ex.Message);}
 }
 private static void ReplaceInventorySmg(global::InventoryBase __instance){
  ApplyInventorySmgIcon(__instance);
  if(__instance!=null&&__instance.itemDescription!=null){
   var selected=__instance.lastItem;
   if(selected!=null&&selected._item==global::Items.itemlist.SMG)
    __instance.itemDescription.text="A fully automatic submachine gun. Chambered in 8mm Compact Ammo with a 25 round capacity magazine";
  }
  if(inventorySmgFailed||__instance==null||__instance.InspectObj==null)return;
  var catalog=global::InventoryManager.allItems;
  if(catalog==null||!catalog.ContainsKey(global::Items.itemlist.SMG))return;
  var item=catalog[global::Items.itemlist.SMG];var parent=__instance.InspectObj;
  if(item==null||item.Image3D==null||!parent.name.StartsWith(item.Image3D.name,StringComparison.Ordinal))return;
  if(parent.Find("SignalisVR_InventoryXiphias")!=null)return;
  GameObject root=null;
  try{
   var originals=parent.GetComponentsInChildren<Renderer>(true).ToArray();if(originals.Length==0)return;
   var bounds=new Bounds();bool first=true;
   foreach(var r in originals){var filter=r.GetComponent<MeshFilter>();if(filter==null||filter.sharedMesh==null)continue;foreach(var vertex in filter.sharedMesh.vertices){var p=parent.InverseTransformPoint(r.transform.TransformPoint(vertex));if(first){bounds=new Bounds(p,Vector3.zero);first=false;}else bounds.Encapsulate(p);}}
   if(first)return;
   if(inventorySmgMeshes.Count==0){
    var shader=Shader.Find("Unlit/Texture");if(shader==null)throw new InvalidOperationException("Inventory texture shader missing");
    foreach(var encoded in XiphiasData.Textures){var tex=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(tex,Convert.FromBase64String(encoded),true))throw new InvalidOperationException("SMG texture decode failed");tex.filterMode=FilterMode.Point;inventorySmgMaterials.Add(new Material(shader){mainTexture=tex});}
    using(var reader=new BinaryReader(new MemoryStream(Convert.FromBase64String(XiphiasData.Geometry)))){
     int count=reader.ReadInt32();for(int part=0;part<count;part++){reader.ReadInt32();int material=reader.ReadInt32(),nv=reader.ReadInt32(),nt=reader.ReadInt32();var v=new Vector3[nv];var uv=new Vector2[nv];var tri=new int[nt];for(int i=0;i<nv;i++)v[i]=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle());for(int i=0;i<nv;i++)uv[i]=new Vector2(reader.ReadSingle(),reader.ReadSingle());for(int i=0;i<nt;i++)tri[i]=reader.ReadInt32();var mesh=new Mesh{vertices=v,uv=uv,triangles=HandSurfaceTopology.DoubleSided(tri)};mesh.RecalculateBounds();inventorySmgMeshes.Add(mesh);inventorySmgSlots.Add(material);}
    }
   }
   root=new GameObject("SignalisVR_InventoryXiphias");root.transform.SetParent(parent,false);root.layer=originals[0].gameObject.layer;
   var rotation=bounds.size.x>bounds.size.z?Quaternion.Euler(0,90,0):Quaternion.identity;
   var fit=new Bounds();first=true;
   foreach(var mesh in inventorySmgMeshes)foreach(var vertex in mesh.vertices){var p=rotation*vertex;if(first){fit=new Bounds(p,Vector3.zero);first=false;}else fit.Encapsulate(p);}
   float scale=Math.Min(bounds.size.x/Math.Max(.001f,fit.size.x),Math.Min(bounds.size.y/Math.Max(.001f,fit.size.y),bounds.size.z/Math.Max(.001f,fit.size.z)));
   root.transform.localRotation=rotation;scale*=.72f;root.transform.localScale=Vector3.one*scale;root.transform.localPosition=-fit.center*scale;
   for(int i=0;i<inventorySmgMeshes.Count;i++){var part=new GameObject("Xiphias part");part.layer=root.layer;part.transform.SetParent(root.transform,false);part.AddComponent<MeshFilter>().sharedMesh=inventorySmgMeshes[i];part.AddComponent<MeshRenderer>().sharedMaterial=inventorySmgMaterials[inventorySmgSlots[i]];}
   foreach(var r in originals)r.enabled=false;
  }catch(Exception ex){if(root!=null)UnityEngine.Object.Destroy(root);inventorySmgFailed=true;MelonLoader.MelonLogger.Warning("Inventory SMG retained original: "+ex.Message);}
 }
} }

