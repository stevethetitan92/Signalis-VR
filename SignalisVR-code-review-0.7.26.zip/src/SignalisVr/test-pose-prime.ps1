$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
$a=$s.IndexOf('        private void PrepareNextPose()')
$b=$s.IndexOf('        private bool ReadPose(', $a)
$method=$s.Substring($a,$b-$a)
$stub=@'
using System;
static class GL {public static int events; public static void IssuePluginEvent(object callback,int token){events++;}}
static class MelonLogger {public static void Warning(string s){}}
class Flow {public bool CanSubmit=true;}
public class PrimeTest {
bool sceneRecoveryDraining=false,active=true,stereo=true,stopping=false,questInputStopped=false,bridgeConfigured=true,questMenuScene=false;
object system=new object(),renderCallback=new object(); Flow diagnostic=new Flow();
int eventId,state=1,requests; bool fail;
int QueuePose(int id){requests++;if(fail)throw new Exception();if(state!=1)return 0;state=4;return 1;}
void Stop(){stopping=true;}
'@
$tail=@'
public static void Test(){
var p=new PrimeTest();
for(int state=0;state<=6;state++){p.state=state;GL.events=0;p.PrepareNextPose();if(GL.events!=(state==1?1:0))throw new Exception("queue state "+state);if(p.state!=(state==1?4:state))throw new Exception("state overwritten");}
p.state=1;GL.events=0;p.PrepareNextPose();p.PrepareNextPose();if(GL.events!=1)throw new Exception("duplicate pending event");
foreach(string name in new[]{"sceneRecoveryDraining","active","stereo","stopping","questInputStopped","bridgeConfigured"}){
var f=typeof(PrimeTest).GetField(name,System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance);bool old=(bool)f.GetValue(p);f.SetValue(p,!old);int before=p.requests;p.PrepareNextPose();if(p.requests!=before)throw new Exception("guard "+name);f.SetValue(p,old);}
p.system=null;int saved=p.requests;p.PrepareNextPose();if(saved!=p.requests)throw new Exception("no system");p.system=new object();
p.diagnostic.CanSubmit=false;p.PrepareNextPose();if(saved!=p.requests)throw new Exception("disabled submission");
p.questMenuScene=true;p.state=1;GL.events=0;p.PrepareNextPose();if(GL.events!=1)throw new Exception("menu path");
p.state=1;p.fail=true;p.PrepareNextPose();if(!p.stopping)throw new Exception("error did not stop");
}}
'@
Add-Type ($stub+$method+$tail)
[PrimeTest]::Test()
'PASS extracted pose preparation lifecycle/state/duplicate/error tests with native queue stub. No compositor timing claim.'

