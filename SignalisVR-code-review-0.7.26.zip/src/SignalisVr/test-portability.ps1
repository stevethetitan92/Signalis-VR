$ErrorActionPreference = 'Stop'
$testRoot = Join-Path $PSScriptRoot ('test-output/portability-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $testRoot -Force | Out-Null
$compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$exe = Join-Path $testRoot 'LoaderTests.exe'
& $compiler /nologo /platform:x64 /target:exe "/out:$exe" (Join-Path $PSScriptRoot 'NativeLibraries.cs') (Join-Path $PSScriptRoot 'vendor/openvr_api.cs') (Join-Path $PSScriptRoot 'LoaderTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Loader harness compilation failed' }
foreach ($case in @('Other Steam Library', 'Unicode-玩家', 'Missing', 'Damaged')) {
    $root = Join-Path $testRoot $case
    $libs = Join-Path $root 'UserLibs/SignalisVrTracking'
    New-Item -ItemType Directory -Path $libs -Force | Out-Null
    Copy-Item $exe (Join-Path $root 'SIGNALIS.exe') -Force
    Copy-Item 'E:/SteamLibrary/steamapps/common/SIGNALIS/UserLibs/SignalisVrTracking/*.dll' $libs -Force
    $expected = @()
    if ($case -eq 'Missing') { Rename-Item (Join-Path $libs 'openvr_api.dll') 'openvr_api.absent' -Force; $expected = @('dependency missing') }
    if ($case -eq 'Damaged') { [IO.File]::WriteAllText((Join-Path $libs 'SignalisVrRenderBridge.dll'), 'not a DLL'); $expected = @('dependency mismatch') }
    # Intentionally run with cwd outside the fake installation.
    & (Join-Path $root 'SIGNALIS.exe') @expected
    if ($LASTEXITCODE -ne 0) { throw "Portability case failed: $case" }
}
