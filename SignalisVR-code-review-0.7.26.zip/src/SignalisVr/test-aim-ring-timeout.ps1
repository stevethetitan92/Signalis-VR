$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'AimRingTimeout.cs') -Raw
$timer=$s.Substring($s.IndexOf(' public sealed class AimRingTimer'))
$timer=$timer.Substring(0,$timer.IndexOf(' public sealed partial class Tracking'))
Add-Type -TypeDefinition ('namespace SignalisVrTracking {'+$timer+'}')
$t=[SignalisVrTracking.AimRingTimer]::new()
if($t.Hidden(100)){throw 'Unfired rings hidden'}
$t.Shot(10);$t.Shot(11)
if($t.Hidden(11.99) -or !$t.Hidden(12)){throw 'Two-second first-shot timeout failed'}
if($t.Alpha(11.25) -ne 1 -or [Math]::Abs($t.Alpha(11.625)-.5) -gt .00001 -or $t.Alpha(12) -ne 0){throw 'Smooth ring fade failed'}
$previous=1.0
for($i=0;$i -le 200;$i++){
 $alpha=[SignalisVrTracking.RingFade]::Alpha($i/100.0)
 if($alpha -lt 0 -or $alpha -gt 1 -or $alpha -gt $previous+.00001){throw 'Ring fade is not bounded and monotonic'}
 $previous=$alpha
}
if([SignalisVrTracking.RingFade]::Alpha([float]::NaN) -ne 0){throw 'Invalid ring age must be hidden'}
$t.Reset()
if($t.Hidden(20)){throw 'Reset did not reveal rings'}
$t.Shot(20)
if($t.Hidden(21.99) -or !$t.Hidden(22)){throw 'Second aiming session failed'}
$render=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
if(!$render.Contains('PrepareAimRings();') -or !$render.Contains('RestoreAimRings();')){throw 'Missing eye scope restoration'}
if($s.Contains('AimLaser') -or $s.Contains('AimDot')){throw 'Timeout changed native laser/dot'}
$impact=Get-Content (Join-Path $PSScriptRoot 'RifleImpact.cs') -Raw
foreach($required in @('Shader.Find("Sprites/Default")','SetPropertyBlock','RingFade.Alpha','Time.realtimeSinceStartup+2f','pellet.hitPos,pellet.hitNorm')){if(!$impact.Contains($required)){throw "Missing transparent native pellet ring integration: $required"}}
'PASS two-second first-shot timer, monotonic smooth fade, continued shots, reset/new session, transparent impact/pellet rings and scoped native sprite restoration; headset appearance unverified.'
