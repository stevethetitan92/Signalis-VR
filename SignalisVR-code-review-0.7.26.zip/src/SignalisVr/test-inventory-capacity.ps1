$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'InventoryCapacityPolicy.cs')
function Check($v,$m){if(-not $v){throw $m}}
# Native load counts include one sentinel NoneItem; overflow uses Count - 1.
foreach($modulesTakeSpace in @($true,$false)) {
 foreach($modules in 0..2) {
  $limit=[SignalisVrTracking.InventoryCapacityPolicy]::Effective($modulesTakeSpace,$modules)
  $exempt=if($modulesTakeSpace){0}else{$modules}
  foreach($carried in 0..14){$nativeCount=1+$carried+$exempt;Check (($nativeCount-1) -le $limit) 'Valid load would overflow to storage'}
  Check ((1+15+$exempt-1) -gt $limit) 'Fifteenth carried slot should be full'
 }
}
Check ([SignalisVrTracking.InventoryCapacityPolicy]::Effective($false,-1) -eq 14) 'Negative module count reduced capacity'
'14-slot capacity and native sentinel/exempt-module load boundaries PASS'
Check ([SignalisVrTracking.InventoryCapacityPolicy]::BaseSlots($false,$false) -eq 6) 'OFF changed normal native capacity'
Check ([SignalisVrTracking.InventoryCapacityPolicy]::BaseSlots($false,$true) -eq 8) 'OFF changed expanded native capacity'
Check ([SignalisVrTracking.InventoryCapacityPolicy]::BaseSlots($true,$false) -eq 14) 'ON failed'
Check ([SignalisVrTracking.InventoryCapacityPolicy]::Effective(6,$false,2) -eq 8) 'Disable lost exempt modules'
