using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private GameObject flashlightGripRoot;
  private readonly List<Mesh> flashlightGripMeshes=new List<Mesh>();
  private readonly List<Material> flashlightGripMaterials=new List<Material>();
  private readonly List<Renderer> flashlightHiddenNative=new List<Renderer>();
  private bool flashlightHidHand;
  private readonly List<Light> flashlightHiddenLights=new List<Light>();
  private bool flashlightGripExitPending;
  private Vector3 flashlightLastGrip;
  private bool FlashlightHandBusy(){
   bool grip=rifleBarrelHeld||manualReload.Stage==ManualReloadPolicy.Step.RackHolding||smgReload.Stage==ManualReloadPolicy.Step.RackHolding||shotgunReload.Stage==ShotgunReloadPolicy.Step.Pumping;
   bool ammo=manualReload.Stage==ManualReloadPolicy.Step.Holding||AdditionalHoldingAmmo()||shotgunReload.Stage==ShotgunReloadPolicy.Step.Holding;
   if(modFlashlightPlacement!=0||controllerMarkers[0]==null){flashlightGripExitPending=false;return false;}
   var local=Quaternion.Inverse(rightWeaponRotation)*(controllerMarkers[0].transform.position-rightWeaponPosition)/UnitsPerMetre;
   if(grip){flashlightLastGrip=local;flashlightGripExitPending=true;}
   bool near=Vector3.Distance(local,flashlightLastGrip)<.10f;
   if(!grip&&!near)flashlightGripExitPending=false;
   return FlashlightHandPolicy.Suppressed(ammo,grip,flashlightGripExitPending,near);
  }
  private void SuppressHandFlashlight(Transform model,Transform holder){
   if(model!=null)foreach(var r in model.GetComponentsInChildren<Renderer>(true))if(r.enabled){flashlightHiddenNative.Add(r);r.enabled=false;}
   foreach(var light in holder.GetComponentsInChildren<Light>(true))if(light.enabled){flashlightHiddenLights.Add(light);light.enabled=false;}
   if(model!=null)foreach(var light in model.GetComponentsInChildren<Light>(true))if(light.enabled){flashlightHiddenLights.Add(light);light.enabled=false;}
  }
  private void HideFlashlightGrip(){if(flashlightGripRoot!=null)flashlightGripRoot.SetActive(false);foreach(var light in flashlightHiddenLights)if(light!=null)light.enabled=true;flashlightHiddenLights.Clear();foreach(var r in flashlightHiddenNative)if(r!=null)r.enabled=true;flashlightHiddenNative.Clear();if(flashlightHidHand&&handsRenderers[0]!=null)handsRenderers[0].enabled=true;flashlightHidHand=false;}
  private void DestroyFlashlightGrip(){HideFlashlightGrip();flashlightGripExitPending=false;if(flashlightGripRoot!=null)UnityEngine.Object.Destroy(flashlightGripRoot);flashlightGripRoot=null;foreach(var m in flashlightGripMeshes)if(m!=null)UnityEngine.Object.Destroy(m);foreach(var m in flashlightGripMaterials)if(m!=null)UnityEngine.Object.Destroy(m);flashlightGripMeshes.Clear();flashlightGripMaterials.Clear();}
 }
}
