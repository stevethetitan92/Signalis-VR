using System;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly ShotgunReloadPolicy shotgunReload=new ShotgunReloadPolicy();
  private static Tracking shotgunOwner;
  private Quaternion shotgunGripRotation;
  private static void ShotgunFired(){
   var owner=shotgunOwner;var w=global::InventoryManager.EquippedWeapon;
   if(owner==null||!owner.manualReloadEnabled||owner.shotgunFailed||w==null||w.parentItem==null||w.parentItem._item!=global::Items.itemlist.Shotgun)return;
   owner.shotgunReload.Fired();
  }
  private bool shotgunFailed,shotgunInsert,shotgunPumpHeld,shotgunEjectPending,shotgunEjectLive;
  private MeshRenderer shotgunEjected;
  private float shotgunEjectedAt=-100;
  private Vector3 shotgunEjectedOrigin,shotgunEjectedVelocity;
  private Quaternion shotgunEjectedRotation;
  private bool shotgunGuide;private float shotgunGuideTime;private Quaternion shotgunGuideRotation;private Vector3 shotgunGuideOffset;
  private bool GuideShotgunShell(Vector3 port,ref Vector3 center,ref Quaternion rotation){
   if(shotgunReload.Stage!=ShotgunReloadPolicy.Step.Holding){shotgunGuide=false;return false;}
   // Imported InsertTarget local X points along the angled loading port.
   var axis=rightWeaponRotation*new Vector3(0,.719239f,.694763f);
   // Capture the shell tip at the physical opening, not its centre in free space.
   var tip=center+rotation*Vector3.up*(.033547f*UnitsPerMetre);
   var delta=(tip-port)/UnitsPerMetre;float along=Vector3.Dot(delta,axis);
   float lateral=(delta-axis*along).magnitude;
   if(shotgunGuide&&(delta.magnitude>.18f||lateral>.08f))shotgunGuide=false;
   var seat=Quaternion.FromToRotation(Vector3.up,axis);
   if(!shotgunGuide&&lateral<.045f&&along>=-.012f&&along<=.012f){shotgunGuide=true;shotgunGuideOffset=Quaternion.Inverse(rightWeaponRotation)*((center-port)/UnitsPerMetre);shotgunGuideTime=Time.realtimeSinceStartup;shotgunGuideRotation=Quaternion.Inverse(seat)*rotation;}
   if(!shotgunGuide)return false;
   float blend=AmmoGuidePolicy.Progress(Time.realtimeSinceStartup-shotgunGuideTime);
   center=port+(rightWeaponRotation*shotgunGuideOffset*(1-blend)+axis*(.033547f*blend))*UnitsPerMetre;
   rotation=seat*Quaternion.Slerp(shotgunGuideRotation,Quaternion.identity,blend);
   return blend>=1;
  }
  private IntPtr shotgunWeapon;
  private float shotgunSampleTime;
  private int shotgunFrame=-1;
  private GameObject shotgunReloadRoot;
  private MeshRenderer shotgunShell,shotgunBase,shotgunPouch,shotgunPort,shotgunPump;
  private Mesh shotgunShellMesh;
  private Material shotgunRed,shotgunBrass,shotgunCue;
  private bool ManualShotgunEligible(){
   var w=global::InventoryManager.EquippedWeapon;
   return manualReloadEnabled&&!shotgunFailed&&!modMenuOpen&&!mouseWeaponTest&&questPolicy.LeftArmed&&questPolicy.RightArmed
    &&ControllerWeaponVisualReady()&&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput&&!global::PlayerState.reloading
    &&!global::PlayerState.hurt&&!global::PlayerState.grappled&&w!=null&&w.parentItem!=null&&w.parentItem._item==global::Items.itemlist.Shotgun;
  }
  private int ShotgunReserve(global::AnWeapon w){return infiniteAmmo?1:w!=null&&w.ammoItem!=null?global::InventoryManager.getCount(w.ammoItem):0;}
  private void CancelShotgunReload(){shotgunReload.Interrupt();shotgunPumpHeld=shotgunGuide=false;shotgunInsert=shotgunEjectPending=false;shotgunWeapon=IntPtr.Zero;HideShotgunReload();}
  private void FilterShotgunReloadInput(bool b){
   try{
    shotgunOwner=this;
    if(!ManualShotgunEligible()){CancelShotgunReload();return;}
    var w=global::InventoryManager.EquippedWeapon;
    if(shotgunWeapon!=IntPtr.Zero&&shotgunWeapon!=w.Pointer)CancelShotgunReload();
    if(shotgunEjectPending){
     shotgunEjectPending=false;
     if(shotgunWeapon==w.Pointer){
      // Pumping cycles the action; only firing consumes ammunition.
      StartShotgunEjection();
      MelonLogger.Msg("MANUAL SHOTGUN: pump ejected "+(shotgunEjectLive?"live shell":"spent shell")+"; loaded="+w.magAmmo);
     }
    }
    if(shotgunInsert){
     shotgunInsert=false;
     int reserve=ShotgunReserve(w),loaded=w.magAmmo;
     if(shotgunReload.Active&&shotgunWeapon==w.Pointer&&Time.realtimeSinceStartup-shotgunSampleTime<.15f&&ShotgunReloadPolicy.CanTransfer(loaded,w.MagSize,reserve)){
      // Same native ammo store/setter used by PlayerAttack.reload; transfer only
      // one round after contact. No native full-mag reload or render-time writes.
      if(!infiniteAmmo)global::InventoryManager.SetCount(w.ammoItem,reserve-1);
      try{w.magAmmo=loaded+1;}catch{if(!infiniteAmmo)global::InventoryManager.SetCount(w.ammoItem,reserve);throw;}
      shotgunReload.Inserted(w.magAmmo,w.MagSize,ShotgunReserve(w));PlayMechanismSound("Shotgun","Insert");
      MelonLogger.Msg("MANUAL SHOTGUN: shell inserted; loaded="+w.magAmmo+" reserve="+ShotgunReserve(w));
     }else shotgunReload.Inserted(w.magAmmo,w.MagSize,ShotgunReserve(w));
    }

    questFrame.buttons&=~(1<<7);if(b)questFrame.buttons&=~(1<<1);
    if(shotgunReload.Active)questFrame.buttons&=~((1<<6)|(1<<5));

   }catch(Exception ex){shotgunFailed=true;CancelShotgunReload();MelonLogger.Warning("Manual shotgun disabled; native reload retained: "+ex.Message);}
  }
  private void EnsureShotgunReload(){
   if(shotgunReloadRoot!=null)return;
   shotgunReloadRoot=new GameObject("SignalisVR_ShotgunReload");UnityEngine.Object.DontDestroyOnLoad(shotgunReloadRoot);shotgunReloadRoot.transform.localScale=Vector3.one*UnitsPerMetre;
   var shader=Shader.Find("Unlit/Color");if(shader==null)throw new InvalidOperationException("Shell material unavailable");
   shotgunRed=new Material(shader);shotgunRed.color=new Color(.65f,.18f,.08f);
   shotgunBrass=new Material(shader);shotgunBrass.color=new Color(.65f,.48f,.2f);
   shotgunCue=new Material(shader);shotgunCue.color=new Color(.18f,.65f,.8f);
   var vertices=new Vector3[18];var tris=new int[96];int t=0;
   for(int i=0;i<8;i++){float a=i*(float)Math.PI/4;vertices[i]=new Vector3(Mathf.Cos(a)*.5f,-.5f,Mathf.Sin(a)*.5f);vertices[i+8]=new Vector3(vertices[i].x,.5f,vertices[i].z);int n=(i+1)%8;int[] face={i,n,i+8,n,n+8,i+8,16,n,i,17,i+8,n+8};foreach(int v in face)tris[t++]=v;}
   vertices[16]=new Vector3(0,-.5f,0);vertices[17]=new Vector3(0,.5f,0);
   shotgunShellMesh=new Mesh();shotgunShellMesh.vertices=vertices;shotgunShellMesh.triangles=tris;shotgunShellMesh.RecalculateBounds();
   shotgunShell=CreateControllerPart(shotgunReloadRoot,shotgunShellMesh,shotgunRed,"FlechetteShell",Vector3.zero,new Vector3(.019f,.058f,.019f));
   shotgunBase=CreateControllerPart(shotgunReloadRoot,shotgunShellMesh,shotgunBrass,"ShellBase",Vector3.zero,new Vector3(.021f,.009f,.021f));
   var box=controllerBodies[0].GetComponent<MeshFilter>().sharedMesh;
   shotgunPouch=CreateControllerPart(shotgunReloadRoot,box,shotgunCue,"ShellPouch",Vector3.zero,new Vector3(.065f,.08f,.025f));
   shotgunPort=CreateControllerPart(shotgunReloadRoot,box,shotgunCue,"LoadingPort",Vector3.zero,new Vector3(.035f,.006f,.06f));
   shotgunPump=CreateControllerPart(shotgunReloadRoot,box,shotgunCue,"PumpGuide",Vector3.zero,new Vector3(.025f,.012f,.05f));
  }
  private void PrepareShotgunReload(){
   HideShotgunReload();
   try{
    if(!ManualShotgunEligible()){CancelShotgunReload();return;}
    if(!handsScoped||renderedWeapon==null||controllerMarkers[0]==null)return;
    EnsureShotgunReload();ApplyHdShotgunShell();var left=controllerMarkers[0].transform;
    var yaw=controllerTrackingToWorld*Quaternion.Euler(0,headComfortPose.eulerAngles.y,0);
    var pouch=stereoPosition+yaw*(new Vector3(-.22f,-.5f,0)*UnitsPerMetre);
    var palm=rightWeaponPosition;
    var port=SelectedActive("Shotgun")?rightWeaponPosition+rightWeaponRotation*(new Vector3(.000102f,.045732f,.182180f)*UnitsPerMetre):palm+rightWeaponRotation*(new Vector3(0,-.035f,.11f)*UnitsPerMetre);
    var pump=SelectedActive("Shotgun")?rightWeaponPosition+rightWeaponRotation*(HdShotgunData.Pump*UnitsPerMetre):palm+rightWeaponRotation*(new Vector3(0,.015f,.27f)*UnitsPerMetre);
    var pinch=left.position;
    var basis=WeaponAimPolicy.ControllerRotation(left.rotation);
    // Preserve the fitted pinch while keeping the wrist in its tracked basis.
    var handBasis=basis*Quaternion.Euler(0,0,90);
    var rot=handBasis*Quaternion.Inverse(ElsterShellPinchData.Basis);
    var tip=left.position+rot*Vector3.up*(.033547f*UnitsPerMetre);
    var shellCenter=left.position-rot*ElsterShellPinchData.Palm*UnitsPerMetre;bool seated=GuideShotgunShell(port,ref shellCenter,ref rot);
    var weapon=global::InventoryManager.EquippedWeapon;
    if(shotgunFrame!=Time.frameCount){shotgunFrame=Time.frameCount;var previous=shotgunReload.Stage;int ejections=shotgunReload.EjectionCount;
     if(shotgunReload.Tick(Time.realtimeSinceStartup,manualLeftGrip,Vector3.Distance(left.position,pouch)<.22f*UnitsPerMetre,
      seated,Vector3.Distance(pinch,pump)<.12f*UnitsPerMetre,
      Vector3.Dot(left.position-palm,rightWeaponRotation*Vector3.back)/UnitsPerMetre,weapon.magAmmo,weapon.MagSize,ShotgunReserve(weapon))){
       shotgunInsert=true;shotgunSampleTime=Time.realtimeSinceStartup;
      }
     if(previous!=ShotgunReloadPolicy.Step.Pumping&&shotgunReload.Stage==ShotgunReloadPolicy.Step.Pumping)shotgunGripRotation=Quaternion.Inverse(rightWeaponRotation)*handsObjects[0].transform.rotation;
     if(shotgunReload.EjectionCount!=ejections){PlayMechanismSound("Shotgun","Pump");shotgunEjectPending=true;shotgunEjectLive=shotgunReload.LastEjectionLive;}
    }
    if(!manualLeftGrip)shotgunPumpHeld=false;
    else if(shotgunReload.Stage==ShotgunReloadPolicy.Step.Pumping)shotgunPumpHeld=true;
    if(SelectedActive("Shotgun"))selectedMoving.transform.localPosition=Vector3.back*shotgunReload.Pull;
    if(shotgunReload.Active)shotgunWeapon=weapon.Pointer;
    var stage=shotgunReload.Stage;
    shotgunShell.transform.position=shellCenter;shotgunShell.transform.rotation=rot;shotgunShell.enabled=stage==ShotgunReloadPolicy.Step.Holding;
    shotgunBase.transform.position=pinch-rot*Vector3.up*(.026f*UnitsPerMetre);shotgunBase.transform.rotation=rot;shotgunBase.enabled=false;
    shotgunPouch.GetComponent<MeshFilter>().sharedMesh=shotgunShell.GetComponent<MeshFilter>().sharedMesh;shotgunPouch.sharedMaterials=shotgunShell.sharedMaterials;shotgunPouch.transform.localScale=Vector3.one;
    shotgunPouch.transform.position=pouch;shotgunPouch.transform.rotation=yaw;shotgunPouch.enabled=stage!=ShotgunReloadPolicy.Step.Holding&&ShotgunReserve(weapon)>0;
    shotgunPort.transform.position=port;shotgunPort.transform.rotation=rightWeaponRotation;shotgunPort.enabled=false;
    shotgunPump.transform.position=pump-rightWeaponRotation*Vector3.forward*(Math.Min(.1f,shotgunReload.Pull)*UnitsPerMetre);shotgunPump.transform.rotation=rightWeaponRotation;
    shotgunPump.enabled=false;
    ShowShotgunEjection();
   }catch(Exception ex){shotgunFailed=true;CancelShotgunReload();MelonLogger.Warning("Shotgun reload visuals disabled: "+ex.Message);}
  }
  private void FitShotgunPumpHand(){
   if(!handsScoped||shotgunReload.Stage!=ShotgunReloadPolicy.Step.Pumping||!ManualShotgunEligible()||!SelectedActive("Shotgun"))return;
   var hand=handsObjects[0].transform;var frame=selectedMoving.transform;var bounds=selectedMoving.GetComponent<MeshFilter>().sharedMesh.bounds;
   hand.rotation=rightWeaponRotation*shotgunGripRotation;
   var palm=new Vector3(bounds.center.x,bounds.min.y-.014f,bounds.center.z);
   hand.position+=frame.TransformPoint(palm)-hand.TransformPoint(handPalmCenters[0]);
   string[] fingers={"index","middle","ring","pinky","thumb"};float[] stations={.033f,.011f,-.011f,-.032f,.035f};
   for(int i=0;i<5;i++)FitFingerToContact(0,fingers[i],frame.TransformPoint(new Vector3(i==4?bounds.min.x-.006f:bounds.max.x+.006f,bounds.center.y,bounds.center.z+stations[i])),12);
  }
  private void StartShotgunEjection(){
   // Authored HD EjectPoint, converted by the same origin as the gun mesh.
   var round=GetHdRound("Shotgun");
   if(shotgunEjected==null){shotgunEjected=CreateControllerPart(shotgunReloadRoot,round.Mesh,round.Materials[0],"Ejected shotgun shell",Vector3.zero,Vector3.one);shotgunEjected.sharedMaterials=round.Materials;}
   shotgunEjectedAt=Time.realtimeSinceStartup;
   shotgunEjectedOrigin=rightWeaponPosition+rightWeaponRotation*new Vector3(.0229f,.0900f,.1725f)*UnitsPerMetre;
   shotgunEjectedVelocity=rightWeaponRotation*new Vector3(.9f,.25f,.05f)*UnitsPerMetre;
   shotgunEjectedRotation=rightWeaponRotation*Quaternion.Euler(90,0,0);
  }
  private void ShowShotgunEjection(){
   float age=Time.realtimeSinceStartup-shotgunEjectedAt;if(shotgunEjected==null||age<0||age>1.5f)return;
   var down=calibrationRoot!=null?-calibrationRoot.transform.up:controllerTrackingToWorld*Vector3.down;
   shotgunEjected.transform.SetPositionAndRotation(shotgunEjectedOrigin+shotgunEjectedVelocity*age+down*(4.905f*age*age*UnitsPerMetre),shotgunEjectedRotation*Quaternion.Euler(age*180,age*240,0));shotgunEjected.enabled=true;
  }
  private void HideShotgunReload(){foreach(var r in new[]{shotgunShell,shotgunBase,shotgunPouch,shotgunPort,shotgunPump,shotgunEjected})if(r!=null)r.enabled=false;}
  private void DestroyShotgunReload(){CancelShotgunReload();if(shotgunReloadRoot!=null)UnityEngine.Object.Destroy(shotgunReloadRoot);if(shotgunShellMesh!=null)UnityEngine.Object.Destroy(shotgunShellMesh);foreach(var m in new[]{shotgunRed,shotgunBrass,shotgunCue})if(m!=null)UnityEngine.Object.Destroy(m);shotgunReloadRoot=null;shotgunShellMesh=null;shotgunShell=shotgunBase=shotgunPouch=shotgunPort=shotgunPump=null;shotgunRed=shotgunBrass=shotgunCue=null;}
 }
}

