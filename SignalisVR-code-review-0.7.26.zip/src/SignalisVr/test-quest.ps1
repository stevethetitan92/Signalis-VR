$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
function Check($v,$message) {if(-not $v){throw $message}}
$p=[SignalisVrTracking.QuestInputPolicy]::new()
Check ([SignalisVrTracking.QuestInputPolicy]::Ready($true,$false,$false,$false)) 'Menu input must work before stereo'
Check (-not [SignalisVrTracking.QuestInputPolicy]::Ready($false,$false,$false,$false)) 'Disconnected input enabled'
Check (-not [SignalisVrTracking.QuestInputPolicy]::Ready($true,$true,$false,$false)) 'Input during stop'
Check (-not [SignalisVrTracking.QuestInputPolicy]::Ready($true,$false,$true,$false)) 'Failed input enabled'
Check (-not [SignalisVrTracking.QuestInputPolicy]::Ready($true,$false,$false,$true)) 'F12 failed to stop input'
$l=[SignalisVrTracking.QuestSample]::new(); $r=[SignalisVrTracking.QuestSample]::new()
$r.trigger=1
Check ($p.Update($true,$l,$r).buttons -eq 0 -and -not $p.Armed) 'Held trigger armed at startup'
$r.trigger=0; $null=$p.Update($true,$l,$r)
Check $p.Armed 'Neutral did not arm'
$r.grip=1
Check ($p.Update($true,$l,$r).buttons -eq 32) 'Right grip must only aim'
$r.trigger=1
Check ($p.Update($true,$l,$r).buttons -eq 96) 'Aim and fire combination'
$r.grip=0; $r.trigger=0; $r.buttons=2
Check ($p.Update($true,$l,$r).buttons -eq 130) 'B must reload and provide contextual menu cancel'
$r.buttons=128
Check ($p.Update($true,$l,$r).buttons -eq 1) 'A must interact'
$r.buttons=0; $l.buttons=128
Check ($p.Update($true,$l,$r).buttons -eq 4) 'X inventory'
$l.buttons=2
Check ($p.Update($true,$l,$r).buttons -eq 8) 'Y pause'
$l.buttons=0; $l.grip=1
Check ($p.Update($true,$l,$r).buttons -eq 0) 'Left grip must not sprint'
$l.grip=0; $l.x=1; $r.x=-1
$f=$p.Update($true,$l,$r)
Check ($f.moveX -eq 1 -and $f.lookX -eq -1) 'Independent stick directions'
$f=$p.Update($false,$l,$r)
Check ($f.buttons -eq 0 -and $f.moveX -eq 0 -and $f.lookX -eq 0 -and -not $p.Armed) 'Focus/dashboard/disconnect release'
$null=$p.Update($true,$l,$r)
Check (-not $p.Armed) 'Held sticks rearmed after interruption'
$l.x=0; $r.x=0; $null=$p.Update($true,$l,$r)
Check $p.Armed 'Neutral reconnect failed'
Check ([SignalisVrTracking.QuestInputPolicy]::Stick(.1) -eq 0) 'Deadzone'
Check ([SignalisVrTracking.QuestInputPolicy]::Stick([float]::NaN) -eq 0) 'Invalid axis'
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
 $t=$a.MainModule.Types | Where-Object FullName -eq 'SignalisVrTracking.Tracking'
 $setup=$t.Methods | Where-Object Name -eq 'InstallQuestNativeReads'
 $names=@($setup.Body.Instructions | Where-Object {$_.OpCode.Name -eq 'ldstr'} | ForEach-Object {$_.Operand})
 Check ($names -contains 'Use' -and $names -notcontains 'Interact') 'Must map internal Use action, not its Interact display label'
 Check ($names -contains 'UIHorizontal') 'Missing native UI category'
 foreach($pair in @(@('Stop','ReleaseQuestControls'),@('OnUpdate','EnsureQuestControllers'),@('OnUpdate','UpdateQuestInputMode'),@('EnsureQuestControllers','PollQuestControllers'),@('OnUpdate','EnsureQuestConnection'),@('OnUpdate','PrepareQuestSceneConnection'),@('PollQuestControllers','Ready'))) {
  $m=$t.Methods | Where-Object Name -eq $pair[0]
  Check (@($m.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.Name -eq $pair[1]}).Count -gt 0) ('Missing integration '+($pair -join ':'))
 }
 $poll=$t.Methods | Where-Object Name -eq 'PollQuestControllers'
 Check (@($poll.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.FieldReference] -and $_.Operand.Name -in @('active','stereo','diagnostic')}).Count -eq 0) 'Controller polling still depends on stereo'
 $connection=$t.Methods | Where-Object Name -eq 'EnsureQuestConnection'
 Check (@($connection.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.Name -in @('Start','RenderStereo','ConfigureBridge','BeginSubmit')}).Count -eq 0) 'Input connection starts stereo'
}finally{$a.Dispose()}
'PASS: 20 controller policy checks and 11 compiled integration checks; headset behavior unverified.'


