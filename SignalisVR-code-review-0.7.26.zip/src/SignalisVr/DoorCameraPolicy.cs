namespace SignalisVrTracking {
 // Door coroutines may briefly return to play between the two halves of a
 // connected door. Keep the handoff closed until gameplay is stable again.
 public sealed class DoorCameraPolicy {
  public bool Active { get; private set; }
  private float stableSince=-1f;
  public bool Observe(bool traversing,bool ready,float now) {
   if(traversing){Active=true;stableSince=-1f;return true;}
   if(!Active)return false;
   if(!ready){stableSince=-1f;return true;}
   if(stableSince<0f)stableSince=now;
   if(now-stableSince>=.25f){Active=false;stableSince=-1f;}
   return Active;
  }
  public void Reset(){Active=false;stableSince=-1f;}
 }
}
