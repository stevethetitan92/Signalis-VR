$ErrorActionPreference='Stop'
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$assembly=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
 $tracking=$assembly.MainModule.Types | Where-Object FullName -eq 'SignalisVrTracking.Tracking'
 foreach($name in @('DoorMotorBefore','DoorMotorAfter','DoorLinkBegin','DoorPoint','TraceDoorLink','TraceDoorMotor')) {
  $method=$tracking.Methods | Where-Object Name -eq $name
  if(!$method){throw "Missing compiled observer: $name"}
  foreach($instruction in $method.Body.Instructions) {
   $operand=$instruction.Operand
   if($operand -is [Mono.Cecil.MethodReference] -and ($operand.Name.StartsWith('set_') -or $operand.Name -match '^(AddForce|MovePosition|MoveRotation|Translate|Rotate|SetPositionAndRotation|StartCoroutine|StopAllCoroutines|SyncTransforms)$')) {throw "Observer mutates game state: $name $operand"}
   if($instruction.OpCode.Name -in @('stfld','stsfld') -and $operand -is [Mono.Cecil.FieldReference] -and $operand.DeclaringType.FullName -ne 'SignalisVrTracking.Tracking') {throw "Observer writes external field: $operand"}
  }
 }
 $text=Get-Content (Join-Path $PSScriptRoot 'DoorMotorTrace.cs') -Raw
 foreach($needle in @('doorMotorTraceCount>=400','doorMotorNext=now+.05f','owned.Pointer!=control.Pointer','0x876FF0L','0x2D2060L','0x2D22C0L','body.interpolation','body.velocity','global::PlayerState.overrideInput','animator.deltaPosition','d.A.position','d.B.position')) {if(!$text.Contains($needle)){throw "Missing bounded native observation: $needle"}}
 $fp=Get-Content (Join-Path $PSScriptRoot 'QuestFirstPerson.cs') -Raw
 if(!$fp.Contains('InstallDoorMotorTrace();')){throw 'Observer not installed'}
 'PASS compiled read-only observers: no game/physics setters or external field writes, owned player only, bounded paired samples and native endpoint/physics/animation evidence. Live hook delivery and fault cause remain unverified.'
}finally{$assembly.Dispose()}
