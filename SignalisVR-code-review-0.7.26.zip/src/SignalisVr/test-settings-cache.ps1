$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'QuestFirstPerson.cs') -Raw
$a=$s.IndexOf('  private static string fpSettingsPath;')
$b=$s.IndexOf("`n }",$a)
$body=$s.Substring($a,$b-$a)
$tail=@'
public static string Read(string path) { using(var r=OpenFpSettings(path))return r.ReadToEnd(); }
public static void Expire(){fpSettingsCheck=DateTime.MinValue;}
}
'@
Add-Type ('using System; public class SettingsCacheTest { static SettingsCacheTest questOwner=null; void TraceOperation(int kind,long start) {} '+$body+$tail)
$path=Join-Path $PSScriptRoot 'settings-cache-test.tmp'
try {
 [IO.File]::WriteAllText($path,"mousesense=3`nother=1")
 $first=[SettingsCacheTest]::Read($path)
 [IO.File]::Delete($path)
 if([SettingsCacheTest]::Read($path) -ne $first){throw 'Cached reader changed content'}
 [IO.File]::WriteAllText($path,"mousesense=8`nother=2")
 [IO.File]::SetLastWriteTimeUtc($path,[DateTime]::UtcNow.AddSeconds(10))
 [SettingsCacheTest]::Expire()
 if([SettingsCacheTest]::Read($path) -notmatch 'mousesense=8'){throw 'Settings changes ignored'}
 if([SettingsCacheTest]::Read($path) -notmatch 'mousesense=8'){throw 'Disposed reader corrupted cached data'}
 'PASS: actual cache method serves independent readers without per-frame disk reads and refreshes changed settings.'
} finally {if(Test-Path $path){Remove-Item -LiteralPath $path}}
