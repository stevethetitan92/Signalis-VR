$ErrorActionPreference='Stop'
$source=(Get-Content (Join-Path $PSScriptRoot 'TraceFileSink.cs') -Raw)+(Get-Content (Join-Path $PSScriptRoot 'DiagnosticWatchdog.cs') -Raw)
# Compile each source separately: using directives cannot follow namespace declarations.
$test=@'
namespace SignalisVrTracking {public static class ReportTests {
 static void Check(bool v,string message){if(!v)throw new System.Exception(message);}
 public static void Run(string root){
  var w=new DiagnosticWatchdog();
  Check(w.Observe(0,true,1)==null,"initial");Check(w.Observe(1,true,2)==null,"progress");
  Check(w.Observe(3,true,2)==null,"grace");Check(w.Observe(4.1,true,2)=="headset-no-progress","stall");
  Check(w.Observe(5,true,2)==null,"cooldown");
  Check(w.Observe(66,false,2)=="update-gap","resume gap");
  w=new DiagnosticWatchdog();for(int i=0;i<20;i++)Check(w.Observe(i,false,0)==null,"inactive stall false positive");
  w=new DiagnosticWatchdog();for(int i=0;i<20;i++)Check(w.Observe(i,true,i)==null,"progress false positive");
  string path=System.IO.Path.Combine(root,"frames.csv");
  var sink=new TraceFileSink(path,"# version=test",1024);
  var data=new double[20];data[0]=2;
  for(int i=0;i<16;i++){
   data[19]=i;Check(sink.Enqueue(data,1,data,1,"# "+new string('x',2000)),"queue");
   System.Threading.Thread.Sleep(30);
  }
  Check(sink.Report("reason=manual-test\nimmutable-snapshot"),"report accepted");
  Check(sink.Finish(5000),"drain");Check(sink.Error==null,"writer error: "+sink.Error);
  Check(sink.LastReport!=null,"missing report");
  Check(System.IO.File.ReadAllText(System.IO.Path.Combine(sink.LastReport,"snapshot.txt")).Contains("immutable-snapshot"),"snapshot");
  Check(System.IO.Directory.GetFiles(root,"frames.csv*").Length==4,"four ring segments");
  Check(System.IO.Directory.GetFiles(sink.LastReport,"timeline-*.csv").Length==4,"four exported segments");
  Check(!sink.Report("after stop"),"closed report accepted");
  foreach(var f in System.IO.Directory.GetFiles(root,"frames.csv*"))Check(new System.IO.FileInfo(f).Length<6000,"unbounded segment");
  sink=new TraceFileSink(System.IO.Path.Combine(root,"pressure","frames.csv"),"# pressure",1024);
  var full=new double[512*20];var empty=new double[0];
  for(int i=0;i<1000;i++)sink.Enqueue(full,512,empty,0,"# pressure");
  Check(sink.Dropped>0,"backpressure not counted");
  int accepted=0;for(int i=0;i<2000&&accepted<20;i++){if(sink.Report("quota "+accepted))accepted++;else System.Threading.Thread.Sleep(5);}
  Check(accepted==20,"report quota not reachable");Check(!sink.Report("21"),"report quota exceeded");
  Check(sink.Finish(10000)&&sink.Error==null,"pressure drain");
  string bad=System.IO.Path.Combine(root,"not-a-directory");System.IO.File.WriteAllText(bad,"x");
  sink=new TraceFileSink(System.IO.Path.Combine(bad,"frames.csv"),"# test");Check(sink.Finish(5000),"failed sink thread");Check(sink.Error!=null,"disk failure not surfaced");
 }
}}
'@
$sources=@((Get-Content (Join-Path $PSScriptRoot 'TraceFileSink.cs') -Raw),(Get-Content (Join-Path $PSScriptRoot 'DiagnosticWatchdog.cs') -Raw),$test)
Add-Type -TypeDefinition ($sources -join "`n")
$root=Join-Path $PSScriptRoot ('report-test-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory $root | Out-Null
try {[SignalisVrTracking.ReportTests]::Run($root); 'PASS: watchdog progress/grace/inactive/cooldown/gap; bounded ring rollover/export; shutdown drain; disk failure isolation.'}
finally {Remove-Item -LiteralPath $root -Recurse -Force}
