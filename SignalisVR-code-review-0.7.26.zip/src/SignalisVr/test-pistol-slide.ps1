$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'PistolSlideVisualPolicy.cs')
function Check($v,$m){if(-not $v){throw $m}}
$p=[SignalisVrTracking.PistolSlideVisualPolicy]::new()
$p.Update(0,$true,$false,$false)
Check (-not $p.Override) 'Native firing slide overridden at rest'
$p.Update(.05,$true,$true,$true)
Check ($p.Amount -gt 0 -and $p.Amount -lt 1) 'No visible opening travel'
$p.Update(.15,$true,$true,$true)
Check ($p.Amount -eq 1) 'Slide not locked fully back'
$p.Update(20,$true,$true,$true)
Check ($p.Amount -eq 1) 'Lock-back timed out'
$p.Update(20.06,$true,$false,$true)
Check ($p.Amount -gt 0 -and $p.Amount -lt 1) 'Rack has no visible closing travel'
$p.Update(20.2,$true,$false,$true)
Check ($p.Amount -eq 0 -and $p.Override) 'Native animation can reopen slide while awaiting reload'
$p.Update(20.3,$true,$false,$false)
Check (-not $p.Override) 'Native firing animation not restored after reload'
$p.Update(21,$true,$true,$false)
Check ($p.Override) 'Empty magazine does not lock back'
$p.Update(22,$false,$true,$true)
Check ($p.Amount -eq 0 -and -not $p.Override) 'Disable does not clear slide override'
'PASS slide opening, sustained lock-back, rack closing, native-animation ownership, empty-mag lock and disable reset; graphics unverified.'
if([SignalisVrTracking.PistolSlideVisualPolicy]::RackReleaseWeight(0) -ne 1 -or [SignalisVrTracking.PistolSlideVisualPolicy]::RackReleaseWeight(.18) -ne 0){throw 'Grip release blend interval'}
if([SignalisVrTracking.PistolSlideVisualPolicy]::PullExtension(-.02) -ne 0 -or [SignalisVrTracking.PistolSlideVisualPolicy]::PullExtension(.04) -ne .25){throw 'Pull extension unclamped'}
if([SignalisVrTracking.PistolSlideVisualPolicy]::PullExtension(.01) -ne .125){throw 'Physical pull not mapped to slide travel'}
'PASS physical pull travel and grip release pose blend.'

# Imported slide follows actual shot notification, with a 35ms recoil / 105ms return.
$t=[SignalisVrTracking.PistolSlideVisualPolicy]
if($t::ShotAmount(0,$true,$false) -ne 0 -or $t::ShotAmount(.035,$true,$false) -ne 1 -or $t::ShotAmount(.14,$true,$false) -ne 0){throw 'Shot endpoints incorrect'}
foreach($hz in @(30,72,90,120,144)){
 for($i=0;$i -le $hz;$i++){$age=$i/[float]$hz;$a=$t::ShotAmount($age,$true,$false);if($a -lt 0 -or $a -gt 1){throw 'Slide exceeded travel'};if($age -ge .035 -and $t::ShotAmount($age,$true,$true) -ne 1){throw 'Last shot failed lockback'}}
}
if($t::ShotAmount(1,$false,$false) -ne 0 -or $t::ShotAmount(1,$false,$true) -ne 1){throw 'Idle/empty state incorrect'}
foreach($age in @([float]::NaN,[float]::PositiveInfinity,-1)){if($t::ShotAmount($age,$true,$false) -ne 0){throw 'Invalid shot timestamp'}}
$import=Get-Content (Join-Path $PSScriptRoot 'SelectedModelVisual.cs') -Raw
if(!$import.Contains('heldShotWeapon==weapon.Pointer') -or !$import.Contains('manualReload.Active?0:PistolSlideVisualPolicy.ShotAmount')){throw 'Shot visual not isolated to weapon/reload'}
'PASS imported pistol shot recoil, return, empty lockback, reload precedence and 30-144Hz bounded motion.'
