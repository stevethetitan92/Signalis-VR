$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'SmgShotAudio.cs') -Raw
$s=$s.Substring(0,$s.IndexOf('  private void InstallSmgShotAudio')).Replace('using HarmonyLib;','')+'}}'
$stub=@"
namespace UnityEngine {public struct Vector3 {public static Vector3 zero;}}
namespace FMODUnity {public static class RuntimeManager {public static int Calls;public static void PlayOneShot(string s,UnityEngine.Vector3 p){Calls++;}}}
namespace MelonLoader {public static class MelonLogger {public static void Warning(string s){}}}
public class Items {public enum itemlist {SMG,Pistol}}
public class AnItem {public Items.itemlist _item;}
public class AnWeapon {public AnItem parentItem=new AnItem();public int magAmmo=40;public string shotMod="native";}
public class PlayerAttack {public AnWeapon weapon=new AnWeapon();}
namespace SignalisVrTracking {public sealed partial class Tracking {
private static Tracking weaponOwner=new Tracking();private bool ControllerWeaponReady(){return true;}
public static void Test(){var a=new PlayerAttack();int state;SmgReadyAudioBegin();SmgAudioPatch.SmgShotAudioBegin(a,out state);a.weapon.magAmmo--;SmgAudioPatch.SmgShotAudioEnd(a,state);SmgReadyAudioEnd(null);if(FMODUnity.RuntimeManager.Calls!=0)throw new System.Exception("First shot doubled");
for(int i=0;i<39;i++){SmgAudioPatch.SmgShotAudioBegin(a,out state);a.weapon.magAmmo--;SmgAudioPatch.SmgShotAudioEnd(a,state);}if(FMODUnity.RuntimeManager.Calls!=39)throw new System.Exception("Continuing shot silent");SmgAudioPatch.SmgShotAudioBegin(a,out state);SmgAudioPatch.SmgShotAudioEnd(a,state);if(FMODUnity.RuntimeManager.Calls!=39)throw new System.Exception("Empty click counted as shot");
a.weapon.magAmmo=10;a.weapon.parentItem._item=Items.itemlist.Pistol;SmgAudioPatch.SmgShotAudioBegin(a,out state);a.weapon.magAmmo--;SmgAudioPatch.SmgShotAudioEnd(a,state);if(FMODUnity.RuntimeManager.Calls!=39)throw new System.Exception("Other gun audio changed");SmgReadyAudioBegin();var error=new System.Exception();if(SmgReadyAudioEnd(error)!=error||smgReadyDepth!=0)throw new System.Exception("Exception left audio scope stuck");}
}}
"@
Add-Type -TypeDefinition ($s+$stub)
[SignalisVrTracking.Tracking]::Test()
Add-Type -Path (Join-Path $PSScriptRoot 'ManualReloadPolicy.cs')
$p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.RequireFreshRackGrip=$true
$p.PressB(0,$false,$true)|Out-Null;$p.Tick(.1,$true,$true,$true,$false)|Out-Null
$p.Tick(.2,$true,$true,$false,$true)|Out-Null;$p.Tick(.4,$true,$true,$false,$true)|Out-Null
$p.Tick(.5,$true,$true,$false,$false,$true,.1)|Out-Null
if($p.Stage -ne 'Inserted'){throw 'Seating magazine automatically grabbed slide'}
$p.Tick(.6,$true,$false,$false,$false,$true,.1)|Out-Null
$p.Tick(.7,$true,$true,$false,$false,$false,.1)|Out-Null
$p.Tick(.8,$true,$true,$false,$false,$true,.1)|Out-Null
if($p.Stage -ne 'RackHolding'){throw 'Grip started just outside handle could not capture'}
$p.Tick(.9,$true,$true,$false,$false,$false,.16)|Out-Null
$p.Tick(1,$true,$true,$false,$false,$false,.1)|Out-Null
if(!$p.Tick(1.1,$true,$false,$false,$false,$false,.1)){throw 'Full pull return release lost stroke'}
'PASS 39 continuing shot sounds, first-shot deduplication, empty/other-gun rejection, exception cleanup; separate magazine/slide grabs, approach capture and pull-return-release.'
