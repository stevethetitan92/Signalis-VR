using UnityEngine;
using UnityStandardAssets.ImageEffects;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly ScreenOverlay[] doorEyeFade=new ScreenOverlay[2];
  private bool doorFadeReported;
  private void RenderNativeDoorFade(int eyeIndex) {
   // Camera.CopyFrom copies camera settings, not the native image effect.
   // Apply its live parameters once, AFTER world and UI rendering, so the
   // native ConnectedDoors transfer is hidden by the same fade as desktop.
   if(!DoorCameraEligible())return;
   // ConnectedDoors.delayedFadeIn/Out resolve MainFader on cameraMain.
   // Prefer that same component over a potentially stale cached MasterFader.
   var main=global::PlayerState.cameraMain;
   var fader=main==null?null:main.GetComponent<global::MainFader>();
   if(fader==null)fader=global::PlayerState.MasterFader;
   if(fader==null||fader.so==null||!fader.so.isActiveAndEnabled)return;
   var source=fader.so;
   if(source.intensity<=0f||source.overlayShader==null)return;
   var overlay=doorEyeFade[eyeIndex];
   if(overlay==null) {
    overlay=eyes[eyeIndex].gameObject.AddComponent<ScreenOverlay>();
    overlay.enabled=false;doorEyeFade[eyeIndex]=overlay;
   }
   // These are private components/materials; never alter the story fader.
   overlay.enabled=false;overlay.blendMode=source.blendMode;
   overlay.intensity=source.intensity;overlay.texture=source.texture;
   overlay.overlayShader=source.overlayShader;
   var target=textures[eyeIndex];
   var temporary=RenderTexture.GetTemporary(target.width,target.height,0,target.format);
   try {overlay.OnRenderImage(target,temporary);Graphics.Blit(temporary,target);}
   finally {RenderTexture.ReleaseTemporary(temporary);}
   if(!doorFadeReported){doorFadeReported=true;MelonLogger.Msg("VR DOOR FADE: native ScreenOverlay mirrored after eye/UI render; intensity="+source.intensity+" blend="+source.blendMode+" texture="+(source.texture==null?"native shader default":source.texture.name));}
  }
 }
}
