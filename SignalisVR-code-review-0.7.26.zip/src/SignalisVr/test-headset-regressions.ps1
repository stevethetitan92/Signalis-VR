$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'ManualReload.cs') -Raw
$method=[regex]::Match($source,'  private bool ManualReloadBlocksAttack\(\)\{[^\r\n]+').Value.Replace('private bool','public bool')
$fixture=@'
namespace SignalisVrTracking {
 public class ActiveState {public bool Active;}
 public sealed class Tracking {
  public bool Pistol,Shotgun,Additional,AdditionalActive;
  public ActiveState manualReload=new ActiveState(),shotgunReload=new ActiveState();
  public bool questAvailabilityValue=true,questMenuScene,pauseMenuVisible,bookScreenVisible,dialogueScreenVisible;
  private bool ManualPistolEligible(){return Pistol;}private bool ManualShotgunEligible(){return Shotgun;}private bool AdditionalGunEligible(){return Additional;}private bool AdditionalReloadActive(){return AdditionalActive;}
'@
Add-Type -TypeDefinition ($fixture+$method+'}}')
foreach($gun in 0..3){foreach($state in 0..7){
 $q=[SignalisVrTracking.Tracking]::new();$q.Pistol=$gun -eq 1;$q.Shotgun=$gun -eq 2;$q.Additional=$gun -eq 3
 $q.manualReload.Active=($state -band 1) -ne 0;$q.shotgunReload.Active=($state -band 2) -ne 0;$q.AdditionalActive=($state -band 4) -ne 0
 $expected=($q.Pistol -and $q.manualReload.Active) -or ($q.Shotgun -and $q.shotgunReload.Active) -or ($q.Additional -and $q.AdditionalActive)
 if($q.ManualReloadBlocksAttack() -ne $expected){throw 'A different gun reload state blocked firing'}
}}
'PASS: actual attack guard, 32 weapon/state combinations; stale shotgun pump cannot block rifle/SMG/pistol.'
Add-Type -TypeDefinition @'
using System;using System.IO;
public static class RifleSurfaceCheck {
 public static void Check(string encoded){using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(encoded)))){
  int count=r.ReadInt32(),hits=0;for(int part=0;part<count;part++){int role=r.ReadInt32(),mat=r.ReadInt32(),nv=r.ReadInt32(),nt=r.ReadInt32();float[,] v=new float[nv,3];for(int i=0;i<nv;i++)for(int j=0;j<3;j++){float x=r.ReadSingle();if(float.IsNaN(x)||float.IsInfinity(x))throw new Exception("Invalid vertex");v[i,j]=x;}r.BaseStream.Position+=nv*8;
   for(int i=0;i<nt;i+=3){int a=r.ReadInt32(),b=r.ReadInt32(),c=r.ReadInt32();if(a<0||b<0||c<0||a>=nv||b>=nv||c>=nv)throw new Exception("Bad triangle");if(part!=1)continue;
    double y1=v[b,1]-v[a,1],z1=v[b,2]-v[a,2],y2=v[c,1]-v[a,1],z2=v[c,2]-v[a,2],dy=.04-v[a,1],dz=.4-v[a,2],det=y1*z2-y2*z1;if(Math.Abs(det)<1e-12)continue;double u=(dy*z2-y2*dz)/det,w=(y1*dz-dy*z1)/det;if(u>=-1e-6&&w>=-1e-6&&u+w<=1+1e-6)hits++;
   }
  }if(hits<2)throw new Exception("Outer barrel sides are missing");
 }}
}
'@
$data=Get-Content (Join-Path $PSScriptRoot 'SelectedModelData.cs') -Raw
[RifleSurfaceCheck]::Check([regex]::Match($data,'Rifle="([^"]+)').Groups[1].Value)
'PASS: rifle finite geometry, valid indices, restored barrel side coverage.'
$hip=Get-Content (Join-Path $PSScriptRoot 'HipAmmo.cs') -Raw
foreach($kind in @('Pistol','Shotgun','SMG','Revolver','Rifle','FlareGun')){if(!$hip.Contains('"'+$kind+'"')){throw "Missing hip type $kind"}}
if($hip.Contains('w.magAmmo') -or $hip.Contains('ShotgunReserve')){throw 'Hip display depends on gun fullness/reserve'}
'PASS source integration: six firearm hip types, display independent of loaded/reserve count. Headset visibility remains unverified.'
