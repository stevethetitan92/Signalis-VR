$ErrorActionPreference='Stop'
$stub=@'
using System;
using N=System.Numerics;
using UnityEngine;
namespace UnityEngine {
 public struct Vector3 {
  public N.Vector3 v;public float z {get{return v.Z;}}
  public Vector3(float x,float y,float z){v=new N.Vector3(x,y,z);}
  public static Vector3 operator +(Vector3 a,Vector3 b){return new Vector3{v=a.v+b.v};}
  public static Vector3 operator -(Vector3 a,Vector3 b){return new Vector3{v=a.v-b.v};}
  public static Vector3 operator *(Vector3 a,float s){return new Vector3{v=a.v*s};}
  public static Vector3 operator /(Vector3 a,float s){return new Vector3{v=a.v/s};}
 }
 public struct Quaternion {
  public N.Quaternion q;
  public static Quaternion Inverse(Quaternion a){return new Quaternion{q=N.Quaternion.Inverse(a.q)};}
  public static Vector3 operator *(Quaternion a,Vector3 b){return new Vector3{v=N.Vector3.Transform(b.v,a.q)};}
 }
}
'@
$checks=@'
public static class GripTravelTests {
 public static void Run(){
  foreach(float scale in new[]{1f,5f})for(int i=0;i<72;i++){
   var q=new Quaternion{q=N.Quaternion.CreateFromYawPitchRoll(i*.17f,i*.09f,i*.23f)};
   var hq=new Quaternion{q=N.Quaternion.CreateFromYawPitchRoll(i*.13f,i*.21f,i*.11f)};
   var gun=new Vector3(2,3,-1);
   var contact=gun+q*new Vector3(-.04f,.06f,.2f)*scale;
   var hand=contact-hq*new Vector3(.025f,.04f,.035f)*scale;
   var p=new SignalisVrTracking.GripTravel();p.Begin(hand,hq,gun,q,contact,scale);
   foreach(float distance in new[]{-.04f,0f,.015f,.03f,.06f}){
    var moved=hand+q*new Vector3(0,0,-distance)*scale;
    float actual=p.Pull(moved,hq,gun,q,scale);
    if(Math.Abs(actual-distance)>.00001f)throw new Exception("Orientation dependent pull");
    var delta=new Vector3(1,-2,3);
    if(Math.Abs(p.Pull(moved+delta,hq,gun+delta,q,scale)-distance)>.00001f)throw new Exception("Shared movement counted as pull");
   }
   var newRotation=new Quaternion{q=N.Quaternion.CreateFromYawPitchRoll(.7f,.4f,.9f)};
   var rotatedHand=contact-newRotation*new Vector3(.025f,.04f,.035f)*scale;
   if(Math.Abs(p.Pull(rotatedHand,newRotation,gun,q,scale))>.00001f)throw new Exception("Wrist pivot counted as pull");
  }
 }
}
'@
Add-Type -TypeDefinition ($stub+(Get-Content (Join-Path $PSScriptRoot 'GripTravel.cs') -Raw).Replace('using UnityEngine;','')+$checks)
[GripTravelTests]::Run()
'PASS grabbed-point travel: 72 orientations, two scales, forward/rearward strokes, shared translation, wrist rotation about contact.'
