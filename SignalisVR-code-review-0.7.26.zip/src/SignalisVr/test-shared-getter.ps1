$ErrorActionPreference='Stop'
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
 $t=$a.MainModule.Types|Where-Object Name -eq Tracking
 if(@($t.Methods|Where-Object Name -eq QuestInputStatePrefix).Count -ne 0){throw 'Shared getter override remains'}
 $setup=$t.Methods|Where-Object Name -eq InstallQuestFirstPerson
 $strings=@($setup.Body.Instructions|Where-Object {$_.OpCode.Name -eq 'ldstr'}|ForEach-Object Operand)
 if($strings -contains 'GetInputState'){throw 'Shared native getter still patched'}
 foreach($name in 'OnGUI','isMouseKeyboard','isControlerInput'){if($strings -notcontains $name){throw "Input-mode adapter missing $name"}}
 $audit=Get-Content (Join-Path $PSScriptRoot '../../outputs/SignalisVrCutscene0480/evidence/native-hook-address-audit.txt')
 foreach($address in '0x60ABF0','0x60AEE0','0x60AD60','0x1202670','0x12058D0','0x12034F0','0x1205710'){
  if(@($audit|Where-Object {$_.StartsWith($address+' ')}).Count -ne 1){throw "Shared/unknown hook address: $address"}
 }
 $shared=@($audit|Where-Object {$_.StartsWith('0x299B70 ')})
 if($shared.Count -lt 2 -or -not ($shared -match 'Collections.Generic.List.*get_Count') -or -not ($shared -match 'Collections.Generic.Stack.*get_Count')){throw 'Missing reproduction evidence for shared getter'}
 'PASS: shared GetInputState hook absent from compiled patch setup; 7 remaining native hook addresses unique in inspected metadata; List/Stack collision reproduced statically. Runtime unverified.'
}finally{$a.Dispose()}
