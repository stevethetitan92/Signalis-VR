$ErrorActionPreference='Stop'
$routing=Get-Content (Join-Path $PSScriptRoot 'QuestLookRouting.cs') -Raw
$gate=$routing.Substring($routing.IndexOf(' private string QuestLookBlocker('))
$gate=$gate.Substring(0,$gate.IndexOf(' private void TraceQuestLook('))
$s=Get-Content (Join-Path $PSScriptRoot 'QuestFirstPerson.cs') -Raw
$axis=$s.Substring($s.IndexOf('  private static float QuestFpAxis('))
$axis=$axis.Substring(0,$axis.IndexOf('  private static bool QuestFpKey('))
$stub=@'
using System;using System.Reflection;using UnityEngine;
namespace UnityEngine {public class GameObject{} public static class Input{public static float GetAxis(string n){return .25f;}}public static class Mathf{public static float Clamp(float v,float a,float b){return Math.Min(b,Math.Max(a,v));}}public static class Time{public static float unscaledDeltaTime=.01f;}}
public static class PlayerState{public enum gameStates{play,paused,menu,inventory,book,loading,dialogue,eventScreen}public static gameStates gameState;public static bool gameOver,cutscene,suspendInput;public static int hp=100;}
public static class BlackSleekGuiSubs{public static bool itemView;}
public class AlternatePlayerController{public bool playing=true,traversing;}
public class Adapter{public GameObject model=new GameObject();public AlternatePlayerController player=new AlternatePlayerController();public float sensitivity=1;}
public class Policy{public bool RightArmed=true;}public class Wheel{public bool Open;}
public class Frame{public float lookX=.5f,lookY=-.75f,moveX,moveY;}
public static class QuestInputPolicy{public static float LookAxis(float v,float dt,float sensitivity){return v;}}
public class Harness {
static Harness questOwner;bool available=true,door,modMenuOpen,questFpPatched=true,stereo=true;public bool pauseMenuVisible=true,dialogueScreenVisible=true;Policy questPolicy=new Policy();Wheel quickSelect=new Wheel();Frame questFrame=new Frame();object questFpMod=new Adapter();FieldInfo questFpPlayer=typeof(Adapter).GetField("player"),questFpModel=typeof(Adapter).GetField("model"),questFpSensitivity=typeof(Adapter).GetField("sensitivity");float questStereoPitch;
bool QuestAvailableNow(){return available;}bool DoorCameraBlocked(){return door;}bool QuestFirstPersonReady(){return true;}void QuestLookConsumed(string s){}
static void Check(bool v,string s){if(!v)throw new Exception(s);}
public static void Run(){var q=new Harness();questOwner=q;
Check(q.QuestLookBlocker(false)==null,"stale cached UI flags must not reject gameplay");
Check(QuestFpAxis("Mouse X")==.75f&&QuestFpAxis("Mouse Y")==.25f,"horizontal stick plus physical mouse; vertical stick disabled");
foreach(PlayerState.gameStates state in new[]{PlayerState.gameStates.dialogue,PlayerState.gameStates.book,PlayerState.gameStates.inventory,PlayerState.gameStates.menu,PlayerState.gameStates.paused,PlayerState.gameStates.loading}){PlayerState.gameState=state;Check(q.QuestLookBlocker(false)!=null,"native state guard");Check(QuestFpAxis("Mouse X")==.25f&&QuestFpAxis("Mouse Y")==.25f,"preserve mouse while VR gated");PlayerState.gameState=PlayerState.gameStates.play;Check(q.QuestLookBlocker(false)==null,"gameplay return restores input");}
PlayerState.gameState=PlayerState.gameStates.eventScreen;Check(q.QuestLookBlocker(true)==null&&q.QuestLookBlocker(false)!=null,"native camera gets event route");
BlackSleekGuiSubs.itemView=true;Check(q.QuestLookBlocker(true)!=null,"item view blocks native look");BlackSleekGuiSubs.itemView=false;
PlayerState.gameState=PlayerState.gameStates.play;PlayerState.cutscene=true;Check(q.QuestLookBlocker(false)!=null,"cutscene");PlayerState.cutscene=false;
PlayerState.suspendInput=true;Check(q.QuestLookBlocker(false)!=null,"suspend");PlayerState.suspendInput=false;
q.door=true;Check(q.QuestLookBlocker(false)!=null,"traversal");q.door=false;q.available=false;Check(q.QuestLookBlocker(false)!=null,"focus");q.available=true;
q.questPolicy.RightArmed=false;Check(q.QuestLookBlocker(false)!=null,"reconnect");q.questPolicy.RightArmed=true;q.quickSelect.Open=true;Check(q.QuestLookBlocker(false)!=null,"wheel");q.quickSelect.Open=false;q.modMenuOpen=true;Check(q.QuestLookBlocker(false)!=null,"mod menu");q.modMenuOpen=false;
Check(QuestFpAxis("Mouse X")==.75f&&QuestFpAxis("Mouse Y")==.25f,"final recovery X, physical Y");questOwner=null;Check(QuestFpAxis("Mouse X")==.25f,"mouse without adapter");}
'@
Add-Type -TypeDefinition ($stub+$gate+$axis+'}')
[Harness]::Run()
'PASS production look gate and axis method: X/Y, physical mouse, stale UI flags, genuine state suppression and repeated recovery. Native headset control still requires playtest.'
