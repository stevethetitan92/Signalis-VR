using System;
namespace SignalisVrTracking {
 public sealed class RifleHingePolicy {
  public const float MaxAngle=65f;
  public float TravelLimit=MaxAngle;
  public float Angle {get;private set;}
  private float velocity,closeStart,closeTime;private bool wasOpen;
  public void Reset(){Angle=velocity=closeStart=closeTime=0;wasOpen=false;}
  public float Tick(float dt,bool open,bool grabbed,float desired,float gravityY,float gravityZ,float handPitch){
   if(float.IsNaN(dt)||float.IsInfinity(dt)||dt<=0)return Angle;
   if(dt>.1f){velocity=0;return Angle;}
   if(!open){
    if(wasOpen){closeStart=Angle;closeTime=0;}closeTime+=dt;
    Angle=closeStart*(1-RifleBarrelMotion.Ease(closeTime/RifleBarrelMotion.CloseSeconds));velocity=0;wasOpen=false;return Angle;
   }
   wasOpen=true;
   if(grabbed){Angle=Math.Max(0,Math.Min(TravelLimit,desired));velocity=0;return Angle;}
   // Damped, bounded hinge. Inputs are weapon-local gravity and gun-hand pitch.
   if(!float.IsNaN(handPitch)&&Math.Abs(handPitch)<35)velocity-=handPitch*.3f/dt;
   int steps=Math.Max(1,(int)Math.Ceiling(dt/.008f));float step=dt/steps;
   for(int i=0;i<steps;i++){
    double a=Angle*Math.PI/180;float torque=(float)(-Math.Cos(a)*gravityY-Math.Sin(a)*gravityZ);
    velocity+=(torque*1100-velocity*3.5f)*step;Angle+=velocity*step;
    if(Angle<=0){Angle=0;velocity=Math.Max(0,velocity);}if(Angle>=TravelLimit){Angle=TravelLimit;velocity=Math.Min(0,velocity);}
   }
   return Angle;
  }
 }
}
