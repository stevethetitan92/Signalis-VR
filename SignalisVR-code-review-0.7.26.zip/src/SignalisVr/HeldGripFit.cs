using System;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly Vector3[][] fingerPads={null,null};
  private void CacheFingerPads(int hand,Mesh source,bool[] allowed) {
   var positions=source.vertices;var weights=source.boneWeights;var bind=source.bindposes;fingerPads[hand]=new Vector3[allowed.Length];
   for(int b=0;b<allowed.Length;b++)if(allowed[b]) {
    Vector3 sum=Vector3.zero;float total=0;
    for(int v=0;v<positions.Length;v++){var w=weights[v];float amount=(w.boneIndex0==b?w.weight0:0)+(w.boneIndex1==b?w.weight1:0)+(w.boneIndex2==b?w.weight2:0)+(w.boneIndex3==b?w.weight3:0);if(amount<.6f)continue;sum+=bind[b].MultiplyPoint3x4(positions[v])*amount;total+=amount;}
    if(total>0)fingerPads[hand][b]=sum/total;
   }
  }
  private int FingerBone(int hand,string finger,string segment) {
   var sources=handSourceBones[hand];if(sources==null)return -1;
   for(int i=0;i<sources.Length;i++)if(sources[i]!=null){string name=sources[i].name.ToLowerInvariant();if(name.Contains(finger)&&name.Contains(segment))return i;}return -1;
  }
  private void FitFingerToContact(int hand,string finger,Vector3 target,int iterations) {
   if(!handsScoped||fingerPads[hand]==null)return;int tip=FingerBone(hand,finger,"03");if(tip<0)return;var end=handCopyBones[hand][tip];
   int[] chain={tip,FingerBone(hand,finger,"02"),FingerBone(hand,finger,"01")};
   for(int pass=0;pass<iterations;pass++)foreach(int b in chain)if(b>=0) {
    var joint=handCopyBones[hand][b];var from=end.TransformPoint(fingerPads[hand][tip])-joint.position;var to=target-joint.position;if(from.sqrMagnitude<1e-10f||to.sqrMagnitude<1e-10f)continue;
    var turn=Quaternion.FromToRotation(from,to);turn=Quaternion.RotateTowards(Quaternion.identity,turn,12f);joint.rotation=turn*joint.rotation;
   }
  }
  private void FitHandAroundBox(int hand,Transform frame,Vector3 center,Vector3 size) {
   if(frame==null||fingerPads[hand]==null)return;
   var palm=frame.InverseTransformPoint(handsObjects[hand].transform.TransformPoint(handPalmCenters[hand]))-center;var halfPalm=size*.5f;
   if(Math.Abs(palm.x)<halfPalm.x+.012f&&Math.Abs(palm.y)<halfPalm.y+.012f&&Math.Abs(palm.z)<halfPalm.z+.012f){
    var away=palm;if(away.sqrMagnitude<1e-8f)away=Vector3.left;int axis=Math.Abs(away.x/Math.Max(.001f,halfPalm.x))>Math.Abs(away.z/Math.Max(.001f,halfPalm.z))?0:2;var surface=palm;if(axis==0)surface.x=(palm.x<0?-1:1)*halfPalm.x;else surface.z=(palm.z<=0?-1:1)*halfPalm.z;var normal=axis==0?new Vector3(palm.x<0?-1:1,0,0):new Vector3(0,0,palm.z<=0?-1:1);handsObjects[hand].transform.position+=frame.TransformPoint(center+surface)+frame.TransformDirection(normal).normalized*(.020f*UnitsPerMetre)-frame.TransformPoint(center+palm);
   }
   string[] fingers={"middle","ring","pinky","index","thumb"};
   foreach(string finger in fingers){int b=FingerBone(hand,finger,"03");if(b<0)continue;var point=frame.InverseTransformPoint(handCopyBones[hand][b].TransformPoint(fingerPads[hand][b]));var half=size*.5f;var local=point-center;
    // Pad centers remain outside the handle by a glove-thickness allowance.
    var q=new Vector3(Mathf.Clamp(local.x,-half.x,half.x),Mathf.Clamp(local.y,-half.y,half.y),Mathf.Clamp(local.z,-half.z,half.z));
    var outside=local-q;if(outside.sqrMagnitude<1e-10f){float dx=half.x-Math.Abs(local.x),dy=half.y-Math.Abs(local.y),dz=half.z-Math.Abs(local.z);if(dx<=dy&&dx<=dz)outside=new Vector3(local.x<0?-1:1,0,0);else if(dy<=dz)outside=new Vector3(0,local.y<0?-1:1,0);else outside=new Vector3(0,0,local.z<0?-1:1);}
    FitFingerToContact(hand,finger,frame.TransformPoint(center+q)+frame.TransformDirection(outside).normalized*(.006f*UnitsPerMetre),6);
   }
  }
  private void FitMeleeHandle(Transform frame,Vector3 center,Vector3 size){
   if(frame==null||fingerPads[1]==null||!handsScoped)return;
   var hand=handsObjects[1].transform;
   int indexBase=FingerBone(1,"index","01"),pinkyBase=FingerBone(1,"pinky","01");
   if(indexBase>=0&&pinkyBase>=0){var across=handCopyBones[1][indexBase].position-handCopyBones[1][pinkyBase].position;if(across.sqrMagnitude>1e-8f)hand.rotation=Quaternion.FromToRotation(across,frame.forward)*hand.rotation;}
   var palm=frame.InverseTransformPoint(hand.TransformPoint(handPalmCenters[1]))-center;
   // A long handle is gripped around its cross-section, never pushed toward an end cap.
   var normal=new Vector3(palm.x,palm.y,0);if(normal.sqrMagnitude<.000001f){normal=frame.InverseTransformDirection(hand.right);normal.z=0;}if(normal.sqrMagnitude<.000001f)normal=Vector3.right;normal.Normalize();
   var half=size*.5f;float radius=1f/Math.Max(Math.Abs(normal.x)/half.x,Math.Abs(normal.y)/half.y);
   var contact=center+normal*(radius+.016f);contact.z=center.z;
   hand.position+=frame.TransformPoint(contact)-hand.TransformPoint(handPalmCenters[1]);
   string[] fingers={"index","middle","ring","pinky","thumb"};float[] station={.035f,.014f,-.007f,-.028f,.038f};
   for(int i=0;i<fingers.Length;i++){
    // Four fingers curl onto the far face; the thumb rests over the index finger.
    var direction=i==4?normal:-normal;var target=center+direction*(radius+.008f);target.z=center.z+station[i];
        if(i==4){int index=FingerBone(1,"index","02");if(index>=0){var pad=frame.InverseTransformPoint(handCopyBones[1][index].TransformPoint(fingerPads[1][index]));var outward=new Vector3(pad.x-center.x,pad.y-center.y,0);if(outward.sqrMagnitude<.000001f)outward=-normal;outward.Normalize();target=pad+outward*.013f;target.z+=.004f;}}
    FitFingerToContact(1,fingers[i],frame.TransformPoint(target),10);
   }
   // Correct individual phalanx pad centers too, not just fingertips.
   for(int pass=0;pass<3;pass++)foreach(string finger in fingers)foreach(string segment in new[]{"01","02","03"}){
    int b=FingerBone(1,finger,segment);if(b<0)continue;var bone=handCopyBones[1][b];var local=frame.InverseTransformPoint(bone.TransformPoint(fingerPads[1][b]))-center;
    if(Math.Abs(local.z)>half.z+.006f||Math.Abs(local.x)>=half.x+.007f||Math.Abs(local.y)>=half.y+.007f)continue;
    var outward=new Vector3(local.x,local.y,0);if(outward.sqrMagnitude<.000001f)outward=normal;outward.Normalize();float r=1f/Math.Max(Math.Abs(outward.x)/half.x,Math.Abs(outward.y)/half.y);
    var target=center+outward*(r+.008f);target.z=center.z+Mathf.Clamp(local.z,-half.z,half.z);
    var joint=bone.parent;if(joint==null)continue;var from=bone.TransformPoint(fingerPads[1][b])-joint.position;var to=frame.TransformPoint(target)-joint.position;
    if(from.sqrMagnitude>1e-10f&&to.sqrMagnitude>1e-10f)joint.rotation=Quaternion.RotateTowards(Quaternion.identity,Quaternion.FromToRotation(from,to),10f)*joint.rotation;
   }
  }
  private void FitHeldToolHands() {
   if(!handsScoped)return;

   if(shotgunShell!=null&&shotgunShell.enabled)FitHandAroundBox(0,shotgunShell.transform,Vector3.zero,Vector3.one*.94f);


   FitImportedThermite();
  }
 }
}


