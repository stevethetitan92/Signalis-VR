using System;
using System.Collections.Generic;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly ProdSwingPolicy prodSwing=new ProdSwingPolicy();
  private GameObject prodRoot;
  private readonly List<MeshRenderer> prodParts=new List<MeshRenderer>();
  private readonly List<Material> prodMaterials=new List<Material>();
  private bool prodFailed,prodSampled,prodHooksReady;
  private int prodFrame=-1,prodReports;
  private float prodTime,prodQueuedTime,prodFlashUntil;
  private Vector3 prodRawTip,prodWorldTip,prodQueuedStart,prodQueuedEnd;
  private global::Room prodRoom;
  private Collider prodQueued;
  private GameObject prodBar;
  private readonly List<MeshRenderer> prodSegments=new List<MeshRenderer>();
  private readonly List<MeshRenderer> prodBarParts=new List<MeshRenderer>();
  private const string ProdDurabilityKey="SignalisVR.NoMarkers.StunProd.RemainingHits.v1";
  private int ProdUses(){return ProdDurability.Normalize(global::SProgress.GetInt(ProdDurabilityKey,ProdDurability.Capacity));}
  private const float ProdLength=.30f,ProdRadius=.025f;
  private bool ProdVrMode(){return active&&stereo&&!desktopMouseOnly&&!mouseWeaponTest&&!stopping;}
  private static bool ProdSelected(){var t=global::InventoryManager.EquippedTool;return t!=null&&t._item==global::Items.itemlist.Taser;}
  private static bool ProdHandOccupied(){var w=global::InventoryManager.EquippedWeapon;return w!=null&&w.parentItem!=null;}
  private bool ProdEligible() {
   return prodHooksReady&&!prodFailed&&ProdVrMode()&&ProdSelected()&&!ProdHandOccupied()&&ControllerWeaponVisualReady()
    &&questPolicy.RightArmed&&!quickSelect.Open&&!modMenuOpen&&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput
    &&!global::PlayerState.grappled&&!global::PlayerState.hurt&&!global::PlayerState.animating&&!global::PlayerState.reloading
    &&global::PlayerState.hp>0&&global::InventoryManager.hasItem(global::InventoryManager.EquippedTool);
  }
  private bool PrepareProdHand(global::InventoryBase inventory) {
   var weapon=global::InventoryManager.EquippedWeapon;
   if(weapon!=null&&weapon.parentItem!=null)inventory.EquipWeapon(weapon.parentItem);
   if(ProdHandOccupied())return false;
   heldQuickHealth=null;quickPreviousWeapon=null;quickUse.Reset();HideQuickHealth();
   CancelManualReload();ResetProdSample();quickBlockFire=true;
   return true;
  }
  private static bool ProdEquipGuard(global::InventoryBase __instance,global::AnItem __0) {
   if(weaponOwner==null||!weaponOwner.ProdVrMode()||!weaponOwner.prodHooksReady||weaponOwner.prodFailed||weaponOwner.handsFailed||weaponOwner.weaponAimFailed||__0==null||__0._item!=global::Items.itemlist.Taser)return true;
   if(global::InventoryManager.EquippedTool==__0)return true; // Native toggle-off.
   try{return weaponOwner.PrepareProdHand(__instance);}catch(Exception ex){weaponOwner.ProdReport("Cannot equip now: "+ex.Message);return false;}
  }
  private static bool ProdNativeUseGuard(ref bool __result) {
   if(weaponOwner==null||!weaponOwner.ProdVrMode()||!weaponOwner.prodHooksReady||weaponOwner.prodFailed||weaponOwner.handsFailed||weaponOwner.weaponAimFailed||!ProdSelected())return true;
   // The native automatic/button hit would bypass physical contact and wear.
   __result=false;return false;
  }
  private static bool ProdFrozenUpdate(global::EnemyController __instance){return weaponOwner==null||!weaponOwner.ProdIsFrozen(__instance);}
  private void InstallSwingProd(HarmonyLib.Harmony h){
   try {

   h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),"Update",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(ProdFrozenUpdate)));
   h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"EquipTool",new[]{typeof(global::AnItem)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(ProdEquipGuard)));
   h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"Taser",Type.EmptyTypes),prefix:new HarmonyMethod(typeof(Tracking),nameof(ProdNativeUseGuard)));
   prodHooksReady=true;
   }catch(Exception ex){prodHooksReady=false;MelonLogger.Warning("Physical stun prod unavailable; native tool retained: "+ex.Message);}
  }
  private void ProdReport(string s){if(prodReports++<80)MelonLogger.Msg("VR STUN PROD: "+s);}
  private void ResetProdSample(){prodSampled=false;prodQueued=null;prodSwing.Reset();}
  private static bool ProdEnemyValid(global::EnemyController e){return e!=null&&e.gameObject.activeInHierarchy&&e.state!=global::EnemyController.enemystate.dead&&e.hitbox!=null&&e.hitbox.HP>0;}
  // Input/update phase only. Rendering queues contact but never consumes inventory.
  private void PollSwingProd() {
   try { PollProdContact(); }
   catch(Exception ex){prodFailed=true;prodPoseValid=false;StopProdAudio();HideSwingProd();MelonLogger.Warning("VR prod contact disabled: "+ex.Message);}
  }
  private void PrepareSwingProd() {
   HideSwingProd();
   if(!ProdPowered()||!prodPoseValid||!handsScoped)return;
   prodRoot.transform.SetPositionAndRotation(prodResolved,prodResolvedRotation);
   foreach(var p in prodParts)p.enabled=true;
   ShowProdEffects();
  }
  // Lightweight closed geometry in the game's angular style; no native scripts cloned.
  private Mesh prodBodyMesh,prodHousingMesh;
  private Mesh ProdOctagonalMesh(){
   var v=new List<Vector3>();var t=new List<int>();
   var profile=new[]{new Vector2(-.35f,-.5f),new Vector2(.35f,-.5f),new Vector2(.5f,-.35f),new Vector2(.5f,.35f),new Vector2(.35f,.5f),new Vector2(-.35f,.5f),new Vector2(-.5f,.35f),new Vector2(-.5f,-.35f)};for(int end=0;end<2;end++)foreach(var p in profile)v.Add(new Vector3(p.x,p.y,end-.5f));
   for(int i=1;i<7;i++)t.AddRange(new[]{0,i+1,i,8,8+i,8+i+1});
   for(int i=0;i<8;i++){int j=(i+1)%8;t.AddRange(new[]{i,j,j+8,i,j+8,i+8});}
   var mesh=new Mesh();mesh.name="Stun prod octagonal body";mesh.vertices=v.ToArray();mesh.triangles=t.ToArray();mesh.RecalculateBounds();mesh.RecalculateNormals();return mesh;
  }
  private Mesh ProdHousingProfile(){
   // Continuous tapered casing traced from the supplied prop silhouette.
   float[] z={.062f,.076f,.088f,.121f,.148f,.165f,.270f};
   float[] width={.027f,.031f,.043f,.039f,.027f,.025f,.025f};
   float[] depth={.025f,.026f,.026f,.024f,.023f,.022f,.022f};
   var ring=new[]{new Vector2(-.37f,-.5f),new Vector2(.37f,-.5f),new Vector2(.5f,-.30f),new Vector2(.5f,.30f),new Vector2(.37f,.5f),new Vector2(-.37f,.5f),new Vector2(-.5f,.30f),new Vector2(-.5f,-.30f)};
   var vertices=new List<Vector3>();var triangles=new List<int>();
   for(int k=0;k<z.Length;k++)foreach(var p in ring)vertices.Add(new Vector3(p.x*width[k],p.y*depth[k],z[k]));
   for(int k=0;k<z.Length-1;k++)for(int i=0;i<8;i++){int a=k*8+i,b=k*8+(i+1)%8;triangles.AddRange(new[]{a,b,b+8,a,b+8,a+8});}
   int end=(z.Length-1)*8;for(int i=1;i<7;i++)triangles.AddRange(new[]{0,i+1,i,end,end+i,end+i+1});
   var mesh=new Mesh();mesh.name="Reference tapered stun prod housing";mesh.vertices=vertices.ToArray();mesh.triangles=triangles.ToArray();mesh.RecalculateBounds();mesh.RecalculateNormals();return mesh;
  }  private void EnsureProdVisual() {
   if(prodRoot!=null)return;
   prodRoot=new GameObject("SignalisVR_DisposableStunProd");UnityEngine.Object.DontDestroyOnLoad(prodRoot);
   var shader=Shader.Find("Unlit/Color");if(shader==null)throw new InvalidOperationException("Prod shader unavailable");
   foreach(var color in new[]{new Color(.055f,.06f,.065f),new Color(.48f,.50f,.51f),new Color(.55f,.025f,.02f),new Color(.03f,.45f,.58f),new Color(.09f,.095f,.10f),new Color(.80f,.81f,.78f)}){var m=new Material(shader);m.color=color;prodMaterials.Add(m);}
   var cube=controllerBodies[1].GetComponent<MeshFilter>().sharedMesh;
   LoadHdMelee(prodRoot,HdProdData.Geometry,HdProdData.Textures,HdProdData.Colors,prodParts,prodMaterials,hdProdMeshes);
   // Turn the housing face around its long axis without twisting the saved wrist.
   foreach(var part in prodParts){part.transform.localPosition=Quaternion.Euler(0,0,180)*part.transform.localPosition;part.transform.localRotation=Quaternion.Euler(0,0,180)*part.transform.localRotation;}
   prodBar=new GameObject("StunProdDurability");prodBar.transform.SetParent(prodRoot.transform,false);
   for(int i=0;i<ProdDurability.Capacity;i++) {
    var p=new Vector3((i-2.5f)*.014f,0,0);
    prodBarParts.Add(CreateControllerPart(prodBar,cube,prodMaterials[1],"DurabilitySlot",p,new Vector3(.013f,.009f,.002f)));
    var segment=CreateControllerPart(prodBar,cube,prodMaterials[3],"Durability",p+new Vector3(0,0,-.002f),new Vector3(.01f,.006f,.002f));
    prodBarParts.Add(segment);prodSegments.Add(segment);
   }
   ProdReport("Right-hand swing tool ready; 30cm reference-style model; no gun may be equipped.");
  }
  private void ProdPart(Mesh mesh,string name,int material,Vector3 p,Vector3 s){prodParts.Add(CreateControllerPart(prodRoot,mesh,prodMaterials[material],name,p,s));}
  private void PrepareProdHud() {
   if(prodBar==null||modHudRoot==null||!modHudOn||!ProdEligible())return;
   prodBar.transform.position=modHudRoot.transform.TransformPoint(new Vector3(0,-.018f,-.002f)*UnitsPerMetre);
   prodBar.transform.rotation=modHudRoot.transform.rotation;
   prodBar.transform.localScale=modHudRoot.transform.lossyScale;
   foreach(var p in prodBarParts)if(p!=null)p.enabled=true;
   int uses=ProdUses();for(int i=0;i<prodSegments.Count;i++)prodSegments[i].enabled=i<uses;
  }
  private void HideSwingProd(){HideProdEffects();foreach(var p in prodParts)if(p!=null)p.enabled=false;foreach(var p in prodBarParts)if(p!=null)p.enabled=false;}
  private void DestroySwingProd(){ClearProdFrozen();foreach(var mesh in hdProdMeshes)if(mesh!=null)UnityEngine.Object.Destroy(mesh);hdProdMeshes.Clear();DestroyProdEffects();DestroyProdAudio();ResetProdSample();if(prodRoot!=null)UnityEngine.Object.Destroy(prodRoot);if(prodHousingMesh!=null)UnityEngine.Object.Destroy(prodHousingMesh);prodHousingMesh=null;if(prodBodyMesh!=null)UnityEngine.Object.Destroy(prodBodyMesh);prodBodyMesh=null;foreach(var m in prodMaterials)if(m!=null)UnityEngine.Object.Destroy(m);prodParts.Clear();prodBarParts.Clear();prodSegments.Clear();prodMaterials.Clear();prodRoot=null;prodBar=null;prodFailed=false;prodFrame=-1;}
 }
}








