$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'SmgStats.cs') -Raw
$start=$s.IndexOf('  private static void ConfigureSmg(');$end=$s.IndexOf('  private void InstallSmgStats(')
$method=$s.Substring($start,$end-$start).Replace('private static void ConfigureSmg','public static void ConfigureSmg')
Add-Type -TypeDefinition ('public class InventoryManager {public static int reserve=10;public static int getCount(object a){return reserve;}public static void SetCount(object a,int n){reserve=n;}}public class AnWeapon {public object ammoItem=new object();public bool fullAuto; public int burstSize=3,MagSize=30,magAmmo=12;} public class StatsHarness {'+$method+'}')
$weapon=[AnWeapon]::new();[StatsHarness]::ConfigureSmg($weapon)
if(!$weapon.fullAuto -or $weapon.burstSize -ne 1 -or $weapon.MagSize -ne 25 -or $weapon.magAmmo -ne 12){throw 'SMG auto/25-round configuration or ammo preservation wrong'}
[StatsHarness]::ConfigureSmg($weapon);[StatsHarness]::ConfigureSmg($null)
if(!$s.Contains('parentItem._item==global::Items.itemlist.SMG') -or !$s.Contains('"ReadyForAttack"')){throw 'SMG-only native attack integration missing'}
'PASS actual SMG full-auto/one-shot cycles/25 capacity/null/idempotence with existing rounds preserved. Native continuous firing and reload unverified.'

$weapon.magAmmo=40;[StatsHarness]::ConfigureSmg($weapon);if($weapon.magAmmo -ne 25 -or [InventoryManager]::reserve -ne 10){throw 'SMG configuration granted unsolicited reserve'};[StatsHarness]::ConfigureSmg($weapon);if([InventoryManager]::reserve -ne 10){throw 'Configuration changed reserve'}

