$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ProdSwingPolicy.cs')
function Check($v,$m){if(-not $v){throw $m}}
$p=[SignalisVrTracking.ProdSwingPolicy]::new()
Check (-not $p.Sample(.02,.03,$false)) 'Initial pose struck'
Check (-not $p.Sample(.02,.03,$true)) 'Priming pose struck'
Check (-not $p.Sample(.02,.03,$true)) 'Insufficient travel struck'
Check (-not $p.Sample(.02,.03,$true)) 'Insufficient travel struck'
Check ($p.Sample(.02,.03,$true)) 'Valid swing rejected'
$p.Spend()
1..10|ForEach-Object {Check (-not $p.Sample(.02,.03,$true)) 'Repeated hit in same swing'}
1..9|ForEach-Object {Check (-not $p.Sample(.02,.001,$true)) 'Rest struck'}
$p.Sample(.02,.04,$true)|Out-Null
$p.Sample(.02,.04,$true)|Out-Null
Check ($p.Sample(.02,.04,$true)) 'Rest did not rearm'
Check (-not $p.Sample(.2,.2,$true)) 'Tracking gap struck'
Check (-not $p.Sample(.02,.7,$true)) 'Teleport struck'
Check (-not $p.Sample(.02,[float]::NaN,$true)) 'Invalid pose struck'
$p.Reset()
1..30|ForEach-Object {Check (-not $p.Sample(.02,.009,$true)) 'Slow drift counted as swing'}
'Prod swing: speed, travel, repeat prevention, rearm and discontinuity checks PASS'
Add-Type -Path (Join-Path $PSScriptRoot 'ProdDurability.cs')
$uses=6
1..5|ForEach-Object {$uses=[SignalisVrTracking.ProdDurability]::Hit($uses);Check ($uses -gt 0) 'Rod consumed before sixth hit'}
Check ($uses -eq 1) 'Incorrect durability after five hits'
Check ([SignalisVrTracking.ProdDurability]::Hit($uses) -eq 0) 'Sixth hit did not exhaust rod'
Check ([SignalisVrTracking.ProdDurability]::Normalize(-10) -eq 6) 'Corrupt durability not normalized'
Check ([SignalisVrTracking.ProdDurability]::Normalize(4) -eq 4) 'Saved wear lost'
'Six-hit durability PASS'
$uses=3
1..1000|ForEach-Object {$uses=[SignalisVrTracking.ProdDurability]::Hit($uses,$true)}
Check ($uses -eq 3) 'Infinite prod lost durability'
Check ([SignalisVrTracking.ProdDurability]::Hit($uses,$false) -eq 2) 'OFF did not restore wear'
'PASS infinite prod freezes previous durability'
foreach($dt in @([float]::NaN,[float]::PositiveInfinity,0,-1)) {
 $p.Reset();Check (-not $p.Sample($dt,.09,$true)) 'Invalid time admitted strike'
}
foreach($hz in @(72,90,120)) {
 $p.Reset();$dt=1.0/$hz;$hit=$false
 $p.Sample($dt,.02,$false)|Out-Null
 1..15|ForEach-Object {if($p.Sample($dt,.02,$true)){$hit=$true}}
 Check $hit "Swing failed at $hz Hz"
 $p.Spend();1..30|ForEach-Object {Check (-not $p.Sample($dt,.02,$true)) 'Continuous contact duplicated hit'}
}
'PASS invalid time and 72/90/120Hz strike/repeat checks'
