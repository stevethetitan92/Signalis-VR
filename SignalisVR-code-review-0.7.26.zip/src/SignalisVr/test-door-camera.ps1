$ErrorActionPreference='Stop'
$policy=Get-Content (Join-Path $PSScriptRoot 'DoorCameraPolicy.cs') -Raw
Add-Type -TypeDefinition ($policy+@'
public static class DoorCameraTests {
 public static void Run() {
  var p=new SignalisVrTracking.DoorCameraPolicy();
  if(p.Observe(false,true,0)||p.Observe(false,false,1))throw new System.Exception("ordinary play/menu must not start a door");
  if(!p.Observe(true,false,2))throw new System.Exception("entry");
  if(!p.Observe(false,true,3)||!p.Observe(false,true,3.24f))throw new System.Exception("settling");
  if(!p.Observe(true,false,3.245f))throw new System.Exception("second connected-door half");
  if(!p.Observe(false,true,4)||!p.Observe(false,true,4.24f)||p.Observe(false,true,4.26f))throw new System.Exception("destination settle/reentry reset");
  p.Observe(true,false,5);p.Observe(false,true,6);
  if(!p.Observe(false,false,6.1f)||!p.Observe(false,true,10)||!p.Observe(false,true,10.2f)||p.Observe(false,true,10.26f))throw new System.Exception("disabled camera/cutscene interrupts settle");
  p.Observe(true,false,11);p.Reset();
  if(p.Active||p.Observe(false,true,12))throw new System.Exception("scene/stop reset");
 }
}
'@)
[DoorCameraTests]::Run()
'PASS actual handoff policy: ordinary play, traversal, both door halves, stability delay, interrupted readiness, lifecycle reset.'
$camera=Get-Content (Join-Path $PSScriptRoot 'DoorCamera.cs') -Raw
$tracking=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
$fp=Get-Content (Join-Path $PSScriptRoot 'QuestFirstPerson.cs') -Raw
foreach($needle in @('id!=doorCameraId||parentId!=doorParentId','return native;','questFpYaw.SetValue(questFpMod,doorYaw)','player.traversing||global::PlayerState.gameState','following native camera','if(DoorNativeTraversing())doorWorldBasis=native;')) {
 if(!$camera.Contains($needle)){throw "Missing camera handoff: $needle"}
}
if($camera -match 'player\.(transform\.(position|rotation)|fAngle|traversing)\s*=|\.velocity\s*='){throw 'Door handoff must not overwrite native traversal/player physics'}
foreach($needle in @('var viewBasis = DoorCameraBasis(','HeadPosition.Map(DoorCameraOrigin(camera.transform.position)','RememberDoorCamera(viewBasis);')) {
 if(!$tracking.Contains($needle)){throw "Missing stereo handoff: $needle"}
}
if(!$fp.Contains('if(q!=null&&q.DoorCameraBlocked())return false;') -or !$fp.Contains('questOwner.ObserveDoorCamera();')){throw 'Missing early heading/movement handoff'}
'PASS source integration guards: same camera/parent, native exit untouched, shared stereo basis, FP heading restoration and movement gating. Live graphics/headset unverified.'

# Execute the production methods; policy-only tests missed the frozen origin.
$origin=[regex]::Match($camera,'private Vector3 DoorCameraOrigin\(Vector3 native\)\{[^}]+\}').Value
$store=[regex]::Match($fp,'private static void QuestFpStoreYaw\(object mod,float proposed\) \{[\s\S]*?\n  \}').Value
if(!$origin -or !$store){throw 'Missing production methods for motion fixture'}
$fixture=@'
using System;
using System.Reflection;
public struct Vector3 { public float x,y,z; public Vector3(float a,float b,float c){x=a;y=b;z=c;} }
public sealed class Mod { public float x; }
public partial class Tracking {
 static Tracking questOwner;
 FieldInfo questFpYaw=typeof(Mod).GetField("x");
 bool blocked,nativeTraversal;float doorYaw=177.55f;
 bool DoorCameraBlocked(){return blocked;}
 bool DoorNativeTraversing(){return nativeTraversal;}
 public static void Run(){
  var q=new Tracking();questOwner=q;
  foreach(bool active in new[]{false,true}) {
   q.blocked=active;
   foreach(var v in new[]{new Vector3(-335,-955,-8.4f),new Vector3(-335,-964,-8.4f),new Vector3(-321,-1113,-8.4f),new Vector3(-323,-1646,-8.4f)}) {
    var got=q.DoorCameraOrigin(v);
    if(got.x!=v.x||got.y!=v.y||got.z!=v.z)throw new Exception("Door origin must follow native camera every frame, including room handoff");
   }
   foreach(bool traversing in new[]{false,true}) {
    q.nativeTraversal=traversing;
    foreach(float cardinal in new[]{0f,90f,180f,270f}) {
     var mod=new Mod();QuestFpStoreYaw(mod,cardinal);
     if(mod.x!=(active&&!traversing?q.doorYaw:cardinal))throw new Exception("Native traversal rig yaw must pass through; only post-traversal settle recovers the user's heading");
    }
   }
  }
 }
'@
Add-Type -TypeDefinition ($fixture+$origin+$store+'}')
[Tracking]::Run()
if($camera -match 'camera\.transform\.(localPosition|position)\s*='){throw 'Door guard must preserve native camera placement'}
foreach($needle in @('instruction.opcode==OpCodes.Stfld','nameof(QuestFpStoreYaw)','yaws!=6')) {
 if(!$fp.Contains($needle)){throw "Missing pre-rotation FPv2 heading integration: $needle"}
}
'PASS actual production origin/yaw methods: native doorway movement and distant room handoff; native cardinal yaw preserved throughout traversal, heading recovered only during settle, ordinary yaw unchanged. Headset confirmation required.'

$dll=Join-Path $PSScriptRoot 'SignalisVrTracking.dll'
if(Test-Path -LiteralPath $dll) {
 Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
 $a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly($dll)
 $nativeFp=[Mono.Cecil.AssemblyDefinition]::ReadAssembly('E:/SteamLibrary/steamapps/common/SIGNALIS/Mods/FPv2_reworked.dll')
 try {
  $t=$a.MainModule.Types | Where-Object FullName -eq 'SignalisVrTracking.Tracking'
  $originIL=($t.Methods | Where-Object Name -eq 'DoorCameraOrigin').Body.Instructions
  if(@($originIL | Where-Object {$_.OpCode.Name -in @('ldfld','ldsfld','call','callvirt')}).Count){throw 'Compiled origin must not freeze or redirect native position'}
  $yawIL=($t.Methods | Where-Object Name -eq 'QuestFpStoreYaw').Body.Instructions
  foreach($name in @('DoorCameraBlocked','DoorNativeTraversing','SetValue')) {
   if(!@($yawIL | Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.Name -eq $name}).Count){throw "Compiled yaw adapter missing $name"}
  }
  $update=($nativeFp.MainModule.Types | Where-Object FullName -eq 'FPv2_reworked.FPv2_rework').Methods | Where-Object Name -eq 'OnUpdate'
  $stores=@($update.Body.Instructions | Where-Object {$_.OpCode.Name -eq 'stfld' -and $_.Operand.Name -eq 'x'})
  if($stores.Count -ne 6){throw 'Read-only native FPv2 yaw stores differ from audited six-store layout'}
 } finally {$a.Dispose();$nativeFp.Dispose()}
 'PASS compiled origin/yaw integration and read-only installed FPv2 six-store layout audit.'
}

$begin=$camera.IndexOf('  private Quaternion DoorCameraBasis(')
$end=$camera.IndexOf("`n  }",$begin)+5
$basis=$camera.Substring($begin,$end-$begin)
$basisFixture=@"
public struct Quaternion { public int heading; public Quaternion(int v){heading=v;} }
public class DoorBasisFixture {
 bool blocked,traversing; Quaternion doorWorldBasis=new Quaternion(37);
 bool DoorCameraBlocked(){return blocked;}
 bool DoorNativeTraversing(){return traversing;}
 $basis
 public static void Run(){
  var q=new DoorBasisFixture();
  q.blocked=true;q.traversing=true;
  foreach(int heading in new[]{0,90,180,270}) {
   if(q.DoorCameraBasis(new Quaternion(heading)).heading!=heading)throw new System.Exception("Door retained approach heading");
  }
  q.traversing=false;
  if(q.DoorCameraBasis(new Quaternion(37)).heading!=270)throw new System.Exception("Exit lost native door heading");
  q.blocked=false;
  if(q.DoorCameraBasis(new Quaternion(52)).heading!=52)throw new System.Exception("Normal look remained locked");
 }
}
"@
Add-Type -TypeDefinition $basisFixture
[DoorBasisFixture]::Run()
'PASS production basis follows all native door headings, retains exit heading during settle and releases normal look'
