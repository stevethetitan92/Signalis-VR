param([string]$GamePath='E:/SteamLibrary/steamapps/common/SIGNALIS',[string]$AudioSourcePath='')
$ErrorActionPreference='Stop'
$scratch=Join-Path $PSScriptRoot 'shot-hook-harness'
New-Item -ItemType Directory -Force $scratch | Out-Null
foreach($name in '0Harmony.dll','MonoMod.RuntimeDetour.dll','MonoMod.Utils.dll','Mono.Cecil.dll'){
 Copy-Item (Join-Path "$GamePath/MelonLoader" $name) $scratch -Force
}
if(!$AudioSourcePath){$AudioSourcePath=Join-Path $PSScriptRoot 'SmgShotAudio.cs'}
$source=Get-Content $AudioSourcePath -Raw
$stub=@'
namespace UnityEngine {public struct Vector3 {public static Vector3 zero;}}
namespace FMODUnity {public static class RuntimeManager {public static int Calls;public static void PlayOneShot(string s,UnityEngine.Vector3 p){Calls++;}}}
namespace MelonLoader {public static class MelonLogger {public static void Warning(string s){}}}
public class Items {public enum itemlist {SMG,Pistol}}
public class AnItem {public Items.itemlist _item;}
public class AnWeapon {public AnItem parentItem=new AnItem();public int magAmmo=40;public string shotMod="native";}
public class PlayerAttack {
 public AnWeapon weapon=new AnWeapon();public bool Fail;
 [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)] public void RaycastShot(){if(Fail)throw new System.InvalidOperationException("native failure");if(weapon.magAmmo>0)weapon.magAmmo--;}
 [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)] public void ReadyForAttack(){RaycastShot();}
}
namespace SignalisVrTracking {public sealed partial class Tracking {
 private static Tracking weaponOwner=new Tracking();private bool ControllerWeaponReady(){return true;}
 private sealed class WeaponPoseScope {internal bool restored;}
 private static int Restores;
 private static void ControllerShotBegin(out WeaponPoseScope __state){__state=new WeaponPoseScope();}
 private static System.Exception ControllerShotEnd(System.Exception __exception,WeaponPoseScope __state){if(__state==null||__state.restored)throw new System.Exception("Pose scope corrupted");__state.restored=true;Restores++;return __exception;}
 public static void Main(){
  var h=new HarmonyLib.Harmony("signalis.shot-composition-test");
  h.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(PlayerAttack),"RaycastShot"),prefix:new HarmonyLib.HarmonyMethod(typeof(Tracking),"ControllerShotBegin"),finalizer:new HarmonyLib.HarmonyMethod(typeof(Tracking),"ControllerShotEnd"));
  weaponOwner.InstallSmgShotAudio(h);
  var a=new PlayerAttack();a.ReadyForAttack();if(a.weapon.magAmmo!=39||Restores!=1||FMODUnity.RuntimeManager.Calls!=0)throw new System.Exception("First shot composition failed");
  for(int i=0;i<39;i++)a.RaycastShot();if(a.weapon.magAmmo!=0||Restores!=40||FMODUnity.RuntimeManager.Calls!=39)throw new System.Exception("Automatic shot composition failed");
  a.weapon.parentItem._item=Items.itemlist.Pistol;a.weapon.magAmmo=10;a.ReadyForAttack();if(a.weapon.magAmmo!=9||Restores!=41||FMODUnity.RuntimeManager.Calls!=39)throw new System.Exception("Pistol firing blocked");
  a.Fail=true;try{a.ReadyForAttack();throw new System.Exception("Failure not reached");}catch(System.InvalidOperationException){}if(Restores!=42||smgReadyDepth!=0)throw new System.Exception("Exception scope stuck");
  System.Console.WriteLine("PASS installed Harmony engine: actual audio hook registration composed with reference-type pose state; first/39 automatic/other-gun shots and exception restoration.");
 }
}}
'@
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.dll')) | Out-Null
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.CSharp.dll')) | Out-Null
$framework=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319'
$refs=[System.Collections.Generic.List[Microsoft.CodeAnalysis.MetadataReference]]::new()
foreach($path in @("$scratch/0Harmony.dll","$framework/mscorlib.dll","$framework/System.dll","$framework/System.Core.dll")){$refs.Add([Microsoft.CodeAnalysis.MetadataReference]::CreateFromFile($path))}
$options=[Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions]::new([Microsoft.CodeAnalysis.OutputKind]::ConsoleApplication)
$trees=[Microsoft.CodeAnalysis.SyntaxTree[]]@([Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($source+$stub))
$c=[Microsoft.CodeAnalysis.CSharp.CSharpCompilation]::Create('ShotHookHarness',$trees,$refs,$options)
$exe=Join-Path $scratch 'ShotHookHarness.exe';$stream=[IO.File]::Create($exe)
try{$result=$c.Emit($stream)}finally{$stream.Dispose()}
if(!$result.Success){$result.Diagnostics | ForEach-Object ToString;throw 'Shot hook harness compile failed'}
& $exe
if($LASTEXITCODE -ne 0){throw 'Actual Harmony hook composition failed'}

