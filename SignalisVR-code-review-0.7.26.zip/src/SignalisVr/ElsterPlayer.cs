using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 internal static class ElsterPosePolicy {
  internal static void Elbow(float upper,float lower,float distance,out float along,out float height) {
   if(upper<=0||lower<=0||float.IsNaN(distance)||float.IsInfinity(distance))throw new ArgumentException("Invalid arm dimensions");
   float d=Math.Max(.0001f,Math.Min(upper+lower-.0001f,Math.Max(Math.Abs(upper-lower)+.0001f,distance)));
   along=(upper*upper-lower*lower+d*d)/(2*d);height=(float)Math.Sqrt(Math.Max(0,upper*upper-along*along));
  }
 }
 public sealed partial class Tracking {
  private bool modFullBodyIk=true;
  private bool elsterSuit;
  private GameObject elsterRoot;
  private Transform[] elsterBones;
  private Vector3[] elsterRest;
  private int[] elsterParents;
  private readonly SkinnedMeshRenderer[] elsterRenderers=new SkinnedMeshRenderer[3];
  private readonly Mesh[] elsterMeshes=new Mesh[3];
  private Material elsterMaterial,elsterSealMaterial;
  private Texture2D elsterTexture;
  private readonly List<Renderer> elsterHidden=new List<Renderer>();
  private readonly Quaternion[] elsterHandBasis=new Quaternion[2];
  private readonly Vector3[] elsterPalm=new Vector3[2];
  private readonly float[] elsterCurl=new float[2];
  private float elsterPoseTime;
  private float elsterBodyYaw;
  private bool elsterFailed;
  private readonly Transform[] elsterLegSources=new Transform[6];
  private int EB(string name){return Array.IndexOf(ElsterAvatarData.Names,name);}
  private static int[] ElsterSeal(Vector3[] vertices,int[] triangles,float minimumY){
   var xyz=new float[vertices.Length*3];for(int i=0;i<vertices.Length;i++){xyz[i*3]=vertices[i].x;xyz[i*3+1]=vertices[i].y;xyz[i*3+2]=vertices[i].z;}
   var caps=new List<int>();
   foreach(var loop in HandSurfaceTopology.BoundaryLoops(xyz,triangles)){
    bool eligible=true;foreach(int i in loop)if(vertices[i].y<minimumY)eligible=false;
    if(!eligible)continue;
    for(int i=1;i<loop.Length-1;i++){caps.Add(loop[0]);caps.Add(loop[i]);caps.Add(loop[i+1]);}
   }
   return HandSurfaceTopology.DoubleSided(caps.ToArray());
  }
  private void EnsureElsterPlayer(){
   bool suit=handsSourceBody!=null&&handsSourceBody.sharedMesh!=null&&handsSourceBody.sharedMesh.name=="Body_Suit";
   if(elsterRoot!=null&&elsterSuit!=suit)DestroyElsterPlayer();
   if(elsterRoot!=null)return;elsterSuit=suit;
   elsterBodyYaw=headComfortPose.eulerAngles.y;
   elsterRoot=new GameObject("SignalisVR_ElsterPlayerTest");elsterRoot.layer=30;UnityEngine.Object.DontDestroyOnLoad(elsterRoot);
   using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(elsterSuit?SuitAvatarData.Mesh:ElsterAvatarData.Mesh)))){
    int nb=r.ReadInt32(),nv=r.ReadInt32(),ni=r.ReadInt32();
    if(nb!=51||nv<1000||nv>20000||ni%3!=0)throw new InvalidDataException("Invalid Elster data");
    elsterBones=new Transform[nb];elsterRest=new Vector3[nb];elsterParents=new int[nb];var binds=new Matrix4x4[nb];
    for(int i=0;i<nb;i++){elsterParents[i]=r.ReadInt32();elsterRest[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());var t=new GameObject(ElsterAvatarData.Names[i]).transform;t.SetParent(elsterRoot.transform,false);t.localPosition=elsterRest[i];elsterBones[i]=t;binds[i]=Matrix4x4.TRS(-elsterRest[i],Quaternion.identity,Vector3.one);}
    for(int i=0;i<nb;i++)if(elsterParents[i]>=0)elsterBones[i].SetParent(elsterBones[elsterParents[i]],true);
    var v=new Vector3[nv];var uv=new Vector2[nv];var weights=new BoneWeight[nv];var groups=new int[nv];
    for(int i=0;i<nv;i++){
     v[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());
     var w=new BoneWeight();w.boneIndex0=r.ReadInt32();w.boneIndex1=r.ReadInt32();w.boneIndex2=r.ReadInt32();w.boneIndex3=r.ReadInt32();w.weight0=r.ReadSingle();w.weight1=r.ReadSingle();w.weight2=r.ReadSingle();w.weight3=r.ReadSingle();weights[i]=w;
     float head=0,left=0,right=0;int[] ids={w.boneIndex0,w.boneIndex1,w.boneIndex2,w.boneIndex3};float[] amounts={w.weight0,w.weight1,w.weight2,w.weight3};
     for(int k=0;k<4;k++){string n=ElsterAvatarData.Names[ids[k]];if(n=="head")head+=amounts[k];if(ids[k]>=8&&ids[k]<=23)left+=amounts[k];if(ids[k]>=27&&ids[k]<=42)right+=amounts[k];}
     groups[i]=head>.5f?-1:left>.5f?1:right>.5f?2:0;
    }
    var tris=new List<int>[] {new List<int>(),new List<int>(),new List<int>()};
    for(int i=0;i<ni;i+=3){int a=r.ReadInt32(),b=r.ReadInt32(),c=r.ReadInt32();if(groups[a]<0||groups[b]<0||groups[c]<0)continue;int g=(groups[a]==groups[b]&&groups[a]==groups[c])?groups[a]:0;tris[g].Add(a);tris[g].Add(b);tris[g].Add(c);}
    elsterTexture=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(elsterTexture,Convert.FromBase64String(elsterSuit?SuitAvatarData.Texture:ElsterAvatarData.Texture),true))throw new InvalidDataException("Elster texture");elsterTexture.filterMode=FilterMode.Point;
    var shader=Shader.Find("Unlit/Texture");if(shader==null)throw new InvalidOperationException("Elster shader missing");elsterMaterial=new Material(shader);elsterMaterial.mainTexture=elsterTexture;elsterSealMaterial=new Material(Shader.Find("Unlit/Color"));elsterSealMaterial.color=Color.black;
    for(int g=0;g<3;g++){var mesh=new Mesh();elsterMeshes[g]=mesh;mesh.name="ElsterPlayer_"+g;mesh.vertices=v;mesh.uv=uv;mesh.boneWeights=weights;mesh.bindposes=binds;mesh.subMeshCount=2;mesh.SetTriangles(HandSurfaceTopology.DoubleSided(tris[g].ToArray()),0);mesh.SetTriangles(ElsterSeal(v,tris[g].ToArray(),g==0?elsterRest[EB("neck")].y-.06f:float.NegativeInfinity),1);mesh.RecalculateNormals();mesh.RecalculateBounds();var obj=new GameObject("ElsterPart"+g);obj.layer=30;obj.transform.SetParent(elsterRoot.transform,false);var skin=obj.AddComponent<SkinnedMeshRenderer>();elsterRenderers[g]=skin;skin.sharedMesh=mesh;skin.bones=elsterBones;skin.rootBone=elsterBones[0];skin.sharedMaterials=new Material[]{elsterMaterial,elsterSealMaterial};skin.localBounds=new Bounds(Vector3.zero,Vector3.one*8);skin.updateWhenOffscreen=true;skin.allowOcclusionWhenDynamic=false;skin.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;skin.enabled=false;}
    for(int hand=0;hand<2;hand++){string s=hand==0?".l":".r";int wrist=EB("hand"+s);var forward=elsterRest[EB("middle1"+s)]-elsterRest[wrist];var across=elsterRest[EB("index1"+s)]-elsterRest[EB("little1"+s)];elsterHandBasis[hand]=Quaternion.LookRotation(forward,Vector3.Cross(across,forward)*(hand==1?1f:-1f));Vector3 sum=Vector3.zero;int count=0;for(int i=0;i<nv;i++)if(groups[i]==hand+1){var w=weights[i];int lo=hand==0?8:27,hi=hand==0?23:42;float handWeight=(w.boneIndex0>=lo&&w.boneIndex0<=hi?w.weight0:0)+(w.boneIndex1>=lo&&w.boneIndex1<=hi?w.weight1:0)+(w.boneIndex2>=lo&&w.boneIndex2<=hi?w.weight2:0)+(w.boneIndex3>=lo&&w.boneIndex3<=hi?w.weight3:0);if(handWeight<=.95f)continue;float amount=(w.boneIndex0==wrist?w.weight0:0)+(w.boneIndex1==wrist?w.weight1:0)+(w.boneIndex2==wrist?w.weight2:0)+(w.boneIndex3==wrist?w.weight3:0);if(amount>.5f){sum+=v[i];count++;}}if(count<3)throw new InvalidDataException("Missing Elster hand surface");elsterPalm[hand]=sum/count;}
   }
   var attack=global::PlayerAttack.instance;
   if(attack!=null){var animators=attack.transform.root.GetComponentsInChildren<Animator>(true);foreach(var a in animators)if(a!=null&&a.isHuman&&a.transform.name=="Character Root"){var types=new[]{HumanBodyBones.LeftUpperLeg,HumanBodyBones.LeftLowerLeg,HumanBodyBones.LeftFoot,HumanBodyBones.RightUpperLeg,HumanBodyBones.RightLowerLeg,HumanBodyBones.RightFoot};for(int i=0;i<6;i++)elsterLegSources[i]=a.GetBoneTransform(types[i]);break;}}
   MelonLogger.Msg("ELSTER PLAYER TEST: imported 51-bone body and weighted fingers; first-person head excluded; visual-only IK, native gameplay preserved.");
  }
  private void ElsterHide(Renderer r){if(r!=null&&r.enabled){elsterHidden.Add(r);r.enabled=false;}}
  private void HideElsterPlayer(){for(int i=0;i<3;i++)if(elsterRenderers[i]!=null)elsterRenderers[i].enabled=false;foreach(var r in elsterHidden)if(r!=null)r.enabled=true;elsterHidden.Clear();}
  private void DestroyElsterPlayer(){HideElsterPlayer();if(elsterRoot!=null)UnityEngine.Object.Destroy(elsterRoot);for(int i=0;i<3;i++){if(elsterMeshes[i]!=null)UnityEngine.Object.Destroy(elsterMeshes[i]);elsterMeshes[i]=null;elsterRenderers[i]=null;}if(elsterMaterial!=null)UnityEngine.Object.Destroy(elsterMaterial);if(elsterSealMaterial!=null)UnityEngine.Object.Destroy(elsterSealMaterial);if(elsterTexture!=null)UnityEngine.Object.Destroy(elsterTexture);savedThumbScale[0]=savedThumbScale[1]=1;elsterRoot=null;elsterBones=null;elsterMaterial=null;elsterTexture=null;}
  private void HideLegacyHandVisuals(){
   foreach(var r in handsRenderers)ElsterHide(r);
   foreach(var r in approvedPoseRenderers)ElsterHide(r);
   foreach(var r in new Renderer[]{prodHandRenderer,patchHand,repairHand})ElsterHide(r);
  }
  private void PrepareElsterPlayer(){
   HideElsterPlayer();if(!handsScoped)return;HideLegacyHandVisuals();if(elsterFailed)return;
   try{
    EnsureElsterPlayer();float now=Time.realtimeSinceStartup,dt=Mathf.Clamp(now-elsterPoseTime,0,.05f);elsterPoseTime=now;
    var root=elsterRoot.transform;root.rotation=controllerTrackingToWorld*Quaternion.Euler(0,elsterBodyYaw,0);root.localScale=Vector3.one*UnitsPerMetre;
    // Restore the pre-0.6.99 tracking-space body anchor requested by the user.
    root.position=stereoPosition-root.rotation*((elsterRest[EB("head")]+new Vector3(0,.09f,.015f))*UnitsPerMetre);
    for(int i=0;i<elsterBones.Length;i++){elsterBones[i].localPosition=elsterParents[i]<0?elsterRest[i]:elsterRest[i]-elsterRest[elsterParents[i]];elsterBones[i].localRotation=Quaternion.identity;elsterBones[i].localScale=Vector3.one;}
    ElsterLegs();
    for(int hand=0;hand<2;hand++){
     bool show=controllerMarkers[hand]!=null&&(controllerVisibility&(1<<hand))!=0;
     elsterRenderers[hand+1].enabled=show;if(!show)continue;
     string side=hand==0?".l":".r";int wrist=EB("hand"+side),upper=EB("upperarm"+side),fore=EB("forearm"+side);
     Vector3 palm;Quaternion basis;ElsterGripKind pose;
     ResolveElsterGrip(hand,out palm,out basis,out pose);
     ResolveSavedGrip(hand,ref palm,ref basis,pose);
     ApplySavedThumb(hand);
     var turn=basis*Quaternion.Inverse(elsterHandBasis[hand]);
     var target=palm-turn*((elsterPalm[hand]-elsterRest[wrist])*UnitsPerMetre);
     ElsterArm(upper,fore,wrist,target,turn,hand);
     float goal=pose==ElsterGripKind.Open?0:1;elsterCurl[hand]=Mathf.MoveTowards(elsterCurl[hand],goal,dt*8f);
     PoseElsterDigits(hand,pose,elsterCurl[hand]);
     FitElsterTriggerContact(hand,pose);
    }
    elsterRenderers[0].enabled=modFullBodyIk;
   }catch(Exception ex){HideElsterPlayer();DestroyElsterPlayer();HideLegacyHandVisuals();elsterFailed=true;MelonLogger.Warning("Elster body unavailable; legacy grip visuals remain hidden: "+ex.Message);}
  }
  private void ElsterArm(int a,int b,int c,Vector3 target,Quaternion wristRotation,int hand){
   Vector3 shoulder=elsterBones[a].position,delta=target-shoulder;float distance=delta.magnitude;if(distance<.0001f)return;
   float upper=(elsterRest[b]-elsterRest[a]).magnitude*UnitsPerMetre,lower=(elsterRest[c]-elsterRest[b]).magnitude*UnitsPerMetre,along,height;ElsterPosePolicy.Elbow(upper,lower,distance,out along,out height);
   Vector3 dir=delta/distance,pole=elsterRoot.transform.TransformDirection(new Vector3(hand==0?-.5f:.5f,-1,-.35f));pole-=dir*Vector3.Dot(pole,dir);if(pole.sqrMagnitude<.0001f)pole=Vector3.Cross(dir,elsterRoot.transform.forward);pole.Normalize();
   // Keep the elbow pole body-relative; rotating a held item must not flip the elbow.
   Vector3 elbow=shoulder+dir*along+pole*height;
   var yaw=elsterRoot.transform.rotation;elsterBones[a].rotation=Quaternion.FromToRotation(yaw*(elsterRest[b]-elsterRest[a]),elbow-shoulder)*yaw;
   elsterBones[b].position=elbow;var foreRotation=Quaternion.FromToRotation(yaw*(elsterRest[c]-elsterRest[b]),target-elbow)*yaw;
   // Carry wrist roll through the forearm without changing elbow/wrist positions.
   var axis=(target-elbow).normalized;var relative=wristRotation*Quaternion.Inverse(foreRotation);
   float projection=relative.x*axis.x+relative.y*axis.y+relative.z*axis.z;
   float norm=Mathf.Sqrt(projection*projection+relative.w*relative.w);
   if(norm>.00001f){var twist=new Quaternion(axis.x*projection/norm,axis.y*projection/norm,axis.z*projection/norm,relative.w/norm);foreRotation=twist*foreRotation;}
   elsterBones[b].rotation=foreRotation;
   // The hand target may exceed the authored arm reach. Extend the forearm to
   // meet it, then cancel inherited scale on the hand to preserve the saved grip.
   float stretch=1f; // Do not inflate forearm width/thickness to reach a distant controller.
   elsterBones[b].localScale=Vector3.one*stretch;elsterBones[c].localScale=Vector3.one/stretch;
   elsterBones[c].position=target;elsterBones[c].rotation=wristRotation;
  }
  private void ElsterLegs(){
   // Native locomotion provides walking poses; no foot-tracking input is invented.
   var src=elsterLegSources;
   for(int side=0;side<2;side++){string s=side==0?".l":".r";for(int j=0;j<2;j++){int a=EB((j==0?"thigh":"calf")+s),b=EB((j==0?"calf":"foot")+s),k=side*3+j;if(src[k]==null||src[k+1]==null)continue;Vector3 direction=src[k+1].position-src[k].position;if(direction.sqrMagnitude<1e-8f)continue;elsterBones[a].rotation=Quaternion.FromToRotation(elsterRoot.transform.rotation*(elsterRest[b]-elsterRest[a]),direction)*elsterRoot.transform.rotation;}}
  }
 }
}





