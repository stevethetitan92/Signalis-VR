$ErrorActionPreference='Stop'
Add-Type -Path "$PSScriptRoot/RoomMapProjection.cs"
$p=[SignalisVrTracking.RoomMapProjection]::new()
$valid=[double[,]]::new(4,4)
for($i=0;$i -lt 4;$i++){$x=$i%2;$y=[Math]::Floor($i/2);$valid[$i,0]=$x;$valid[$i,1]=$y;$valid[$i,2]=3*$x+2*$y+5;$valid[$i,3]=-$x+4*$y-7}
if(!$p.Fit($valid)){throw 'Valid fit rejected'}
foreach($bad in @([double]::NaN,[double]::PositiveInfinity,[double]::NegativeInfinity)){
 for($r=0;$r -lt 4;$r++){for($c=0;$c -lt 4;$c++){$v=$valid.Clone();$v[$r,$c]=$bad;if($p.Fit($v)){throw "Nonfinite anchor accepted $r $c"}}}
}
if($p.Fit($null) -or $p.Fit([double[,]]::new(4,3))){throw 'Malformed anchors accepted'}
# Stress the actual fit under translated, rotated, reflected and unequal-scale layouts.
for($i=1;$i -le 200;$i++){
 $a=$i*.03;$co=[Math]::Cos($a);$si=[Math]::Sin($a);$flip=if($i%2){-1}else{1};$v=[double[,]]::new(4,4)
 for($j=0;$j -lt 4;$j++){$x=($j%2)*7+1000;$y=[Math]::Floor($j/2)*9-2000;$v[$j,0]=$x;$v[$j,1]=$y;$v[$j,2]=2*$co*$x-$si*$y+11;$v[$j,3]=$flip*(2*$si*$x+$co*$y)-15}
 if(!$p.Fit($v)){throw 'Stress fit failed'};[double]$u=0;[double]$w=0;$p.Point(1003,-1996,[ref]$u,[ref]$w)
 if([Math]::Abs($u-(2*$co*1003-$si*(-1996)+11)) -gt .00001 -or [Math]::Abs($w-($flip*(2*$si*1003+$co*(-1996))-15)) -gt .00001){throw 'Stress point mismatch'}
}
$s=Get-Content "$PSScriptRoot/ModHud.cs" -Raw
$a=$s.IndexOf('  private static int LiveMapDoorState(');$b=$s.IndexOf('  private bool MapPlayerPoint(', $a);$m=$s.Substring($a,$b-$a)
Add-Type (@'
using System;
public class Connection {public int minimapState;public bool locked,externalUnlocker;public object key;}
public class Physical {public bool locked;}
public class AutoTraverseDoor {public Connection connection;public Physical door;}
public class MinimapDoor {public AutoTraverseDoor door;public int state;}
public class DoorCheck {
'@+$m+@'
public static void Run(){foreach(bool locked in new[]{false,true})foreach(bool physical in new[]{false,true})foreach(bool key in new[]{false,true})foreach(bool external in new[]{false,true})foreach(int state in new[]{0,3}){
var d=new MinimapDoor{door=new AutoTraverseDoor{connection=new Connection{locked=locked,key=key?new object():null,externalUnlocker=external,minimapState=state},door=new Physical{locked=physical}}};
int expected=state==3?2:(locked||physical)?(key||external?4:2):1;if(LiveMapDoorState(d)!=expected)throw new Exception("door color");}
var fallback=new MinimapDoor{state=4};if(LiveMapDoorState(fallback)!=4)throw new Exception("native fallback");}
}
'@)
[DoorCheck]::Run()
$start=$s.IndexOf('  private void RefreshModMiniMap()');$manager=$s.IndexOf('var manager=', $start);$prefix=$s.Substring($start,$manager-$start)
foreach($list in 'mapPointPositions','mapPointKinds','mapLabelPoints','mapLabelTexts'){if(!$prefix.Contains($list+'.Clear();')){throw "Stale presentation on unavailable map: $list"}}
$enemy=Get-Content "$PSScriptRoot/EnemyEyeMaterials.cs" -Raw
if(!$enemy.Contains('GetComponentsInChildren<SkinnedMeshRenderer>(true)') -or !$enemy.Contains('new[]{"OnEnable","Load"}') -or !$enemy.Contains('q.nextEyeEnemyScan=0')){throw 'Enemy activation rescan missing'}
foreach($guard in 'renderer.enabled','renderer.gameObject.activeInHierarchy','enemy.BurnEffect.burning','if(c.Frame!=Time.frameCount)','originals[i].mainTexture') {if(!$enemy.Contains($guard)){throw "Native visibility/animation/texture guard absent: $guard"}}
'PASS 48 invalid-anchor cases, malformed arrays, 200 transformed room fits, 32 live door-state combinations, unavailable-map cleanup and enemy activation/visibility integration. Simulated/source checks; not a headset benchmark.'
