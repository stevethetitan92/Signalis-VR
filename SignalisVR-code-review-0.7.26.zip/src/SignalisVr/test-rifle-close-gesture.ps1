$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'RifleCloseGesturePolicy.cs')
function Check($v,$why){if(-not $v){throw $why}}
foreach($hz in @(30,60,72,90,120,144)){
 $p=[SignalisVrTracking.RifleCloseGesturePolicy]::new();$hits=0
 $p.Tick(0,0,$true)|Out-Null
 for($i=1;$i -le $hz;$i++){if($p.Tick($i/$hz,240/$hz,$true)){$hits++}}
 Check ($hits -eq 1) "Flick failed/latch repeated at $hz Hz"
 $p.Tick(2,0,$false)|Out-Null
 $p.Tick(3,0,$true)|Out-Null;$hits=0
 for($i=1;$i -le $hz;$i++){if($p.Tick(3+$i/$hz,240/$hz,$true)){$hits++}}
 Check ($hits -eq 1) 'Next opening did not rearm'
}
foreach($speed in @(-240,0,30,100)){
 $p=[SignalisVrTracking.RifleCloseGesturePolicy]::new()
 for($i=0;$i -lt 300;$i++){Check (-not $p.Tick($i/60,$speed/60,$true)) 'Slow/downward movement closed rifle'}
}
$p=[SignalisVrTracking.RifleCloseGesturePolicy]::new()
$p.Tick(0,0,$true)|Out-Null
Check (-not $p.Tick(.05,15,$true)) 'Partial movement closed rifle'
Check (-not $p.Tick(.1,15,$false)) 'Disabled/holding ammo closed rifle'
Check (-not $p.Tick(.15,15,$true)) 'Stale loading motion carried into rearm'
Check (-not $p.Tick(.3,30,$true)) 'Tracking gap counted as flick'
Check (-not $p.Tick(.35,60,$true)) 'Tracking jump counted as flick'
Check (-not $p.Tick(.4,[float]::NaN,$true)) 'Invalid tracking counted as flick'
Check (-not $p.Tick(.45,20,$true)) 'Invalid tracking failed to reset'
'PASS: upward flick across 30–144 Hz, single close per opening, rearm, disabled/loading gate, slow/downward motion, tracking gap/jump/NaN.'
Add-Type -Path (Join-Path $PSScriptRoot 'RifleBarrelMotion.cs')
foreach($hz in @(30,60,72,90,120,144)){
 $phase=1.0;$last=1.0
 for($i=1;$i -le [Math]::Ceiling(.24*$hz);$i++){
  $phase=[SignalisVrTracking.RifleBarrelMotion]::Advance($phase,$false,1.0/$hz)
  $e=[SignalisVrTracking.RifleBarrelMotion]::Ease($phase)
  Check ($e -ge 0 -and $e -le $last) 'Closure overshoot/reversal'
  $last=$e
 }
 Check ($phase -lt .00001) 'Closure duration differs by frame rate'
}
Check ([SignalisVrTracking.RifleBarrelMotion]::Ease(.001) -lt .0000001) 'Closure endpoint is abrupt'
Check ([SignalisVrTracking.RifleBarrelMotion]::Ease(0) -eq 0) 'Breech not fully shut'
Check ([SignalisVrTracking.RifleBarrelMotion]::Ease(1) -eq 1) 'Barrels not fully open'
'PASS: 240ms monotonic eased closure, no overshoot, settled endpoints, 30–144 Hz.'
