using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private bool questMenuPrompts;private readonly Dictionary<string,Sprite> questPromptSprites=new Dictionary<string,Sprite>();
 private readonly Dictionary<IntPtr,bool> questPromptKeyboard=new Dictionary<IntPtr,bool>();
 private readonly Dictionary<IntPtr,bool> questMouseVisible=new Dictionary<IntPtr,bool>();
 private bool QuestMenuControl(){return QuestAvailableNow()&&questPolicy.Armed&&(questMenuScene||pauseMenuVisible||global::PlayerState.menu||global::PlayerState.pauseMenu);}
 private void InstallQuestMenus(){
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::MenuMouse),"Update"),prefix:new HarmonyMethod(typeof(Tracking),nameof(QuestMenuMouse)));
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::MenuNavigation),"Update"),prefix:new HarmonyMethod(typeof(Tracking),nameof(QuestMenuNavigation)));
  foreach(string method in new[]{"OnEnable","Update"})questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::PauseMenuShowControls),method),postfix:new HarmonyMethod(typeof(Tracking),nameof(QuestPauseLegend)));
  questHarmony.Patch(AccessTools.DeclaredMethod(typeof(global::InputActionPromptIcon),"ApplyIcon"),prefix:new HarmonyMethod(typeof(Tracking),nameof(QuestPromptBegin)),postfix:new HarmonyMethod(typeof(Tracking),nameof(QuestPromptEnd)));
 }
 private readonly Dictionary<IntPtr,string[]> questPauseText=new Dictionary<IntPtr,string[]>();
 private static void QuestPauseLegend(global::PauseMenuShowControls __instance){
  var q=questOwner;if(q==null)return;
  q.UpdatePauseControlsImage(__instance);
  if(!q.QuestMenuControl()){
   string[] old;if(q.questPauseText.TryGetValue(__instance.Pointer,out old)){if(__instance.KBLeft!=null)__instance.KBLeft.text=old[0];if(__instance.KBRight!=null)__instance.KBRight.text=old[1];q.questPauseText.Remove(__instance.Pointer);}return;
  }
  if(__instance.KBLeft==null||__instance.KBRight==null)return;
  if(!q.questPauseText.ContainsKey(__instance.Pointer))q.questPauseText[__instance.Pointer]=new[]{__instance.KBLeft.text,__instance.KBRight.text};
  // Reuse the two-column legend, without a misleading Xbox/keyboard diagram.
  if(__instance.Controller!=null)__instance.Controller.SetActive(false);if(__instance.KBM!=null)__instance.KBM.SetActive(true);
  __instance.KBLeft.text="MOVE     LEFT STICK\nINTERACT / CONFIRM     A\nSPRINT     LEFT STICK CLICK\nINVENTORY     X\nPAUSE     HOLD B 3 SECONDS / Y\nBACK     B";
  __instance.KBRight.text="AIM     RIGHT HAND\nFIRE / USE     RIGHT TRIGGER\nRELOAD     MANUAL\nGRAB / SUPPORT     LEFT GRIP\nMENU PAGES     GRIPS\nMENU VALUES     LEFT STICK";
 }
 private static bool QuestMenuMouse(global::MenuMouse __instance){
  var q=questOwner;if(q==null)return true;

  if(!q.QuestMenuControl()){bool shown;if(q.questMouseVisible.TryGetValue(__instance.Pointer,out shown)){if(__instance.SpriteRend!=null)__instance.SpriteRend.enabled=shown;q.questMouseVisible.Remove(__instance.Pointer);}return true;}
  if(__instance.SpriteRend!=null){if(!q.questMouseVisible.ContainsKey(__instance.Pointer))q.questMouseVisible[__instance.Pointer]=__instance.SpriteRend.enabled;__instance.SpriteRend.enabled=false;}return false;
 }
 private static void QuestMenuNavigation(global::MenuNavigation __instance){if(questOwner!=null&&questOwner.QuestMenuControl())__instance.mousePos=Input.mousePosition;}
 private static void QuestPromptBegin(global::InputActionPromptIcon __instance){
  var q=questOwner;if(q==null)return;
  if(q.QuestMenuControl()){if(!q.questPromptKeyboard.ContainsKey(__instance.Pointer))q.questPromptKeyboard[__instance.Pointer]=__instance.Keyboard;__instance.Keyboard=false;}
  else {bool old;if(q.questPromptKeyboard.TryGetValue(__instance.Pointer,out old)){__instance.Keyboard=old;q.questPromptKeyboard.Remove(__instance.Pointer);}}
 }
 private static void QuestPromptEnd(global::InputActionPromptIcon __instance){
  var q=questOwner;if(q==null||!q.QuestMenuControl())return;string action,label=null;
  if(q.questNativeActions.TryGetValue(__instance.Action,out action))switch(action){case "Use":case "Confirm":label="A";break;case "Cancel":label="B";break;case "Inventory":label="X";break;case "Pause":label="Y";break;case "TabLeft":label="L GRIP";break;case "TabRight":label="R GRIP";break;case "UIHorizontal":case "UIVertical":label="L STICK";break;}
  if(__instance.Override!=global::InputActionPromptIcon.actions.None)label="L STICK";
  if(label==null)return;var sprite=q.QuestPromptSprite(label);if(__instance.SR!=null)__instance.SR.sprite=sprite;if(__instance.IMG!=null)__instance.IMG.sprite=sprite;
 }
 private Sprite QuestPromptSprite(string label){
  Sprite sprite;if(questPromptSprites.TryGetValue(label,out sprite))return sprite;
  const int w=128,h=48;var tex=new Texture2D(w,h,TextureFormat.RGBA32,false);var pixels=new Color[w*h];for(int y=0;y<h;y++)for(int x=0;x<w;x++)pixels[y*w+x]=(x<2||x>=w-2||y<2||y>=h-2)?Color.white:new Color(.025f,.025f,.025f,1);
  string letters="ABXYLGRIPSTCK";string[] glyphs={"01110100011000111111100011000110001","11110100011000111110100011000111110","10001100010101000100010101000110001","10001100010101000100001000010000100","10000100001000010000100001000011111","01111100001000010111100011000101111","11110100011000111110101001001010001","11111001000010000100001000010011111","11110100011000111110100001000010000","01111100001000001110000010000111110","11111001000010000100001000010000100","01111100001000010000100001000001111","10001100101010011000101001001010001"};
  int scale=label.Length>2?2:4,start=(w-(label.Length*6-1)*scale)/2;
  for(int c=0;c<label.Length;c++){int index=letters.IndexOf(label[c]);if(index<0)continue;for(int y=0;y<7;y++)for(int x=0;x<5;x++)if(glyphs[index][y*5+x]=='1')for(int yy=0;yy<scale;yy++)for(int xx=0;xx<scale;xx++)pixels[(h/2+3*scale-y*scale+yy)*w+start+c*6*scale+x*scale+xx]=Color.white;}
  tex.SetPixels(pixels);tex.Apply();tex.filterMode=FilterMode.Point;sprite=Sprite.Create(tex,new Rect(0,0,w,h),new Vector2(.5f,.5f),100);questPromptSprites[label]=sprite;return sprite;
 }
 private void PollQuestMenus(){
  bool menu=QuestMenuControl();if(menu){questFrame.buttons&=~((1<<8)|(1<<9));if(manualLeftGrip)questFrame.buttons|=1<<8;if(modMenuRightGrip)questFrame.buttons|=1<<9;global::InputControl.usingController=true;}
  if(menu==questMenuPrompts)return;questMenuPrompts=menu;foreach(var prompt in UnityEngine.Object.FindObjectsOfType<global::InputActionPromptIcon>())prompt.ApplyIcon();
 }
} }
