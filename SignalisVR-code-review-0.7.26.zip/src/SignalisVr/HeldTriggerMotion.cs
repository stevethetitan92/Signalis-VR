using System;
using UnityEngine;
namespace SignalisVrTracking {
 public static class TriggerMotion {
  public static float Pressure(float input,bool allowed){return !allowed||float.IsNaN(input)||float.IsInfinity(input)?0:Math.Max(0,Math.Min(1,input));}
  public static float Amount(float age) {
   if(float.IsNaN(age)||age<0||age>=.24f)return 0;
   float t=age<.055f?age/.055f:age<.09f?1:1-(age-.09f)/.15f;
   t=Math.Max(0,Math.Min(1,t));return t*t*(3-2*t);
  }
  public static float Amount(float age,float initial){float value=Amount(age);return age>=0&&age<.055f?Math.Max(0,Math.Min(1,initial))+(1-Math.Max(0,Math.Min(1,initial)))*value:value;}
  public static float Blend(float delta){return delta<=0?0:1-(float)Math.Exp(-Math.Min(.1f,delta)*24);}
 }
 public sealed partial class Tracking {
  private float heldShotTime=-100f,healthSqueezeTime=-100f;
  private IntPtr heldShotWeapon;
  private float heldShotInitial;
  private float gunVisualTrigger;
  private float GunSqueeze(){return TriggerMotion.Pressure(gunVisualTrigger,!modMenuOpen&&questAvailabilityValue&&!AdditionalReloadActive()&&!manualReload.Active&&!global::PlayerState.paused);}
  private void RecordHeldTriggerShot(){var w=global::InventoryManager.EquippedWeapon;if(w==null)return;heldShotInitial=GunSqueeze();heldShotWeapon=w.Pointer;heldShotTime=Time.realtimeSinceStartup;EmitHdShotSmoke();}
  private readonly Quaternion[][] gripPrevious={null,null};
  private readonly int[] gripFrames={-1,-1};
  private void ResetRightHandAfterProd(){
   gripPrevious[1]=null;gripFrames[1]=-1;handGripModel=null;handGripCalibrationModel=null;
   var bones=handCopyBones[1];if(bones==null||handNeutralRotations[1]==null)return;
   for(int i=0;i<bones.Length;i++)if(bones[i]!=null&&handSourceBones[1][i]!=handsWrists[1]){
    bones[i].localPosition=handNeutralPositions[1][i];bones[i].localRotation=handNeutralRotations[1][i];bones[i].localScale=handNeutralScales[1][i];
   }
  }
  private void SmoothHeldFingers() {
   if(!handsScoped)return;
   for(int h=0;h<2;h++) {
    var bones=handCopyBones[h];if(bones==null)continue;
    if(gripPrevious[h]==null||gripPrevious[h].Length!=bones.Length){gripPrevious[h]=new Quaternion[bones.Length];for(int i=0;i<bones.Length;i++)if(handSourceBones[h][i]!=null)gripPrevious[h][i]=bones[i].localRotation;gripFrames[h]=-1;}
    bool newFrame=gripFrames[h]!=Time.frameCount;
    float blend=TriggerMotion.Blend(Time.unscaledDeltaTime);
    for(int i=0;i<bones.Length;i++)if(handSourceBones[h][i]!=null&&handSourceBones[h][i]!=handsWrists[h]) {
     if(newFrame)gripPrevious[h][i]=Quaternion.Slerp(gripPrevious[h][i],bones[i].localRotation,blend);
     bones[i].localRotation=gripPrevious[h][i];
    }
    gripFrames[h]=Time.frameCount;
   }
  }
 }
}
