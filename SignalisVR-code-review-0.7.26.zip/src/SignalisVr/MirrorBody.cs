using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed class MirrorVisibilityScope : IDisposable {
  private readonly List<Renderer> renderers=new List<Renderer>();
  private readonly List<bool> enabled=new List<bool>();
  public void Set(Renderer renderer,bool value){if(renderer==null)return;renderers.Add(renderer);enabled.Add(renderer.enabled);renderer.enabled=value;}
  public bool HasChanges {get{return renderers.Count>0;}}
  public void RestoreInto(MirrorVisibilityScope target){for(int i=renderers.Count-1;i>=0;i--)target.Set(renderers[i],enabled[i]);}
  public void Dispose(){for(int i=renderers.Count-1;i>=0;i--)if(renderers[i]!=null)renderers[i].enabled=enabled[i];renderers.Clear();enabled.Clear();}
 }
 public sealed partial class Tracking {
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
  private delegate void MirrorRenderNative(IntPtr self,IntPtr method);
  private MirrorRenderNative mirrorRenderOriginal;
  private bool mirrorRenderScoped;
  private int mirrorBodyReports;
  private SkinnedMeshRenderer mirrorBodyCopy,mirrorBodySource;
  private SkinnedMeshRenderer ReflectionBody(){
   var source=handsSourceBody;
   if(source==null||!source.gameObject.activeInHierarchy)return null;
   if(mirrorBodySource!=source||mirrorBodyCopy==null||mirrorBodyCopy.sharedMesh!=source.sharedMesh){
    if(mirrorBodyCopy!=null)UnityEngine.Object.Destroy(mirrorBodyCopy.gameObject);
    var go=new GameObject("SignalisVR_ReflectionBody");
    go.transform.SetParent(source.transform,false);go.layer=source.gameObject.layer;
    mirrorBodyCopy=go.AddComponent<SkinnedMeshRenderer>();mirrorBodyCopy.enabled=false;
    mirrorBodyCopy.sharedMesh=source.sharedMesh;mirrorBodyCopy.bones=source.bones;
    mirrorBodyCopy.rootBone=source.rootBone;mirrorBodyCopy.localBounds=source.localBounds;
    mirrorBodyCopy.updateWhenOffscreen=true;mirrorBodySource=source;
   }
   mirrorBodyCopy.sharedMaterials=source.sharedMaterials;
   return mirrorBodyCopy;
  }
  private global::MirrorCameraScript[] vrMirrorCameras;
  private readonly List<global::MirrorCameraScript> vrEnabledMirrors=new List<global::MirrorCameraScript>();
  private float nextVrMirrorScan;
  private void PrepareVrMirrors(){
   ReflectionBody();
   if(vrMirrorCameras==null||Time.realtimeSinceStartup>=nextVrMirrorScan){vrMirrorCameras=Resources.FindObjectsOfTypeAll<global::MirrorCameraScript>();nextVrMirrorScan=Time.realtimeSinceStartup+2f;}
   foreach(var mirror in vrMirrorCameras)if(mirror!=null&&mirror.gameObject.activeInHierarchy&&!mirror.enabled){vrEnabledMirrors.Add(mirror);mirror.enabled=true;}
  }
  private void RestoreVrMirrors(){foreach(var mirror in vrEnabledMirrors)if(mirror!=null)mirror.enabled=false;vrEnabledMirrors.Clear();}
  private void DestroyVrMirrorState(){RestoreVrMirrors();if(mirrorBodyCopy!=null)UnityEngine.Object.Destroy(mirrorBodyCopy.gameObject);mirrorBodyCopy=null;mirrorBodySource=null;vrMirrorCameras=null;nextVrMirrorScan=0;}
  private void InstallMirrorBody() {
   try {
    var address=QuestNativeAddress(typeof(global::MirrorCameraScript),"NativeMethodInfoPtr_RenderMirror_Internal_Void_0");
    IntPtr gameBase=IntPtr.Zero;
    foreach(System.Diagnostics.ProcessModule module in System.Diagnostics.Process.GetCurrentProcess().Modules)
     if(string.Equals(module.ModuleName,"GameAssembly.dll",StringComparison.OrdinalIgnoreCase))gameBase=module.BaseAddress;
    if(gameBase==IntPtr.Zero||address.ToInt64()-gameBase.ToInt64()!=0x643F70)throw new InvalidOperationException("Mirror layout differs from inspected build");
    mirrorRenderOriginal=AttachQuestNative<MirrorRenderNative>(address,new MirrorRenderNative(RenderMirrorWithBody));
    MelonLogger.Msg("VR MIRROR: native character visibility scoped to reflection render.");
   }catch(Exception ex){MelonLogger.Warning("Mirror body hook unavailable: "+ex.Message);}
  }
  private void RenderMirrorWithBody(IntPtr self,IntPtr method) {
   if((!handsScoped&&(eyeBodyScope==null||!eyeBodyScope.HasChanges))||mirrorRenderScoped){mirrorRenderOriginal(self,method);return;}
   mirrorRenderScoped=true;
   bool called=false,maskSaved=false; global::MirrorScript mirrorSettings=null; int savedMask=0;
   try {
    var mirror=new global::MirrorCameraScript(self);
    mirrorSettings=mirror.mirrorScript;
    if(mirrorSettings==null){called=true;mirrorRenderOriginal(self,method);return;}
    savedMask=mirrorSettings.ReflectLayers;maskSaved=true;
    mirrorSettings.ReflectLayers=savedMask&~(1<<30);
    using(var visibility=new MirrorVisibilityScope()) {
     if(eyeBodyScope!=null)eyeBodyScope.RestoreInto(visibility);
     if(handsScoped&&handsBody!=null)for(int i=0;i<handsBody.Length;i++)visibility.Set(handsBody[i],handsBodyEnabled[i]);
     // The perspective mod can already have hidden the source before our eye
     // snapshot. Reflect the selected native body, including its intact head.
     var reflectedBody=handsSourceBody!=null&&handsSourceBody.gameObject.activeInHierarchy?mirrorBodyCopy:null;
     if(reflectedBody!=null){
      // A separate renderer shares the intact native mesh and animated bones.
      // Native per-camera visibility scripts cannot hide this renderer.
      visibility.Set(handsSourceBody,false);visibility.Set(reflectedBody,true);
      mirrorSettings.ReflectLayers=(int)mirrorSettings.ReflectLayers|(1<<reflectedBody.gameObject.layer);
     }
     // Never toggle eye renderers inside OnWillRenderObject; reflection excludes layer30.
     if(equippedVisualScoped&&equippedOriginals!=null)for(int i=0;i<equippedOriginals.Length;i++)visibility.Set(equippedOriginals[i],equippedOriginalEnabled[i]);

     called=true;mirrorRenderOriginal(self,method);
     if(mirrorBodyReports++<12)MelonLogger.Msg("VR MIRROR: callback completed; currentCamera="+(Camera.current==null?"none":Camera.current.name)+" bodyCopy="+(reflectedBody!=null)+" mask="+(int)mirrorSettings.ReflectLayers+"; visual result unverified.");
    }
   }catch(Exception ex){
    if(mirrorBodyReports++<4)MelonLogger.Warning("VR mirror visibility scope failed: "+ex.Message);
    if(!called)mirrorRenderOriginal(self,method);
   }finally{try{if(maskSaved&&mirrorSettings!=null)mirrorSettings.ReflectLayers=savedMask;}finally{mirrorRenderScoped=false;}}
  }
 }
}

