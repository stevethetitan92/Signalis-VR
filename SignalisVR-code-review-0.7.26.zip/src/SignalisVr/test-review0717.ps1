$ErrorActionPreference='Stop'
[Reflection.Assembly]::LoadFrom((Resolve-Path 'work/quest-native-lab/MelonLoader/Mono.Cecil.dll'))|Out-Null
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try{
 $t=$a.MainModule.Types|Where-Object FullName -eq 'SignalisVrTracking.Tracking'
 function Calls($name){@(($t.Methods|Where-Object Name -eq $name).Body.Instructions|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference]}|ForEach-Object {$_.Operand.Name})}
 foreach($n in @('get_tried','get_inRange','get_open','get_traversing')){if((Calls 'MapDoorTried')-contains $n){throw "Door history reads proximity/native state: $n"}}
 if((Calls 'PrepareMapLabels')-notcontains 'CombineMeshes'){throw 'Labels are not batched'}
 if((Calls 'PrepareMapLabels')-notcontains 'Remove'){throw 'Map labels remain owned by health HUD'}
 foreach($n in @('set_cullingMode','set_updateWhenOffscreen')){if((Calls 'PrepareEnemyEyeMaterials')-contains $n){throw "Global enemy animation override: $n"}}
 if((Calls 'PrepareEnemyEyeMaterials')-notcontains 'get_enabled'){throw 'Hidden enemy renderer gate absent'}
 foreach($n in @('FilterAdditionalReloadInput','FilterManualReloadInput')){if((Calls $n)-notcontains 'RetainPhysicalReload'){throw "$n discards physical reload on a temporary gate"}}
 if((Calls 'PrepareManualReload')-notcontains 'ManualSlideRear'){throw 'Authored slide anchor lost'}
 if((Calls 'MeasureItemObjectBounds')-notcontains 'get_isTrigger'){throw 'Range triggers can become marker anchors'}
 if((Calls 'RefreshModMiniMap')-notcontains 'Edge'){throw 'Door glyphs not snapped to room edge'}
}finally{$a.Dispose()}
'PASS compiled regression guards: interaction-only door history, batched independently-owned labels, native enemy visibility, persistent reload state, authored slide contact, physical marker bounds and room-edge doors. Not headset verification.'
