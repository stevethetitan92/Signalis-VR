using UnityEngine;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private GameObject importedLaserRoot,importedLaserDot;private LineRenderer importedLaserBeam;private Material importedLaserMaterial;
 private bool ImportedMuzzle(out Vector3 local){
  local=Vector3.zero;var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null)return false;
  switch(w.parentItem._item){
   case global::Items.itemlist.Pistol:local=HdPistolData.Muzzle;return true;
   case global::Items.itemlist.Shotgun:local=HdShotgunData.Muzzle;return true;
   case global::Items.itemlist.Rifle:local=HdRifleData.Muzzle;return true;
   case global::Items.itemlist.Revolver:local=HdRevolverData.Muzzle*AmmoGuidePolicy.RevolverScale;return true;
   case global::Items.itemlist.FlareGun:local=HdFlareGunData.Muzzle;return true;
   case global::Items.itemlist.SMG:local=new Vector3(0,.101756f,.383283f);return true;
   default:return false;
  }
 }
 private void PrepareImportedLaser(){
  Vector3 local;if(!handsScoped||!ImportedMuzzle(out local)||(!IsXiphias()&&(selectedRoot==null||selectedFailed)))return;
  // Suppress native ray artwork during this render scope; its transforms belong to the old gun.
  foreach(var state in laserEndpointStates)if(state.Renderer!=null)state.Renderer.enabled=false;
  foreach(var a in modLaserObjects)if(a!=null&&a.line!=null)a.line.enabled=false;
  var attack=global::PlayerAttack.instance;
  if(!modLasersOn||attack==null||!attack.aiming||ManualReloadBlocksAttack())return;
  if(importedLaserRoot==null){
   importedLaserRoot=new GameObject("SignalisVR_ImportedLaser");importedLaserRoot.layer=30;UnityEngine.Object.DontDestroyOnLoad(importedLaserRoot);
   importedLaserMaterial=new Material(Shader.Find("Unlit/Color"));
   importedLaserBeam=importedLaserRoot.AddComponent<LineRenderer>();importedLaserBeam.sharedMaterial=importedLaserMaterial;importedLaserBeam.positionCount=2;importedLaserBeam.useWorldSpace=true;importedLaserBeam.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;
   importedLaserDot=GameObject.CreatePrimitive(PrimitiveType.Sphere);importedLaserDot.name="SignalisVR_LaserHit";importedLaserDot.layer=30;importedLaserDot.transform.SetParent(importedLaserRoot.transform,false);UnityEngine.Object.Destroy(importedLaserDot.GetComponent<Collider>());importedLaserDot.GetComponent<Renderer>().sharedMaterial=importedLaserMaterial;
  }
  var origin=rightWeaponPosition+rightWeaponRotation*local*UnitsPerMetre;var direction=rightWeaponRotation*Vector3.forward;
  RaycastHit hit;bool contact=Physics.Raycast(origin,direction,out hit,30*UnitsPerMetre,attack.WallMask.value|attack.TargetMask.value,QueryTriggerInteraction.Ignore);
  var end=contact?hit.point:origin+direction*(30*UnitsPerMetre);
  importedLaserMaterial.color=modLaserColors[modLaserColor];importedLaserBeam.startWidth=importedLaserBeam.endWidth=.0015f*UnitsPerMetre;importedLaserBeam.SetPosition(0,origin);importedLaserBeam.SetPosition(1,end);importedLaserBeam.enabled=true;
  importedLaserDot.SetActive(contact);importedLaserDot.transform.position=end-direction*.002f*UnitsPerMetre;importedLaserDot.transform.localScale=Vector3.one*.005f*UnitsPerMetre;
 }
 private void HideImportedLaser(){if(importedLaserBeam!=null)importedLaserBeam.enabled=false;if(importedLaserDot!=null)importedLaserDot.SetActive(false);}
 private void DestroyImportedLaser(){if(importedLaserRoot!=null)UnityEngine.Object.Destroy(importedLaserRoot);if(importedLaserMaterial!=null)UnityEngine.Object.Destroy(importedLaserMaterial);importedLaserRoot=importedLaserDot=null;importedLaserBeam=null;importedLaserMaterial=null;}
} }
