$ErrorActionPreference='Stop'
Add-Type -Path @((Join-Path $PSScriptRoot 'ShotgunReloadPolicy.cs'),(Join-Path $PSScriptRoot 'HingedReloadPolicy.cs'),(Join-Path $PSScriptRoot 'CylinderFlickPolicy.cs'))
function Check($value,$why){if(-not $value){throw $why}}
$p=[SignalisVrTracking.HingedReloadPolicy]::new()
$p.PressB()
Check ($p.Stage -eq 'Open') 'B did not open cylinder/barrel'
$p.Tick(0,$true,$true,$false,0,6,10)|Out-Null
Check ($p.Stage -eq 'Holding') 'Fresh hip grip did not hold ammo'
$p.Tick(.1,$true,$false,$true,0,6,10)|Out-Null
Check ($p.Tick(.23,$true,$false,$true,0,6,10)) 'Chamber dwell did not request transfer'
Check (-not $p.Tick(.3,$true,$true,$true,0,6,10)) 'Pending transfer repeated'
$p.Inserted()
$p.Tick(.4,$true,$true,$true,0,6,10)|Out-Null
Check ($p.Stage -eq 'Open') 'Held grip duplicated next ammo grab'
$p.Tick(.5,$false,$false,$false,0,6,10)|Out-Null
$p.Tick(.6,$true,$true,$false,0,6,10)|Out-Null
$p.Tick(.7,$false,$false,$true,0,6,10)|Out-Null
Check ($p.Stage -eq 'Open') 'Dropped ammo transferred'
$p.PressB()
Check (-not $p.Active) 'B backup did not close cylinder'
foreach($loaded in 0..6){foreach($reserve in 0..8){
 $amount=[SignalisVrTracking.ManualAmmoTransfer]::LoaderAmount($loaded,6,$reserve,$false)
 Check ($amount -eq [Math]::Min(6-$loaded,$reserve)) 'Speedloader exceeds free chambers/reserve'
}}
Check ([SignalisVrTracking.ManualAmmoTransfer]::LoaderAmount(4,6,0,$true) -eq 2) 'Infinite ammo overfilled cylinder'
Check ([SignalisVrTracking.ManualAmmoTransfer]::Amount(2,2,8,$false) -eq 0) 'Rifle overfilled'
$f=[SignalisVrTracking.CylinderFlickPolicy]::new()
Check (-not $f.Tick(0,12,$true)) 'Tiny roll closed cylinder'
Check (-not $f.Tick(.06,12,$true)) 'Insufficient flick closed cylinder'
Check ($f.Tick(.12,12,$true)) 'Deliberate flick did not close cylinder'
$f.Reset()
foreach($time in 0..20){Check (-not $f.Tick($time*.1,1,$true)) 'Slow rotation closed cylinder'}
Check (-not $f.Tick(3,30,$false)) 'Closed/held ammo flick was accepted'
Check (-not $f.Tick(4,100,$true)) 'Tracking jump treated as flick'
Check ([SignalisVrTracking.RifleCases]::Eject(0) -eq 0) 'Unfired rifle ejected spent cases'
Check ([SignalisVrTracking.RifleCases]::Eject([SignalisVrTracking.RifleCases]::Fired(0,2)) -eq 1) 'One rifle shot did not eject one case'
Check ([SignalisVrTracking.RifleCases]::Eject([SignalisVrTracking.RifleCases]::Fired(1,2)) -eq 2) 'Two rifle shots did not eject two cases'
Write-Host 'PASS: hinged reload, partial speedloader, reserve limits, drops, cylinder flick and rifle case counts'
