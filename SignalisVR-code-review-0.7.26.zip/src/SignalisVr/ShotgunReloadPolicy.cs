namespace SignalisVrTracking {
 public sealed class ShotgunReloadPolicy {
  public enum Step { Idle, Holding, AwaitingInsert, PumpReady, Pumping }
  public Step Stage {get;private set;}
  public bool Active {get{return Stage!=Step.Idle;}}
  private bool lastGrip,needsPump,pulled,spent,strokeLive;
  public int EjectionCount {get;private set;}
  public bool LastEjectionLive {get;private set;}
  private float dwell=-1,origin;
  public float Pull {get;private set;}
  public bool NeedsPump {get{return needsPump;}}
  // Interrupting a gesture must not chamber a round (menus, tracking or swaps).
  public void Interrupt(){Stage=needsPump?Step.PumpReady:Step.Idle;lastGrip=false;pulled=false;dwell=-1;Pull=0;}
  public void Fired(){needsPump=true;spent=true;Stage=Step.PumpReady;pulled=false;dwell=-1;Pull=0;}
  public void Cancel(){Stage=Step.Idle;lastGrip=false;needsPump=spent=strokeLive=false;pulled=false;dwell=-1;Pull=0;}
  // Return true exactly once for a held-shell insertion. Ammo transfer is owned by Update.
  public bool Tick(float now,bool grip,bool pouch,bool port,bool pump,float position,int loaded,int capacity,int reserve){
   bool down=grip&&!lastGrip;lastGrip=grip;
   if((Stage==Step.Idle||Stage==Step.PumpReady)&&down&&pouch&&CanTransfer(loaded,capacity,reserve)){needsPump=needsPump||loaded==0;Stage=Step.Holding;dwell=-1;}
   else if(Stage==Step.Holding){
    if(!grip){Stage=needsPump?Step.PumpReady:Step.Idle;dwell=-1;}
    else if(port){if(dwell<0)dwell=now;if(now-dwell>=.12f){Stage=Step.AwaitingInsert;dwell=-1;return true;}}
    else dwell=-1;
   }else if((Stage==Step.PumpReady||Stage==Step.Idle&&down)&&grip&&pump){strokeLive=!needsPump&&loaded>0;Stage=Step.Pumping;origin=position;pulled=false;Pull=0;}
   else if(Stage==Step.Pumping){
    if(float.IsNaN(position)||float.IsInfinity(position)||System.Math.Abs(position-origin)>.35f){Interrupt();return false;}
    Pull=System.Math.Min(.1f,System.Math.Max(0,position-origin));
    if(Pull>=.07f&&!pulled){
     pulled=true;
     if(strokeLive||spent){LastEjectionLive=strokeLive;EjectionCount++;}
     spent=strokeLive=false;needsPump=true;
    }
    if(!grip){Stage=Step.PumpReady;Pull=0;}
    else if(pulled&&Pull<=.02f){needsPump=loaded==0;Stage=needsPump?Step.PumpReady:Step.Idle;Pull=0;}
   }
   return false;
  }
  public void Inserted(int loaded,int capacity,int reserve){Stage=needsPump?Step.PumpReady:Step.Idle;}
  public static bool CanTransfer(int loaded,int capacity,int reserve){return loaded>=0&&capacity>0&&loaded<capacity&&reserve>0;}
 }
}
