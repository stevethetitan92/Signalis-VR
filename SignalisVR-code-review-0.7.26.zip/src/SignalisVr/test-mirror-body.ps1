$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'MirrorBody.cs') -Raw
$scope=$source.Substring($source.IndexOf(' public sealed class MirrorVisibilityScope'),$source.IndexOf(' public sealed partial class Tracking')-$source.IndexOf(' public sealed class MirrorVisibilityScope'))
Add-Type -TypeDefinition (@'
using System;using System.Collections.Generic;
namespace UnityEngine {public class Renderer {public bool enabled;}}
usingPlaceholder
public static class MirrorTests {
 public static void Run() {
  var body=new UnityEngine.Renderer();var hand=new UnityEngine.Renderer{enabled=true};
  try {using(var s=new MirrorVisibilityScope()) {s.Set(body,true);s.Set(hand,false);s.Set(null,true);if(!body.enabled||hand.enabled)throw new Exception("scope did not expose native body");s.Set(body,false);throw new InvalidOperationException("simulated render failure");}}
  catch(InvalidOperationException){}
  if(body.enabled||!hand.enabled)throw new Exception("render failure/duplicate must restore exact original visibility");
  var unchanged=new UnityEngine.Renderer();using(var s=new MirrorVisibilityScope()){s.Set(unchanged,false);}if(unchanged.enabled)throw new Exception("native disabled state not preserved");
  var native=new UnityEngine.Renderer{enabled=true};
  using(var eye=new MirrorVisibilityScope()) {
   eye.Set(native,false);
   using(var reflection=new MirrorVisibilityScope()){eye.RestoreInto(reflection);if(!native.enabled)throw new Exception("no-hands reflection missing");}
   if(native.enabled)throw new Exception("native body leaked into eye");
  }
  if(!native.enabled)throw new Exception("eye scope lost original body state");
  foreach(bool initial in new[]{false,true})foreach(bool fail in new[]{false,true}) {
   native.enabled=initial;
   using(var eye=new MirrorVisibilityScope()) {
    eye.Set(native,!initial);eye.Set(native,initial);
    try {using(var reflection=new MirrorVisibilityScope()) {
     eye.RestoreInto(reflection);
     if(native.enabled!=initial)throw new Exception("duplicate restoration lost original state");
     if(fail)throw new InvalidOperationException("reflection failed");
    }}catch(InvalidOperationException){}
    if(native.enabled!=initial)throw new Exception("reflection did not restore eye state");
   }
   if(native.enabled!=initial)throw new Exception("eye did not restore original state");
  }
  using(var eye=new MirrorVisibilityScope()) {
   native.enabled=false;eye.Set(native,false);
   using(var reflection=new MirrorVisibilityScope()){eye.RestoreInto(reflection);reflection.Set(native,true);if(!native.enabled)throw new Exception("hand scope override missing");}
   if(native.enabled)throw new Exception("nested hand visibility leaked");
  }
 }
}
'@).Replace('usingPlaceholder',$scope.Replace('Renderer','UnityEngine.Renderer'))
[MirrorTests]::Run()
'PASS actual reflection visibility scope: native/copy visibility, nulls, disabled state, reverse restoration after render failure and duplicate entries.'
if(!$source.Contains('NativeMethodInfoPtr_RenderMirror_Internal_Void_0') -or !$source.Contains('0x643F70')){throw 'Native hook layout not guarded'}
'PASS audited native layout guard; live mirror hook/rendering remains unverified.'
