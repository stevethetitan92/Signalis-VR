using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private readonly Dictionary<int,global::AnItem> mapIconItems=new Dictionary<int,global::AnItem>();
 private readonly List<SpriteRenderer> mapIconRenderers=new List<SpriteRenderer>();
 private int mapIconCount;
 private Sprite MapNativeIcon(int kind,out Color color){
  color=Color.white;if(kind<100||kind==100+(int)global::Items.itemlist.RevolverAmmo)return null;
  if(kind==100+(int)global::Items.itemlist.SMG)ApplyInventorySmgIcon(null);
  global::AnItem item;
  if(!mapIconItems.TryGetValue(kind,out item)||item==null){
   foreach(var entry in Resources.FindObjectsOfTypeAll<global::AnItem>())if(entry!=null)mapIconItems[100+(int)entry._item]=entry;
   if(!mapIconItems.TryGetValue(kind,out item)||item==null)return null;
  }
  if(item.type==global::AnItem.AnItemType.Health)color=new Color(.52f,.93f,.62f);
  else if(item.type==global::AnItem.AnItemType.Ammo)color=new Color(1,.85f,.1f);
  if(item._item.ToString()=="Taser")color=new Color(.22f,.48f,1);
  if(item._item.ToString()=="SignalFlare")color=new Color(1,.45f,.05f);
  return item.Icon!=null?item.Icon:item.Image;
 }
 private void MapNativeVr(Vector2 p,int kind,float size){
  size*=.40f;
  Color color;var icon=MapNativeIcon(kind,out color);if(icon==null)return;
  for(int halo=0;halo<2;halo++){
   if(mapIconCount==mapIconRenderers.Count){var go=new GameObject("MapItemIcon");go.layer=30;go.transform.SetParent(modMapRoot.transform,false);mapIconRenderers.Add(go.AddComponent<SpriteRenderer>());}
   var r=mapIconRenderers[mapIconCount++];r.sprite=icon;r.enabled=true;r.sortingOrder=halo==0?3:5;var tint=color;tint.a=halo==0?.18f:.95f;r.color=tint;
   r.transform.localPosition=new Vector3(p.x,p.y,-.006f*UnitsPerMetre);
   r.transform.localRotation=Quaternion.identity;r.transform.localScale=Vector3.one*(12*size/Mathf.Max(icon.bounds.size.x,icon.bounds.size.y))*(halo==0?1.2f:1);
  }
 }
 private void MapNativeDesktop(Vector2 at,int kind,float size){
  size*=.40f;
  Color color;var icon=MapNativeIcon(kind,out color);if(icon==null)return;
  var tex=icon.texture;var uv=icon.textureRect;float aspect=uv.width/uv.height;
  float w=12*size*Mathf.Min(1,aspect),h=12*size/Mathf.Max(1,aspect);
  uv=new Rect(uv.x/tex.width,uv.y/tex.height,uv.width/tex.width,uv.height/tex.height);
  var old=GUI.color;
  for(int halo=0;halo<2;halo++){float k=halo==0?1.2f:1;var c=color;c.a=halo==0?.18f:.95f;GUI.color=c;GUI.DrawTextureWithTexCoords(new Rect(at.x-w*k/2,at.y-h*k/2,w*k,h*k),tex,uv,true);}
  GUI.color=old;
 }
 private void MapPointLines(Vector2 p,int kind,float size,Action<Vector2,Vector2,Color,float> draw){
  if(kind==100+(int)global::Items.itemlist.RevolverAmmo)kind=10;
  if(kind>=100)return;
  // Match native sprites: every symbol fits the same 10.2-unit square.
  float span=kind==0?10f:kind==1?10f:kind==2?12f:kind==3?9.8f:kind==4?11f:kind==5?11f:kind==6?13f:kind==7?12f:kind==8?11f:10f;
  size*=4.8f/span;
  Color white=Color.white,red=new Color(1,.12f,.12f),gold=new Color(1,.85f,.1f),orange=new Color(1,.45f,.05f),green=new Color(.52f,.93f,.62f),blue=new Color(.22f,.48f,1),pink=new Color(1,.51f,.76f);
  Action<Color,float[]> path=(c,v)=>{for(int i=2;i<v.Length;i+=2)draw(p+new Vector2(v[i-2],v[i-1])*size,p+new Vector2(v[i],v[i+1])*size,c,size*.7f);};
  Action<Color,float,float,float> circle=(c,x,y,r)=>{for(int i=0;i<16;i++){float a=i*(float)Math.PI/8,b=(i+1)*(float)Math.PI/8;draw(p+new Vector2(x+Mathf.Cos(a)*r,y+Mathf.Sin(a)*r)*size,p+new Vector2(x+Mathf.Cos(b)*r,y+Mathf.Sin(b)*r)*size,c,size*.7f);}};
  if(kind==0){path(new Color(.65f,.015f,.025f),new float[]{-3,5,3,5,3,-2,1,-5,-1,-5,-3,-2,-3,5});}
  if(kind==1){path(red,new float[]{-5,-5,5,-5,5,5,-5,5,-5,-5});for(int i=-1;i<=1;i+=2){path(red,new float[]{i*1.65f,-5,i*1.65f,5});path(red,new float[]{-5,i*1.65f,5,i*1.65f});}}
  if(kind==2){path(orange,new float[]{-6,-4,6,-4,6,3,5,5,-5,5,-6,3,-6,-4});path(orange,new float[]{-6,3,6,3});path(orange,new float[]{-6,1,-1,1,-1,-1,1,-1,1,1,6,1});path(orange,new float[]{-1,1,-1,2,1,2,1,1});}
  if(kind==3){circle(gold,2.5f,2.5f,2.3f);path(gold,new float[]{1,1,-4,-4,-5,-3,-3,-1,-2,-2});}
  if(kind==4){path(white,new float[]{-3,-5,-6,-5,-6,3,-5,3});path(white,new float[]{-2,-4,-5,-4,-5,4,-4,4});path(white,new float[]{-4,-3,5,-3,5,3,3,5,-4,5,-4,-3});path(white,new float[]{3,5,3,3,5,3});for(int i=0;i<3;i++)path(red,new float[]{-2,2-i*1.5f,3,2-i*1.5f});}
  if(kind==5||kind==8){var c=kind==5?red:white;int n=kind==8?2:1;for(int i=0;i<n;i++){float x=n==1?0:i*5-2.5f;path(c,new float[]{x-1.5f,-5,x+1.5f,-5,x+1.5f,2,x+.7f,5,x,6,x-.7f,5,x-1.5f,2,x-1.5f,-5});path(c,new float[]{x-1.5f,2,x+1.5f,2});}}
  if(kind==6){path(green,new float[]{-6,-4,5,-5,5,3,-6,4,-6,-4});path(green,new float[]{-6,4,-4,6,7,5,7,-3,5,-5});path(green,new float[]{5,3,7,5});path(green,new float[]{-2,5,-2,7,2,7,2,5});path(green,new float[]{-6,2,5,1});}
  if(kind==7){path(blue,new float[]{-6,-5,6,-5,6,-3,-6,-3,-6,-5});for(int i=0;i<5;i++){float x=i*2.5f-5;path(blue,new float[]{x-.7f,-3,x-.7f,2,x,5,x+.7f,2,x+.7f,-3});}}
  if(kind==9){var c=new Color(.8f,.333f,0);path(c,new float[]{-3,-4,-3,4,-2,5,2,5,3,4,3,-4,2,-5,-2,-5,-3,-4});path(c,new float[]{-3,4,-2,3,2,3,3,4});path(c,new float[]{-3,-3,-2,-4,2,-4,3,-3});path(red,new float[]{0,-3,-2,-1,-1,1,0,0,1,3,2,0,2,-1,0,-3});}
  if(kind==10){
   // Filled reference silhouette: rounded projectile, shoulder, case and separated rim.
   var yellow=new Color(1,1,0);
   for(float y=-5;y<=5;y+=.25f){
    if((y>1.45f&&y<1.95f)||(y>-4.5f&&y<-4.05f))continue;
    float half=y>=1.95f?1.55f*(float)Math.Sqrt(Math.Max(0,1-Math.Pow((y-1.95f)/3.05f,2))):y>-.7f?1.6f:2.1f;
    if(y<=-4.5f)half=1.8f;
    draw(p+new Vector2(-half,y)*size,p+new Vector2(half,y)*size,yellow,size*.28f);
   }
  }
 }
}}

