$ErrorActionPreference='Stop'
$s=Get-Content "$PSScriptRoot/DependencyGuards.cs" -Raw
$a=$s.IndexOf(' private static bool FlashlightSceneReady()');$method=$s.Substring($a,$s.LastIndexOf('}}')-$a)
$fixture=@'
using System;
public class Transform {public int childCount;public Transform child;public Transform Find(string path){if(path!="Character Origin/Character Root/Ellie_Default/FlashLightHolder/FlashLight")throw new Exception("path");return child;}}
public class GameObject {public static GameObject root;public Transform transform=new Transform();public static GameObject Find(string name){return root;}}
public class Check {
'@
Add-Type ($fixture+$method+@'
public static void Run(){if(FlashlightSceneReady())throw new Exception("missing root");GameObject.root=new GameObject();if(FlashlightSceneReady())throw new Exception("missing flashlight");GameObject.root.transform.child=new Transform();for(int i=0;i<5;i++){GameObject.root.transform.child.childCount=i;if(FlashlightSceneReady()!=(i>1))throw new Exception("child count");}}
}
'@)
[Check]::Run()
$s=Get-Content "$PSScriptRoot/EnemyEyeMaterials.cs" -Raw
$method=[regex]::Match($s,' private void RestoreEnemyEyeMaterials\(\)\{[^\r\n]+').Value
Add-Type (@'
using System;using System.Collections.Generic;
public class Renderer {public bool enabled;}
public class RestoreCheck {
List<Renderer> enemyEyeVisible=new List<Renderer>();Dictionary<Renderer,bool> enemyEyeEnabled=new Dictionary<Renderer,bool>();
'@+$method+@'
public static void Run(){var t=new RestoreCheck();var copy=new Renderer{enabled=true};var native=new Renderer{enabled=false};var hidden=new Renderer{enabled=true};t.enemyEyeVisible.Add(copy);t.enemyEyeVisible.Add(null);t.enemyEyeEnabled[native]=true;t.enemyEyeEnabled[hidden]=false;t.RestoreEnemyEyeMaterials();if(copy.enabled||!native.enabled||hidden.enabled||t.enemyEyeVisible.Count!=0||t.enemyEyeEnabled.Count!=0)throw new Exception("restore");t.RestoreEnemyEyeMaterials();}
}
'@)
[RestoreCheck]::Run()
if(!$s.Contains('c.Materials.Length!=originals.Length')){throw 'Changed material layout not invalidated'}
$map=Get-Content "$PSScriptRoot/MapPoints.cs" -Raw
if(!$map.Contains('mapObjects.Add(point);highlightContexts.Clear();')){throw 'Marker ownership cache stale after discovery'}
$controls=Get-Content "$PSScriptRoot/ControlsTab.cs" -Raw
if(!$controls.Contains('DestroyControlsTab(){DestroyPauseControlsImage();')){throw 'Pause image outlives its texture'}
$menu=Get-Content "$PSScriptRoot/ModMenu.cs" -Raw
if($menu.Contains('Assign carried items on the Item Wheel tab.')){throw 'Instructions point to removed tab'}
'PASS actual flashlight hierarchy guard and enemy eye restoration, plus marker/material/pause lifecycle integration checks. Native Unity and headset behavior unverified.'
