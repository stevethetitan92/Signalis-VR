using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private const string MapDiscoveryPrefix="SignalisVR.Map.Discovered.v2:";
 private readonly List<Vector2> mapLabelPoints=new List<Vector2>();
 private readonly List<string> mapLabelTexts=new List<string>();
 private readonly List<Mesh> mapLabelMeshes=new List<Mesh>();
 private readonly List<Transform> mapLabelTransforms=new List<Transform>();
 private readonly List<string> mapLabelPrevious=new List<string>();
 private readonly List<Renderer[]> mapLabelRenderers=new List<Renderer[]>();
 private static bool MapSameRoom(global::Room a,global::Room b){return a!=null&&b!=null&&(a==b||(a.minimapRoom!=null&&a.minimapRoom==b.minimapRoom));}
 private string MapCanonicalId(string live,int kind,global::Room room){
  string selected=null;int count=0;
  foreach(var e in mapCatalogue)if(e.Kind==kind&&e.Floor==(int)room.floor&&MapIdentityPolicy.Matches(e.Id,live)){selected=e.Id;count++;}
  string id=MapDiscoveryPrefix+(count==1?selected:live),old=MapDiscoveryPrefix+live;
  if(id!=old&&global::SProgress.GetInt(old,0)!=0&&global::SProgress.GetInt(id,0)==0){global::SProgress.SetInt(id,1);MelonLoader.MelonLogger.Msg("MAP MIGRATE: "+old+" -> "+id);}
  return id;
 }
 private static string MapVisitKey(int floor,string room){return "SignalisVR.Map.Visited.v1:"+floor+"|"+room;}
 private void MapMarkVisited(){var r=global::PlayerState.currentRoom;if(r==null||r.minimapRoom==null)return;string k=MapVisitKey((int)r.floor,r.minimapRoom.name);if(global::SProgress.GetInt(k,0)==0){global::SProgress.SetInt(k,1);nextModMapRefresh=0;}}
 private float MapDiscoveryDistance(MapPoint point,Vector3 player){
  // Native interaction range is an authoritative close-enough observation.
  if(point.Inter!=null&&point.Inter.inRange)return 0;
  var p=point.Target.position;float d=new Vector2(player.x-p.x,player.y-p.y).magnitude;
  if(point.Inter!=null&&point.Inter.pointOfInterest!=null){p=point.Inter.pointOfInterest.position;d=Mathf.Min(d,new Vector2(player.x-p.x,player.y-p.y).magnitude);}
  return d/UnitsPerMetre;
 }
 private void MapRememberPosition(MapPoint point,Vector2 position,global::PersistentMinimapFloor floor,Transform basis){
  if(point.Room.minimapRoom==null)return;Vector2 lo,hi;if(!MapCatalogueBounds(floor,basis,point.Room.minimapRoom.name,out lo,out hi))return;
  var raw=position/modMapScale+modMapCenter;
  int x=(int)(Mathf.InverseLerp(lo.x,hi.x,raw.x)*100000),y=(int)(Mathf.InverseLerp(lo.y,hi.y,raw.y)*100000);
  if(global::SProgress.GetInt(point.Id+":position",0)==0||global::SProgress.GetInt(point.Id+":x",0)!=x||global::SProgress.GetInt(point.Id+":y",0)!=y){global::SProgress.SetInt(point.Id+":x",x);global::SProgress.SetInt(point.Id+":y",y);global::SProgress.SetInt(point.Id+":position",1);}
 }
 private void AddMapLabel(Vector2 point,string text){
  if(string.IsNullOrWhiteSpace(text))return;
  text=System.Text.RegularExpressions.Regex.Replace(text,"<[^>]+>","");
  var lines=text.Replace("\r","").Split('\n');
  for(int i=0;i<lines.Length;i++)if(!string.IsNullOrWhiteSpace(lines[i])){mapLabelPoints.Add(point+new Vector2(0,((lines.Length-1)*.5f-i)*.0045f*UnitsPerMetre));mapLabelTexts.Add(lines[i].Trim().ToUpperInvariant());}
 }
 private void MapRoomLabels(global::PersistentMinimapFloor floor,Transform basis){
  var rooms=new List<global::PersistentMinimapRoom>();if(floor.Rooms!=null)foreach(var r in floor.Rooms)if(r!=null&&!rooms.Contains(r))rooms.Add(r);foreach(var r in floor.GetComponentsInChildren<global::PersistentMinimapRoom>(true))if(r!=null&&!rooms.Contains(r))rooms.Add(r);
  foreach(var room in rooms){
   if(room.RoomID==null)continue;
   bool visited=global::SProgress.GetInt(MapVisitKey((int)floor.FloorID,room.RoomID.name),0)!=0;
   if(!room.discovered&&room.room!=global::PlayerState.currentRoom)continue;
   Vector2 labelLow,labelHigh;if(!MapCatalogueBounds(floor,basis,room.RoomID.name,out labelLow,out labelHigh))continue;
   if(room.RoomLabel!=null&&!string.IsNullOrWhiteSpace(room.RoomLabel.text)){
    var p=basis.InverseTransformPoint(room.RoomLabel.transform.position);AddMapLabel((new Vector2(Mathf.Clamp(p.x,labelLow.x,labelHigh.x),Mathf.Clamp(p.y,labelLow.y,labelHigh.y))-modMapCenter)*modMapScale,room.RoomLabel.text);
   }else{Vector2 lo,hi;if(MapCatalogueBounds(floor,basis,room.RoomID.name,out lo,out hi))AddMapLabel(((lo+hi)*.5f-modMapCenter)*modMapScale,room.RoomID.name);}
  }
 }
 private void MapPuzzleLabel(global::MinimapPOI poi,Transform basis){
  foreach(var text in poi.GetComponentsInChildren<TMPro.TextMeshPro>(true)){
   if(string.IsNullOrWhiteSpace(text.text))continue;var p=basis.InverseTransformPoint(text.transform.position);AddMapLabel((new Vector2(p.x,p.y)-modMapCenter)*modMapScale,text.text);
  }
 }
 private Mesh mapLabelsBatch;private MeshRenderer mapLabelsView;private bool mapLabelsDirty=true;
 private void PrepareMapLabels(){
  if(!mapLabelsDirty){if(mapLabelsView!=null)mapLabelsView.enabled=true;return;}
  for(int i=0;i<mapLabelTexts.Count;i++){
   if(i>=mapLabelMeshes.Count){var mesh=CreateModHudText("MapLabel"+i,0);var filters=modHudRoot.GetComponentsInChildren<MeshFilter>(true);Transform t=null;foreach(var f in filters)if(f.sharedMesh==mesh&&f.gameObject.name=="MapLabel"+i){t=f.transform;break;}if(t==null)throw new InvalidOperationException("Map label mesh unavailable");t.SetParent(modMapRoot.transform,false);mapLabelMeshes.Add(mesh);mapLabelTransforms.Add(t);mapLabelPrevious.Add(null);var owned=t.GetComponentsInChildren<Renderer>(true);foreach(var r in owned)modHudRenderers.Remove(r);mapLabelRenderers.Add(owned);}
   string previous=mapLabelPrevious[i];UpdateModHudText(mapLabelMeshes[i],mapLabelTexts[i],ref previous);mapLabelPrevious[i]=previous;
   var p=mapLabelPoints[i];mapLabelTransforms[i].localPosition=new Vector3(p.x,p.y,-.01f*UnitsPerMetre);mapLabelTransforms[i].localRotation=Quaternion.identity;mapLabelTransforms[i].localScale=Vector3.one*.20f;
   foreach(var r in mapLabelRenderers[i])r.enabled=false;
  }
  for(int i=mapLabelTexts.Count;i<mapLabelRenderers.Count;i++)foreach(var r in mapLabelRenderers[i])r.enabled=false;
  if(mapLabelsView==null&&mapLabelRenderers.Count>0){var go=new GameObject("MapLabelsBatched");go.layer=30;go.transform.SetParent(modMapRoot.transform,false);mapLabelsBatch=new Mesh();mapLabelsBatch.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;go.AddComponent<MeshFilter>().sharedMesh=mapLabelsBatch;mapLabelsView=go.AddComponent<MeshRenderer>();mapLabelsView.sharedMaterial=mapLabelRenderers[0][0].sharedMaterial;mapLabelsView.sortingOrder=5;}
  if(mapLabelsView!=null){var combine=new CombineInstance[mapLabelTexts.Count];for(int i=0;i<combine.Length;i++)combine[i]=new CombineInstance{mesh=mapLabelMeshes[i],transform=Matrix4x4.TRS(mapLabelTransforms[i].localPosition,Quaternion.identity,mapLabelTransforms[i].localScale)};mapLabelsBatch.Clear();if(combine.Length>0)mapLabelsBatch.CombineMeshes(combine,true,true);mapLabelsView.enabled=combine.Length>0;}mapLabelsDirty=false;
 }
}}
