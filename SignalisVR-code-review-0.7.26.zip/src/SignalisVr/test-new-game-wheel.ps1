$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'QuickNewGame.cs') -Raw
$helper=$s.Substring($s.IndexOf(' public static class QuickSlotDefaults'))
$helper=$helper.Substring(0,$helper.IndexOf(' public sealed partial class Tracking'))
Add-Type -TypeDefinition ('namespace SignalisVrTracking {'+$helper+'}')
$slots=[string[]]@('Pistol','Taser','Health25','Shotgun')
[SignalisVrTracking.QuickSlotDefaults]::Clear($slots)
if(($slots -join '|') -ne 'None|None|None|None'){throw 'New-game slots retained prior assignments'}
if([SignalisVrTracking.QuickSlotDefaults]::Caption('NO ITEM',0) -ne 'NO ITEM'){throw 'Empty wheel caption has extra count'}
if([SignalisVrTracking.QuickSlotDefaults]::Caption('Pistol',4) -ne 'Pistol 4'){throw 'Carried item lost count'}
foreach($needle in @('typeof(global::SaveManager),"NewGame"','postfix:','QuickSlotDefaults.Clear(q.quickSlots)','q.SaveModSettings();')){if(!$s.Contains($needle)){throw "New-game reset/save integration missing: $needle"}}
if($s.Contains('"LoadGame"') -or $s.Contains('"ResetProgress"')){throw 'Normal save-load/progress reset also clears wheel'}
$menu=Get-Content (Join-Path $PSScriptRoot 'ModMenu.cs') -Raw
if($menu.Contains('HUD Placement') -or !$menu.Contains('"HUD"') -or !$menu.Contains('modHudOn?(modHudRight?"RIGHT HAND":"LEFT HAND"):"OFF"') -or !$menu.Contains('if(index==3){CycleHudMode(direction);return;}')){throw 'HUD ON/OFF integration wrong'}
'PASS actual new-game slot clearing and NO ITEM/count captions, NewGame-only saved reset and HUD binary control source guards. Native NewGame hook delivery unverified.'
