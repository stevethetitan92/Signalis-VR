using UnityEngine;
using HarmonyLib;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private global::StorageBox stereoStorageBox;
 private global::Room stereoStorageRoom;
 private global::InventoryBase stereoStorageInventory;
 private float stereoStorageStart;
 private bool stereoStorageSawInventory;
 private void InstallStorageStereo(){questHarmony.Patch(AccessTools.Method(typeof(global::StorageBox),"triggered"),prefix:new HarmonyMethod(typeof(Tracking),nameof(StorageStereoTriggered)));}
 private static void StorageStereoTriggered(global::StorageBox __instance){
  var q=questOwner;if(q==null||!q.immersiveRequested)return;
  q.stereoStorageBox=__instance;q.stereoStorageRoom=global::PlayerState.currentRoom;q.stereoStorageStart=Time.realtimeSinceStartup;q.stereoStorageSawInventory=false;
  q.stereoStorageInventory=null;foreach(var i in Resources.FindObjectsOfTypeAll<global::InventoryBase>())if(i!=null&&i.gameObject.scene.IsValid()){q.stereoStorageInventory=i;break;}
 }
 private bool StorageStereoActive(){
  if(stereoStorageBox==null||stereoStorageRoom!=global::PlayerState.currentRoom||!stereoStorageBox.gameObject.activeInHierarchy)return false;
  var state=global::PlayerState.gameState;
  if(state==global::PlayerState.gameStates.inventory){stereoStorageSawInventory=true;return true;}
  if(state==global::PlayerState.gameStates.play&&stereoStorageSawInventory){stereoStorageBox=null;return false;}
  return !stereoStorageSawInventory&&Time.realtimeSinceStartup-stereoStorageStart<8&&(state==global::PlayerState.gameStates.play||state==global::PlayerState.gameStates.cutscene);
 }
}}
