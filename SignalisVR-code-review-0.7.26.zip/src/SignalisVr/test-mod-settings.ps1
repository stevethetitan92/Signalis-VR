$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ModSettingsFile.cs')
$path=Join-Path $PSScriptRoot ('settings-test-data/'+[guid]::NewGuid().ToString()+'.settings')
$s=[SignalisVrTracking.ModSettingsFile]::Load($path)
if(-not $s.Lasers -or -not $s.HudOn -or $s.MiniMap -or $s.Inventory14Slots){throw 'Missing file defaults failed; cheats must be OFF'}
$s.Lasers=$false;$s.LaserColor=4;$s.ManualReload=$true;$s.HudOn=$false;$s.HudRight=$false;$s.MiniMap=$true
$s.Inventory14Slots=$true
$s.Save($path)
$r=[SignalisVrTracking.ModSettingsFile]::Load($path)
if($r.Lasers -or $r.LaserColor -ne 4 -or -not $r.ManualReload -or $r.HudOn -or $r.HudRight -or -not $r.MiniMap -or -not $r.Inventory14Slots){throw 'Settings roundtrip failed'}
$s.LaserColor=2;$s.Save($path)
if(([SignalisVrTracking.ModSettingsFile]::Load($path)).LaserColor -ne 2 -or -not(Test-Path ($path+'.bak'))){throw 'Replacement save/backup failed'}
$s.Inventory14Slots=$false;$s.Save($path)
if(([SignalisVrTracking.ModSettingsFile]::Load($path)).Inventory14Slots){throw 'OFF choice did not persist'}
[IO.File]::WriteAllLines($path,@('LaserColor=99','HudOn=garbage','MiniMap=True','Unknown=True','broken'))
$r=[SignalisVrTracking.ModSettingsFile]::Load($path)
if($r.LaserColor -ne 0 -or -not $r.HudOn -or -not $r.MiniMap -or $r.Inventory14Slots){throw 'Malformed/legacy settings must not enable cheat'}
$s.LaserColor=-1
$failed=$false;try{$s.Save($path)}catch{$failed=$true}
if(-not $failed){throw 'Invalid save accepted'}
'PASS defaults, full roundtrip, replacement/backup, malformed values and invalid save rejection. Test files retained in output only.'
$s=[SignalisVrTracking.ModSettingsFile]::new()
if($s.InfiniteLife -or $s.InfiniteAmmo -or $s.InfiniteStunProd){throw 'Gameplay cheats must default OFF'}
$s.InfiniteLife=$true;$s.InfiniteAmmo=$true;$s.InfiniteStunProd=$true;$s.Save($path)
$r=[SignalisVrTracking.ModSettingsFile]::Load($path)
if(-not $r.InfiniteLife -or -not $r.InfiniteAmmo -or -not $r.InfiniteStunProd){throw 'Gameplay cheat ON roundtrip failed'}
$s.InfiniteLife=$false;$s.InfiniteAmmo=$false;$s.InfiniteStunProd=$false;$s.Save($path)
$r=[SignalisVrTracking.ModSettingsFile]::Load($path)
if($r.InfiniteLife -or $r.InfiniteAmmo -or $r.InfiniteStunProd){throw 'Gameplay cheat OFF roundtrip failed'}
[IO.File]::WriteAllLines($path,@('InfiniteLife=broken','InfiniteAmmo=broken','InfiniteStunProd=broken'))
$r=[SignalisVrTracking.ModSettingsFile]::Load($path)
if($r.InfiniteLife -or $r.InfiniteAmmo -or $r.InfiniteStunProd){throw 'Malformed cheat settings enabled cheat'}
'PASS all gameplay cheat persistence/defaults'
foreach($key in @('AllWeapons','InstantKill','MapComplete')) {
 $s=[SignalisVrTracking.ModSettingsFile]::new()
 if($s.$key){throw "$key default ON"}
 $s.$key=$true;$s.Save($path)
 if(-not ([SignalisVrTracking.ModSettingsFile]::Load($path)).$key){throw "$key ON save failed"}
 $s.$key=$false;$s.Save($path)
 if(([SignalisVrTracking.ModSettingsFile]::Load($path)).$key){throw "$key OFF save failed"}
}
'PASS storage, instant kill and Map Complete persistence'
$s=[SignalisVrTracking.ModSettingsFile]::new()
if($s.AlyxWheel){throw 'Wheel default ON'}
$s.AlyxWheel=$true;$s.WheelSlots=@('Pistol','Taser','Health25','Flashlight');$s.Save($path)
$r=[SignalisVrTracking.ModSettingsFile]::Load($path)
if(-not $r.AlyxWheel -or ($r.WheelSlots -join ',') -ne 'Pistol,Taser,Health25,Flashlight'){throw 'Wheel assignment persistence failed'}
'PASS wheel toggle and four assignments persist'



