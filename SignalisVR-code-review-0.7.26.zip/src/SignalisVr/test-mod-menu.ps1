$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ModMenuInput.cs')
$p=[SignalisVrTracking.ModMenuInput]::new()
function Check($v,$text){if(-not $v){throw $text}}
Check (-not $p.Toggle($true,$true,$false)) 'Single stick toggled'
Check ($p.Toggle($true,$true,$true)) 'Chord failed'
Check (-not $p.Toggle($true,$true,$true)) 'Held chord repeated'
Check (-not $p.Toggle($true,$false,$true)) 'Partial release toggled'
Check (-not $p.Toggle($true,$true,$true)) 'Partial release rearmed'
$p.Toggle($true,$false,$false)|Out-Null
Check ($p.Toggle($true,$true,$true)) 'Full release failed to rearm'
$p.Toggle($false,$false,$false)|Out-Null
Check (-not $p.Toggle($true,$true,$true)) 'Reconnect held chord toggled'
Check ($p.Navigate(-1,1) -eq 1) 'Down selection'
Check ($p.Navigate(-1,1.1) -eq 0) 'Repeat too early'
Check ($p.Navigate(-1,1.5) -eq 1) 'Repeat missing'
Check ($p.Navigate(1,1.6) -eq -1) 'Direction change missing'
Check ($p.Confirm($true)) 'Confirm edge missing'
Check (-not $p.Confirm($true)) 'Confirm repeated'
Check ($p.Cancel($true)) 'Cancel edge missing'
'PASS: chord latch, reconnect, navigation repeat and button edges; runtime menu unverified.'
# Grip section changes: one edge; held/both/reconnect inputs do not repeat.
Check ($p.Section($false,$false,$false) -eq 0) 'Closed menu section change'
Check ($p.Section($true,$false,$true) -eq 1) 'Right grip did not move right'
Check ($p.Section($true,$false,$true) -eq 0) 'Held right repeated'
Check ($p.Section($true,$true,$true) -eq 0) 'Both grips changed section'
Check ($p.Section($true,$true,$false) -eq 0) 'Partial release changed section'
$p.Section($true,$false,$false)|Out-Null
Check ($p.Section($true,$true,$false) -eq -1) 'Left grip did not move left'
$p.Section($false,$false,$true)|Out-Null
Check ($p.Section($true,$false,$true) -eq 0) 'Held grip at open/reconnect changed section'
'PASS grip section edges'
Check ($p.Adjust(1,10) -eq 1) 'Right adjustment missing'
Check ($p.Adjust(1,10.1) -eq 0) 'Adjustment repeat too early'
Check ($p.Adjust(1,10.5) -eq 1) 'Adjustment repeat missing'
Check ($p.Adjust(-1,10.6) -eq -1) 'Left adjustment missing'
Check ($p.Adjust(0,10.7) -eq 0) 'Neutral adjustment'
Check ($p.Adjust(-1,10.8) -eq -1) 'Neutral did not rearm'
'PASS joystick horizontal adjustment and release/repeat timing.'
$menu=Get-Content (Join-Path $PSScriptRoot 'ModMenu.cs') -Raw
$start=$menu.IndexOf('  private void AdjustModMenu(')
$end=$menu.IndexOf('  public override void OnGUI()', $start)
$hud=Get-Content (Join-Path $PSScriptRoot 'HudPlacement.cs') -Raw
$cycle=$hud.Substring($hud.IndexOf('  private void CycleHudMode('),$hud.IndexOf('  private void OpenHudPlacement(')-$hud.IndexOf('  private void CycleHudMode('))
$method=$menu.Substring($start,$end-$start).Replace('private void AdjustModMenu','public void AdjustModMenu')
Add-Type -TypeDefinition (@'
using System;
public class AdjustTest { public bool enhancedResolutionAvailable=true,flashlightModAvailable=true,enhancedResolutionRequested=true,flashlightModRequested=true;
 public int wheelPickSlot=-1,modLaserColor,modFlashlightPlacement;public bool modFullBodyIk,modHudForearm,modMenuWheel,modMenuCheats,modMenuTest,mapComplete,inventory14Slots,infiniteLife,infiniteAmmo,infiniteStunProd,allWeapons,instantKill,modHudOn=true,modHudRight=true,modLasersOn=true,manualReloadEnabled,modMiniMap=true,quickEnabled;
 public string[] modLaserNames={"RED","GREEN","BLUE","ORANGE","WHITE"};public int last=-1;
 private void ActivateModMenu(int i){last=i;if(modMenuCheats&&i==1)infiniteLife=!infiniteLife;}
'@+$cycle+$method+@'
 public static void Test(){var t=new AdjustTest();t.AdjustModMenu(9,-1);t.AdjustModMenu(10,-1);if(t.enhancedResolutionRequested||t.flashlightModRequested)throw new Exception("mod OFF failed");t.AdjustModMenu(9,1);t.AdjustModMenu(10,1);if(!t.enhancedResolutionRequested||!t.flashlightModRequested)throw new Exception("mod ON failed");t.enhancedResolutionAvailable=false;t.AdjustModMenu(9,-1);if(!t.enhancedResolutionRequested)throw new Exception("unavailable mod changed");t.AdjustModMenu(1,-1);if(t.modLaserColor!=4)throw new Exception("color left wrap");t.AdjustModMenu(1,1);if(t.modLaserColor!=0)throw new Exception("color right wrap");t.AdjustModMenu(3,-1);if(!t.modHudOn||t.modHudRight)throw new Exception("HUD left hand");t.AdjustModMenu(3,-1);if(t.modHudOn)throw new Exception("HUD off");t.AdjustModMenu(3,1);if(!t.modHudOn||t.modHudRight)throw new Exception("HUD off to left");t.AdjustModMenu(3,1);if(!t.modHudOn||!t.modHudRight)throw new Exception("HUD right to wrist");t.AdjustModMenu(0,1);if(t.last!=-1)throw new Exception("ON repeated");t.AdjustModMenu(0,-1);if(t.last!=0)throw new Exception("OFF missing");t.last=-1;t.AdjustModMenu(11,1);if(t.last!=-1)throw new Exception("joystick must not activate Done");t.modMenuCheats=true;t.AdjustModMenu(1,1);t.last=-1;t.AdjustModMenu(1,1);if(!t.infiniteLife||t.last!=-1)throw new Exception("cheat held ON repeated");t.AdjustModMenu(1,-1);if(t.infiniteLife)throw new Exception("cheat OFF missing");t.last=-1;t.AdjustModMenu(7,1);if(t.last!=-1)throw new Exception("Back activated");t.modMenuCheats=false;t.modMenuTest=true;t.last=-1;t.AdjustModMenu(0,-1);if(t.last!=-1)throw new Exception("Test tab changed Settings");t.modMenuTest=false;t.modMenuWheel=true;t.AdjustModMenu(0,1);if(t.last!=-1)throw new Exception("wheel assignment changed");}
}
'@)
[AdjustTest]::Test()
'PASS actual menu adjustment: bidirectional values/wrap, cheats, no repeated ON, Done/Back/slot protection.'


