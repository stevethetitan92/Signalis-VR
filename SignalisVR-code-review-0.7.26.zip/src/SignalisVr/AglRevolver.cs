using System;
using System.IO;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Vector3[] aglHandRest,aglHandAnimated;private float[] aglIndexWeights;
  private void PrepareAglMechanism(){
   float open=additionalOpen;var swing=Quaternion.AngleAxis(90*open,Vector3.forward);float pull=GunSqueeze();
   var triggerTurn=Quaternion.AngleAxis(18*pull,Vector3.right);
   float cock=pull<.85f?pull/.85f:1-(pull-.85f)/.15f;
   var hammerTurn=Quaternion.AngleAxis(-32*Mathf.Clamp01(cock),Vector3.right);
   var w=global::InventoryManager.EquippedWeapon;PrepareRevolverEjector(swing);
   for(int i=0;i<selectedParts.Count;i++){
    int role=selectedRoles[i];var t=selectedParts[i].transform;Quaternion turn=Quaternion.identity;Vector3 pivot=Vector3.zero;
    if(role==6||i==1||i==5)selectedParts[i].enabled=false;
    // Fired rounds disappear immediately; no invisible ejector prerequisite.
    if(role==2||role>=10){turn=swing;pivot=HdRevolverData.Pivot;if(role>=10){selectedParts[i].enabled=role-10<w.magAmmo;selectedParts[i].GetComponent<MeshFilter>().sharedMesh=selectedMeshes[i];}}
    if(role==3){turn=hammerTurn;pivot=HdRevolverData.HammerPivot;}
    if(role==4){turn=triggerTurn;pivot=HdRevolverData.TriggerPivot;}
    t.localRotation=turn;t.localPosition=pivot-turn*pivot;if(i==1||i==5)t.localPosition-=Vector3.forward*revolverRod.Pull;
   }
   var chamber=HdRevolverData.Chamber;
   additionalChamber=selectedRoot.transform.TransformPoint(HdRevolverData.Pivot+swing*(chamber-HdRevolverData.Pivot));
   additionalLoadDirection=rightWeaponRotation*Vector3.forward;additionalBolt=additionalChamber;additionalAnchors=AdditionalGunEligible();
   ShowRevolverEjected();
  }
  private void CreateAglLoader(Shader shader,int count){
   var vertices=new System.Collections.Generic.List<Vector3>();var normals=new System.Collections.Generic.List<Vector3>();var uv=new System.Collections.Generic.List<Vector2>();
   var triangles=new System.Collections.Generic.List<int[]>();var materials=new System.Collections.Generic.List<Material>();
   var center=HdRevolverData.OpenLoaderCenter;var openTurn=Quaternion.AngleAxis(90,Vector3.forward);
   for(int i=0;i<selectedMeshes.Count;i++)if(selectedRoles[i]==6||(selectedRoles[i]>=10&&selectedRoles[i]-10>=additionalLoaderStart&&selectedRoles[i]-10<additionalLoaderStart+count)){
    var mesh=selectedMeshes[i];int offset=vertices.Count;
    foreach(var v in mesh.vertices){var p=HdRevolverData.Pivot+openTurn*(v-HdRevolverData.Pivot)-center;vertices.Add(new Vector3(p.x,p.z,-p.y));}
    foreach(var n in mesh.normals){var q=openTurn*n;normals.Add(new Vector3(q.x,q.z,-q.y));}uv.AddRange(mesh.uv);var indices=mesh.triangles;for(int j=0;j<indices.Length;j++)indices[j]+=offset;
    triangles.Add(indices);materials.Add(selectedParts[i].sharedMaterial);
   }
   additionalMesh=new Mesh();additionalMesh.vertices=vertices.ToArray();additionalMesh.uv=uv.ToArray();additionalMesh.subMeshCount=triangles.Count;
   for(int i=0;i<triangles.Count;i++)additionalMesh.SetTriangles(triangles[i],i);
   additionalMesh.normals=normals.ToArray();additionalMesh.RecalculateBounds();
   additionalAmmo=CreateControllerPart(additionalRoot,additionalMesh,materials[0],"HDSpeedloader",Vector3.zero,Vector3.one);additionalAmmo.sharedMaterials=materials.ToArray();
  }
  private void AnimateAglHand(){
   var mesh=approvedPoseMeshes[5];if(mesh==null)return;
   if(aglHandRest==null||aglHandRest.Length!=mesh.vertexCount){aglHandRest=mesh.vertices;aglHandAnimated=new Vector3[aglHandRest.Length];aglIndexWeights=new float[aglHandRest.Length];using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(PsxModelData.IndexWeights))))for(int i=0;i<aglIndexWeights.Length;i++)aglIndexWeights[i]=r.ReadSingle();}
   float pull=GunSqueeze();for(int i=0;i<aglHandRest.Length;i++){var turn=Quaternion.AngleAxis(18*pull*aglIndexWeights[i],Vector3.right);aglHandAnimated[i]=HdRevolverData.TriggerPivot+turn*(aglHandRest[i]-HdRevolverData.TriggerPivot);}
   mesh.vertices=aglHandAnimated;mesh.RecalculateNormals();mesh.RecalculateBounds();
  }
 }
}


