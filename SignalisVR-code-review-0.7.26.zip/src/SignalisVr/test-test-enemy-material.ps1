$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'TestMenuActions.cs') -Raw
$p=$s.Substring($s.IndexOf(' public static class TestEnemyMaterialPolicy'))
$p=$p.Substring(0,$p.IndexOf(' public sealed partial class Tracking'))
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$p+'}')
$t=[SignalisVrTracking.TestEnemyMaterialPolicy]
$cases=@(
 @('Toon/Cutoff','TransparentCutout',2000,$true,$true),
 @('Toon/Cutoff with Emission','TransparentCutout',2000,$true,$true),
 @('EnemyShader_Ampli','Opaque',2000,$false,$false),
 @('GradualBurn','TransparentCutout',3001,$false,$false),
 @('Refraction','Opaque',2000,$true,$false),
 @('Toon/Cutoff','Transparent',3000,$true,$false),
 @('Toon/Cutoff','Opaque',2000,$false,$false))
foreach($c in $cases){if($t::Body($c[0],$c[1],$c[2],$c[3]) -ne $c[4]){throw "Wrong material classification: $($c[0])"}}
if(!$t::Overlay('EnemyShader_Ampli') -or $t::Overlay('GradualBurn')){throw 'Burn overlay confused with auxiliary FX'}
# Regression: recorded EULR has three valid material slots plus FX and burn overlays.
$count=0;foreach($i in @(0,1,2,2,1,2,3)){ $c=$cases[$i];if($t::Body($c[0],$c[1],$c[2],$c[3])){$count++}}
if($count -ne 3){throw 'Recorded EULR no longer qualifies'}
if($s.Contains('material.renderQueue>=3000)return -1')){throw 'Whole-prefab veto remains'}
'PASS recorded EULR base/FX/burn mix qualifies, refraction-only/no-texture rejected. Clone rendering remains headset-unverified.'
