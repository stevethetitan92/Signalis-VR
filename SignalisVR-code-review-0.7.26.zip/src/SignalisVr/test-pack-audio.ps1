$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'PackAudio.cs') -Raw
$stub=@'
namespace UnityEngine {public struct Vector3 {public float x,y,z;}}
namespace UnhollowerBaseLib {
 public static class IL2CPP {public static uint il2cpp_class_value_size(System.IntPtr p,ref uint a){return 224;}}
 public static class Il2CppClassPointerStore<T>{public static System.IntPtr NativeClassPtr;}
}
namespace FMOD {
 public enum RESULT {OK,ERR} [global::System.Flags] public enum MODE {OPENMEMORY=1,_2D=2,LOOP_NORMAL=4,LOOP_OFF=8,_3D=16,_3D_HEADRELATIVE=32,_3D_INVERSETAPEREDROLLOFF=64}
 public struct CREATESOUNDEXINFO {public int cbsize;public uint length;}
 public struct VECTOR {public float x,y,z;}
 public struct Sound {public RESULT release(){Probe.Releases++;return RESULT.OK;}}
 public struct ChannelGroup {}
 public struct Channel {
  public int id;
  public RESULT set3DMinMaxDistance(float min,float max){return RESULT.OK;}
  public RESULT set3DAttributes(ref VECTOR p,ref VECTOR v){return RESULT.OK;}
  public RESULT setLowPassGain(float v){return RESULT.OK;}
  public RESULT isPlaying(out bool value){value=Probe.Playing.Contains(id);return RESULT.OK;}
  public RESULT setMode(MODE m){Probe.LastMode=m;return RESULT.OK;}
  public RESULT setVolume(float v){return Probe.FailVolume?RESULT.ERR:RESULT.OK;}
  public RESULT setPaused(bool p){if(!p)Probe.Playing.Add(id);return RESULT.OK;}
  public RESULT stop(){Probe.Stops++;Probe.Playing.Remove(id);return RESULT.OK;}
 }
 public static class Probe {public static int Creates,Plays,Stops,Releases;public static bool FailVolume;public static MODE LastMode;public static byte[] Wave;public static System.Collections.Generic.HashSet<int> Playing=new System.Collections.Generic.HashSet<int>();}
 public struct System {
  public RESULT createSound(string path,MODE mode,out Sound sound){
   if(mode!=MODE._2D)throw new global::System.Exception("Unexpected sound mode");
   Probe.Wave=global::System.IO.File.ReadAllBytes(path);Probe.Creates++;sound=new Sound();return RESULT.OK;
  }
  public RESULT getMasterChannelGroup(out ChannelGroup group){group=new ChannelGroup();return RESULT.OK;}
  public RESULT playSound(Sound s,ChannelGroup g,bool paused,out Channel channel){if(!paused)throw new global::System.Exception("Started before setup");channel=new Channel{id=++Probe.Plays};return RESULT.OK;}
 }
}
namespace FMODUnity {public static class RuntimeManager {public static FMOD.System CoreSystem;}}
namespace SignalisVrTracking {public static class PackAudioCheck {
 public static void Run(){
  var audio=new PackAudio(new byte[]{1,2,3,4},22050);
  using(var r=new System.IO.BinaryReader(new System.IO.MemoryStream(FMOD.Probe.Wave))){
   if(new string(r.ReadChars(4))!="RIFF"||r.ReadInt32()!=40||new string(r.ReadChars(8))!="WAVEfmt "||r.ReadInt32()!=16||r.ReadInt16()!=1||r.ReadInt16()!=1||r.ReadInt32()!=22050||r.ReadInt32()!=44100||r.ReadInt16()!=2||r.ReadInt16()!=16||new string(r.ReadChars(4))!="data"||r.ReadInt32()!=4||r.ReadInt32()!=67305985)throw new System.Exception("PCM WAV header or samples corrupt");
  }
  for(int i=0;i<100;i++)audio.Play(.35f,true);
  if(FMOD.Probe.Plays!=1||FMOD.Probe.Playing.Count!=1||FMOD.Probe.LastMode!=FMOD.MODE.LOOP_NORMAL)throw new System.Exception("Loop restarted");
  audio.Stop();audio.Play(.35f,true);if(FMOD.Probe.Plays!=2)throw new System.Exception("Loop failed to resume");
  for(int i=0;i<40;i++)audio.Play(.8f,false);
  if(FMOD.Probe.Plays!=42||FMOD.Probe.LastMode!=FMOD.MODE.LOOP_OFF)throw new System.Exception("Automatic shots dropped");
  FMOD.Probe.FailVolume=true;int stops=FMOD.Probe.Stops;try{audio.Play(.8f,false);throw new System.Exception("Failure missing");}catch(System.InvalidOperationException){}
  if(FMOD.Probe.Stops!=stops+1)throw new System.Exception("Failed channel leaked");
  audio.Dispose();audio.Dispose();audio.Play(1,false);if(FMOD.Probe.Releases!=1||FMOD.Probe.Plays!=43)throw new System.Exception("Dispose lifecycle");
  foreach(var pcm in new byte[][]{null,new byte[0],new byte[3]}){try{new PackAudio(pcm,22050);throw new System.Exception("Invalid PCM accepted");}catch(System.ArgumentException){}}
 }
}}
'@
# These stubs check the actual wrapper's data/lifetime behavior, not audible FMOD output.
$stub=$stub.Replace('public static System.Collections.Generic.HashSet<int> Playing=new System.Collections.Generic.HashSet<int>()','public static global::System.Collections.Generic.HashSet<int> Playing=new global::System.Collections.Generic.HashSet<int>()')
Add-Type -TypeDefinition ($source+$stub)
[SignalisVrTracking.PackAudioCheck]::Run()
'PASS actual PackAudio WAV bytes, single persistent loop, stop/resume, forty one-shots, channel failure cleanup and idempotent disposal. Native FMOD playback remains unverified.'

