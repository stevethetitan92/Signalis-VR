using System;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static bool allWeapons,grantWeaponsPending;
  private static readonly global::Items.itemlist[] StorageWeapons={global::Items.itemlist.Pistol,global::Items.itemlist.Revolver,global::Items.itemlist.Shotgun,global::Items.itemlist.Rifle,global::Items.itemlist.FlareGun,global::Items.itemlist.SMG};
  private static readonly global::Items.itemlist[] StorageAmmo={global::Items.itemlist.PistolAmmo,global::Items.itemlist.RevolverAmmo,global::Items.itemlist.ShotgunAmmo,global::Items.itemlist.RifleAmmo,global::Items.itemlist.FlareGunAmmo,global::Items.itemlist.SmgAmmo};
  private void PollGrantWeapons() {
   if(!allWeapons||!grantWeaponsPending||!CheatPlayerReady())return;
   var items=global::InventoryManager.allItems;
   if(items==null||global::InventoryManager.boxItems==null)return;
   // Resolve everything before any mutation; never spawn world pickup scripts.
   foreach(var id in StorageWeapons)if(!items.ContainsKey(id)||items[id]==null)return;
   foreach(var id in StorageAmmo)if(!items.ContainsKey(id)||items[id]==null)return;
   grantWeaponsPending=false;
   try {
    foreach(var id in StorageWeapons)if(!global::InventoryManager.boxContainsItem(items[id]))global::InventoryManager.boxItem(items[id],1);
    foreach(var id in StorageAmmo)global::InventoryManager.boxItem(items[id],4);
    MelonLogger.Msg("ALL WEAPONS: six guns present in storage; four rounds of each of six ammo types added. Save the game to retain storage changes.");
   }catch(Exception ex){modSettingsError="Storage grant incomplete; see log before trying again.";MelonLogger.Warning("All weapons grant stopped: "+ex.Message);}
  }
 }
}
