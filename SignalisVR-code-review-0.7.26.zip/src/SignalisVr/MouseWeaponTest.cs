using System;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  // VR package: normal automatic startup; optional desktop mouse trial stays off.
  private readonly bool desktopMouseOnly=false;
  private bool mouseWeaponTest;
  private readonly HotkeyEdge mouseWeaponKey=new HotkeyEdge();
  private Camera mouseWeaponCamera,mouseRenderCamera;
  private float nextMouseCameraSearch;
  private WeaponPoseScope mouseRenderScope;
  private int mouseCameraMask;
  private Camera.CameraCallback mouseBeforeRender,mouseAfterRender;
  private void InstallMouseWeaponTest() {
   mouseBeforeRender=(Action<Camera>)BeforeMouseWeaponCamera;
   mouseAfterRender=(Action<Camera>)AfterMouseWeaponCamera;
   Camera.onPreCull+=mouseBeforeRender;Camera.onPostRender+=mouseAfterRender;
  }
  private bool MouseGameFocused() {
   uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
   return foreground==questProcessId;
  }
  private void PollMouseWeaponTest() {
   // Recovery if an interrupted camera render never reached its post callback.
   RestoreMouseWeaponCamera();
   bool pressed=mouseWeaponKey.Poll((GetAsyncKeyState(0x74)&0x8000)!=0);
   if(pressed&&MouseGameFocused()) {
    mouseWeaponTest=!mouseWeaponTest;mouseWeaponCamera=null;nextMouseCameraSearch=0f;
    MelonLogger.Msg("MOUSE WEAPON TEST: "+(mouseWeaponTest?"ON. Desktop first person required; RMB aim, LMB fire.":"OFF. Ordinary desktop aiming restored."));
   }
   if((mouseWeaponTest||desktopMouseOnly)&&(mouseWeaponCamera==null||!mouseWeaponCamera.isActiveAndEnabled)&&Time.realtimeSinceStartup>=nextMouseCameraSearch) {
    nextMouseCameraSearch=Time.realtimeSinceStartup+1f;mouseWeaponCamera=FindGameplayCamera();
   }
   if(mouseWeaponTest&&mouseWeaponCamera==null)ReportWeaponGate(global::PlayerAttack.instance,false);
  }
  private bool MouseWeaponReady() {
   return MouseWeaponPolicy.Ready(mouseWeaponTest,active&&stereo,MouseGameFocused(),
    mouseWeaponCamera!=null&&mouseWeaponCamera.isActiveAndEnabled&&!mouseWeaponCamera.orthographic,
    WeaponGameplayReady(),
    global::PlayerState.paused||global::PlayerState.eventScreen||global::PlayerState.cutscene||global::PlayerState.suspendInput||global::PlayerState.reloading,
    (GetAsyncKeyState(0x02)&0x8000)!=0);
  }
  private void BeforeMouseWeaponCamera(Camera c) {
   if(desktopMouseOnly)BeforeDesktopHud(c);
   if(!mouseWeaponTest||c!=mouseWeaponCamera)return;
   try {
    if(!MouseWeaponReady()){ReportWeaponGate(global::PlayerAttack.instance,false);return;}
    RestoreMouseWeaponCamera();
    mouseRenderScope=BeginControllerWeapon(global::PlayerAttack.instance);
    ReportWeaponGate(global::PlayerAttack.instance,mouseRenderScope!=null);
    mouseRenderCamera=c;mouseCameraMask=c.cullingMask;c.cullingMask|=1<<30;
    ShowRifleImpacts();
   }catch(Exception ex){RestoreMouseWeaponCamera();WeaponAimFailure(ex);}
  }
  private void AfterMouseWeaponCamera(Camera c) {
   try {if(c==mouseRenderCamera)RestoreMouseWeaponCamera();}
   finally {if(c==desktopHudCamera)RestoreDesktopHud();}
  }
  private void RestoreMouseWeaponCamera() {
   try {if(mouseRenderScope!=null)mouseRenderScope.Restore();}
   finally {
    mouseRenderScope=null;
    if(mouseRenderCamera!=null){mouseRenderCamera.cullingMask=mouseCameraMask;HideRifleImpacts();}
    mouseRenderCamera=null;
   }
  }
 }
 internal static class MouseWeaponPolicy {
  internal static bool Ready(bool enabled,bool vr,bool focused,bool camera,bool playing,bool blocked,bool aim) {
   return enabled&&!vr&&focused&&camera&&playing&&!blocked&&aim;
  }
 }
}

