namespace SignalisVrTracking {
 public sealed class ManualReloadPolicy {
  public enum Step { Idle, Ejected, Holding, Inserted, RackHolding, AwaitingGame }
  public Step Stage {get;private set;}
  public bool Active {get{return Stage!=Step.Idle;}}
  private bool previousGrip,sawNativeReload,rackGripReleased;
  private float inWellSince=-1f,requestedAt;
  private float pullOrigin;
  private float peakPull;
  public bool RequiresRack {get;private set;}
  public float RackPull {get;private set;}
  public float MaximumPull=.055f;
  public float MinimumPull=.02f;
  public float InsertionDwell=.12f;
  public float PeakPull {get{return peakPull;}}
  public bool RequireFreshRackGrip;
  public void Cancel(){Stage=Step.Idle;previousGrip=false;inWellSince=-1f;sawNativeReload=false;RackPull=0;}
  // B only ejects. Grip at slide followed by release is the sole rack action.
  public bool PressB(float now,bool grip,bool canReload,bool requiresRack=true) {
   if(Stage==Step.Idle&&canReload){RequiresRack=requiresRack;Stage=Step.Ejected;previousGrip=grip;inWellSince=-1f;}
   return false;
  }
  public bool Tick(float now,bool eligible,bool grip,bool pouch,bool well,bool slide=false,float pullPosition=0f) {
   if(!eligible){Cancel();return false;}
   bool down=grip&&!previousGrip;previousGrip=grip;if(!grip)rackGripReleased=true;
   if(Stage==Step.Ejected&&down&&pouch){Stage=Step.Holding;inWellSince=-1f;}
   else if(Stage==Step.Holding) {
    if(!grip){Stage=Step.Ejected;inWellSince=-1f;}
    else if(well) {
     if(inWellSince<0)inWellSince=now;
     if(now-inWellSince>=InsertionDwell){Stage=Step.Inserted;rackGripReleased=false;inWellSince=-1f;if(!RequiresRack){Stage=Step.AwaitingGame;requestedAt=now;sawNativeReload=false;return true;}}
    }else {inWellSince=-1f;if(!grip)Stage=Step.Ejected;}
   }else if(Stage==Step.Inserted&&grip&&slide&&(!RequireFreshRackGrip||rackGripReleased)){Stage=Step.RackHolding;pullOrigin=pullPosition;RackPull=0;peakPull=0;}
   else if(Stage==Step.RackHolding) {
    if(float.IsNaN(pullPosition)||float.IsInfinity(pullPosition)||System.Math.Abs(pullPosition-pullOrigin)>.35f){Stage=Step.Inserted;RackPull=peakPull=0;return false;}
    RackPull=System.Math.Min(MaximumPull,System.Math.Max(0,pullPosition-pullOrigin));
    peakPull=System.Math.Max(peakPull,RackPull);
    if(!grip) {
     if(peakPull<MinimumPull){Stage=Step.Inserted;RackPull=0;return false;}
     Stage=Step.AwaitingGame;requestedAt=now;sawNativeReload=false;return true;
    }
   }
   return false;
  }
  // Hard-stop contact stays seated when the user releases their grip.
  public bool Seat(float now){if(Stage!=Step.Holding)return false;rackGripReleased=false;Stage=RequiresRack?Step.Inserted:Step.AwaitingGame;inWellSince=-1;requestedAt=now;sawNativeReload=false;return !RequiresRack;}
  public void BeginRack(float pullPosition){if(Stage!=Step.Idle&&Stage!=Step.Inserted)return;Stage=Step.RackHolding;RequiresRack=true;previousGrip=true;pullOrigin=pullPosition;RackPull=peakPull=0;}
  // Presentation/commit bridge for the independent SMG detector. Pistol still
  // uses its existing Tick path and never calls these methods.
  public void PresentExternalRack(float pull,float peak){if(Stage!=Step.RackHolding)return;RackPull=pull;peakPull=peak;}
  public void FinishExternalRack(bool accepted,float now){if(Stage!=Step.RackHolding)return;Stage=accepted?Step.AwaitingGame:Step.Inserted;requestedAt=now;sawNativeReload=false;if(!accepted)RackPull=0;}
  public bool ObserveGame(float now,bool reloading,bool ammoIncreased) {
   if(Stage!=Step.AwaitingGame)return false;
   if(reloading)sawNativeReload=true;
   if(!reloading&&(ammoIncreased||sawNativeReload)){Cancel();return true;}
   if(now-requestedAt>3f&&!sawNativeReload)Stage=Step.Inserted;
   return false;
  }
 }
}
