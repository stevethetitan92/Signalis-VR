using System;
using System.IO;
using UnityEngine;
namespace SignalisVrTracking {
 public static class RepairSprayUseMotion {
  public static float Amount(float age){if(float.IsNaN(age)||age<0||age>=.95f)return 0;float a=age<.22f?age/.22f:age<.65f?1:1-(age-.65f)/.30f;return a*a*(3-2*a);}
  public static void ClearSlots(string[] slots,string item){for(int i=0;i<slots.Length;i++)if(slots[i]==item)slots[i]="None";}
 }
 public sealed partial class Tracking {
  private MeshRenderer repairHand;
  private Mesh repairHandMesh;
  private Material repairHandMaterial;
  private Vector3[] repairHandRest;
  private float[] repairIndexWeights;
  private void ShowRepairHand(float squeeze){
   if(repairHand==null){
    using(var r=new BinaryReader(new MemoryStream(Convert.FromBase64String(RepairSprayPoseData.Mesh)))){
     repairHandRest=new Vector3[r.ReadInt32()];var indices=new int[r.ReadInt32()];
     for(int i=0;i<repairHandRest.Length;i++)repairHandRest[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
     for(int i=0;i<indices.Length;i++)indices[i]=r.ReadInt32();
     var wb=Convert.FromBase64String(RepairSprayPoseData.Weights);repairIndexWeights=new float[repairHandRest.Length];for(int i=0;i<repairIndexWeights.Length;i++)repairIndexWeights[i]=BitConverter.ToSingle(wb,i*4);
     repairHandMesh=new Mesh();repairHandMesh.vertices=repairHandRest;repairHandMesh.triangles=indices;
    }
    repairHandMaterial=new Material(Shader.Find("Unlit/Color"));repairHandMaterial.color=new Color(.015f,.018f,.02f);
    repairHand=CreateControllerPart(healthGripFrame.gameObject,repairHandMesh,repairHandMaterial,"ApprovedRepairRightHand",Vector3.zero,Vector3.one);
   }
   var vertices=(Vector3[])repairHandRest.Clone();var pivot=new Vector3(-.077f,.4076f,-.01f);var rotation=Quaternion.Euler(0,0,16*squeeze);
   for(int i=0;i<repairHandRest.Length;i++){var v=repairHandRest[i];float w=Mathf.Clamp01((.32f-v.x)/.35f);w=w*w*(3-2*w)*repairIndexWeights[i];vertices[i]=Vector3.Lerp(v,pivot+rotation*(v-pivot),w);}
   repairHandMesh.vertices=vertices;repairHandMesh.RecalculateNormals();repairHandMesh.RecalculateBounds();repairHand.enabled=true;if(handsRenderers[1]!=null)handsRenderers[1].enabled=false;
  }
  private void ClearRepairHand(){if(repairHand!=null)UnityEngine.Object.Destroy(repairHand.gameObject);if(repairHandMesh!=null)UnityEngine.Object.Destroy(repairHandMesh);if(repairHandMaterial!=null)UnityEngine.Object.Destroy(repairHandMaterial);repairHand=null;repairHandMesh=null;repairHandMaterial=null;repairHandRest=null;}
 }
}
