using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace SignalisVrTracking {
 public static class EnemyFirePolicy {
  public static int AfterTick(int hp){return Math.Max(0,hp-4);}
  public static float Opacity(float age){if(age<0||age>=6)return 0;return Math.Min(1,age/.12f)*Math.Min(1,(6-age)/.5f);}
 }
 public sealed partial class Tracking {
  private sealed class EnemyFire {internal IntPtr Id;internal global::EnemyController Enemy;internal global::Room Room;internal GameObject Root;internal Renderer[] Body;internal MeshRenderer[] Sprites;internal Bounds Bounds;internal float Age;internal int DamageTicks;internal bool Corpse;internal MaterialPropertyBlock Color=new MaterialPropertyBlock();internal Transform Torso,Head;internal Vector3[] Local=new Vector3[48],Drift=new Vector3[48];internal bool[] Anchored=new bool[48];}
  private readonly List<EnemyFire> enemyFires=new List<EnemyFire>();
  private readonly Vector3[] enemyFireAnimatedVertices=new Vector3[81];
  private float enemyFireMotionTime;
  private void AnimateEnemyFlames(float t){
   if(enemyFireVolume==null)return;
   for(int j=0;j<=8;j++)for(int k=0;k<=8;k++){
    float v=j/8f,a=k*(float)Math.PI/4;
    float wave=v*12-t*8;
    float r=Mathf.Pow(Mathf.Max(0,Mathf.Sin(v*(float)Math.PI)),.65f)*(1-.6f*v)*.6f;
    r*=1+.22f*Mathf.Sin(wave+a*2)+.1f*Mathf.Sin(v*23-t*13-a);
    float curl=v*v;
    enemyFireAnimatedVertices[j*9+k]=new Vector3(Mathf.Cos(a)*r+curl*(.22f*Mathf.Sin(wave)+.08f*Mathf.Sin(t*11-v*7)),v*(1+.12f*curl*Mathf.Sin(t*7-v*5)),Mathf.Sin(a)*r+curl*.18f*Mathf.Cos(wave*.8f));
   }
   enemyFireVolume.vertices=enemyFireAnimatedVertices;enemyFireVolume.RecalculateBounds();
  }
  private Mesh enemyFireQuad,enemyFireVolume;private Texture2D enemyFireTexture,enemySmokeTexture;private Material enemyFireMaterial,enemySmokeMaterial;
  private void EnsureEnemyFire(){
   if(enemyFireMaterial!=null)return;
   var shader=Shader.Find("Sprites/Default");if(shader==null)throw new InvalidOperationException("Enemy fire shader missing");
   enemyFireTexture=new Texture2D(128,128,TextureFormat.RGBA32,false);enemyFireTexture.wrapMode=TextureWrapMode.Clamp;
   enemyFireTexture.filterMode=FilterMode.Point;
   enemySmokeTexture=new Texture2D(128,128,TextureFormat.RGBA32,false);enemySmokeTexture.wrapMode=TextureWrapMode.Clamp;
   for(int y=0;y<128;y++)for(int x=0;x<128;x++){
    // 16 by 32 crisp flame cells; an elliptical lower cap rounds the base.
    float v=(Mathf.Floor(y/4f)+.5f)/32f,u=(Mathf.Floor(x/8f)+.5f)/8f-1;
    float cap=(v-.22f)/.22f;
    float width=v<.22f?.68f*Mathf.Sqrt(Mathf.Max(0,1-cap*cap)):.68f*Mathf.Pow((1-v)/.78f,.8f);
    float bend=Mathf.Sin(v*11)*v*.21f+Mathf.Sin(v*23)*v*.06f;
    float edge=Mathf.Clamp01(1-Mathf.Abs(u-bend)/width);
    float grain=.78f+.14f*Mathf.Sin(u*27+v*39)+.08f*Mathf.Sin(u*61-v*23);
    float alpha=Mathf.Floor(Mathf.Clamp01(edge*6)*grain*4+.5f)/4;
    float hot=Mathf.Floor(Mathf.Clamp01(edge*1.6f-v*.85f)*5+.5f)/5;
    enemyFireTexture.SetPixel(x,y,new Color(1,.12f+.86f*hot,.015f+.6f*hot*hot*hot,alpha));
    float su=(x-63.5f)/63.5f,sy=y/127f*2-1,rad=su*su+sy*sy,cloud=Mathf.Clamp01(1-rad);
    float wisps=.72f+.18f*Mathf.Sin(su*13+sy*9)+.1f*Mathf.Sin(su*25-sy*17);
    enemySmokeTexture.SetPixel(x,y,new Color(1,1,1,cloud*cloud*wisps));
   }
   enemyFireTexture.Apply();enemyFireMaterial=new Material(shader);enemyFireMaterial.mainTexture=enemyFireTexture;
   enemySmokeTexture.Apply();enemySmokeMaterial=new Material(shader);enemySmokeMaterial.mainTexture=enemySmokeTexture;
   enemyFireQuad=new Mesh();enemyFireQuad.vertices=new[]{new Vector3(-.5f,0,0),new Vector3(.5f,0,0),new Vector3(.5f,1,0),new Vector3(-.5f,1,0)};
   enemyFireQuad.uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(1,1),new Vector2(0,1)};
   enemyFireQuad.triangles=HandSurfaceTopology.DoubleSided(new[]{0,1,2,0,2,3});enemyFireQuad.RecalculateBounds();
   var vertices=new List<Vector3>();var uv=new List<Vector2>();var triangles=new List<int>();
   for(int j=0;j<=8;j++)for(int k=0;k<=8;k++){
    float v=j/8f,a=k*(float)Math.PI/4,r=Mathf.Pow(Mathf.Max(0,Mathf.Sin(v*(float)Math.PI)),.65f)*(1-.6f*v)*.6f;
    vertices.Add(new Vector3(Mathf.Cos(a)*r+Mathf.Sin(v*9)*v*.08f,v,Mathf.Sin(a)*r));uv.Add(new Vector2(.5f+Mathf.Cos(a)*.22f,v));
    if(j<8&&k<8){int n=j*9+k;triangles.AddRange(new[]{n,n+9,n+1,n+1,n+9,n+10});}
   }
   enemyFireVolume=new Mesh();enemyFireVolume.vertices=vertices.ToArray();enemyFireVolume.uv=uv.ToArray();enemyFireVolume.triangles=HandSurfaceTopology.DoubleSided(triangles.ToArray());enemyFireVolume.RecalculateBounds();
  }
  private void BeginEnemyFire(global::EnemyController enemy){
   EnemyFire effect=null;
   try{
    if(!FireEnemyValid(enemy)||(!ProdEnemyValid(enemy)&&enemy.BurnEffect!=null&&enemy.BurnEffect.burning))return;foreach(var active in enemyFires)if(active.Id==enemy.Pointer){active.Age=0;active.DamageTicks=0;return;}
    if(!ProdEnemyValid(enemy)){effect=new EnemyFire{Id=enemy.Pointer,Enemy=enemy,Room=global::PlayerState.currentRoom,Sprites=new MeshRenderer[0]};BeginCorpseFire(effect);enemyFires.Add(effect);return;}
    EnsureEnemyFire();
    if(enemyFires.Count>=8){DisposeEnemyFire(enemyFires[0]);enemyFires.RemoveAt(0);}
    var bodyList=new List<Renderer>();foreach(var r in enemy.GetComponentsInChildren<SkinnedMeshRenderer>(true).ToArray())bodyList.Add(r);var body=bodyList.ToArray();
    if(body.Length==0){foreach(var r in enemy.GetComponentsInChildren<MeshRenderer>(true).ToArray())bodyList.Add(r);body=bodyList.ToArray();}
    effect=new EnemyFire{Id=enemy.Pointer,Enemy=enemy,Room=global::PlayerState.currentRoom,Body=body,Root=new GameObject("SignalisVR_EnemyFire"),Sprites=new MeshRenderer[64],Bounds=new Bounds(enemy.transform.position,Vector3.one*.5f*UnitsPerMetre)};
    UpdateEnemyFireBounds(effect);
    for(int i=0;i<effect.Sprites.Length;i++){var r=CreateControllerPart(effect.Root,i<48?enemyFireVolume:enemyFireQuad,i>=48&&i<60?enemySmokeMaterial:enemyFireMaterial,"Enemy flame smoke ember",Vector3.zero,Vector3.one);r.enabled=false;r.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;r.receiveShadows=false;effect.Sprites[i]=r;}
    PrepareBurnReaction(effect);enemyFires.Add(effect);enemy.permadeath=true;if(!ProdEnemyValid(enemy))BeginCorpseFire(effect);
   }catch(Exception ex){if(effect!=null)DisposeEnemyFire(effect);MelonLoader.MelonLogger.Warning("Enemy fire visual unavailable: "+ex.Message);}
  }
  private void UpdateEnemyFireBounds(EnemyFire f){
   bool found=false;Bounds b=f.Bounds;
   foreach(var r in f.Body){if(r==null||!r.gameObject.activeInHierarchy)continue;var candidate=r.bounds;if(candidate.size.sqrMagnitude<.0001f)continue;if(!found){b=candidate;found=true;}else b.Encapsulate(candidate);}
   if(found)f.Bounds=b;
  }
  private void PollEnemyFire(){
   if(global::PlayerState.paused||!WeaponGameplayReady()||pauseMenuVisible||modMenuOpen||!ProdVrMode())return;
   if(enemyFires.Count>0){enemyFireMotionTime+=Mathf.Max(0,Time.deltaTime);AnimateEnemyFlames(enemyFireMotionTime);}else enemyFireMotionTime=0;
   for(int n=enemyFires.Count-1;n>=0;n--){var f=enemyFires[n];
    try{
     if(!FireEnemyValid(f.Enemy)||f.Room!=global::PlayerState.currentRoom){DisposeEnemyFire(f);enemyFires.RemoveAt(n);continue;}
     if(!ProdEnemyValid(f.Enemy)&&!f.Corpse)BeginCorpseFire(f);
     f.Age+=Mathf.Max(0,Time.deltaTime);
     int due=Math.Min(6,(int)Math.Floor(f.Age));
     while(!f.Corpse&&f.DamageTicks<due&&ProdEnemyValid(f.Enemy)){
      f.DamageTicks++;f.Enemy.hitbox.HP=EnemyFirePolicy.AfterTick(f.Enemy.hitbox.HP);
      f.Enemy.TakeDamage(0f,0f,0f,true);
     }
     if(!ProdEnemyValid(f.Enemy)&&!f.Corpse)BeginCorpseFire(f);
     if(!FireEnemyValid(f.Enemy)||f.Age>=6||f.Room!=global::PlayerState.currentRoom){DisposeEnemyFire(f);enemyFires.RemoveAt(n);continue;}
     if(f.Corpse)continue; // Native burning owns downed-body visuals.
     UpdateEnemyFireBounds(f);float fade=EnemyFirePolicy.Opacity(f.Age);var b=f.Bounds;
     var up=controllerTrackingToWorld*Vector3.up;var right=controllerTrackingToWorld*Vector3.right;var forward=controllerTrackingToWorld*Vector3.forward;var rotation=Quaternion.identity;
     if(f.Enemy!=null){var facing=Vector3.ProjectOnPlane(f.Enemy.transform.forward,up);if(facing.sqrMagnitude>.001f){forward=facing.normalized;right=Vector3.Cross(up,forward).normalized;}}
     rotation=Quaternion.LookRotation(forward,up);
     var ext=b.extents;
     float ex=Mathf.Abs(right.x)*ext.x+Mathf.Abs(right.y)*ext.y+Mathf.Abs(right.z)*ext.z;
     float ey=Mathf.Abs(up.x)*ext.x+Mathf.Abs(up.y)*ext.y+Mathf.Abs(up.z)*ext.z;
     float ez=Mathf.Abs(forward.x)*ext.x+Mathf.Abs(forward.y)*ext.y+Mathf.Abs(forward.z)*ext.z;
     float height=Mathf.Clamp(b.size.magnitude*.4f,.24f*UnitsPerMetre,.82f*UnitsPerMetre);
     for(int i=0;i<f.Sprites.Length;i++){
      float phase=Mathf.Repeat(f.Age*(i<48?1.05f+(i%5)*.09f:.38f)+i*.618034f,1);
      float angle=i*2.399963f;bool face=i%8==0;
      float level=face?.86f+(i%3)*.02f:.53f+(i%6)*.035f;
      float radius=Mathf.Min(ex*.5f,ey*(face?.09f:.2f));
      float depth=Mathf.Cos(angle)*(Mathf.Min(ez,ey*(face?.11f:.14f))+.025f*UnitsPerMetre);
      var point=b.center+right*(Mathf.Sin(angle)*radius)+up*((level-.5f)*ey*2)+forward*depth;
      if(i<48){var anchor=face?f.Head:f.Torso;if(anchor!=null){if(!f.Anchored[i]){f.Local[i]=anchor.InverseTransformPoint(point);f.Anchored[i]=true;}point=anchor.TransformPoint(f.Local[i]);}}
      bool smoke=i>=48&&i<60,ember=i>=60;float rise=smoke?phase*1.15f*UnitsPerMetre:ember?phase*1.4f*UnitsPerMetre:phase*ey*.06f;
      point+=right*(Mathf.Sin(f.Age*3.1f+i*1.7f)*phase*(smoke?.12f:.015f)*UnitsPerMetre);
      if(i<48)f.Drift[i]=up*rise+right*(Mathf.Sin(f.Age*3.1f+i*1.7f)*phase*.015f*UnitsPerMetre);
      float width=ember?.008f*UnitsPerMetre:smoke?height*(.65f+phase):height*(.55f+.08f*Mathf.Sin(f.Age*11+i));
      float h=ember?.035f*UnitsPerMetre:smoke?width:height*(.9f+.2f*Mathf.Sin(f.Age*9+i)+.1f*Mathf.Sin(f.Age*21+i*2));
      if(!smoke&&!ember){width=Mathf.Min(width,ey*(face?.2f:.34f))*.85f;h=Mathf.Min(h,ey*(face?.32f:.55f))*.85f;}
      var color=smoke?new Color(.24f,.23f,.22f,.38f):new Color(1,1,1,.95f);
      if(!smoke&&!ember){float flicker=Mathf.Sin(f.Age*(2.1f+(i%5)*.17f)+i*2.399963f)+.35f*Mathf.Sin(f.Age*7.3f+i);color.a*=Mathf.SmoothStep(0,1,Mathf.Clamp01((flicker+.15f)/.65f));}
      color.a*=fade*(1-phase)*Mathf.Clamp01(phase*9);f.Color.SetColor("_Color",color);
      var r=f.Sprites[i];r.SetPropertyBlock(f.Color);r.transform.SetPositionAndRotation(point+up*rise,rotation*Quaternion.Euler(0,(i%3)*60,0));r.transform.localScale=new Vector3(width,h,i<48?width:1);r.enabled=true;
     }
    }catch(Exception ex){enemyFires.RemoveAt(n);DisposeEnemyFire(f);MelonLoader.MelonLogger.Warning("Enemy fire ended: "+ex.Message);}
   }
  }
  private void DisposeEnemyFire(EnemyFire f){FinishCorpseFire(f);EndBurnReaction(f.Id);if(f.Root!=null){f.Root.SetActive(false);UnityEngine.Object.Destroy(f.Root);}}
  private void DestroyEnemyFire(){if(flareContactMesh!=null)UnityEngine.Object.Destroy(flareContactMesh);flareContactMesh=null;foreach(var f in enemyFires)DisposeEnemyFire(f);enemyFires.Clear();if(enemyFireQuad!=null)UnityEngine.Object.Destroy(enemyFireQuad);if(enemyFireMaterial!=null)UnityEngine.Object.Destroy(enemyFireMaterial);if(enemyFireTexture!=null)UnityEngine.Object.Destroy(enemyFireTexture);if(enemySmokeMaterial!=null)UnityEngine.Object.Destroy(enemySmokeMaterial);if(enemySmokeTexture!=null)UnityEngine.Object.Destroy(enemySmokeTexture);if(enemyFireVolume!=null)UnityEngine.Object.Destroy(enemyFireVolume);enemyFireVolume=null;enemyFireQuad=null;enemyFireMaterial=null;enemyFireTexture=null;enemySmokeMaterial=null;enemySmokeTexture=null;}
 }
}






