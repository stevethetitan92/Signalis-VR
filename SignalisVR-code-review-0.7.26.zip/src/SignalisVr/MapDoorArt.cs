using System;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private void MapDoorLines(Vector2 p,int state,float size,float angle,Action<Vector2,Vector2,Color,float> draw){
  size*=.47f;
  Color color=state==4?new Color(1,.85f,.1f):state==2?new Color(1,.12f,.12f):state==1?new Color(.1f,.8f,1):new Color(.52f,.54f,.53f);
  float ca=Mathf.Cos(angle),sa=Mathf.Sin(angle);
  Func<float,float,Vector2> at=(x,y)=>p+new Vector2(x*ca-y*sa,x*sa+y*ca)*size;
  Action<float,float,float,float,float> line=(x,y,u,v,w)=>draw(at(x,y),at(u,v),color,w*size);
  float h=state==0?1.5f:2.7f;
  line(-5.1f,-h,5.1f,-h,.7f);line(5.1f,-h,5.1f,h,.7f);line(5.1f,h,-5.1f,h,.7f);line(-5.1f,h,-5.1f,-h,.7f);
  line(-3.4f,-h+.6f,-3.4f,h-.6f,.9f);line(3.4f,-h+.6f,3.4f,h-.6f,.9f);
  line(-2.8f,0,2.8f,0,state==0?.7f:2.5f);
 }
}}
