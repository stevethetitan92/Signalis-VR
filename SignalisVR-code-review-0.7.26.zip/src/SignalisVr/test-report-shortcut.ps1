$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ReportShortcut.cs')
function Check($value,$why){if(!$value){throw $why}}
$p=[SignalisVrTracking.ReportShortcut]::new()
Check (!$p.Update($true,$true,$true)) 'Held at connection fired'
Check $p.Consume 'Held Y leaked at connection'
$p.Update($true,$false,$false) | Out-Null
Check (!$p.Update($true,$true,$false) -and !$p.Consume) 'Grip alone fired or consumed'
Check ($p.Update($true,$true,$true) -and $p.Consume) 'Grip plus fresh Y did not report'
Check (!$p.Update($true,$true,$true) -and $p.Consume) 'Held chord repeated'
Check (!$p.Update($true,$false,$true) -and $p.Consume) 'Grip release leaked Y pause'
Check (!$p.Update($true,$true,$true)) 'Grip re-press while Y held repeated'
$p.Update($true,$true,$false) | Out-Null
Check ($p.Update($true,$true,$true)) 'Y release did not rearm while grip held'
$p.Update($true,$false,$false) | Out-Null
Check (!$p.Update($true,$false,$true) -and !$p.Consume) 'Y alone blocked pause'
Check (!$p.Update($true,$true,$true) -and !$p.Consume) 'Late grip triggered from old Y press'
$p.Update($false,$true,$true) | Out-Null
Check (!$p.Update($true,$true,$true) -and $p.Consume) 'Reconnect held chord fired or leaked'
$p.Update($true,$false,$false) | Out-Null
Check ($p.Update($true,$true,$true)) 'Reconnect neutral failed to rearm'
Add-Type -Path (Join-Path $PSScriptRoot '../../work/quest-native-lab/MelonLoader/Mono.Cecil.dll')
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
$t=$a.MainModule.Types | Where-Object FullName -eq SignalisVrTracking.Tracking
function Body($name){(($t.Methods | Where-Object Name -eq $name | Select-Object -First 1).Body.Instructions | ForEach-Object ToString) -join "`n"}
$body=Body PollQuestControllers
Check ($body.IndexOf('PollReportShortcut') -lt $body.IndexOf('PollModMenu')) 'Chord sampled after menu'
Check ($body.IndexOf('PollReportShortcut') -lt $body.IndexOf('SnapshotQuestNative')) 'Pause filtered after native publication'
Check ((Body PollReportShortcut).Contains('RequestProblemReport')) 'Report request missing'
Check ((Body PollReportHaptics).Contains('TriggerHapticPulse')) 'Controller feedback missing'
Check ((Body PollModMenu).Contains('ModMenuInput::Toggle')) 'Original stick menu gesture replaced'
$source=Get-Content (Join-Path $PSScriptRoot 'ProblemReports.cs') -Raw
Check ($source.Contains('questFrame.buttons&=~(1<<3)')) 'Y pause bit not consumed'
Check (!$source.Contains('manualLeftGrip=false')) 'Report cancels support grip'
$a.Dispose()
'PASS: left grip + fresh Y, single fire, grip-release pause suppression, Y rearm, ordinary Y preserved, reconnect cancellation, compiled pre-menu/pre-native wiring, original stick menu and saved-report haptics.'
