namespace SignalisVrTracking { internal static class HdRifleData {
public static readonly string Geometry=HdAsset.Read("Rifle-0.bin");
public static readonly string[] Textures={HdAsset.Read("Rifle-1.bin"),HdAsset.Read("Rifle-2.bin"),HdAsset.Read("Rifle-3.bin"),HdAsset.Read("Rifle-4.bin"),HdAsset.Read("Rifle-5.bin")};
public static readonly float[] Colors={1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,0.9063317179679871f,0.9063317179679871f,0.9063317179679871f,1.0f};
public static readonly UnityEngine.Vector3 Pivot=new UnityEngine.Vector3(-0.00000000f,0.00845300f,0.17607400f);
public static readonly UnityEngine.Vector3 Muzzle=new UnityEngine.Vector3(-0.00000600f,0.04420000f,0.81750700f);
public static readonly UnityEngine.Vector3 Chamber0=new UnityEngine.Vector3(-0.00000000f,0.05574500f,0.12070000f);
public static readonly UnityEngine.Vector3 Chamber1=new UnityEngine.Vector3(-0.00000000f,0.02987800f,0.12070000f);
public static readonly UnityEngine.Vector3 Support=new UnityEngine.Vector3(-0.00000000f,0.01930000f,0.35150000f);
} }
