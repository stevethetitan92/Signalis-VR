using System;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly ModMenuInput modMenuInput=new ModMenuInput();
  private bool modMenuOpen,modMenuOwnsPause,modMenuControls;

  private int modMenuSelection;
  private bool modMenuCheats,modMenuRightGrip,modMenuWheel,modMenuTest;
  private int ModMenuCount(){return modMenuControls?1:modMenuTest?3:modMenuWheel?WheelListCount():modMenuCheats?10:12;}
  private const string InventoryCheatWarning="WARNING: Disabling 14 slots after enabling it may cause item loss. You are responsible for any lost items. Move extra items into storage before turning it off.";
  private GUIStyle modMenuStyle,modMenuTitle,modMenuHelp;
  private void CloseModMenu(bool resume) {
   if(desktopMouseOnly&&modMenuOpen){desktopMenuRelease=true;desktopMenuClosedFrame=Time.frameCount;}
   hudPlacementEditing=false;hudPlacementChoosing=false;bool owned=modMenuOwnsPause;modMenuOpen=false;modMenuOwnsPause=false;modMenuControls=false;modMenuTest=false;
   questPolicy.Update(false,new QuestSample(),new QuestSample());
   if(resume&&owned&&global::PauseMenu.instance!=null)global::PauseMenu.instance.setPause(false);
  }
  private void OpenModMenu() {
   var pause=global::PauseMenu.instance;
   if(pause==null||bookScreenVisible||dialogueScreenVisible||global::PlayerState.eventScreen)return;
   bool alreadyPaused=pause.MenuObject!=null&&pause.MenuObject.activeInHierarchy;
   if(!alreadyPaused&&!WeaponGameplayReady())return;
   if(!EnsureDesktopMenuCapture())return;
   modMenuOwnsPause=!alreadyPaused;
   if(modMenuOwnsPause)pause.setPause(true);
   if(pause.MenuObject==null||!pause.MenuObject.activeInHierarchy){modMenuOwnsPause=false;return;}
   wheelPickSlot=-1;modMenuOpen=true;modMenuControls=false;modMenuCheats=false;modMenuWheel=false;modMenuTest=false;modMenuSelection=0;
   MelonLogger.Msg("MOD MENU: both stick clicks toggle; left grip + Y reports a problem. Left stick selects, A confirms, B returns. Press DONE to save choices.");
  }
  private void PollModMenu() {
   try {
    bool wasOpen=modMenuOpen;
    bool available=questAvailabilityValue&&questPolicy.LeftArmed&&questPolicy.RightArmed;
    bool toggle=modMenuInput.Toggle(available,(questFrame.buttons&(1<<8))!=0,(questFrame.buttons&(1<<9))!=0);
    int section=modMenuInput.Section(modMenuOpen&&available&&!reportShortcut.Consume,manualLeftGrip,modMenuRightGrip);
    bool confirm=modMenuInput.Confirm((questFrame.buttons&1)!=0);
    bool cancel=modMenuInput.Cancel(hudPlacementEditing?hudPlacementBack:(questFrame.buttons&(1<<1))!=0);
    if(toggle){if(modMenuOpen)CloseModMenu(true);else OpenModMenu();}
    else if(modMenuOpen&&available) {
     if(hudPlacementEditing){if(cancel){hudPlacementEditing=false;hudPlacementChoosing=true;}else if(confirm)SaveHudPlacement();else MoveHudPlacement(questFrame.uiX,questFrame.uiY,hudPlacementLeftTrigger,hudPlacementRightTrigger);questFrame=new QuestFrame();return;}
     if(hudPlacementChoosing){if(cancel)hudPlacementChoosing=false;else if(confirm)EditHudPlacement();else {int handMove=modMenuInput.Navigate(questFrame.uiY,Time.realtimeSinceStartup);hudPlacementHand=(hudPlacementHand+handMove+2)%2;}questFrame=new QuestFrame();return;}
     if(section!=0)SelectModSection(ModMenuSections.Next(CurrentModSection(),section));
     else
     if(cancel){if(wheelPickSlot>=0)CloseWheelPicker();else if(modMenuWheel){modMenuWheel=false;modMenuSelection=6;}else if(modMenuCheats){modMenuCheats=false;modMenuSelection=0;}else if(modMenuTest)SelectModSection(0);else if(modMenuControls)modMenuControls=false;else CloseModMenu(true);}
     else {
      if(PollWheelAssignment(questFrame.uiX,questFrame.uiY)){questFrame=new QuestFrame();return;}
      int move=modMenuInput.Navigate(questFrame.uiY,Time.realtimeSinceStartup);
      int adjustment=modMenuInput.Adjust(Math.Abs(questFrame.uiY)>.5f?0f:questFrame.uiX,Time.realtimeSinceStartup);
      if(!modMenuControls)modMenuSelection=(modMenuSelection+move+ModMenuCount())%ModMenuCount();
      if(!modMenuControls&&!modMenuTest&&adjustment!=0)AdjustModMenu(modMenuSelection,adjustment);
      if(modMenuWheel)wheelListScroll.y=Math.Max(0,(modMenuSelection-7)*58);
      if(confirm)ActivateModMenu(modMenuSelection);
     }
    }
    if(wasOpen||modMenuOpen||toggle)questFrame=new QuestFrame();
   }catch(Exception ex){CloseModMenu(false);MelonLogger.Warning("Mod menu closed; use normal pause menu: "+ex.Message);}
  }
  private void ActivateModMenu(int index) {
   if(modMenuTest){ActivateTestMenu(index);return;}
   if(modMenuControls){FinishModMenu();return;}

   if(modMenuWheel){ActivateWheelPicker(index);return;}
   if(modMenuCheats) {
    if(index==0){inventory14Slots=!inventory14Slots;ApplyInventoryCapacity();}
    else if(index==1){infiniteLife=!infiniteLife;ApplyGameplayCheats();}
    else if(index==2){infiniteAmmo=!infiniteAmmo;ApplyGameplayCheats();}
    else if(index==3){infiniteStunProd=!infiniteStunProd;}
    else if(index==4){allWeapons=!allWeapons;grantWeaponsPending=allWeapons;PollGrantWeapons();}
    else if(index==5){instantKill=!instantKill;}

    else if(index==6){mapComplete=!mapComplete;if(mapComplete)CompleteAllMaps();nextModMapRefresh=0;}
    else if(index==8){modMenuCheats=false;modMenuSelection=0;}
    else if(index==9)FinishModMenu();
    return;
   }
   switch(index) {
    case 0: modLasersOn=!modLasersOn;break;
    case 1: modLaserColor=(modLaserColor+1)%modLaserNames.Length;break;
    case 2: manualReloadEnabled=!manualReloadEnabled;CancelManualReload();break;
    case 3: CycleHudMode(1);break;
    case 4: OpenHudPlacement();break;
    case 5: modMiniMap=!modMiniMap;nextModMapRefresh=0;break;
    case 6: quickEnabled=!quickEnabled;quickSelect.Reset();break;
    case 7: modFlashlightPlacement=(modFlashlightPlacement+1)%3;break;
    case 8: modFullBodyIk=!modFullBodyIk;break;
    case 9: if(enhancedResolutionAvailable)enhancedResolutionRequested=!enhancedResolutionRequested;break;
    case 10: if(flashlightModAvailable)flashlightModRequested=!flashlightModRequested;break;
    case 11: FinishModMenu();break;
   }
  }
  private void AdjustModMenu(int index,int direction) {
   if(wheelPickSlot>=0||modMenuWheel||modMenuTest)return;
   bool on=direction>0;
   if(modMenuCheats) {
    bool current=index==0?inventory14Slots:index==1?infiniteLife:index==2?infiniteAmmo:index==3?infiniteStunProd:index==4?allWeapons:index==5?instantKill:mapComplete;
    if(index>=0&&index<7&&current!=on)ActivateModMenu(index);
    return;
   }
   if(index==9){if(enhancedResolutionAvailable)enhancedResolutionRequested=on;return;}
   if(index==10){if(flashlightModAvailable)flashlightModRequested=on;return;}
   if(index==8){modFullBodyIk=!modFullBodyIk;return;}
   if(index==7){modFlashlightPlacement=(modFlashlightPlacement+direction+3)%3;return;}
   if(index==1){modLaserColor=(modLaserColor+direction+modLaserNames.Length)%modLaserNames.Length;return;}
   if(index==3){CycleHudMode(direction);return;}
   bool value=index==0?modLasersOn:index==2?manualReloadEnabled:index==5?modMiniMap:quickEnabled;
   if((index==0||index==2||index==5||index==6)&&value!=on)ActivateModMenu(index);
  }
  public override void OnGUI() {
   if(!modMenuOpen){if(desktopMouseOnly)DrawDesktopModHud();return;}
   var pause=global::PauseMenu.instance;
   if(pause==null||pause.MenuObject==null||!pause.MenuObject.activeInHierarchy){CloseModMenu(false);return;}
   var oldColor=GUI.color;int oldDepth=GUI.depth;
   try {
    GUI.depth=-10000;
    float scale=Math.Min(Screen.width/1920f,Screen.height/1080f);
    float width=1480f*scale,x=(Screen.width-width)/2f,y=(Screen.height-870f*scale)/2f;
    if(modMenuStyle==null){modMenuStyle=new GUIStyle(GUI.skin.label);modMenuStyle.alignment=TextAnchor.MiddleCenter;modMenuTitle=new GUIStyle(modMenuStyle);modMenuHelp=new GUIStyle(modMenuStyle);modMenuHelp.wordWrap=true;}
    modMenuStyle.fontSize=Math.Max(12,(int)(26*scale));modMenuTitle.fontSize=Math.Max(16,(int)(32*scale));modMenuHelp.fontSize=Math.Max(11,(int)(20*scale));
    var red=new Color(.88f,.12f,.055f);var cyan=new Color(.42f,.8f,.9f);var gray=new Color(.42f,.45f,.43f);
    PaintMenuRect(new Rect(0,0,Screen.width,Screen.height),new Color(.018f,.022f,.02f,1f));
    if(hudPlacementEditing){DrawHudPlacement(x,y,width,scale);return;}
    if(hudPlacementChoosing){DrawHudHandChoice(x,y,width,scale);return;}
    if(modMenuControls){DrawControlsTab(x,y,width,scale);return;}
    PaintMenuRect(new Rect(x,y,width,44*scale),red);
    MenuText(new Rect(x,y,width,44*scale),modMenuTest?"T E S T":modMenuWheel?"ADD ITEM":modMenuCheats?"C H E A T S":"M O D   S E T T I N G S",Color.white,modMenuTitle);
    if(DrawModTabs(x,y,width,scale))return;
    if(modMenuTest){DrawTestTab(x,y,width,scale);return;}
    if(modMenuCheats){DrawCheatsTab(x,y,width,scale);return;}
    if(modMenuWheel){DrawWheelBoxes(x,y,width,scale);return;}
    string[] labels={"Lasers","Laser Color","Manual Reload","HUD","HUD placement","Mini Map","Item Wheel","Flashlight Placement","Inverse Kinematics","Enhanced Resolution Mod","Flashlight Mod"};
    string[] values={modLasersOn?"ON":"OFF",modLaserNames[modLaserColor],manualReloadEnabled?"ON":"OFF",modHudOn?(modHudRight?"RIGHT HAND":"LEFT HAND"):"OFF","A: ADJUST",modMiniMap?"ON":"OFF",quickEnabled?"ON":"OFF",flashlightLocations[modFlashlightPlacement],modFullBodyIk?"FULL BODY":"JUST HANDS",OptionalModValue(enhancedResolutionAvailable,enhancedResolutionRequested,enhancedResolutionActive),OptionalModValue(flashlightModAvailable,flashlightModRequested,flashlightModActive)};
    string[] descriptions={"Show or hide the weapon aiming laser.","Choose RED, GREEN, BLUE, ORANGE or WHITE for the aiming laser.","PISTOL / SMG: B ejects; LEFT GRIP at hip, insert magazine, grip/pull/release slide or bolt. REVOLVER: B opens, insert speedloader; flick wrist or B closes. RIFLE / FLARE: B opens, insert rounds at breech, B closes. SHOTGUN: LEFT GRIP at hip anytime, insert underneath. From empty: pull pump back then forward.","Show or hide the holographic health and ammo HUD attached beside the selected wrist.","Move the HUD beside a static view of Elster's left or right hand and forearm. Press A to adjust and A again to save.","VR: hold your left hand forward, palm down, to reveal the map above it. Turn it back or lower it to hide. Desktop: show the map.","Turn the item wheel ON or OFF. Hold RIGHT joystick click and physically move your RIGHT hand to select. Assign carried items from the inventory action menu using Add To Item Wheel.","Set the flashlight OFF, on the HEAD following your gaze, or UNDER BARREL on the equipped gun. Without a gun, under-barrel placement follows your head. Native flashlight ON/OFF still applies.","Full body shows your body, arms and hands. Just hands hides the body and arms while keeping your hand grips.","Enable or disable the installed Enhanced Resolution mod. Press DONE to save, then restart the game. Current-session UI and textures stay intact.","Enable or disable the installed Flashlight Mod. Press DONE to save, then restart the game. This controls the external mod, separately from VR flashlight placement.","Save your choices for next launch and return to the game."};
    if(modMenuWheel){labels=new[]{"Up space","Right space","Down space","Left space","Back"};values=new[]{QuickName(0),QuickName(1),QuickName(2),QuickName(3),"< SETTINGS"};descriptions=new[]{"Select a carried item for the UP space.","Select a carried item for the RIGHT space.","Select a carried item for the DOWN space.","Select a carried item for the LEFT space.","Return to settings. The ON/OFF toggle is in the main menu.","Save the four assignments and settings."};}

    for(int i=0;i<labels.Length;i++) {
     float rowY=y+(115+i*(modMenuCheats||modMenuWheel?58:47))*scale;bool selected=i==modMenuSelection;
     if(selected)PaintMenuRect(new Rect(x,rowY-7*scale,990*scale,47*scale),new Color(.12f,.16f,.15f));
     MenuText(new Rect(x,rowY,410*scale,48*scale),labels[i],Color.white,modMenuStyle);
     var box=new Rect(x+455*scale,rowY,470*scale,48*scale);
     PaintMenuRect(box,selected?Color.white:gray);PaintMenuRect(new Rect(box.x+2*scale,box.y+2*scale,box.width-4*scale,box.height-4*scale),Color.black);
     MenuText(box,values[i],wheelPickSlot<0&&i==1?modLaserColors[modLaserColor]:cyan,modMenuStyle);
     MenuText(new Rect(box.x-32*scale,rowY,30*scale,48*scale),"<",gray,modMenuStyle);
     MenuText(new Rect(box.xMax+2*scale,rowY,30*scale,48*scale),">",gray,modMenuStyle);
     if(MenuClicked(new Rect(x,rowY,985*scale,48*scale))){modMenuSelection=i;ActivateModMenu(i);return;}
    }
    PaintMenuRect(new Rect(x+1030*scale,y+148*scale,2*scale,440*scale),gray);
    MenuText(new Rect(x+1070*scale,y+154*scale,370*scale,48*scale),modMenuSelection<labels.Length?labels[modMenuSelection].ToUpperInvariant():"DONE",cyan,modMenuStyle);
    MenuText(new Rect(x+1070*scale,y+220*scale,370*scale,245*scale),descriptions[modMenuSelection],Color.white,modMenuHelp);
    if(!modMenuWheel&&!modMenuCheats&&modMenuSelection==5)DrawModMapLegend(x+1070*scale,y+470*scale,scale);
    else if(!modMenuWheel&&!modMenuCheats)MenuText(new Rect(x+1070*scale,y+475*scale,370*scale,120*scale),desktopMouseOnly?"DESKTOP PREVIEW\nHand placement and reload gestures need the headset.":"VR SETTINGS\nBoth stick clicks open / close.",gray,modMenuHelp);
    if(modMenuCheats)MenuText(new Rect(x,y+580*scale,width,80*scale),InventoryCheatWarning,Color.white,modMenuHelp);
    MenuText(new Rect(x,y+665*scale,width,60*scale),desktopMouseOnly?"UP / DOWN   Select     LEFT / RIGHT / ENTER   Change     F4   Close":"LEFT STICK: Up/Down Select, Left/Right Change   A: Change   B: Back   GRIPS: Sections",Color.white,modMenuHelp);
    var done=new Rect(x,y+750*scale,430*scale,52*scale);PaintMenuRect(done,modMenuSelection==labels.Length?new Color(.25f,.3f,.3f):red);
    MenuText(done,"D O N E",Color.white,modMenuStyle);if(MenuClicked(done))FinishModMenu();
    MenuText(new Rect(x+470*scale,y+750*scale,width-470*scale,52*scale),"EXTERNAL MOD SWITCHES REQUIRE RESTART",cyan,modMenuStyle);
    MenuText(new Rect(x,y+818*scale,width,36*scale),modSettingsError??"Press DONE to save choices for next launch",red,modMenuHelp);
   }catch(Exception ex){CloseModMenu(false);MelonLogger.Warning("Mod menu drawing failed: "+ex.Message);}
   finally {GUI.color=oldColor;GUI.depth=oldDepth;}
  }
  private static void PaintMenuRect(Rect r,Color c){GUI.color=c;GUI.DrawTexture(r,Texture2D.whiteTexture);}
  private void DrawModMapLegend(float x,float y,float s){
   string[] labels={"RED LOCK: Locked","YELLOW LOCK: Key / unlock action","BLUE ENTRANCE: Passable"};
   Color[] colors={new Color(1f,.15f,.1f),new Color(1f,.85f,.1f),new Color(.3f,.75f,1f)};
   for(int i=0;i<3;i++){float cy=y+(i*53+20)*s;var c=colors[i];
    if(i<2){PaintMenuRect(new Rect(x,cy,14*s,10*s),c);DrawMapLine(new Vector2(x+3*s,cy),new Vector2(x+3*s,cy-9*s),2*s,c);DrawMapLine(new Vector2(x+3*s,cy-9*s),new Vector2(x+11*s,cy-9*s),2*s,c);DrawMapLine(new Vector2(x+11*s,cy-9*s),new Vector2(x+11*s,cy),2*s,c);}
    else {DrawMapLine(new Vector2(x,cy+10*s),new Vector2(x,cy-9*s),2*s,c);DrawMapLine(new Vector2(x,cy-9*s),new Vector2(x+14*s,cy-9*s),2*s,c);DrawMapLine(new Vector2(x+14*s,cy-9*s),new Vector2(x+14*s,cy+10*s),2*s,c);}
    MenuText(new Rect(x+24*s,cy-20*s,346*s,43*s),labels[i],Color.white,modMenuHelp);
   }
  }
  private static void MenuText(Rect r,string text,Color c,GUIStyle style){DrawPixelText(r,text,c,style);}
  private static bool MenuClicked(Rect r){var e=Event.current;if(e.type==EventType.MouseDown&&e.button==0&&r.Contains(e.mousePosition)){e.Use();return true;}return false;}
  private bool MenuRow(Rect r,string text,bool selected) {
   PaintMenuRect(r,Color.white);PaintMenuRect(new Rect(r.x+2,r.y+2,r.width-4,r.height-4),selected?Color.white:Color.black);
   MenuText(r,text,selected?Color.black:Color.white,modMenuStyle);
   var e=Event.current;if(e.type==EventType.MouseDown&&e.button==0&&r.Contains(e.mousePosition)){e.Use();return true;}return false;
  }
 }
}





















