$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'MacheteRemoval.cs') -Raw
$a=$s.IndexOf(' private static bool RemovedMachete');$b=$s.IndexOf(' private static bool RemoveMachetePickup')
$methods=$s.Substring($a,$b-$a).Replace('private static','public static')
Add-Type -TypeDefinition (@'
using System.Collections.Generic;
public static class Items {public enum itemlist {Machete,Pistol}}
public class AnItem {public Items.itemlist _item;public bool hidden;}
public class Weapon {public AnItem parentItem;}
public static class InventoryManager {
 public static Dictionary<Items.itemlist,AnItem> allItems=new Dictionary<Items.itemlist,AnItem>();
 public static Dictionary<AnItem,int> elsterItems=new Dictionary<AnItem,int>(),boxItems=new Dictionary<AnItem,int>();
 public static Weapon EquippedWeapon;public static AnItem EquippedTool,CurrentItem;
}
public static class RemovalHarness {
'@+$methods+'}')
$m=[AnItem]::new();$m._item=[Items+itemlist]::Machete
$p=[AnItem]::new();$p._item=[Items+itemlist]::Pistol
[InventoryManager]::allItems.Add($m._item,$m);[InventoryManager]::allItems.Add($p._item,$p)
[InventoryManager]::elsterItems.Add($m,1);[InventoryManager]::elsterItems.Add($p,2);[InventoryManager]::boxItems.Add($m,3);[InventoryManager]::boxItems.Add($p,4)
$w=[Weapon]::new();$w.parentItem=$m;[InventoryManager]::EquippedWeapon=$w;[InventoryManager]::EquippedTool=$m;[InventoryManager]::CurrentItem=$m
[RemovalHarness]::RemoveExistingMachete()
if([InventoryManager]::elsterItems.ContainsKey($m) -or [InventoryManager]::boxItems.ContainsKey($m) -or [InventoryManager]::EquippedWeapon -or [InventoryManager]::EquippedTool -or [InventoryManager]::CurrentItem -or !$m.hidden){throw 'Machete remains'}
if([InventoryManager]::elsterItems[$p] -ne 2 -or [InventoryManager]::boxItems[$p] -ne 4 -or $p.hidden){throw 'Unrelated item affected'}
if([RemovalHarness]::RejectMacheteItem($m) -or ![RemovalHarness]::RejectMacheteItem($p)){throw 'Grant/equip guard failed'}
$w.parentItem=$p;[InventoryManager]::EquippedWeapon=$w;[RemovalHarness]::RemoveExistingMachete();if([InventoryManager]::EquippedWeapon -ne $w){throw 'Pistol unequipped'}
Add-Type -Path (Join-Path $PSScriptRoot '../../work/quest-native-lab/MelonLoader/Mono.Cecil.dll')
$dll=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
if(@($dll.MainModule.Resources|Where-Object Name -match 'machete').Count){throw 'Machete audio embedded'}
if(@($dll.MainModule.Types|Where-Object Name -match 'HdMacheteData|MacheteDamage').Count){throw 'Machete assets/combat compiled'}
$tracking=$dll.MainModule.Types|Where-Object Name -eq Tracking
if(@($tracking.Methods|Where-Object Name -match 'SwingMachete|MacheteEligible|MacheteSelected').Count){throw 'Machete runtime remains'}
'PASS production inventory/storage purge, equip/grant rejection, other-item preservation, repeat cleanup; compiled DLL excludes machete geometry/audio/combat. Runtime world pickup rendering unverified.'
