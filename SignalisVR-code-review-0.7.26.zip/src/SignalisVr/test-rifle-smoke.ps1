$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'RifleChamberSmoke.cs') -Raw
$a=$s.IndexOf(' public static class RifleSmokeTiming');$b=$s.IndexOf(' public sealed partial class Tracking')
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$s.Substring($a,$b-$a)+'}')
foreach($mask in 0..3){foreach($chamber in 0..1){foreach($particle in 0..6){
 if([SignalisVrTracking.RifleSmokeTiming]::Age($mask,$chamber,-.1,$particle) -ge 0){throw 'Smoke before ejection'}
 if([SignalisVrTracking.RifleSmokeTiming]::Age($mask,$chamber,2.1,$particle) -ge 0){throw 'Smoke failed to expire'}
 $age=[SignalisVrTracking.RifleSmokeTiming]::Age($mask,$chamber,.23,$particle)
 if(($age -ge 0) -ne (($mask -band (1 -shl $chamber)) -ne 0)){throw 'Smoke emitted from unfired chamber'}
}}}
'PASS upper/lower/both/neither spent-chamber smoke gating, no pre-emission and finite fade lifetime. Renderer not executed.'

