$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'MapIcons.cs') -Raw
$start=$s.IndexOf(' private void MapPointLines(');$body=$s.Substring($start);$body=$body.Substring(0,$body.LastIndexOf('}}'))
$stub=@'
using System;using System.Collections.Generic;using UnityEngine; public class Items { public enum itemlist { RevolverAmmo=44 } }
namespace UnityEngine {public struct Vector2{public float x,y;public Vector2(float a,float b){x=a;y=b;}public static Vector2 operator+(Vector2 a,Vector2 b){return new Vector2(a.x+b.x,a.y+b.y);}public static Vector2 operator*(Vector2 a,float b){return new Vector2(a.x*b,a.y*b);}}public struct Color{public float r,g,b;public Color(float x,float y,float z){r=x;g=y;b=z;}public static Color white{get{return new Color(1,1,1);}}}public static class Mathf{public static float Cos(float v){return (float)Math.Cos(v);}public static float Sin(float v){return (float)Math.Sin(v);}}}
public class ArtHarness {
public static void Run(){var q=new ArtHarness();for(int kind=0;kind<11;kind++){int count=0,red=0,white=0;q.MapPointLines(new Vector2(0,0),kind,1,(a,b,c,w)=>{count++;if(float.IsNaN(a.x)||float.IsNaN(b.y)||w<=0)throw new Exception("invalid stroke");if(c.r==1&&c.g<.2f&&c.b<.2f)red++;if(c.r==1&&c.g==1&&c.b==1)white++;});if(count==0)throw new Exception("empty icon "+kind);if(kind==4&&(red!=3||white<10))throw new Exception("document needs three red lines and white pages");if(kind==9&&red==0)throw new Exception("flare flame must be red");if(kind==8&&white!=count)throw new Exception("rifle ammo must be white");}}
'@
Add-Type -TypeDefinition ($stub+$body+'}')
[ArtHarness]::Run()
$s=Get-Content (Join-Path $PSScriptRoot 'EnemyFire.cs') -Raw
$policy=$s.Substring($s.IndexOf(' public static class EnemyFirePolicy {'));$policy=$policy.Substring(0,$policy.IndexOf(' public sealed partial class Tracking'))
Add-Type -TypeDefinition ('using System;'+$policy)
foreach($hp in @(0,1,3,4,5,10,100)){if([EnemyFirePolicy]::AfterTick($hp) -ne [Math]::Max(0,$hp-4)){throw 'Burn tick damage wrong'}}
'PASS production geometry for eleven icon categories, three red document lines, red flare flame, white rifle rounds, finite strokes and four-point burn ticks.'

