$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'DoorFade.cs') -Raw
$stubs=@'
namespace UnityEngine {
 public class Texture {public string name="NativeFade";}
 public class Texture2D:Texture {}
 public class Shader {}
 public class GameObject {public T AddComponent<T>() where T:new(){return new T();}}
 public class Camera {public GameObject gameObject=new GameObject();public object component;public T GetComponent<T>() where T:class{return component as T;}}
 public class RenderTexture:Texture {
  public int width=640,height=480,format;public static int created,released;
  public static RenderTexture GetTemporary(int w,int h,int depth,int f){created++;return new RenderTexture{width=w,height=h,format=f};}
  public static void ReleaseTemporary(RenderTexture t){released++;}
 }
 public static class Graphics {public static int copies;public static void Blit(Texture s,RenderTexture d){copies++;}}
}
namespace UnityStandardAssets.ImageEffects {
 public class ScreenOverlay {
  public bool enabled,isActiveAndEnabled=true;public int blendMode;
  public float intensity;public UnityEngine.Texture2D texture;public UnityEngine.Shader overlayShader;
  public static int draws;public static bool fail;
  public void OnRenderImage(UnityEngine.RenderTexture s,UnityEngine.RenderTexture d){draws++;if(fail)throw new System.Exception("fixture draw failure");}
 }
}
namespace MelonLoader {public static class MelonLogger {public static void Msg(string message){}}}
public class MainFader {public UnityStandardAssets.ImageEffects.ScreenOverlay so;}
public static class PlayerState {public static MainFader MasterFader;public static UnityEngine.Camera cameraMain;}
'@
$tests=@'
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private UnityEngine.Camera[] eyes={new UnityEngine.Camera(),new UnityEngine.Camera()};
  private UnityEngine.RenderTexture[] textures={new UnityEngine.RenderTexture(),new UnityEngine.RenderTexture()};
  private bool eligible=true;private bool DoorCameraEligible(){return eligible;}
  public static void Run(){
   var t=new Tracking();t.RenderNativeDoorFade(0);
   var native=new UnityStandardAssets.ImageEffects.ScreenOverlay{intensity=.4f,blendMode=4,overlayShader=new UnityEngine.Shader(),texture=new UnityEngine.Texture2D()};
   PlayerState.MasterFader=new MainFader{so=native};
   PlayerState.cameraMain=new UnityEngine.Camera{component=PlayerState.MasterFader};
   PlayerState.MasterFader=new MainFader{so=new UnityStandardAssets.ImageEffects.ScreenOverlay{intensity=1}};
   t.RenderNativeDoorFade(0);t.RenderNativeDoorFade(1);
   foreach(var privateEffect in t.doorEyeFade) {
    if(privateEffect==native||privateEffect.enabled||privateEffect.intensity!=.4f||privateEffect.blendMode!=4||privateEffect.texture!=native.texture||privateEffect.overlayShader!=native.overlayShader)throw new System.Exception("Private native-fade copy must match live parameters without auto-rendering or sharing component");
   }
   if(UnityStandardAssets.ImageEffects.ScreenOverlay.draws!=2||UnityEngine.RenderTexture.released!=2||UnityEngine.Graphics.copies!=2)throw new System.Exception("Exactly once per eye and balanced temporary targets");
   native.intensity=.8f;native.texture=null;t.RenderNativeDoorFade(0);
   if(t.doorEyeFade[0].intensity!=.8f||t.doorEyeFade[0].texture!=null)throw new System.Exception("Track live fade, including native null-texture shader default");
   native.intensity=0;t.RenderNativeDoorFade(0);native.intensity=.8f;native.isActiveAndEnabled=false;t.RenderNativeDoorFade(0);native.isActiveAndEnabled=true;t.eligible=false;t.RenderNativeDoorFade(0);
   if(UnityStandardAssets.ImageEffects.ScreenOverlay.draws!=3)throw new System.Exception("No additional pass when invisible, disabled or outside gameplay");
   t.eligible=true;UnityStandardAssets.ImageEffects.ScreenOverlay.fail=true;
   try{t.RenderNativeDoorFade(0);}catch(System.Exception){}
   if(UnityEngine.RenderTexture.created!=UnityEngine.RenderTexture.released)throw new System.Exception("Temporary release on rendering exception");
   if(native.intensity!=.8f||native.texture!=null||native.blendMode!=4||!native.isActiveAndEnabled)throw new System.Exception("Native story fader must remain untouched");
  }
 }
}
'@
Add-Type -TypeDefinition ($source+$stubs+$tests)
[SignalisVrTracking.Tracking]::Run()
$render=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
if($render.IndexOf('RenderNativeDoorFade(i);') -lt $render.IndexOf('RenderSnowCursor(eyes[i]);') -or $render.IndexOf('RenderNativeDoorFade(i);') -gt $render.IndexOf('SubmitEyes();')){throw 'Native fade must run after UI and before submit'}
'PASS actual native-fade forwarding: both eyes once, live parameters, native texture default, no-op states, private effects, untouched original, exception-safe temporary release and after-UI integration. GPU/headset result unverified.'
