$ErrorActionPreference='Stop'
Add-Type -Path "$PSScriptRoot/ModSettingsFile.cs"
$fixture=Join-Path ([IO.Path]::GetFullPath("$PSScriptRoot/../../outputs/DependencyToggles0726")) ('settings-'+[guid]::NewGuid()+'.txt')
$s=[SignalisVrTracking.ModSettingsFile]::Load($fixture)
if(!$s.EnhancedResolutionMod -or !$s.FlashlightMod){throw 'Existing users must default enabled'}
foreach($er in $false,$true){foreach($fl in $false,$true){$s.EnhancedResolutionMod=$er;$s.FlashlightMod=$fl;$s.Save($fixture);$r=[SignalisVrTracking.ModSettingsFile]::Load($fixture);if($r.EnhancedResolutionMod -ne $er -or $r.FlashlightMod -ne $fl){throw 'Switch persistence failed'}}}
Add-Type -Path "$PSScriptRoot/../../work/quest-native-lab/MelonLoader/Mono.Cecil.dll"
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly("$PSScriptRoot/SignalisVrTracking.dll")
try {
$t=$a.MainModule.Types|Where-Object FullName -eq 'SignalisVrTracking.Tracking'
foreach($pair in @(@('EnhancedResolutionAllowed','enhancedResolutionActive'),@('FlashlightModAllowed','flashlightModActive'))){$m=$t.Methods|Where-Object Name -eq $pair[0];if(!($m.Body.Instructions|Where-Object { $_.OpCode.Name -eq 'ldsfld' -and $_.Operand.Name -eq $pair[1]})){throw 'Callback gate missing'}}
foreach($name in 'enhancedResolutionActive','flashlightModActive'){$writers=@($t.Methods|Where-Object { $_.Body -and ($_.Body.Instructions|Where-Object {$_.OpCode.Name -eq 'stsfld' -and $_.Operand.Name -eq $name})});if($writers.Name|Where-Object {$_ -notin '.cctor','InstallOptionalModSwitches'}){throw 'Active switches changed mid-session'}}
}finally{$a.Dispose()}
'PASS both defaults, four saved combinations, compiled callback gates, and immutable session choices.'
'Runtime dependency coexistence and restart behavior remain unverified.'
