using System;
using System.IO;
using UnityEngine;
namespace SignalisVrTracking {
 public static class RepairPatchMotion {
  public const float Duration=.58f;
  public static float Amount(float age){if(float.IsNaN(age)||age<0||age>=Duration)return 0;float a=age<.20f?age/.20f:age<.30f?1:1-(age-.30f)/.28f;return a*a*(3-2*a);}
  public static bool PacketVisible(bool used,float age){return !used||age<.14f;}
 }
 public sealed partial class Tracking {
  private Transform patchGripFrame;
  private MeshRenderer patchHand;
  private Mesh patchHandMesh;
  private Material patchHandMaterial;
  private Vector3[] patchRest,patchFist,patchVertices;
  private void FitPatchGrip(){
   if(patchGripFrame==null||handsObjects[1]==null)return;
   var tracked=controllerMarkers[1].transform;
   var basis=WeaponAimPolicy.ControllerRotation(tracked.rotation)*Quaternion.Euler(0,0,-90);
   patchGripFrame.rotation=basis*Quaternion.Inverse(ElsterPatchGripData.Basis);
   var center=patchGripFrame.GetComponent<MeshFilter>().sharedMesh.bounds.center;
   var desiredCenter=tracked.position-patchGripFrame.rotation*(ElsterPatchGripData.Palm*UnitsPerMetre);
   quickHealthRoot.transform.position+=desiredCenter-patchGripFrame.TransformPoint(center);
  }

  private void ClearPatchGrip(){if(patchHand!=null)UnityEngine.Object.Destroy(patchHand.gameObject);if(patchHandMesh!=null)UnityEngine.Object.Destroy(patchHandMesh);if(patchHandMaterial!=null)UnityEngine.Object.Destroy(patchHandMaterial);patchHand=null;patchHandMesh=null;patchHandMaterial=null;patchGripFrame=null;patchRest=patchFist=patchVertices=null;}
 }
}
