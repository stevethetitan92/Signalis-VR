$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
function Check($v,$why){if(-not $v){throw $why}}
$count=0
# AddForce defaults to force * fixedDelta / mass. The FP mod calls it once
# per rendered update. Accumulated impulse must not depend on rendering FPS.
foreach($fps in 30,60,72,90,120,144) {
 foreach($fixedStep in .01,.02) {
  foreach($stick in .25,1,-1) {
   $impulse=0.0
   for($frame=0;$frame -lt $fps;$frame++) {
    $impulse += [SignalisVrTracking.QuestInputPolicy]::StrafeScale($stick,(1.0/$fps),$fixedStep)*$fixedStep
   }
   Check ([Math]::Abs($impulse-[Math]::Abs($stick)) -lt .00001) "Frame-dependent strafe at $fps fps"
   $count++
  }
 }
}
foreach($case in @(@(1,0,.02),@(1,.01,0),@(1,.01,[float]::NaN),@([float]::NaN,.01,.02),@(1,-1,.02))) {
 Check ([SignalisVrTracking.QuestInputPolicy]::StrafeScale($case[0],$case[1],$case[2]) -eq 0) 'Invalid/time-paused strafe must not push';$count++
}
Check ([Math]::Abs([SignalisVrTracking.QuestInputPolicy]::StrafeScale(1,1,.02)-2.5) -lt .00001) 'Hitch force unbounded';$count++
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$mod=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
$fp=[Mono.Cecil.AssemblyDefinition]::ReadAssembly('E:/SteamLibrary/steamapps/common/SIGNALIS/Mods/FPv2_reworked.dll')
try {
 $tracking=$mod.MainModule.Types | Where-Object Name -eq Tracking
 function Calls($name){($tracking.Methods | Where-Object Name -eq $name).Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.MethodReference]} | ForEach-Object {$_.Operand.Name}}
 Check ((Calls 'EnsureQuestControllers') -contains 'PollQuestControllers') 'Managed update polling missing'
 Check ((Calls 'TraceQuestRouting') -contains 'get_input') 'Missing actual gameplay consumer diagnostic'
 Check ((Calls 'QuestFpSetHeading') -contains 'GetValue') 'Native FP degree yaw is not read'
 Check ((Get-Content (Join-Path $PSScriptRoot 'QuestFirstPerson.cs') -Raw).Contains('original=(float)q.questFpYaw.GetValue(q.questFpMod)')) 'Quest strafe does not use degree yaw'
 Check ((Calls 'QuestFpForce') -contains 'StrafeScale') 'Force compensation is not integrated'
 Check ((Calls 'QuestFpForce') -contains 'get_deltaTime') 'Paused physics uses wrong clock'
 Check ((Calls 'QuestFpForce') -contains 'get_fixedDeltaTime') 'Force does not account for physics interval'
 $late=($fp.MainModule.Types | Where-Object Name -eq FPv2_rework).Methods | Where-Object Name -eq OnLateUpdate
 Check (@($late.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.Name -eq 'set_fAngle'}).Count -eq 1) 'Unexpected installed FP heading setter layout'
 Check (@($late.Body.Instructions | Where-Object {$_.Operand -is [Mono.Cecil.FieldReference] -and $_.Operand.DeclaringType.FullName -eq 'UnityEngine.Quaternion' -and $_.Operand.Name -eq 'y'}).Count -eq 1) 'Underlying quaternion/degrees mismatch changed'
 # No OS keyboard/mouse injection, game launch, or process-spawning code belongs in the mod.
 foreach($type in $mod.MainModule.Types){foreach($m in $type.Methods){if($m.PInvokeInfo){Check ($m.PInvokeInfo.EntryPoint -notmatch 'SendInput|keybd_event|mouse_event|CreateProcess|ShellExecute') 'Unwanted OS injection or launch'}}}
}finally{$mod.Dispose();$fp.Dispose()}
"PASS: $count strafe impulse/invalid-input cases, 8 compiled integration/installed-FP-layout checks, and no OS input injection or game launcher. No game started; headset/gameplay behavior remains unverified."

