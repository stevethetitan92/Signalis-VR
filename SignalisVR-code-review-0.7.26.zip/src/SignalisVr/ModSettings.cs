using System;
using System.IO;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private string modSettingsError;
  private static string ModSettingsPath(){return Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"UserData","SignalisVrNoMarkers.settings");}
  private void LoadModSettings(){
   try{var s=ModSettingsFile.Load(ModSettingsPath());modFullBodyIk=s.FullBodyIk;enhancedResolutionRequested=s.EnhancedResolutionMod;flashlightModRequested=s.FlashlightMod;quickEnabled=s.AlyxWheel;for(int i=0;i<4;i++)quickSlots[i]=Array.IndexOf(QuickChoices,s.WheelSlots[i])>=0?s.WheelSlots[i]:"None";modFlashlightPlacement=s.FlashlightPlacement;modLasersOn=s.Lasers;modLaserColor=s.LaserColor;manualReloadEnabled=s.ManualReload;modHudOn=s.HudOn;modHudRight=s.HudRight;modHudForearm=false;if(s.HudForearm)modHudRight=true;hudPlacementForearmOffset=new UnityEngine.Vector3(s.HudForearmX,s.HudForearmY,s.HudForearmZ);hudPlacementOffset=new UnityEngine.Vector3(s.HudRightX,s.HudRightY,s.HudRightZ);hudPlacementLeftOffset=new UnityEngine.Vector3(s.HudLeftX,s.HudLeftY,s.HudLeftZ);modMiniMap=s.MiniMap;inventory14Slots=s.Inventory14Slots;infiniteLife=s.InfiniteLife;infiniteAmmo=s.InfiniteAmmo;infiniteStunProd=s.InfiniteStunProd;allWeapons=s.AllWeapons;instantKill=s.InstantKill;mapComplete=s.MapComplete;MelonLogger.Msg("MOD SETTINGS: loaded saved choices (defaults if no settings file).");}
   catch(Exception ex){MelonLogger.Warning("MOD SETTINGS: defaults retained; could not load: "+ex.Message);}
  }
  private void SaveModSettings(){new ModSettingsFile{EnhancedResolutionMod=enhancedResolutionRequested,FlashlightMod=flashlightModRequested,FullBodyIk=modFullBodyIk,AlyxWheel=quickEnabled,WheelSlots=quickSlots,Lasers=modLasersOn,LaserColor=modLaserColor,FlashlightPlacement=modFlashlightPlacement,ManualReload=manualReloadEnabled,HudOn=modHudOn,HudRight=modHudRight,HudForearm=modHudForearm,HudForearmX=hudPlacementForearmOffset.x,HudForearmY=hudPlacementForearmOffset.y,HudForearmZ=hudPlacementForearmOffset.z,HudRightX=hudPlacementOffset.x,HudRightY=hudPlacementOffset.y,HudRightZ=hudPlacementOffset.z,HudLeftX=hudPlacementLeftOffset.x,HudLeftY=hudPlacementLeftOffset.y,HudLeftZ=hudPlacementLeftOffset.z,MiniMap=modMiniMap,Inventory14Slots=inventory14Slots,InfiniteLife=infiniteLife,InfiniteAmmo=infiniteAmmo,InfiniteStunProd=infiniteStunProd,AllWeapons=allWeapons,InstantKill=instantKill,MapComplete=mapComplete}.Save(ModSettingsPath());}
  private void FinishModMenu(){
   try{SaveModSettings();modSettingsError=null;MelonLogger.Msg("MOD SETTINGS: choices saved.");CloseModMenu(true);}
   catch(Exception ex){modSettingsError="Could not save settings. Press DONE to retry.";MelonLogger.Warning("MOD SETTINGS: save failed; menu remains open: "+ex.Message);}
  }
 }
}



