using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class FireHitVoice {internal global::EnemyController Enemy;internal PackAudio Audio;internal Vector3 Position;internal global::Room Room;internal float Age;}
 private readonly List<FireHitVoice> fireHitVoices=new List<FireHitVoice>();
 private byte[] fireHitPcm;
 private void PlayFireHit(Vector3 point,global::EnemyController enemy){
  if(!ProdEnemyValid(enemy))return;
  PackAudio sound=null;
  try{
   if(fireHitPcm==null)fireHitPcm=Convert.FromBase64String(HdAsset.Read("fire-enemy-hit.pcm"));
   sound=new PackAudio(fireHitPcm,44100);
   sound.SpatialOnce(Quaternion.Inverse(stereoRotation)*(point-stereoPosition)/UnitsPerMetre,.85f);
   if(fireHitVoices.Count>=16){fireHitVoices[0].Audio.Dispose();fireHitVoices.RemoveAt(0);}
   fireHitVoices.Add(new FireHitVoice{Enemy=enemy,Audio=sound,Position=point,Room=global::PlayerState.currentRoom});
  }catch(Exception ex){if(sound!=null)sound.Dispose();MelonLoader.MelonLogger.Warning("Fire enemy impact audio unavailable: "+ex.Message);}
 }
 private void PollFireHitAudio(){
  bool paused=global::PlayerState.paused||!WeaponGameplayReady()||pauseMenuVisible||modMenuOpen||!ProdVrMode();
  for(int i=fireHitVoices.Count-1;i>=0;i--){var v=fireHitVoices[i];
   try{
    if(!ProdEnemyValid(v.Enemy)||v.Room!=global::PlayerState.currentRoom||v.Age>=6f){v.Audio.Dispose();fireHitVoices.RemoveAt(i);continue;}
    if(paused){v.Audio.PauseLoop();continue;}
    v.Age+=Mathf.Max(0,Time.deltaTime);
    v.Audio.SpatialOnce(Quaternion.Inverse(stereoRotation)*(v.Position-stereoPosition)/UnitsPerMetre,.85f);
   }catch(Exception ex){fireHitVoices.RemoveAt(i);try{v.Audio.Dispose();}catch{}MelonLoader.MelonLogger.Warning("Fire impact audio ended: "+ex.Message);}
  }
 }
 private void DestroyFireHitAudio(){foreach(var v in fireHitVoices)v.Audio.Dispose();fireHitVoices.Clear();fireHitPcm=null;}
}}
