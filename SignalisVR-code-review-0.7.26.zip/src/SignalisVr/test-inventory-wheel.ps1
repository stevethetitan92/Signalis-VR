$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'InventoryWheel.cs') -Raw
$start=$s.IndexOf(' public static class InventoryWheelPolicy')
$end=$s.IndexOf(' public sealed partial class Tracking')
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$s.Substring($start,$end-$start)+'}')
$allowed=@('Pistol','Revolver','Shotgun','Rifle','FlareGun','SMG','Taser','Health25','Health50','Health100','HealthFast','SignalFlare')
foreach($id in $allowed){if(![SignalisVrTracking.InventoryWheelPolicy]::Allowed($id)){throw "Missing $id"}}
foreach($id in @('None','Machete','Receiver','PhotoModule','Flashlight','PistolAmmo','Key','Document',$null)){if([SignalisVrTracking.InventoryWheelPolicy]::Allowed($id)){throw "Unexpected $id"}}
foreach($id in $allowed){foreach($from in 0..3){foreach($to in 0..3){$slots=[string[]]@('None','None','None','None');$slots[$from]=$id;[SignalisVrTracking.InventoryWheelPolicy]::Assign($slots,$to,$id);if($slots[$to] -ne $id -or @($slots|Where-Object {$_ -eq $id}).Count -ne 1){throw 'Move duplicated/lost item'}}}}
$slots=[string[]]@('Pistol','SMG','Pistol','Taser');[SignalisVrTracking.InventoryWheelPolicy]::Assign($slots,1,'Pistol');if(($slots -join '|') -ne 'None|Pistol|None|Taser'){throw 'Replace/move failed'}
$slots=[string[]]@('Pistol','Pistol','Receiver','Health25');[SignalisVrTracking.InventoryWheelPolicy]::Normalize($slots);if(($slots -join '|') -ne 'Pistol|None|None|Health25'){throw 'Existing settings migration failed'}
foreach($needle in @('confirm=a&&!o.inventoryWheelConfirmHeld','if(confirm){','if(cancel){o.CloseInventoryWheel();return false;}','o.SaveModSettings();','o.quickSlots=old;','v.itemName.text="Choose Slot"','v.itemDescription.rectTransform','Add To Item Wheel','inventoryWheelIcons[i].color=Color.white')){if(!$s.Contains($needle)){throw "Missing integration: $needle"}}
'PASS eligibility, all 192 move combinations, occupied-slot replacement, legacy duplicate migration; source guards for A confirmation/B cancellation/save rollback and description-panel placement. Headset input and rendering unverified.'
