$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
$script:checks=0
function Check($value,$message){if(!$value){throw $message};$script:checks++}
$f=[SignalisVrTracking.QuestFrame]::new();$f.moveX=.6;$f.moveY=.9;$f.uiX=.6;$f.uiY=.9;$f.lookX=-.4;$f.lookY=.3
function Axis($name,$physical,$fp){[SignalisVrTracking.QuestNativeRouting]::Axis($name,$physical,$f,$fp)}
Check ([Math]::Abs((Axis 'Move Vertical' 0 $true)-.9) -lt .00001) 'Forward lost in FP'
$f.moveY=-.9
Check ([Math]::Abs((Axis 'Move Vertical' 0 $true)+.9) -lt .00001) 'Backward lost in FP'
Check ((Axis 'Move Horizontal' 0 $true) -eq 0) 'FP strafe duplicated'
Check ([Math]::Abs((Axis 'UIHorizontal' 0 $true)-.6) -lt .00001) 'Menu strafe suppressed by FP'
Check ((Axis 'Move Vertical' 1 $true) -eq 1) 'W keyboard overridden'
Check ((Axis 'Move Vertical' -1 $true) -eq -1) 'S keyboard overridden'
Check ((Axis 'Move Horizontal' 1 $true) -eq 1) 'A/D keyboard overridden'
Check ((Axis 'unknown' .75 $true) -eq .75) 'Unknown native action changed'
Check ([Math]::Abs((Axis 'Move Vertical' -.9 $true)+.9) -lt .00001) 'Custom input doubled'
Check ([Math]::Abs((Axis 'Aim Horizontal' 0 $false)+.4) -lt .00001) 'Aim X mismatch'
Check ([Math]::Abs((Axis 'Aim Vertical' 0 $false)-.3) -lt .00001) 'Aim Y mismatch'
# Every button: one down frame, sustained hold with no repeat, one up frame.
for($i=0;$i -lt 10;$i++){
 $e=[SignalisVrTracking.QuestButtonEdges]::new();$mask=1 -shl $i
 $e.Sample(0,1);$e.Sample($mask,2);$e.Sample($mask,2)
 Check ($e.Down -eq $mask -and $e.Up -eq 0) "Button $i first press"
 $e.Sample($mask,3);Check ($e.Down -eq 0 -and $e.Up -eq 0) "Button $i held repeat"
 $e.Sample(0,4);Check ($e.Up -eq $mask -and $e.Down -eq 0) "Button $i release"
 $e.Sample(0,5);Check ($e.Up -eq 0) "Button $i repeated release"
 $e.Sample($mask,6);$e.Reset();Check ($e.Down -eq 0 -and $e.Up -eq 0) "Button $i stop reset"
}
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
 $t=$a.MainModule.Types|Where-Object Name -eq Tracking
 function Calls($name){($t.Methods|Where-Object Name -eq $name).Body.Instructions|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference]}|ForEach-Object {$_.Operand.Name}}
 Check ((Calls InstallQuestNativeReads) -contains 'AttachQuestNative') 'Actual native hooks missing'
 Check ((Calls AttachQuestNative) -contains 'NativeHookAttach') 'No loader native detour'
 Check ((Calls QuestNativeAxis) -contains 'Invoke') 'Native physical axis original omitted'
 foreach($name in 'QuestNativeHeld','QuestNativeDown','QuestNativeUp'){Check ((Calls $name) -contains 'Invoke') "$name physical original omitted"}
 Check ((Calls SnapshotQuestNative) -contains 'QuestAvailableNow') 'Focus guard missing'
 Check (@($t.Methods|Where-Object Name -eq 'QuestNativeUpdate').Count -eq 0) 'Native Update detour must be absent'
 $allCalls=@($t.Methods|ForEach-Object {$_.Body.Instructions}|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference]}|ForEach-Object {$_.Operand.Name})
 foreach($banned in 'CreateCustomController','AddEmptyMap','CreateElementMap','add_InputSourceUpdateEvent','AddController','SetAxisValue','SetButtonValue'){
  Check ($allCalls -notcontains $banned) "Custom controller mutation remains: $banned"
 }
 Check ((Calls TraceQuestRouting) -contains 'get_Move') 'Actual game action observation missing'
 Check ((Calls ReleaseQuestControls) -contains 'Reset') 'Release leaves stale edges'
 $bt=$t.NestedTypes|Where-Object Name -eq QuestButtonNative
 $invoke=$bt.Methods|Where-Object Name -eq Invoke
 Check ($invoke.MethodReturnType.MarshalInfo.NativeType.ToString() -eq 'I1') 'Native bool return ABI must be 1 byte'
 Check (@($invoke.Parameters).Count -eq 3) 'Native self/action/MethodInfo signature mismatch'
}finally{$a.Dispose()}
"PASS: $checks routing, button lifecycle, native ABI and compiled integration checks. No native game execution or headset validation."


