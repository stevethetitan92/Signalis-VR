using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly List<MeshRenderer> prodArcs=new List<MeshRenderer>();
  private Material prodArcMaterial,prodGlowMaterial,prodHandMaterial;
  private readonly List<MeshRenderer> prodGlows=new List<MeshRenderer>(),prodSparks=new List<MeshRenderer>();
  private Mesh prodHandMesh;
  private MeshRenderer prodHandRenderer;
  private float prodFadeUntil;
  private class ProdFragment {public bool settled;public GameObject root;public Mesh mesh;public BoxCollider probe;public Vector3 velocity,spin,gravity;public float expires;}
  private readonly List<ProdFragment> prodFragments=new List<ProdFragment>();
  private readonly List<Material> prodBrokenMaterials=new List<Material>();
  private static readonly float[] ProdSpeeds={2.3f,4.1f,6.7f,3.2f,5.3f,8.4f},ProdVibrations={29,43,61,37,53,73},ProdSways={1.7f,2.9f,4.3f,2.2f,3.7f,5.1f},ProdPhases={0,2.1f,4.2f,1.05f,3.15f,5.25f};
  private Vector3 ProdArcPoint(int k,float u,float t){
   // Fixed electrode endpoints with jagged, discretely changing discharges.
   // Smoothly orbiting waves looked like ribbons instead of electricity.
   int tick=(int)(t*30),node=(int)(u*10+.5f);float e=Mathf.Sin((float)Math.PI*u);
   float y=Mathf.Sin(node*73+tick*19+k*31),z=Mathf.Sin(node*37+tick*43+k*17);
   return new Vector3(-.0142f+.0274f*u,e*y*.0015f,.270f+e*z*.0025f);
  }
  private void EnsureProdEffects(){
   if(prodArcMaterial!=null)return;
   var shader=Shader.Find("Unlit/Color");
   prodArcMaterial=new Material(shader);prodArcMaterial.color=new Color(.65f,.95f,1);
   var glowShader=Shader.Find("Sprites/Default");prodGlowMaterial=new Material(glowShader!=null?glowShader:shader);prodGlowMaterial.color=new Color(.1f,.65f,1,.16f);
   var cube=controllerBodies[1].GetComponent<MeshFilter>().sharedMesh;
   for(int k=0;k<6;k++)for(int j=0;j<10;j++){var r=CreateControllerPart(prodRoot,cube,prodArcMaterial,"ElectricalArc",Vector3.zero,Vector3.one);r.enabled=false;prodArcs.Add(r);var g=CreateControllerPart(prodRoot,cube,prodGlowMaterial,"ArcHalo",Vector3.zero,Vector3.one);g.enabled=false;prodGlows.Add(g);}
   for(int k=0;k<6;k++){var r=CreateControllerPart(prodRoot,cube,prodArcMaterial,"ArcSpark",Vector3.zero,Vector3.one*.0016f);r.enabled=false;prodSparks.Add(r);}
  }
  private void ShowProdEffects(){
   EnsureProdEffects();
   float t=Time.time;int tick=(int)(t*30);for(int k=0;k<6;k++)for(int j=0;j<10;j++){
    Vector3 a=ProdArcPoint(k,j/10f,t),b=ProdArcPoint(k,(j+1)/10f,t);var r=prodArcs[k*10+j];
    r.transform.localPosition=(a+b)*.5f;r.transform.localRotation=Quaternion.FromToRotation(Vector3.up,(b-a).normalized);r.transform.localScale=new Vector3(.0006f,(b-a).magnitude,.0006f);r.enabled=(k+tick)%3==0;
    var g=prodGlows[k*10+j];g.transform.localPosition=r.transform.localPosition;g.transform.localRotation=r.transform.localRotation;g.transform.localScale=new Vector3(.0015f,(b-a).magnitude,.0015f);g.enabled=r.enabled;
   }
   for(int k=0;k<6;k++){var r=prodSparks[k];r.transform.localPosition=ProdArcPoint(k,.5f+.48f*Mathf.Sin(t*ProdSpeeds[k]*1.3f+ProdPhases[k]),t);r.enabled=(k+tick)%3==0;}
  }
  private void HideProdEffects(){if(prodHandRenderer!=null)prodHandRenderer.enabled=false;foreach(var list in new[]{prodArcs,prodGlows,prodSparks})foreach(var r in list)if(r!=null)r.enabled=false;}
  private void BeginProdBreakup(){
   prodFadeUntil=Time.unscaledTime+.45f;
   var material=new Material(Shader.Find("Unlit/Color"));material.color=new Color(.025f,.025f,.025f);prodBrokenMaterials.Add(material);
   float[] cuts={-.4f,-.16f,-.06f,.07f,.18f,.4f};
   for(int group=0;group<5;group++){
    var mesh=FractureProdMesh(cuts[group],cuts[group+1]);if(mesh==null)continue;
    var root=new GameObject("SpentProdJaggedPiece");root.transform.SetPositionAndRotation(prodResolved,prodResolvedRotation);root.transform.localScale=Vector3.one*UnitsPerMetre;
    CreateControllerPart(root,mesh,material,"Broken section",Vector3.zero,Vector3.one).enabled=true;
    Bounds bounds=mesh.bounds;
    var probe=root.AddComponent<BoxCollider>();probe.center=bounds.center;probe.size=bounds.size+Vector3.one*.001f;probe.enabled=false;
    var f=new ProdFragment{root=root,mesh=mesh,probe=probe,velocity=prodResolvedRotation*new Vector3((group-2)*.045f,.02f,.02f)*UnitsPerMetre,spin=new Vector3(35+group*13,17-group*9,group*23-40),gravity=controllerTrackingToWorld*Vector3.down*(9.81f*UnitsPerMetre),expires=Time.time+20};prodFragments.Add(f);
   }
  }
  private bool ProdDebrisObstacle(Collider c){return c!=null&&c.enabled&&!c.isTrigger&&(global::PlayerState.player==null||!c.transform.IsChildOf(global::PlayerState.player.transform))&&(prodRoot==null||!c.transform.IsChildOf(prodRoot.transform));}
  private void PollProdDebris(){
   float dt=Math.Min(Time.deltaTime,.05f);int steps=Math.Max(1,(int)Math.Ceiling(dt/.004f));float step=dt/steps;
   for(int i=prodFragments.Count-1;i>=0;i--){var f=prodFragments[i];if(f.root==null||Time.time>=f.expires){if(f.root!=null)UnityEngine.Object.Destroy(f.root);if(f.mesh!=null)UnityEngine.Object.Destroy(f.mesh);prodFragments.RemoveAt(i);continue;}
    if(f.settled)continue;
    for(int s=0;s<steps;s++){
     var tr=f.root.transform;var old=tr.position;var rotation=tr.rotation*Quaternion.Euler(f.spin*step);f.velocity+=f.gravity*step;var delta=f.velocity*step;float distance=delta.magnitude;Vector3 normal=Vector3.zero;
     var centre=old+rotation*(f.probe.center*UnitsPerMetre);var half=f.probe.size*(.5f*UnitsPerMetre);
     foreach(var hit in Physics.BoxCastAll(centre,half,delta.normalized,rotation,distance,-1,QueryTriggerInteraction.Ignore))if(ProdDebrisObstacle(hit.collider)&&hit.distance<distance){distance=Math.Max(0,hit.distance-.001f*UnitsPerMetre);normal=hit.normal;}
     var next=old+delta.normalized*distance;
     for(int pass=0;pass<4;pass++)foreach(var c in Physics.OverlapBox(next+rotation*(f.probe.center*UnitsPerMetre),half,rotation,-1,QueryTriggerInteraction.Ignore)){
      if(!ProdDebrisObstacle(c))continue;Vector3 direction;float depth;if(Physics.ComputePenetration(f.probe,next,rotation,c,c.transform.position,c.transform.rotation,out direction,out depth)){next+=direction*(depth+.001f*UnitsPerMetre);normal=direction;}
     }
     if(normal.sqrMagnitude>.1f){float vn=Vector3.Dot(f.velocity,normal);if(vn<0)f.velocity=(f.velocity-normal*vn)*.65f-normal*vn*.12f;f.spin*=.55f;}
     tr.SetPositionAndRotation(next,rotation);
     if(normal.sqrMagnitude>.1f&&Vector3.Dot(normal,-f.gravity.normalized)>.65f&&f.velocity.magnitude<.08f*UnitsPerMetre&&f.spin.magnitude<5){f.settled=true;break;}
    }
   }
  }
  private void DestroyProdEffects(){
   if(prodSurfaceBake!=null)UnityEngine.Object.Destroy(prodSurfaceBake);prodSurfaceBake=null;prodFaces.Clear();
   HideProdEffects();foreach(var list in new[]{prodArcs,prodGlows,prodSparks})foreach(var r in list)if(r!=null)UnityEngine.Object.Destroy(r.gameObject);if(prodHandRenderer!=null)UnityEngine.Object.Destroy(prodHandRenderer.gameObject);
   foreach(var f in prodFragments){if(f.root!=null)UnityEngine.Object.Destroy(f.root);if(f.mesh!=null)UnityEngine.Object.Destroy(f.mesh);}prodFragments.Clear();foreach(var m in prodBrokenMaterials)if(m!=null)UnityEngine.Object.Destroy(m);prodBrokenMaterials.Clear();
   if(prodHandMesh!=null)UnityEngine.Object.Destroy(prodHandMesh);if(prodHandMaterial!=null)UnityEngine.Object.Destroy(prodHandMaterial);if(prodArcMaterial!=null)UnityEngine.Object.Destroy(prodArcMaterial);
   prodHandMesh=null;prodHandRenderer=null;prodHandMaterial=null;prodArcMaterial=null;prodArcs.Clear();prodGlows.Clear();prodSparks.Clear();if(prodGlowMaterial!=null)UnityEngine.Object.Destroy(prodGlowMaterial);prodGlowMaterial=null;if(prodProbe!=null)UnityEngine.Object.Destroy(prodProbe);prodProbe=null;prodPoseValid=false;prodFadeUntil=0;
  }
 }
}
