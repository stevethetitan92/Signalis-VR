$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'ShotgunAim.cs') -Raw
$start=$source.IndexOf(' internal sealed class ShotgunAimSnapshot')
$actual='namespace SignalisVrTracking {'+$source.Substring($start)
$stub=@'
using System;using UnityEngine;using N=System.Numerics;
namespace UnityEngine {
 public struct Vector3 {
  public N.Vector3 v;public Vector3(float x,float y,float z){v=new N.Vector3(x,y,z);}
  public float magnitude {get{return v.Length();}}
  public static Vector3 operator +(Vector3 a,Vector3 b){return new Vector3{v=a.v+b.v};}
  public static Vector3 operator -(Vector3 a,Vector3 b){return new Vector3{v=a.v-b.v};}
 }
 public struct Quaternion {
  public N.Quaternion v;public static Quaternion Inverse(Quaternion q){return new Quaternion{v=N.Quaternion.Inverse(q.v)};}
  public static Quaternion operator *(Quaternion a,Quaternion b){return new Quaternion{v=a.v*b.v};}
  public static Vector3 operator *(Quaternion q,Vector3 p){return new Vector3{v=N.Vector3.Transform(p.v,q.v)};}
 }
 public class Transform {
  public Vector3 position;public Quaternion rotation=new Quaternion{v=N.Quaternion.Identity};
  public Transform parent;public bool IsChildOf(Transform other){return this==other||(parent!=null&&parent.IsChildOf(other));}
 }
 public struct Bounds {public Vector3 center,extents;}
 public class GameObject {}
 public class Collider {public Transform transform=new Transform();public Bounds bounds;public bool overlaps,eligible;public GameObject gameObject=new GameObject();}
 public enum QueryTriggerInteraction {Collide}
 public static class Physics {
  public static Collider[] candidates;public static Vector3 queryCenter,exactPosition;public static Quaternion exactRotation;
  public static Collider[] OverlapSphere(Vector3 center,float radius,int mask,QueryTriggerInteraction triggers){queryCenter=center;return candidates;}
  public static bool ComputePenetration(Collider a,Vector3 p,Quaternion q,Collider b,Vector3 bp,Quaternion bq,out Vector3 d,out float distance){exactPosition=p;exactRotation=q;d=new Vector3();distance=1;return b.overlaps;}
 }
}
namespace Il2CppSystem.Collections.Generic {public class List<T>:System.Collections.Generic.List<T>{}}
public class PlayerAttack {public static Il2CppSystem.Collections.Generic.List<GameObject> shotgunTargets;}
public class ShotgunCone {
 public bool fail;
 public void OnTriggerStay(Collider c){if(fail)throw new Exception("Injected callback failure");if(c.eligible&&!PlayerAttack.shotgunTargets.Contains(c.gameObject))PlayerAttack.shotgunTargets.Add(c.gameObject);}
}
'@
$test=@'
public static class ShotgunTests {
 static void Vec(Vector3 a,Vector3 b){if(N.Vector3.Distance(a.v,b.v)>.0001f)throw new Exception("Incorrect cone projection");}
 public static string Run(){
  var root=new Transform();var muzzle=new Transform{position=new Vector3(2,3,4)};
  var cone=new ShotgunCone();var shape=new Collider{bounds=new Bounds{center=new Vector3(2,3,7),extents=new Vector3(1,1,3)}};shape.transform.position=new Vector3(2,3,5);
  var hit=new Collider{overlaps=true,eligible=true};var miss=new Collider{overlaps=false,eligible=true};var wrongTag=new Collider{overlaps=true,eligible=false};var self=new Collider{overlaps=true,eligible=true};self.transform.parent=root;
  Physics.candidates=new[]{shape,hit,hit,miss,wrongTag,self};
  var original=new Il2CppSystem.Collections.Generic.List<GameObject>();original.Add(new GameObject());PlayerAttack.shotgunTargets=original;
  var snapshot=new SignalisVrTracking.ShotgunAimSnapshot(cone,shape,muzzle,root);
  muzzle.position=new Vector3(10,20,30);muzzle.rotation=new Quaternion{v=N.Quaternion.CreateFromAxisAngle(N.Vector3.UnitY,(float)Math.PI/2)};
  var restore=snapshot.Apply();
  Vec(Physics.queryCenter,new Vector3(13,20,30));Vec(Physics.exactPosition,new Vector3(11,20,30));
  if(Math.Abs(N.Quaternion.Dot(Physics.exactRotation.v,muzzle.rotation.v))<.9999f)throw new Exception("Wrong spread rotation");
  if(PlayerAttack.shotgunTargets==original||PlayerAttack.shotgunTargets.Count!=1||PlayerAttack.shotgunTargets[0]!=hit.gameObject)throw new Exception("Overlap/tag/dedup/self exclusion failed");
  restore();if(PlayerAttack.shotgunTargets!=original||original.Count!=1)throw new Exception("Original target list lost");
  cone.fail=true;bool threw=false;try{snapshot.Apply();}catch{threw=true;}
  if(!threw||PlayerAttack.shotgunTargets!=original)throw new Exception("Failure did not restore original list");
  return "PASS: production shotgun snapshot mapping, exact-overlap filtering, native eligibility delegation, dedup, self exclusion and target-list restoration on success/failure. Live collider/physics behavior unverified.";
 }
}
'@
Add-Type -TypeDefinition ($stub+$actual+$test)
[ShotgunTests]::Run()
