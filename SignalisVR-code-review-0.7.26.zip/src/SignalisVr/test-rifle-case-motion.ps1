$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'RifleCaseMotion.cs')
foreach($hz in @(30,60,90,144,1000)){
 [single]$velocity=0;[double]$position=0
 for($i=0;$i -lt $hz;$i++){$position += [SignalisVrTracking.RifleCaseMotion]::Step([ref]$velocity,-9.81,1.0/$hz)}
 if([Math]::Abs($position+4.905) -gt .001 -or [Math]::Abs($velocity+9.81) -gt .001){throw 'Gravity/frame-rate regression'}
}
if([SignalisVrTracking.RifleCaseMotion]::LaunchZ(0) -eq [SignalisVrTracking.RifleCaseMotion]::LaunchZ(1)){throw 'Cases have identical launch profiles'}
$decay=[SignalisVrTracking.RifleCaseMotion]::SpinDecay(1)
if($decay -le 0 -or $decay -ge 1){throw 'Spin damping adds energy'}
$e=[SignalisVrTracking.RifleCaseMotion]::Restitution
if($e -le 0 -or $e -ge .3){throw 'Unnatural bounce coefficient'}
'PASS ballistic drop across30-1000Hz, independent launch profiles, spin damping and low restitution. Does not execute Unity contact queries.'
