using System;
using HarmonyLib;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static bool capacityHooksReady,capacityErrorReported;
  private static bool inventory14Slots,capacityWasApplied;
  private static void ApplyInventoryCapacity() {
   if(CalibrationInventoryActive()){global::InventoryManager.maxSlots=50;global::PlayerState.settings.maxInventorySlots=50;return;}
   if(!capacityHooksReady)return;
   if(!inventory14Slots&&!capacityWasApplied)return;
   try {
    var settings=global::PlayerState.settings;if(settings==null)return;
    int slots=InventoryCapacityPolicy.BaseSlots(inventory14Slots,settings.emergencyRequisitionMode);
    settings.maxInventorySlots=slots;
    global::InventoryManager.maxSlots=InventoryCapacityPolicy.Effective(slots,settings.modulesTakeInventorySpace,global::InventoryManager.modules);
    capacityWasApplied=inventory14Slots;
   }catch(Exception ex){if(!capacityErrorReported){capacityErrorReported=true;MelonLogger.Warning("Inventory capacity unavailable: "+ex.Message);}}
  }
  private void InstallInventoryCapacity() {
   if(capacityHooksReady)return;
   try {
    var h=new HarmonyLib.Harmony("signalis.vr.nomarkers.inventory14");
    var apply=new HarmonyMethod(typeof(Tracking),nameof(ApplyInventoryCapacity));
    h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryManager),"Awake",Type.EmptyTypes),prefix:apply,postfix:apply);
    h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryManager),"initializeInventory",Type.EmptyTypes),prefix:apply,postfix:apply);
    // Load hard-codes 6/8, then restores items, then checks overflow. Applying
    // after EACH restored stack is essential: a Load postfix alone is too late.
    foreach(string name in new[]{"AddItem","RemoveItem"})
     h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryManager),name,new[]{typeof(global::AnItem),typeof(int)}),postfix:apply);
    h.Patch(AccessTools.DeclaredMethod(typeof(global::SaveManager),"Load",Type.EmptyTypes),prefix:apply,postfix:apply);
    h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"updateItems",Type.EmptyTypes),prefix:apply);
    h.Patch(AccessTools.DeclaredMethod(typeof(global::InventoryBase),"initializeBox",Type.EmptyTypes),prefix:apply);
    capacityHooksReady=true;ApplyInventoryCapacity();
    MelonLogger.Msg("INVENTORY CHEAT: 14 slots="+inventory14Slots+"; saved toggle in Cheats menu.");
   }catch(Exception ex){hCleanupInventory();MelonLogger.Warning("Inventory expansion unavailable: "+ex.Message);}
  }
  private static void hCleanupInventory(){capacityHooksReady=false;}
 }
}

