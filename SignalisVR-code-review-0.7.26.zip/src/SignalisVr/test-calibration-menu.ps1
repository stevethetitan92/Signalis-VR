$ErrorActionPreference='Stop'
$source=Get-Content "$PSScriptRoot/TestMenuActions.cs" -Raw
$start=$source.IndexOf('  private void ActivateTestMenu(')
$end=$source.IndexOf('  private int TestTemplateScore(')
$methods=$source.Substring($start,$end-$start).Replace('private void','public void')
Add-Type -TypeDefinition (@'
using System; using MelonLoader;
public static class PlayerState {public static int hp=100;}
namespace MelonLoader {public static class MelonLogger {public static void Warning(string s){}}}
public class CalibrationMenuTest {
 public object calibrationRoot; public bool infiniteLife=true,ready=true; public int enters,leaves,saves,done,reports;public string testMenuStatus;
 bool CheatPlayerReady(){return ready;}void SaveModSettings(){saves++;}void EnterCalibrationRoom(){enters++;}void LeaveCalibrationRoom(bool restore){leaves++;}void FinishModMenu(){done++;}void RequestProblemReport(string reason){if(reason!="manual-menu")throw new Exception("report reason");reports++;}
'@+$methods+@'
 public static void Test(){var t=new CalibrationMenuTest();t.ActivateTestMenu(0);if(t.enters!=1||PlayerState.hp!=100)throw new Exception("entry dispatch");t.calibrationRoot=new object();t.ActivateTestMenu(0);if(t.leaves!=1)throw new Exception("leave dispatch");t.ActivateTestMenu(1);if(t.reports!=1||t.done!=0)throw new Exception("report dispatch");t.ActivateTestMenu(2);if(t.done!=1)throw new Exception("done dispatch");foreach(int hp in new[]{1,25,100}){PlayerState.hp=hp;t.infiniteLife=true;t.SetTestHalfHealth();if(PlayerState.hp!=50||t.infiniteLife)throw new Exception("half health");}PlayerState.hp=0;t.SetTestHalfHealth();if(PlayerState.hp!=0)throw new Exception("dead revived");}
}
'@)
[CalibrationMenuTest]::Test()
$room=Get-Content "$PSScriptRoot/CalibrationRoom.cs" -Raw
if($room -notmatch 'SpawnTestEnemy\(\);SetTestHalfHealth\(\);'){throw 'Entry health call absent'}
$poll=$room.Substring($room.IndexOf('  private void PollCalibrationRoom('))
if($poll.Contains('SetTestHalfHealth();')){throw 'Health reset outside entry'}
$ui=Get-Content "$PSScriptRoot/ControlsTab.cs" -Raw
if($ui.Contains('Set Health to 50%') -or $ui.Contains('Spawn Basic Enemy')){throw 'Removed row still present'}
'PASS actual Test menu dispatch and half-health method; entry-only call, removed rows, no per-frame reset. Native room entry unverified.'

