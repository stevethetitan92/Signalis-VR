$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'RoomDoorPoint.cs')
$cases=@(@(-10,4,0,4),@(20,4,10,4),@(3,-12,3,0),@(3,16,3,8),@(1,4,0,4),@(9,4,10,4),@(5,1,5,0),@(5,7,5,8),@(-4,12,0,8),@(15,-2,10,0))
foreach($case in $cases){$u=0.0;$v=0.0;[SignalisVrTracking.RoomDoorPoint]::Edge($case[0],$case[1],0,0,10,8,[ref]$u,[ref]$v);if($u -ne $case[2] -or $v -ne $case[3]){throw "Wrong wall anchor: $case -> $u,$v"}}
$u=0.0;$v=0.0;[SignalisVrTracking.RoomDoorPoint]::Edge(3,4,10,10,0,0,[ref]$u,[ref]$v);if($u -ne 3 -or $v -ne 4){throw 'Unavailable artwork must retain native point'}
$src=Get-Content (Join-Path $PSScriptRoot 'ModHud.cs') -Raw
if(!$src.Contains('roomLow=Vector2.Min(roomLow,point)') -or !$src.Contains('RoomDoorPoint.Edge(xy.x,xy.y,doorLow.x,doorLow.y,doorHigh.x,doorHigh.y')){throw 'Must use owning room bounds in the same map basis'}
'PASS wall anchors: four outside walls, four inner offsets, outside corners and unavailable artwork. Bounding outline approximation; native artwork/headset fit unverified.'
