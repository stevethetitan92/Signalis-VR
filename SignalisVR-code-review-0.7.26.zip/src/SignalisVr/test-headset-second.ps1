$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ReloadContactPolicy.cs'),(Join-Path $PSScriptRoot 'ManualReloadPolicy.cs')
foreach($hz in 30,72,90,120){
 $p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.PressB(0,$false,$true,$false)|Out-Null
 $p.Tick(.1,$true,$true,$true,$false)|Out-Null
 $loaded=$false
 for($i=0;$i -lt $hz;$i++){
  $along=[float](-.1 + .22*$i/$hz)
  $capture=[SignalisVrTracking.ReloadContactPolicy]::PistolCapture(.015,$along)
  $well=$capture -and [SignalisVrTracking.ReloadContactPolicy]::PistolSeated($along)
  if($capture -and [SignalisVrTracking.ReloadContactPolicy]::Slide($along) -gt 0){throw 'Magazine penetrated past seat'}
  if($p.Tick((.2+$i/$hz),$true,$true,$false,$well)){$loaded=$true;break}
 }
 if(!$loaded){throw "Pistol overshoot failed at $hz Hz"}
}
foreach($along in @([float]::NaN,[float]::PositiveInfinity,-.3,.3)){if([SignalisVrTracking.ReloadContactPolicy]::PistolCapture(.01,$along)){throw 'Invalid insertion accepted'}}
$p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.PressB(0,$false,$true,$true)|Out-Null
$p.Tick(.1,$true,$true,$true,$false)|Out-Null
$p.Tick(.2,$true,$true,$false,$true)|Out-Null
$p.Tick(.4,$true,$true,$false,$true)|Out-Null
$p.Tick(.5,$true,$true,$false,$false,$true,.12)|Out-Null
$p.Tick(.6,$true,$true,$false,$false,$false,.13)|Out-Null
if($p.Tick(.7,$true,$false,$false,$false,$false,.13)){throw 'Incomplete rack completed'}
$p.Tick(.8,$true,$true,$false,$false,$true,.12)|Out-Null
$p.Tick(.9,$true,$true,$false,$false,$false,.16)|Out-Null
if(!$p.Tick(1,$true,$false,$false,$false,$false,.12)){throw 'Rack peak lost when handle returned before release'}
'PASS continuous pistol insertion with overshoot at 30/72/90/120Hz, seating clamp, invalid positions and rack retry/peak retention.'
$s=Get-Content (Join-Path $PSScriptRoot 'SmgStats.cs') -Raw
$s=$s.Substring(0,$s.IndexOf('  private void InstallSmgStats(')).Replace('using HarmonyLib;','')
$stubs=@'
namespace UnityEngine {public static class Time {public static int frameCount=10;}}
public class Items {public enum itemlist {Pistol,SMG,Revolver,Rifle,Shotgun,FlareGun}}
public class AnItem {public Items.itemlist _item;}
public class AnWeapon {public AnItem parentItem=new AnItem();public int magAmmo=6,MagSize=6,burstSize;public bool fullAuto;public float burstSpeed=.1f;}
public static class InventoryManager {public static AnWeapon EquippedWeapon;public static System.Collections.Generic.Dictionary<Items.itemlist,AnWeapon> allWeapons;}
public class PlayerAttack {public static PlayerAttack instance=new PlayerAttack();public static int burst;public float timer;public AnWeapon weapon;public bool aiming=true,attack=true;}
namespace SignalisVrTracking { public sealed partial class Tracking {
 private static Tracking weaponOwner;private bool manualReloadEnabled=true,vr=true,ready=true,blocked;private int manualPulseUntil=-1,additionalPulse=-1;private QuestFrame questFrame;
 private bool ProdVrMode(){return vr;}private bool ControllerWeaponReady(){return ready;}private bool ManualReloadBlocksAttack(){return blocked;}
 private struct QuestFrame {public int buttons;}
 public static void CheckFiring(){var q=new Tracking();weaponOwner=q;var w=new AnWeapon();InventoryManager.EquippedWeapon=w;
 foreach(Items.itemlist id in System.Enum.GetValues(typeof(Items.itemlist))){w.parentItem._item=id;if(ManualNativeReloadGuard())throw new System.Exception("Unrequested native reload "+id);}
 w.parentItem._item=Items.itemlist.Pistol;q.manualPulseUntil=11;if(ManualNativeReloadGuard())throw new System.Exception("Legacy pistol pulse bypassed physical reload");UnityEngine.Time.frameCount=12;if(ManualNativeReloadGuard())throw new System.Exception("Expired pulse accepted");
 w.parentItem._item=Items.itemlist.SMG;q.additionalPulse=12;if(ManualNativeReloadGuard())throw new System.Exception("Legacy SMG pulse bypassed physical reload");q.additionalPulse=-1;if(q.manualPulseUntil<0||q.additionalPulse!=-1)throw new System.Exception("Test pulse setup failed");
 PlayerAttack.instance.timer=.1f;q.questFrame.buttons=64;for(int i=0;i<200;i++){PlayerAttack.instance.timer-=.01f;PlayerAttack.burst=0;ApplySmgStats();if(PlayerAttack.burst!=1||PlayerAttack.instance.timer<.1f)throw new System.Exception("Held automatic cycle stopped");}
 q.questFrame.buttons=0;ApplySmgStats();if(PlayerAttack.burst!=0)throw new System.Exception("Release left queued shot");
 q.questFrame.buttons=64;w.magAmmo=0;ApplySmgStats();if(PlayerAttack.burst!=0||w.magAmmo!=0)throw new System.Exception("Empty gun fired or refilled");
 w.magAmmo=6;q.blocked=true;ApplySmgStats();if(PlayerAttack.burst!=0)throw new System.Exception("Reload firing allowed");q.blocked=false;q.ready=false;ApplySmgStats();if(PlayerAttack.burst!=0)throw new System.Exception("Unavailable controls fired");
 q.vr=false;if(!ManualNativeReloadGuard())throw new System.Exception("Desktop reload blocked");q.vr=true;q.manualReloadEnabled=false;if(!ManualNativeReloadGuard())throw new System.Exception("Native reload mode blocked");
 }
}}
'@
Add-Type -TypeDefinition ($s+'}}'+$stubs)
[SignalisVrTracking.Tracking]::CheckFiring()
'PASS actual native reload gate for six guns, legacy/expired pulse rejection, 200 held SMG cycles and native burst-window retention, release, empty, busy and desktop/native fallback.'
