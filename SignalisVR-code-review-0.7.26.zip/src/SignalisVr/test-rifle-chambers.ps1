$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'RifleChambers.cs') -Raw
$a=$s.IndexOf(' public sealed class RifleChamberPolicy');$b=$s.IndexOf(' public sealed partial class Tracking')
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$s.Substring($a,$b-$a)+'}')
$p=[SignalisVrTracking.RifleChamberPolicy]::new()
if(!$p.Insert(1) -or $p.Insert(1) -or $p.Mask -ne 2){throw 'Lower chamber occupancy failed'}
if($p.Candidate(.018,.001) -ne -1 -or $p.Candidate(.001,.018) -ne 0){throw 'Occupied zone accepted or empty zone rejected'}
if(!$p.Insert(0) -or $p.Count -ne 2){throw 'Upper chamber insertion failed'}
$p.Sync(1);if($p.Mask -ne 2 -or $p.Spent -ne 1){throw 'First fired case mapping incorrect'}
$p.Ejected();if($p.Spent -ne 0 -or $p.Mask -ne 2){throw 'Unfired round ejected'}
$p.Sync(0);if($p.Spent -ne 2){throw 'Second fired case mapping incorrect'}
$p.Reset();if($p.Spent -ne 0 -or $p.Mask -ne 0){throw 'Weapon reset failed'}
if($p.Candidate(.1,.1) -ne -1){throw 'Remote insertion accepted'}
'PASS either chamber first, occupied rejection, independent fired/loaded masks, spent-only ejection and reset.'
