$ErrorActionPreference='Stop'
# Machete functionality was explicitly removed in 0.7.21; retain its removal regression.
& "$PSScriptRoot/test-no-machete.ps1"
