$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'HeldModules.cs') -Raw
$policy=$s.Substring($s.IndexOf(' public static class ReceiverTuning'));$policy=$policy.Substring(0,$policy.IndexOf(' public sealed partial class Tracking'))
$n=Get-Content (Join-Path $PSScriptRoot 'ModuleSnapshots.cs') -Raw
$names=$n.Substring($n.IndexOf(' public static class SnapshotNames'));$names=$names.Substring(0,$names.IndexOf(' public sealed partial class Tracking'))
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$policy+$names+'}')
$p=[SignalisVrTracking.ReceiverTuning]
if($p::Turn(81,15,50,250) -ne 82 -or $p::Turn(81,-15,50,250) -ne 80 -or $p::Turn(249.9,15,50,250) -ne 250 -or $p::Turn(50,-15,50,250) -ne 50){throw 'Frequency direction/range'}
if($p::Turn(81,100,50,250) -ne 81 -or $p::Turn(81,[float]::NaN,50,250) -ne 81){throw 'Tracking spike corrupts frequency'}
if([SignalisVrTracking.SnapshotNames]::Caption(1) -ne 'snapshot 001' -or [SignalisVrTracking.SnapshotNames]::Caption(1000) -ne 'snapshot 1000'){throw 'Snapshot archive numbering'}
foreach($guard in @('radio._frequency=ReceiverTuning.Turn','receiverArrowArmed','receiverKnobHeld','global::RadioManager.moduleInstalled')){if(!$s.Contains($guard)){throw "Missing physical tuning ownership $guard"}}
foreach($guard in @('global::SProgress.SetString(SnapshotSaveKey','Path.GetFileName(file)!=file','read.Remove(pair.Value)','ImageConversion.EncodeToPNG','snapshotQueued=false','SnapshotContent','snapshotBooks.ContainsKey','preserveAspect=true')){if(!$n.Contains($guard)){throw "Missing archive protection $guard"}}
'PASS frequency direction/clamp/tracking-spike rejection, snapshot numbering and save-bound archive/input integration. Native hooks, Memory display and graphics remain runtime-unverified.'
