using System;
using System.Collections.Generic;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private void CloseHandSurface(Mesh mesh) {
   var old=mesh.vertices;var positions=new List<Vector3>();var normals=new List<Vector3>();var uv=new List<Vector2>();var weights=new List<BoneWeight>();
   var oldNormals=mesh.normals;var oldUv=mesh.uv;var oldWeights=mesh.boneWeights;
   var oldTangents=mesh.tangents;var oldColors=mesh.colors;var oldUv2=mesh.uv2;
   var capSources=new List<int>();
   var xyz=new float[old.Length*3];var all=new List<int>();var sub=new List<int[]>();
   for(int i=0;i<old.Length;i++){positions.Add(old[i]);normals.Add(oldNormals.Length==old.Length?oldNormals[i]:Vector3.up);uv.Add(oldUv.Length==old.Length?oldUv[i]:Vector2.zero);weights.Add(oldWeights[i]);xyz[i*3]=old[i].x;xyz[i*3+1]=old[i].y;xyz[i*3+2]=old[i].z;}
   for(int s=0;s<mesh.subMeshCount;s++){var raw=mesh.GetTriangles(s);var t=new int[raw.Length];for(int i=0;i<t.Length;i++)t[i]=raw[i];sub.Add(t);all.AddRange(t);}
   var caps=new List<int>();var loops=HandSurfaceTopology.BoundaryLoops(xyz,all.ToArray());
   foreach(var ring in loops) {
    Vector3 center=Vector3.zero,normal=Vector3.zero;Vector2 texture=Vector2.zero;var influence=new Dictionary<int,float>();
    foreach(int i in ring){center+=positions[i];normal+=normals[i];texture+=uv[i];var w=weights[i];AddCapWeight(influence,w.boneIndex0,w.weight0);AddCapWeight(influence,w.boneIndex1,w.weight1);AddCapWeight(influence,w.boneIndex2,w.weight2);AddCapWeight(influence,w.boneIndex3,w.weight3);}
    int v=positions.Count;positions.Add(center/ring.Length);normals.Add(normal.normalized);uv.Add(texture/ring.Length);
    capSources.Add(ring[0]);
    var sorted=new List<KeyValuePair<int,float>>(influence);sorted.Sort((a,b)=>b.Value.CompareTo(a.Value));
    float sum=0;for(int i=0;i<Math.Min(4,sorted.Count);i++)sum+=sorted[i].Value;
    var weight=new BoneWeight();if(sorted.Count>0){weight.boneIndex0=sorted[0].Key;weight.weight0=sorted[0].Value/sum;}if(sorted.Count>1){weight.boneIndex1=sorted[1].Key;weight.weight1=sorted[1].Value/sum;}if(sorted.Count>2){weight.boneIndex2=sorted[2].Key;weight.weight2=sorted[2].Value/sum;}if(sorted.Count>3){weight.boneIndex3=sorted[3].Key;weight.weight3=sorted[3].Value/sum;}weights.Add(weight);
    for(int i=0;i<ring.Length;i++){caps.Add(ring[i]);caps.Add(ring[(i+1)%ring.Length]);caps.Add(v);}
   }
   // Closed internal glove volumes fill the hollow palm/finger segments exposed
   // when curling. Native textured surfaces stay on the outside.
   var core=new List<int>();var used=new HashSet<int>(all);var groups=new Dictionary<int,List<int>>();
   foreach(int i in used){var w=weights[i];int b=w.boneIndex0;float max=w.weight0;if(w.weight1>max){b=w.boneIndex1;max=w.weight1;}if(w.weight2>max){b=w.boneIndex2;max=w.weight2;}if(w.weight3>max)b=w.boneIndex3;if(!groups.ContainsKey(b))groups[b]=new List<int>();groups[b].Add(i);}
   var bind=mesh.bindposes;
   foreach(var group in groups) {
    if(group.Value.Count<4)continue;int bone=group.Key;var transform=bind[bone];var inverse=transform.inverse;
    Vector3 min=transform.MultiplyPoint3x4(positions[group.Value[0]]),max=min;
    foreach(int i in group.Value){var p=transform.MultiplyPoint3x4(positions[i]);min=Vector3.Min(min,p);max=Vector3.Max(max,p);}
    var center=(min+max)*.5f;var half=(max-min)*.5f*.92f;
    float thickness=Math.Max(half.x,Math.Max(half.y,half.z))*.12f;
    if(thickness<.0001f)continue;
    half=new Vector3(Math.Max(half.x,thickness),Math.Max(half.y,thickness),Math.Max(half.z,thickness));
    int start=positions.Count;
    for(int c=0;c<8;c++){
     var offset=new Vector3((c&1)==0?-half.x:half.x,(c&2)==0?-half.y:half.y,(c&4)==0?-half.z:half.z);
     positions.Add(inverse.MultiplyPoint3x4(center+offset));normals.Add(inverse.MultiplyVector(offset.normalized).normalized);uv.Add(Vector2.zero);
     weights.Add(new BoneWeight{boneIndex0=bone,weight0=1});capSources.Add(group.Value[0]);
    }
    int[] faces={0,2,3,0,3,1,4,5,7,4,7,6,0,1,5,0,5,4,2,6,7,2,7,3,0,4,6,0,6,2,1,3,7,1,7,5};
    foreach(int i in faces)core.Add(start+i);
   }
   mesh.vertices=positions.ToArray();mesh.normals=normals.ToArray();mesh.uv=uv.ToArray();mesh.boneWeights=weights.ToArray();
   if(oldTangents.Length==old.Length){var a=new Vector4[positions.Count];for(int i=0;i<old.Length;i++)a[i]=oldTangents[i];for(int i=0;i<capSources.Count;i++)a[old.Length+i]=oldTangents[capSources[i]];mesh.tangents=a;}
   if(oldColors.Length==old.Length){var a=new Color[positions.Count];for(int i=0;i<old.Length;i++)a[i]=oldColors[i];for(int i=0;i<capSources.Count;i++)a[old.Length+i]=oldColors[capSources[i]];mesh.colors=a;}
   if(oldUv2.Length==old.Length){var a=new Vector2[positions.Count];for(int i=0;i<old.Length;i++)a[i]=oldUv2[i];for(int i=0;i<capSources.Count;i++)a[old.Length+i]=oldUv2[capSources[i]];mesh.uv2=a;}
   // Preserve UVs/materials on native faces; new wrist caps use interpolated UVs.
   for(int s=0;s<sub.Count;s++){var indices=new List<int>(sub[s]);if(s==0)indices.AddRange(caps);mesh.SetTriangles(HandSurfaceTopology.DoubleSided(indices.ToArray()),s);}
   mesh.subMeshCount=sub.Count+1;mesh.SetTriangles(HandSurfaceTopology.DoubleSided(core.ToArray()),sub.Count);
   mesh.RecalculateBounds();MelonLogger.Msg("HAND SURFACE: double-sided hand; closed boundary loops="+loops.Count+" cap triangles="+caps.Count/3+" solid core triangles="+core.Count/3);
  }
  private static void AddCapWeight(Dictionary<int,float> weights,int bone,float value){if(value<=0)return;float old;weights.TryGetValue(bone,out old);weights[bone]=old+value;}
 }
}

