$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'TraceFileSink.cs') -Raw
$test=@'
namespace SignalisVrTracking {public static class SinkTest {
 public static void Run(string path) {
  var sink=new TraceFileSink(path,"# test");
  var native=new double[20];var managed=new double[20];native[0]=2;native[19]=777;managed[0]=10;managed[19]=777;
  if(!sink.Enqueue(native,1,managed,1,"# status"))throw new System.Exception("First batch rejected");
  native[19]=managed[19]=999; // Queued rows must own a copy, not caller's mutable arrays.
  if(!sink.Finish(5000))throw new System.Exception("Writer did not drain");
  if(sink.Error!=null)throw new System.Exception(sink.Error);
  string data=System.IO.File.ReadAllText(path);
  if(!data.Contains("native,2,")||!data.Contains("unity,10,")||!data.Contains(",777")||data.Contains(",999"))throw new System.Exception("Batch ownership/copy failed");
  if(!data.Contains("# complete droppedBatches=0"))throw new System.Exception("Missing final drain");
  if(sink.Enqueue(native,1,managed,1,"late")||sink.Dropped!=1)throw new System.Exception("Completed sink accepted write");
 }
}}
'@
Add-Type ($source+$test)
$file=Join-Path $PSScriptRoot 'trace-sink-test.tmp'
try {[SignalisVrTracking.SinkTest]::Run($file);'PASS: background writer copies mutable buffers, drains both origins, preserves shared IDs, counts rejected batches.'}
finally {if(Test-Path $file){Remove-Item -LiteralPath $file}}
