using System;
using HarmonyLib;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private static bool infiniteLife,infiniteAmmo,infiniteStunProd,instantKill,gameplayCheatHooksReady;
  private static int cheatDamageReports,cheatAmmoReports;
  private static bool CheatPlayerReady(){return global::PlayerState.player!=null&&!global::PlayerState.noplayer&&!global::PlayerState.gameOver;}
  private static bool BlockCheatDamage(int __0) {
   if(!gameplayCheatHooksReady||!infiniteLife||!CheatPlayerReady()||__0<=0)return true;
   if(cheatDamageReports++<8)MelonLogger.Msg("INFINITE LIFE: native incoming damage blocked: "+__0);
   return false;
  }
  private static void FillCheatMagazine() {
   if(CalibrationInventoryActive()||(weaponOwner!=null&&weaponOwner.manualReloadEnabled&&weaponOwner.ProdVrMode()))return;
   if(!gameplayCheatHooksReady||!infiniteAmmo||!CheatPlayerReady())return;
   var w=global::InventoryManager.EquippedWeapon;
   if(w==null||w.parentItem==null||w.MagSize<=0)return;
   switch(w.parentItem._item) {
    case global::Items.itemlist.Pistol:case global::Items.itemlist.Revolver:
    case global::Items.itemlist.Shotgun:case global::Items.itemlist.Rifle:
    case global::Items.itemlist.FlareGun:case global::Items.itemlist.SMG:break;
    default:return;
   }
   if(w.magAmmo!=w.MagSize) {
    w.magAmmo=w.MagSize;
    if(cheatAmmoReports++<8)MelonLogger.Msg("INFINITE AMMO: native magazine replenished: "+w.parentItem._item+"="+w.magAmmo);
   }
  }
  private static void ApplyGameplayCheats() {
   if(!gameplayCheatHooksReady||(!infiniteLife&&!infiniteAmmo)||!CheatPlayerReady())return;
   if(infiniteLife&&global::PlayerState.hp<100&&!global::PlayerState.cutscene)global::PlayerState.hp=100;
   FillCheatMagazine();
  }
  private static void InstantKillEnemy(global::EnemyController __instance) {
   if(!gameplayCheatHooksReady||!instantKill||!CheatPlayerReady()||__instance==null||__instance.hitbox==null)return;
   // The float arguments are effect probabilities, NOT damage. Native hit
   // callers already adjust Hitbox.HP; leave native death handling in control.
   __instance.hitbox.HP=0;
  }
  private void InstallGameplayCheats() {
   if(gameplayCheatHooksReady)return;
   try {
    var h=new HarmonyLib.Harmony("signalis.vr.nomarkers.lifeammo");
    h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerState),"damagePlayer",new[]{typeof(int),typeof(UnityEngine.Vector2)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(BlockCheatDamage)));
    var fill=new HarmonyMethod(typeof(Tracking),nameof(FillCheatMagazine));
    // ReadyForAttack checks ammo before calling RaycastShot, whose final native
    // instruction decrements magAmmo. Cover both sides, including an empty gun.
    h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"ReadyForAttack",Type.EmptyTypes),prefix:fill);
    h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"RaycastShot",Type.EmptyTypes),postfix:fill);
    h.Patch(AccessTools.DeclaredMethod(typeof(global::PlayerAttack),"RaycastShot",Type.EmptyTypes),postfix:new HarmonyMethod(typeof(Tracking),nameof(ShotgunFired)));
    h.Patch(AccessTools.DeclaredMethod(typeof(global::EnemyController),"TakeDamage",new[]{typeof(float),typeof(float),typeof(float),typeof(bool)}),prefix:new HarmonyMethod(typeof(Tracking),nameof(InstantKillEnemy)));
    gameplayCheatHooksReady=true;
    MelonLogger.Msg("CHEATS: native damage/shot hooks installed; life="+infiniteLife+" ammo="+infiniteAmmo);
   }catch(Exception ex){gameplayCheatHooksReady=false;MelonLogger.Warning("Life/ammo cheats unavailable: "+ex.Message);}
  }
 }
}



