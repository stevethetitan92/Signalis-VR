// Software test harness only. Not linked into the delivered mod.
using System;
using System.Collections.Generic;
using System.Linq;
namespace UnityEngine
{
    public class Object
    {
        private static int nextId;
        private readonly int id = ++nextId;
        public int GetInstanceID() { return id; }
    }
    public class Component : Object
    {
        public Transform transform;
        public T[] GetComponentsInChildren<T>(bool inactive) where T : Component
        { return transform.Walk<T>().ToArray(); }
    }
    public class Transform : Component
    {
        public string name;
        public bool active = true;
        public readonly List<Component> components = new List<Component>();
        public readonly List<Transform> children = new List<Transform>();
        public Transform(string n) { name = n; transform = this; components.Add(this); }
        public T Attach<T>(T c) where T : Component { c.transform = this; components.Add(c); return c; }
        public IEnumerable<T> Walk<T>() where T : Component
        {
            foreach (var c in components) if (c is T) yield return (T)c;
            foreach (var t in children) foreach (var c in t.Walk<T>()) yield return c;
        }
    }
    public class Renderer : Component
    { public bool forceRenderingOff; public bool enabled = true; }
    public class SpriteRenderer : Renderer { }
    public class Camera : Component
    {
        public sealed class CameraCallback
        {
            public Action<Camera> action;
            public static implicit operator CameraCallback(Action<Camera> a) { return new CameraCallback { action = a }; }
            public static CameraCallback operator +(CameraCallback a, CameraCallback b)
            { return (Action<Camera>)Delegate.Combine(a == null ? null : a.action, b.action); }
        }
        public static CameraCallback onPreCull;
        public static void Render() { if (onPreCull != null) onPreCull.action(new Camera()); }
    }
    public static class Time { public static int frameCount; public static float realtimeSinceStartup; }
    public static class Resources
    {
        public static int searches;
        public static readonly List<Object> objects = new List<Object>();
        public static T[] FindObjectsOfTypeAll<T>() { searches++; return objects.OfType<T>().ToArray(); }
    }
}
public class DoorInteractionPopup : UnityEngine.Component
{ public UnityEngine.SpriteRenderer block, bar; public bool enabled = true; public int interactions; }
public class Ladder : UnityEngine.Component
{ public UnityEngine.SpriteRenderer block, bar; public bool enabled = true; public int interactions; }
namespace MelonLoader
{
    public static class MelonLogger
    { public static int warnings; public static void Warning(string s) { warnings++; } }
}
namespace SignalisVrTracking
{
    public static class MarkerSuppressionTests
    {
        private static int checks;
        private static void Check(bool value, string message)
        { checks++; if (!value) throw new Exception(message); }
        private static UnityEngine.SpriteRenderer Sprite(UnityEngine.Transform root)
        { return root.Attach(new UnityEngine.SpriteRenderer()); }
        public static string Run()
        {
            var doorRoot = new UnityEngine.Transform("Door Icon E") { active = false };
            var door = doorRoot.Attach(new DoorInteractionPopup());
            door.block = Sprite(doorRoot); door.block.enabled = false;
            var labelRoot = new UnityEngine.Transform("nested label"); doorRoot.children.Add(labelRoot);
            door.bar = Sprite(labelRoot);
            var extraLabel = labelRoot.Attach(new UnityEngine.Renderer());
            var ladderRoot = new UnityEngine.Transform("Ladder");
            var ladder = ladderRoot.Attach(new Ladder());
            var renamed = new UnityEngine.Transform("renamed marker root");
            ladder.block = Sprite(renamed); ladder.bar = Sprite(renamed);
            var icon = new UnityEngine.Transform("Ladder Icon"); ladderRoot.children.Add(icon);
            var extraLadderLabel = Sprite(icon);
            var geometry = ladderRoot.Attach(new UnityEngine.Renderer());
            var objectPrompt = Sprite(new UnityEngine.Transform("Interaction_inspect"));
            var bookPrompt = Sprite(new UnityEngine.Transform("Book"));
            UnityEngine.Resources.objects.Add(door); UnityEngine.Resources.objects.Add(ladder);
            int otherCallback = 0;
            UnityEngine.Camera.onPreCull = (Action<UnityEngine.Camera>)(c => otherCallback++);
            MarkerSuppression.Install(); MarkerSuppression.Install();
            UnityEngine.Camera.Render(); // Desktop, no VR Tracking instance or stage.
            Check(otherCallback == 1, "Existing camera callback lost");
            Check(door.block.forceRenderingOff && door.bar.forceRenderingOff, "Inactive door base/label visible");
            Check(extraLabel.forceRenderingOff, "Nested door label visible");
            Check(ladder.block.forceRenderingOff && ladder.bar.forceRenderingOff, "Renamed ladder artwork visible");
            Check(extraLadderLabel.forceRenderingOff, "Additional ladder label visible");
            Check(!geometry.forceRenderingOff, "Ladder physical geometry hidden");
            Check(!objectPrompt.forceRenderingOff && !bookPrompt.forceRenderingOff, "Object prompt hidden");
            Check(!door.block.enabled && door.bar.enabled, "Renderer enabled state changed");
            Check(door.enabled && ladder.enabled && !doorRoot.active, "Controller/active state changed");
            door.interactions++; ladder.interactions++;
            Check(door.interactions == 1 && ladder.interactions == 1, "Interaction state changed");
            door.block.enabled = true; doorRoot.active = true;
            UnityEngine.Camera.Render(); // Left eye, same frame.
            Check(door.block.forceRenderingOff, "Popup reactivation revealed artwork");
            door.bar.forceRenderingOff = false;
            UnityEngine.Camera.Render(); // Right eye must enforce independently.
            Check(door.bar.forceRenderingOff, "Next camera did not reapply veto");
            var spawnedRoot = new UnityEngine.Transform("new scene door");
            var spawned = spawnedRoot.Attach(new DoorInteractionPopup()); spawned.block = Sprite(spawnedRoot);
            UnityEngine.Resources.objects.Add(spawned);
            UnityEngine.Time.frameCount++;
            UnityEngine.Camera.Render();
            Check(spawned.block.forceRenderingOff, "New popup not discovered on next frame");
            MarkerSuppression.EnableRegistry(true);
            UnityEngine.Time.frameCount++; UnityEngine.Camera.Render();
            int searches=UnityEngine.Resources.searches;
            UnityEngine.Time.frameCount++; UnityEngine.Camera.Render();
            Check(UnityEngine.Resources.searches==searches,"Registry still performs global searches each frame");
            var newLabel=Sprite(labelRoot);
            UnityEngine.Time.frameCount++; UnityEngine.Camera.Render();
            Check(newLabel.forceRenderingOff,"New child artwork under registered controller missed");
            var liveRoot=new UnityEngine.Transform("lifecycle spawn");
            var live=liveRoot.Attach(new DoorInteractionPopup());live.block=Sprite(liveRoot);
            UnityEngine.Resources.objects.Add(live);
            MarkerSuppression.RegisterDoor(live);MarkerSuppression.RegisterDoor(live);
            UnityEngine.Camera.Render(); // New registration invalidates even within the same Unity frame.
            Check(live.block.forceRenderingOff,"Lifecycle spawn not suppressed before next camera");
            Check(UnityEngine.Resources.searches==searches,"Registration forced unnecessary global scan");
            var newLadderRoot=new UnityEngine.Transform("new ladder");
            var liveLadder=newLadderRoot.Attach(new Ladder());liveLadder.bar=Sprite(newLadderRoot);
            MarkerSuppression.RegisterLadder(liveLadder);UnityEngine.Resources.objects.Add(liveLadder);
            UnityEngine.Camera.Render();
            Check(liveLadder.bar.forceRenderingOff,"Lifecycle ladder missed");
            var inactiveRoot=new UnityEngine.Transform("fallback inactive"){active=false};
            var inactive=inactiveRoot.Attach(new DoorInteractionPopup());inactive.block=Sprite(inactiveRoot);
            UnityEngine.Resources.objects.Add(inactive);
            UnityEngine.Time.realtimeSinceStartup=1.1f;UnityEngine.Time.frameCount++;UnityEngine.Camera.Render();
            Check(inactive.block.forceRenderingOff,"Periodic inactive fallback discovery failed");
            Check(UnityEngine.Resources.searches==searches+2,"Fallback scan frequency changed");
            MarkerSuppression.EnableRegistry(false);
            UnityEngine.Time.frameCount++;UnityEngine.Camera.Render();searches=UnityEngine.Resources.searches;
            UnityEngine.Time.frameCount++;UnityEngine.Camera.Render();
            Check(UnityEngine.Resources.searches==searches+2,"Hook failure did not restore per-frame search");
            UnityEngine.Resources.objects.Clear();
            MarkerSuppression.Reset();
            UnityEngine.Camera.Render();
            Check(MelonLoader.MelonLogger.warnings == 0, "Suppression threw");
            return "PASS: " + checks + " software suppression checks (not a Unity/headset runtime test).";
        }
    }
}
