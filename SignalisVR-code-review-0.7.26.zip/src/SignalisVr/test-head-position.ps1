$ErrorActionPreference='Stop'
$stub=@'
using System;
using N=System.Numerics;
namespace UnityEngine {
 public struct Vector3 {
  public N.Vector3 v;
  public Vector3(float x,float y,float z){v=new N.Vector3(x,y,z);}
  public static Vector3 operator +(Vector3 a,Vector3 b){return new Vector3{v=a.v+b.v};}
  public static Vector3 operator -(Vector3 a,Vector3 b){return new Vector3{v=a.v-b.v};}
  public static Vector3 operator *(Vector3 a,float b){return new Vector3{v=a.v*b};}
 }
 public struct Quaternion {
  public N.Quaternion q;
  public static Vector3 operator *(Quaternion a,Vector3 b){return new Vector3{v=N.Vector3.Transform(b.v,a.q)};}
 }
}
'@
$checks=@'
public static class HeadPositionTests {
 static void Check(UnityEngine.Vector3 a,UnityEngine.Vector3 b,string label){if(N.Vector3.Distance(a.v,b.v)>.0001f)throw new Exception(label);}
 public static string Run(){
  var origin=new UnityEngine.Vector3(10,-30,-8);
  var neutral=new UnityEngine.Vector3(2,1.7f,-4);
  var identity=new UnityEngine.Quaternion{q=N.Quaternion.Identity};
  Check(SignalisVrTracking.HeadPosition.Map(origin,identity,neutral,neutral,5),origin,"Standing height should cancel");
  foreach(var d in new[]{new UnityEngine.Vector3(.2f,0,0),new UnityEngine.Vector3(0,.2f,0),new UnityEngine.Vector3(0,0,.2f),new UnityEngine.Vector3(-.2f,-.1f,-.3f)})
   Check(SignalisVrTracking.HeadPosition.Map(origin,identity,neutral+d,neutral,5),origin+d*5,"Physical translation axis/scale");
  var floor=new UnityEngine.Quaternion{q=N.Quaternion.CreateFromAxisAngle(N.Vector3.UnitX,-(float)Math.PI/2)};
  Check(SignalisVrTracking.HeadPosition.Map(origin,floor,neutral+new UnityEngine.Vector3(0,-.2f,0),neutral,5),origin+new UnityEngine.Vector3(0,0,1),"Crouch into game floor");
  var moved=neutral+new UnityEngine.Vector3(.3f,.1f,-.2f);
  Check(SignalisVrTracking.HeadPosition.Map(origin,floor,moved,moved,5),origin,"Recenter clears lean");
  var newRoom=new UnityEngine.Vector3(900,30,20);
  Check(SignalisVrTracking.HeadPosition.Map(newRoom,floor,moved,moved,5),newRoom,"Recenter new camera origin");
  var delta=new UnityEngine.Vector3(.3f,-.2f,.1f);
  for(int angle=0;angle<360;angle+=5){
   var basis=new UnityEngine.Quaternion{q=floor.q*N.Quaternion.CreateFromAxisAngle(N.Vector3.UnitY,angle*(float)Math.PI/180)};
   var result=SignalisVrTracking.HeadPosition.Map(origin,basis,neutral+delta,neutral,5);
   if(Math.Abs(N.Vector3.Distance(result.v,origin.v)-delta.v.Length()*5)>.0001f)throw new Exception("Yaw must not change physical distance");
   Check(SignalisVrTracking.HeadPosition.Map(newRoom,basis,neutral+delta,neutral,5),newRoom+(result-origin),"Scene origin covariance");
   var hand=neutral+new UnityEngine.Vector3(.25f,-.35f,.4f);
   var handWorld=SignalisVrTracking.HeadPosition.Map(origin,basis,hand,neutral,5);
   Check(handWorld-result,basis*((hand-(neutral+delta))*5),"Controller-head relative pose shares scale and origin");
   var newNeutral=neutral+new UnityEngine.Vector3(1,.2f,-.4f);
   Check(SignalisVrTracking.HeadPosition.Map(newRoom,basis,hand,newNeutral,5)-SignalisVrTracking.HeadPosition.Map(newRoom,basis,neutral+delta,newNeutral,5),handWorld-result,"Recenter preserves hand-head displacement");
  }
  return "PASS: actual position helper axes, scale, crouch, recenter, scene origin and 72 rotated distance/covariance cases. No headset claim.";
 }
}
'@
$helper=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'HeadPosition.cs')).Replace('using UnityEngine;','').Replace('Vector3','UnityEngine.Vector3').Replace('Quaternion','UnityEngine.Quaternion')
Add-Type -TypeDefinition ($stub+$helper+$checks)
[HeadPositionTests]::Run()
$source=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
foreach($needle in @('trackedHeadPosition = new Vector3(preparedMatrix[3], preparedMatrix[7], -preparedMatrix[11]);','neutralHeadPosition = trackedHeadPosition;','eye.transform.position = stereoPosition + stereoRotation *','HeadPosition.Map(DoorCameraOrigin(camera.transform.position), trackingToWorld, trackedHeadPosition, neutralHeadPosition, UnitsPerMetre)')) {
 if(!$source.Contains($needle)){throw "Missing integration: $needle"}
}
'PASS: synchronized pose, recenter and translated eye integration guards.'
