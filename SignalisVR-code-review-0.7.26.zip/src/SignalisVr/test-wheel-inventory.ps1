$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'WheelInventoryPicker.cs') -Raw
$policy=$s.Substring(0,$s.IndexOf(' public sealed partial class Tracking'))+'}'
# Exercise the actual assignment/neutral-gate methods with a minimal inventory boundary.
$start=$s.IndexOf('  private void AssignWheelBox(');$end=$s.IndexOf('  private void DrawModItemIcon(')
$methods=$s.Substring($start,$end-$start).Replace('private void AssignWheelBox','public void AssignWheelBox').Replace('private bool PollWheelAssignment','public bool PollWheelAssignment')
Add-Type -TypeDefinition ($policy.Replace('using UnityEngine;','')+' namespace SignalisVrTracking { public class AssignHarness { public int wheelPendingChoice=-1; public bool modMenuWheel=true,wheelDirectionArmed; public string modSettingsError; public int count=1; public string[] quickSlots={"None","None","None","None"}; public string[] QuickChoices={"None","Pistol"}; private int QuickCount(int i){return count;} private int WheelCatalogItem(int i){return i;} private void CloseWheelPicker(){wheelPendingChoice=-1;wheelDirectionArmed=false;} private void RefreshWheelInventory(){} '+$methods+'}}')
$p=[SignalisVrTracking.WheelInventoryPicker]
if(($p::Carried([int[]]@(1,0,3,0,2,-1,1)) -join ',') -ne '2,4,6'){throw 'Carried filtering failed'}
foreach($sample in @(@(0,1,0),@(1,0,1),@(0,-1,2),@(-1,0,3),@(0,0,-1))){if($p::Direction($sample[0],$sample[1]) -ne $sample[2]){throw 'Cardinal assignment wrong'}}

foreach($id in @("PistolAmmo","RevolverAmmo","ShotgunAmmo","RifleAmmo","SMGAmmo","FlareAmmo","Ammo","Flashlight")){if($p::Allowed($id)){throw "Excluded item leaked into picker: $id"}}
foreach($id in @("Pistol","Health50","PhotoModule","Receiver","Taser","SignalFlare","Machete")){if(!$p::Allowed($id)){throw "Usable item excluded: $id"}}
$h=[SignalisVrTracking.AssignHarness]::new();$h.wheelPendingChoice=1
$h.PollWheelAssignment(1,0)|Out-Null
if($h.quickSlots[1] -ne 'None'){throw 'Selection stick carried through without neutral'}
$h.PollWheelAssignment(0,0)|Out-Null;$h.PollWheelAssignment(1,0)|Out-Null
if($h.quickSlots[1] -ne 'Pistol' -or $h.wheelPendingChoice -ne -1){throw 'Item assignment not committed once'}
$h.wheelPendingChoice=0;$h.AssignWheelBox(1);if($h.quickSlots[1] -ne 'None'){throw 'Clear changed inventory instead of shortcut'}
$h.count=0;$h.wheelPendingChoice=1;$h.AssignWheelBox(0);if($h.quickSlots[0] -ne 'None' -or !$h.modSettingsError){throw 'Uncarried item assigned'}
if($s.Contains('Next page') -or $s.Contains('PageSize') -or $s.Contains('QuickDirections[i]')){throw 'Old pagination/direction box labels retained'}
foreach($guard in @('GUI.BeginScrollView','foreach(var pair in inv)','DrawModItemIcon(item','float[] xs={1060,1280,1060,840}')){if(!$s.Contains($guard)){throw "Missing layout integration $guard"}}
'PASS carried filtering; actual item-first assignment/neutral gate/clear/missing-item guard; cardinal directions and continuous icon-list integration. Runtime unverified.'
