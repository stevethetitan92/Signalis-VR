using System;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Mesh cylinderRoundsMesh;private int cylinderVisibleRounds=-1;
  private void DestroyCylinderRounds(){if(cylinderRoundsMesh!=null)UnityEngine.Object.Destroy(cylinderRoundsMesh);cylinderRoundsMesh=null;cylinderVisibleRounds=-1;}
  private void ShowCylinderRounds(MeshRenderer rounds,int count){
   if(rounds==null)return;count=Math.Max(0,Math.Min(6,count));if(cylinderRoundsMesh==null){var source=rounds.GetComponent<MeshFilter>().sharedMesh;cylinderRoundsMesh=UnityEngine.Object.Instantiate(source);cylinderRoundsMesh.name="Bullets";}
   if(cylinderVisibleRounds!=count){Mesh source=null;for(int i=0;i<equippedCopies.Length;i++)if(equippedCopies[i]==rounds){source=equippedOriginals[i].GetComponent<MeshFilter>().sharedMesh;break;}if(source==null||source.vertexCount!=144||source.subMeshCount!=1)return;var selected=new System.Collections.Generic.List<int>();var triangles=source.GetTriangles(0);for(int t=0;t<triangles.Length;t+=3)if(RevolverRoundLayout.RoundForVertex(triangles[t])<count){selected.Add(triangles[t]);selected.Add(triangles[t+1]);selected.Add(triangles[t+2]);}cylinderRoundsMesh.SetTriangles(selected.ToArray(),0);cylinderVisibleRounds=count;}rounds.GetComponent<MeshFilter>().sharedMesh=cylinderRoundsMesh;rounds.enabled=count>0;
  }
  private MeshRenderer ReloadCopy(string meshName){if(IsXiphias()&&xiphiasRoot!=null){if(meshName=="SMG_Mag")return xiphiasMagazine;if(meshName=="SMG_Action")return xiphiasHandle;}if(equippedCopies==null)return null;foreach(var r in equippedCopies)if(r!=null){var f=r.GetComponent<MeshFilter>();if(f!=null&&f.sharedMesh!=null&&f.sharedMesh.name==meshName)return r;}return null;}
  private void RotateReloadBranch(MeshRenderer anchor,Quaternion rotation,Vector3 pivot){
   if(anchor==null)return;var branch=anchor.transform;Transform native=null;for(int i=0;i<equippedCopies.Length;i++)if(equippedCopies[i]==anchor){native=equippedOriginals[i].transform;break;}
   if(native==null)return;
   for(int i=0;i<equippedCopies.Length;i++)if(equippedCopies[i]!=null&&equippedOriginals[i]!=null&&(equippedOriginals[i].transform==native||equippedOriginals[i].transform.IsChildOf(native))){var t=equippedCopies[i].transform;t.position=pivot+rotation*(t.position-pivot);t.rotation=rotation*t.rotation;}
  }
  private void TranslateReloadBranch(MeshRenderer anchor,Vector3 offset){Transform native=null;for(int i=0;i<equippedCopies.Length;i++)if(equippedCopies[i]==anchor){native=equippedOriginals[i].transform;break;}if(native==null)return;for(int i=0;i<equippedCopies.Length;i++)if(equippedCopies[i]!=null&&equippedOriginals[i]!=null&&(equippedOriginals[i].transform==native||equippedOriginals[i].transform.IsChildOf(native)))equippedCopies[i].transform.position+=offset;}
  private void PrepareAllGunMechanisms(){
   additionalAnchors=false;if(PrepareSelectedMechanism())return;var w=global::InventoryManager.EquippedWeapon;if(w==null||w.parentItem==null)return;
   var id=w.parentItem._item;bool eligible=AdditionalGunEligible()||RetainPhysicalReload();
   if(id==global::Items.itemlist.Shotgun&&ManualShotgunEligible()){
    var pump=ReloadCopy("Shotgun_Handle");if(pump!=null){float pull=Math.Min(.10f,Math.Max(0,shotgunReload.Pull));pump.transform.position-=rightWeaponRotation*Vector3.forward*(pull*UnitsPerMetre);}
    return;
   }
   if(!eligible){if(cylinderRoundsMesh!=null){for(int i=0;i<equippedCopies.Length;i++)if(equippedCopies[i]!=null&&equippedCopies[i].GetComponent<MeshFilter>().sharedMesh==cylinderRoundsMesh)equippedCopies[i].GetComponent<MeshFilter>().sharedMesh=equippedOriginals[i].GetComponent<MeshFilter>().sharedMesh;DestroyCylinderRounds();}return;}
   if(id==global::Items.itemlist.SMG){
    var magazine=ReloadCopy("SMG_Mag");var bolt=ReloadCopy("SMG_Action");if(magazine==null||bolt==null)return;
    var bounds=magazine.GetComponent<MeshFilter>().sharedMesh.bounds;additionalChamber=magazine.transform.TransformPoint(new Vector3(bounds.center.x,bounds.max.y,bounds.center.z));additionalLoadDirection=rightWeaponRotation*Vector3.up;
    if(IsXiphias())additionalChamber=xiphiasRoot.transform.TransformPoint(new Vector3(0,.02728f,.121475f));
    additionalBolt=IsXiphias()&&xiphiasHandle!=null?XiphiasHandleContact():bolt.bounds.center;
    if(smgReload.Active)magazine.enabled=smgReload.Stage==ManualReloadPolicy.Step.Inserted||smgReload.Stage==ManualReloadPolicy.Step.RackHolding||smgReload.Stage==ManualReloadPolicy.Step.AwaitingGame;
    float pull=smgReload.Stage==ManualReloadPolicy.Step.RackHolding?Math.Min(.030f,smgReload.RackPull):0;float age=Time.realtimeSinceStartup-additionalRackTime;if(age>=0&&age<.18f)pull=additionalReleasePull*(1-age/.18f);
    bolt.transform.position-=rightWeaponRotation*Vector3.forward*(pull*UnitsPerMetre);additionalBolt=IsXiphias()&&xiphiasHandle!=null?XiphiasHandleContact():bolt.bounds.center;additionalAnchors=true;
    if(smgReload.Stage==ManualReloadPolicy.Step.RackHolding&&handsScoped){FitFingerToContact(0,"thumb",additionalBolt-rightWeaponRotation*Vector3.right*(.012f*UnitsPerMetre),8);FitFingerToContact(0,"index",additionalBolt+rightWeaponRotation*Vector3.right*(.012f*UnitsPerMetre),8);}
   }else{
    MeshRenderer moving=id==global::Items.itemlist.Revolver?ReloadCopy("Drum"):ReloadCopy(id==global::Items.itemlist.Rifle?"RifleBarrel":"Barrel");if(moving==null)return;
    float eased=additionalOpen*additionalOpen*(3-2*additionalOpen);
    if(id==global::Items.itemlist.Revolver){var offset=rightWeaponRotation*Vector3.left*(.045f*UnitsPerMetre*eased);var pivot=moving.bounds.center;RotateReloadBranch(moving,Quaternion.AngleAxis(25*eased,rightWeaponRotation*Vector3.forward),pivot);TranslateReloadBranch(moving,offset);var rounds=ReloadCopy("Bullets");if(rounds!=null){ShowCylinderRounds(rounds,w.magAmmo);var b=rounds.GetComponent<MeshFilter>().sharedMesh.bounds;additionalChamber=rounds.transform.TransformPoint(new Vector3(b.min.x,b.center.y,b.center.z));additionalLoadDirection=rounds.transform.right;}else{additionalChamber=moving.bounds.center;additionalLoadDirection=moving.transform.right;}}
    else{var native=moving.transform;Transform pivot=null;for(int i=0;i<equippedCopies.Length;i++)if(equippedCopies[i]==moving){pivot=equippedOriginals[i].transform.parent;break;}var p=pivot!=null?pivot.position:native.position;var turn=Quaternion.AngleAxis(32*eased,rightWeaponRotation*Vector3.right);RotateReloadBranch(moving,turn,p);var b=moving.GetComponent<MeshFilter>().sharedMesh.bounds;bool forward=Vector3.Dot(moving.transform.right,rightWeaponRotation*Vector3.forward)>=0;additionalChamber=moving.transform.TransformPoint(new Vector3(forward?b.min.x:b.max.x,b.center.y,b.center.z));additionalLoadDirection=turn*(rightWeaponRotation*Vector3.forward);}
    additionalBolt=additionalChamber;additionalAnchors=true;
   }
  }
 }
}
