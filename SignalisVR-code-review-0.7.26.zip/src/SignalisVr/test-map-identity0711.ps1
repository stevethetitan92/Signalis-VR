$ErrorActionPreference='Stop'
Add-Type -Path "$PSScriptRoot/MapIdentityPolicy.cs"
$p=[SignalisVrTracking.MapIdentityPolicy]
$saved='5|First Aid Room|Rooms/Detention/FirstAid/Chunk/SavePoint'
$live='5|First Aid Room|FirstAid/Chunk/SavePoint'
if(!$p::Matches($saved,$live) -or !$p::Matches($live,$saved)){throw 'Room reload identity mismatch'}
foreach($other in @('6|First Aid Room|FirstAid/Chunk/SavePoint','5|Office|FirstAid/Chunk/SavePoint','5|First Aid Room|FirstAid/Chunk/StorageBox','5|First Aid Room|OtherFirstAid/Chunk/SavePoint')){if($p::Matches($saved,$other)){throw "Aliased unrelated object: $other"}}
if(!$p::Matches('scene-unique-id','scene-unique-id') -or $p::Matches('scene-unique-id','other-id')){throw 'Native pickup identity failed'}
'PASS native pickup IDs and room-load path suffix identity; no cross-floor, cross-room, partial-path or object-type alias.'
