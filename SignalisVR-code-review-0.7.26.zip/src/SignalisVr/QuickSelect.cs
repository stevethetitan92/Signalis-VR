using System;
using System.Collections.Generic;
using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly QuickSelectPolicy quickSelect=new QuickSelectPolicy();
  private string[] quickSlots={"None","None","None","None"};
  private static readonly string[] QuickChoices={"None","Pistol","Revolver","Shotgun","Rifle","FlareGun","SMG","Taser","Health25","Health50","Health100","HealthFast","SignalFlare","Receiver","PhotoModule"};
  private static readonly string[] QuickNames={"NO ITEM","Pistol","Revolver","Shotgun","Rifle","Flare Gun","SMG","Stun Prod","Repair Patch","Repair Spray","Repair Spray+","Autoinjector","Thermite Flare","Receiver","Eidetic Module"};
  private static readonly string[] QuickDirections={"Up","Right","Down","Left"};
  private global::InventoryBase quickInventory;
  private float nextQuickInventory,quickFlashUntil;
  private int quickLast=-1;
  private bool quickFailed,quickEnabled;
  private string quickStatus="";
  private bool quickGestureHeld;
  private Vector3 quickGestureOrigin;
  private Vector3 quickWristOffset;
  private bool quickCaptureWrist;
  private Vector3 quickDisplayOffset;
  private Quaternion quickGestureBasis=Quaternion.identity;
  private void PollHandWheel(bool available,bool clicked) {
   bool ready=available&&QuickReady()&&ControllerWeaponVisualReady();
   if(ready&&clicked&&!quickGestureHeld){quickGestureOrigin=rawControllerPositions[1];quickGestureBasis=Quaternion.Inverse(controllerTrackingToWorld)*stereoRotation;quickCaptureWrist=true;quickWristOffset=Vector3.zero;}
   quickGestureHeld=ready&&clicked;
   var delta=Quaternion.Inverse(quickGestureBasis)*(rawControllerPositions[1]-quickGestureOrigin);
   // 9.75cm activates; return within 3.75cm before another item. Tracking-space
   // displacement excludes locomotion. Recenter/teleport cancels until release.
   if(clicked&&delta.magnitude>.65f){ready=false;}
   PollQuickSelect(ready,clicked,delta.x/.15f,delta.y/.15f);
  }
  private string QuickName(int slot){int i=Array.IndexOf(QuickChoices,quickSlots[slot]);return i<0?"NO ITEM":QuickNames[i];}
  private global::AnItem QuickItem(int slot){if(quickSlots[slot]=="Receiver")return ReceiverCatalog();global::Items.itemlist id;if(!Enum.TryParse(quickSlots[slot],out id)||quickSlots[slot]=="None"||global::InventoryManager.allItems==null||!global::InventoryManager.allItems.ContainsKey(id))return null;return global::InventoryManager.allItems[id];}
  private int QuickCount(global::AnItem item){if(item!=null&&receiverCatalog!=null&&item.Pointer==receiverCatalog.Pointer)return ReceiverOwned()?1:0;var items=global::InventoryManager.elsterItems;return item!=null&&items!=null&&items.ContainsKey(item)?items[item]:0;}
  private bool QuickReady(){return quickEnabled&&!quickFailed&&ProdVrMode()&&questPolicy.LeftArmed&&questPolicy.RightArmed&&ModHudGameplayReady()&&!modMenuOpen&&!global::PlayerState.reloading&&!global::PlayerState.animating&&!global::PlayerState.grappled&&!global::PlayerState.hurt;}
  private void PollQuickSelect(bool available,bool touch,float x,float y) {
   bool wasOpen=quickSelect.Open;
   int selection=quickSelect.Update(available&&QuickReady(),touch,x,y);
   if(wasOpen||quickSelect.Open){questFrame=new QuestFrame();manualLeftGrip=false;modMenuRightGrip=false;sprintToggle.Reset();ResetProdSample();}
   if(selection<0)return;
   quickLast=selection;quickFlashUntil=Time.realtimeSinceStartup+.4f;
   try {
    var item=QuickItem(selection);
    if(QuickCount(item)==0){quickStatus="Not carried";return;}
    if(quickInventory==null&&Time.realtimeSinceStartup>=nextQuickInventory){nextQuickInventory=Time.realtimeSinceStartup+1f;foreach(var inv in Resources.FindObjectsOfTypeAll<global::InventoryBase>())if(inv!=null&&inv.gameObject.scene.IsValid()){quickInventory=inv;break;}}
    if(quickInventory==null){quickStatus="Inventory not ready";return;}
    CancelManualReload();
    string id=quickSlots[selection];quickNonFirearmAudio=!QuickFirearm(id);if(EquipHeldModule(id,true))return;ClearHeldModules();healthUsed=false;
    if(id.StartsWith("Health",StringComparison.Ordinal)) {
     var weapon=global::InventoryManager.EquippedWeapon;
     if(weapon!=null&&weapon.parentItem!=null){quickPreviousWeapon=weapon.parentItem;quickInventory.EquipWeapon(weapon.parentItem);}
     if(global::InventoryManager.EquippedWeapon!=null){quickStatus="Cannot holster now";return;}
     if(ProdSelected()||ThermiteSelected())global::InventoryManager.EquippedTool=null;
     heldQuickHealth=item;quickUse.Reset();
    }else if(id=="Taser"||id=="SignalFlare") {
     if((id=="Taser"||id=="SignalFlare")&&!PrepareProdHand(quickInventory)){quickStatus="Cannot holster now";return;}
     if(global::InventoryManager.EquippedTool!=item)quickInventory.EquipTool(item);
     heldQuickHealth=null;quickPreviousWeapon=null;
    }else {
     var weapon=global::InventoryManager.EquippedWeapon;
     if(weapon==null||weapon.parentItem!=item)quickInventory.EquipWeapon(item);
     heldQuickHealth=null;quickPreviousWeapon=null;
    }
    bool equipped=heldQuickHealth==item||global::InventoryManager.EquippedTool==item||(global::InventoryManager.EquippedWeapon!=null&&global::InventoryManager.EquippedWeapon.parentItem==item);
    if(equipped)PlayWheelItemEquip(id);
    quickStatus=QuickName(selection);MelonLogger.Msg("QUICK SELECT: "+QuickDirections[selection]+" -> "+id);
   }catch(Exception ex){quickStatus="Item unavailable";MelonLogger.Warning("Quick-select action failed: "+ex.Message);}
  }
  private global::AnItem heldQuickHealth,quickHealthVisualItem,quickPreviousWeapon;
  private bool quickBlockFire;
  private readonly QuickUsePolicy quickUse=new QuickUsePolicy();
  private GameObject quickHealthRoot;
  private readonly List<Renderer> quickHealthRenderers=new List<Renderer>();
  private void PollQuickHealth(bool available,bool trigger) {
   if(healthUsed){questFrame.buttons&=~((1<<5)|(1<<6)|(1<<7));if(Time.realtimeSinceStartup>=healthFinishTime&&available&&WeaponGameplayReady()&&!global::PlayerState.animating){ClearDepletedHealthSlot();healthUsed=false;heldQuickHealth=null;RestoreQuickWeapon();}return;}
   if(quickBlockFire){questFrame.buttons&=~(1<<6);if(!trigger)quickBlockFire=false;}
   if(heldQuickHealth==null){quickUse.Reset();if(quickPreviousWeapon!=null&&available&&WeaponGameplayReady()&&!global::PlayerState.paused&&!global::PlayerState.cutscene)try{RestoreQuickWeapon();}catch(Exception ex){MelonLogger.Warning("Restore quick weapon failed: "+ex.Message);}return;}
   // Every held-health frame owns aim/fire/reload, including the use frame.
   questFrame.buttons&=~((1<<5)|(1<<6)|(1<<7));
   bool ready=available&&QuickReady();
   if(!quickEnabled||QuickCount(heldQuickHealth)==0||global::InventoryManager.EquippedWeapon!=null){heldQuickHealth=null;quickUse.Reset();return;}
   if(!quickUse.Update(ready,trigger))return;
   if(global::PlayerState.hp>=100){quickStatus="Health full";return;}
   var item=heldQuickHealth;bool spray=item._item==global::Items.itemlist.Health50||item._item==global::Items.itemlist.Health100;
   try {if(quickInventory!=null&&QuickCount(item)>0){quickInventory.useItem(item);healthUsed=true;healthSqueezeTime=Time.realtimeSinceStartup;healthFinishTime=healthSqueezeTime+(spray?.95f:item._item==global::Items.itemlist.Health25?RepairPatchMotion.Duration:.30f);MelonLogger.Msg("QUICK SELECT: trigger used "+item._item);}}
   catch(Exception ex){MelonLogger.Warning("Held health use failed: "+ex.Message);}
  }
  private void ClearDepletedHealthSlot(){if(heldQuickHealth==null||QuickCount(heldQuickHealth)>0)return;RepairSprayUseMotion.ClearSlots(quickSlots,heldQuickHealth._item.ToString());try{SaveModSettings();}catch(Exception e){MelonLogger.Warning("Depleted health wheel save: "+e.Message);}}
  private void RestoreQuickWeapon(){quickNonFirearmAudio=false;var item=quickPreviousWeapon;quickPreviousWeapon=null;quickBlockFire=true;questFrame.buttons&=~(1<<6);if(item!=null&&quickInventory!=null&&QuickCount(item)>0&&global::InventoryManager.EquippedWeapon==null)quickInventory.EquipWeapon(item);}
  private void PrepareQuickHealth() {
   HideQuickHealth();if((healthUsed&&Time.realtimeSinceStartup>=healthFinishTime)||heldQuickHealth==null||(!healthUsed&&!QuickReady())||!handsScoped||controllerMarkers[1]==null)return;
   try {
    if(quickHealthRoot==null||quickHealthVisualItem!=heldQuickHealth) {
     DestroyQuickHealthVisual();quickHealthVisualItem=heldQuickHealth;
     quickHealthRoot=new GameObject("SignalisVR_HeldHealth");UnityEngine.Object.DontDestroyOnLoad(quickHealthRoot);
     var model=heldQuickHealth.Image3D;
     Bounds bounds=new Bounds();bool found=false;
     if(model!=null)foreach(var original in model.GetComponentsInChildren<MeshRenderer>(true)) {
      var filter=original.GetComponent<MeshFilter>();if(filter==null||filter.sharedMesh==null)continue;
      var go=new GameObject("HealthGeometry");go.layer=30;go.transform.SetParent(quickHealthRoot.transform,false);
      go.transform.localPosition=model.transform.InverseTransformPoint(original.transform.position);
      go.transform.localRotation=Quaternion.Inverse(model.transform.rotation)*original.transform.rotation;
      var scale=original.transform.lossyScale;var baseScale=model.transform.lossyScale;
      go.transform.localScale=new Vector3(scale.x/baseScale.x,scale.y/baseScale.y,scale.z/baseScale.z);
      go.AddComponent<MeshFilter>().sharedMesh=filter.sharedMesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterials=original.sharedMaterials;r.enabled=false;quickHealthRenderers.Add(r);SplitHealthTrigger(filter.sharedMesh,go,r);if(filter.sharedMesh.name=="HealthPatchPack"&&filter.sharedMesh.vertexCount==128)patchGripFrame=go.transform;
      var b=filter.sharedMesh.bounds;
      for(int i=0;i<8;i++){var corner=b.center+Vector3.Scale(b.extents,new Vector3((i&1)==0?-1:1,(i&2)==0?-1:1,(i&4)==0?-1:1));var p=go.transform.TransformPoint(corner);if(!found){bounds=new Bounds(p,Vector3.zero);found=true;}else bounds.Encapsulate(p);}
     }
     if(found){float factor=.21f*UnitsPerMetre/Mathf.Max(.001f,Mathf.Max(bounds.size.x,Mathf.Max(bounds.size.y,bounds.size.z)));foreach(var r in quickHealthRenderers){r.transform.localPosition=(r.transform.localPosition-bounds.center)*factor;r.transform.localScale*=factor;}}
     else {var r=quickHealthRoot.AddComponent<SpriteRenderer>();r.sprite=heldQuickHealth.Image!=null?heldQuickHealth.Image:heldQuickHealth.Icon;if(r.sprite!=null)quickHealthRoot.transform.localScale=Vector3.one*(.10f*UnitsPerMetre/Mathf.Max(.001f,Mathf.Max(r.sprite.bounds.size.x,r.sprite.bounds.size.y)));r.enabled=false;quickHealthRenderers.Add(r);}
    }
    var hand=controllerMarkers[1].transform;quickHealthRoot.transform.position=hand.position+hand.forward*(.035f*UnitsPerMetre);quickHealthRoot.transform.rotation=hand.rotation*Quaternion.Euler(0,90,0);FitHealthGrip();FitPatchGrip();
    foreach(var r in quickHealthRenderers)r.enabled=patchGripFrame==null||RepairPatchMotion.PacketVisible(healthUsed,Time.realtimeSinceStartup-healthSqueezeTime);
   }catch(Exception ex){heldQuickHealth=null;DestroyQuickHealthVisual();MelonLogger.Warning("Held health visual unavailable: "+ex.Message);}
  }
  private void HideQuickHealth(){if(patchHand!=null)patchHand.enabled=false;if(repairHand!=null)repairHand.enabled=false;foreach(var r in healthTriggerParts)if(r!=null)r.enabled=false;foreach(var r in quickHealthRenderers)if(r!=null)r.enabled=false;}
  private void DestroyQuickHealthVisual(){ClearPatchGrip();ClearHealthGrip();if(quickHealthRoot!=null)UnityEngine.Object.Destroy(quickHealthRoot);quickHealthRoot=null;quickHealthVisualItem=null;quickHealthRenderers.Clear();}
  private GameObject quickRoot;
  private readonly List<Renderer> quickRenderers=new List<Renderer>();
  private readonly List<Material> quickMaterials=new List<Material>();
  private readonly List<Mesh> quickMeshes=new List<Mesh>();
  private readonly SpriteRenderer[] quickIcons=new SpriteRenderer[4];
  private readonly SpriteRenderer[] quickIconGlows=new SpriteRenderer[4];
  private readonly Material[] quickRims=new Material[4],quickRimGlows=new Material[4];
  private readonly Mesh[] quickTexts=new Mesh[4];
  private readonly string[] quickCaptions=new string[4];
  private readonly Material[] quickDiscs=new Material[4];
  private Mesh quickCenterText;private string quickCenterCaption;
  private Mesh QuickText(GameObject parent,Vector3 position) {
   var go=new GameObject("QuickLabel");go.layer=30;go.transform.SetParent(parent.transform,false);go.transform.localPosition=position*UnitsPerMetre;
   var mesh=new Mesh();quickMeshes.Add(mesh);go.AddComponent<MeshFilter>().sharedMesh=mesh;
   var m=new Material(Shader.Find("Sprites/Default"));m.mainTexture=modGlyphAtlas;m.color=new Color(1f,1f,1f,.95f);quickMaterials.Add(m);
   var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=m;r.sortingOrder=9;r.enabled=false;quickRenderers.Add(r);return mesh;
  }
  private Material QuickRim(GameObject parent,float radius,float width,float depth,float alpha) {
   var go=new GameObject("HologramRim");go.layer=30;go.transform.SetParent(parent.transform,false);go.transform.localPosition=new Vector3(0,0,depth)*UnitsPerMetre;
   var vertices=new Vector3[64];var triangles=new int[192];
   for(int i=0;i<32;i++){float angle=i*(float)Math.PI/16;var unit=new Vector3(Mathf.Cos(angle),Mathf.Sin(angle),0)*UnitsPerMetre;vertices[i*2]=unit*radius;vertices[i*2+1]=unit*(radius-width);int a=i*2,b=((i+1)%32)*2,n=i*6;triangles[n]=a;triangles[n+1]=b+1;triangles[n+2]=b;triangles[n+3]=a;triangles[n+4]=a+1;triangles[n+5]=b+1;}
   var mesh=new Mesh();mesh.vertices=vertices;mesh.triangles=triangles;mesh.RecalculateBounds();quickMeshes.Add(mesh);go.AddComponent<MeshFilter>().sharedMesh=mesh;
   var material=new Material(Shader.Find("Sprites/Default"));material.mainTexture=Texture2D.whiteTexture;material.color=new Color(.3f,.85f,1f,alpha);quickMaterials.Add(material);
   var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=material;r.sortingOrder=6;r.enabled=false;quickRenderers.Add(r);return material;
  }
  private void QuickTextGlow(GameObject parent,Mesh mesh,Vector3 position) {
   var material=new Material(Shader.Find("Sprites/Default"));material.mainTexture=modGlyphAtlas;material.color=new Color(.35f,.85f,1f,.14f);quickMaterials.Add(material);
   for(int side=-1;side<=1;side+=2){var go=new GameObject("QuickLabelGlow");go.layer=30;go.transform.SetParent(parent.transform,false);go.transform.localPosition=(position+new Vector3(side*.0006f,0,.001f))*UnitsPerMetre;go.AddComponent<MeshFilter>().sharedMesh=mesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=material;r.sortingOrder=7;r.enabled=false;quickRenderers.Add(r);}
  }
  private void EnsureQuickVisual() {
   if(quickRoot!=null)return;
   EnsureGlyphAtlas();quickRoot=new GameObject("SignalisVR_QuickSelect");UnityEngine.Object.DontDestroyOnLoad(quickRoot);
   var positions=new[]{new Vector3(0,.13f,0),new Vector3(.16f,0,0),new Vector3(0,-.13f,0),new Vector3(-.16f,0,0)};
   for(int slot=0;slot<4;slot++) {
    var root=new GameObject(QuickDirections[slot]);root.layer=30;root.transform.SetParent(quickRoot.transform,false);root.transform.localPosition=positions[slot]*UnitsPerMetre;
    root.transform.localPosition+=new Vector3(0,0,.018f)*UnitsPerMetre;
    root.transform.localRotation=Quaternion.identity;
    var vertices=new Vector3[33];var triangles=new int[96];
    for(int i=0;i<32;i++){float angle=i*(float)Math.PI/16;vertices[i+1]=new Vector3(Mathf.Cos(angle),Mathf.Sin(angle),0)*(.063f*UnitsPerMetre);triangles[i*3]=0;triangles[i*3+1]=(i+1)%32+1;triangles[i*3+2]=i+1;}
    var mesh=new Mesh();mesh.vertices=vertices;mesh.triangles=triangles;mesh.RecalculateBounds();quickMeshes.Add(mesh);root.AddComponent<MeshFilter>().sharedMesh=mesh;
    var mat=new Material(Shader.Find("Sprites/Default"));mat.mainTexture=Texture2D.whiteTexture;quickDiscs[slot]=mat;quickMaterials.Add(mat);
    var r=root.AddComponent<MeshRenderer>();r.sharedMaterial=mat;r.enabled=false;quickRenderers.Add(r);
    quickRims[slot]=QuickRim(root,.063f,.0012f,-.002f,.85f);
    quickRimGlows[slot]=QuickRim(root,.065f,.005f,.004f,.14f);
    QuickRim(root,.063f,.0008f,.008f,.25f);
    var icon=new GameObject("ItemIcon");icon.layer=30;icon.transform.SetParent(root.transform,false);icon.transform.localPosition=new Vector3(0,.014f,-.003f)*UnitsPerMetre;
    quickIcons[slot]=icon.AddComponent<SpriteRenderer>();quickIcons[slot].sortingOrder=8;quickIcons[slot].enabled=false;quickRenderers.Add(quickIcons[slot]);
    var glow=new GameObject("ItemHologramGlow");glow.layer=30;glow.transform.SetParent(icon.transform,false);glow.transform.localPosition=new Vector3(0,0,.001f);glow.transform.localScale=Vector3.one*1.035f;quickIconGlows[slot]=glow.AddComponent<SpriteRenderer>();quickIconGlows[slot].sortingOrder=7;quickIconGlows[slot].enabled=false;quickRenderers.Add(quickIconGlows[slot]);
    quickTexts[slot]=QuickText(root,new Vector3(0,-.042f,-.005f));
    QuickTextGlow(root,quickTexts[slot],new Vector3(0,-.042f,-.005f));
   }
   quickCenterText=QuickText(quickRoot,new Vector3(0,0,-.006f));
   QuickTextGlow(quickRoot,quickCenterText,new Vector3(0,0,-.006f));
  }
  private void PrepareQuickSelect() {
   HideQuickSelect();if(!quickSelect.Open||!QuickReady()||controllerMarkers[1]==null)return;
   try {
    EnsureQuickVisual();
    var wrist=handsObjects[1]!=null?handsObjects[1].transform:controllerMarkers[1].transform;
    quickCaptureWrist=false;
    quickRoot.transform.rotation=wrist.rotation*Quaternion.Inverse(handsCorrections[1])*Quaternion.Euler(90,0,0);
    quickRoot.transform.position=wrist.position+quickRoot.transform.rotation*(new Vector3(0,0,-.025f)*UnitsPerMetre);
    foreach(var r in quickRenderers)r.enabled=true;
    for(int i=0;i<4;i++) {
     var item=QuickItem(i);int count=QuickCount(item);var icon=quickIcons[i];icon.sprite=item==null?null:(item.Icon!=null?item.Icon:item.Image);icon.enabled=icon.sprite!=null;
     if(icon.sprite!=null){float size=Mathf.Max(icon.sprite.bounds.size.x,icon.sprite.bounds.size.y);icon.transform.localScale=Vector3.one*(.065f*UnitsPerMetre/Mathf.Max(size,.001f));}icon.color=count>0?new Color(.75f,.95f,1f,.9f):new Color(.4f,.5f,.55f,.5f);
     quickIconGlows[i].sprite=icon.sprite;quickIconGlows[i].enabled=icon.enabled;quickIconGlows[i].color=new Color(.3f,.85f,1f,count>0?.14f:.04f);
     bool highlighted=i==quickLast&&Time.realtimeSinceStartup<quickFlashUntil;
     quickDiscs[i].color=highlighted?new Color(.1f,.9f,1f,.25f):count>0?new Color(.05f,.5f,.65f,.1f):new Color(.1f,.18f,.2f,.06f);
     quickRims[i].color=new Color(.3f,.85f,1f,highlighted?1f:count>0?.75f:.25f);
     quickRimGlows[i].color=new Color(.3f,.85f,1f,highlighted?.25f:count>0?.14f:.04f);
     UpdateModHudText(quickTexts[i],QuickSlotDefaults.Caption(QuickName(i),count),ref quickCaptions[i]);
    }
    UpdateModHudText(quickCenterText,Time.realtimeSinceStartup<quickFlashUntil?quickStatus:"QUICK SELECT",ref quickCenterCaption);
   }catch(Exception ex){quickFailed=true;quickSelect.Reset();HideQuickSelect();MelonLogger.Warning("Quick-select visual disabled: "+ex.Message);}
  }
  private void ClearWheelOcclusion(){
   if(!quickSelect.Open||quickRoot==null||!QuickReady())return;
   HideXiphias();HideSelected();HideSwingProd();HideThermite();HideQuickHealth();HideHeldModules();HideManualReload();
   if(equippedCopies!=null)foreach(var r in equippedCopies)if(r!=null)r.enabled=false;
   foreach(var r in heldTriggerRenderers)if(r!=null)r.enabled=false;
   foreach(var r in handsRenderers)if(r!=null)r.enabled=false;
  }
  private void HideQuickSelect(){foreach(var r in quickRenderers)if(r!=null)r.enabled=false;}
  private void DestroyQuickSelect(){if(quickItemEquipSound!=null)quickItemEquipSound.Dispose();quickItemEquipSound=null;DestroyHeldModules();healthUsed=false;heldQuickHealth=null;quickPreviousWeapon=null;DestroyQuickHealthVisual();quickSelect.Reset();if(quickRoot!=null)UnityEngine.Object.Destroy(quickRoot);foreach(var m in quickMaterials)UnityEngine.Object.Destroy(m);foreach(var m in quickMeshes)UnityEngine.Object.Destroy(m);quickRoot=null;quickInventory=null;quickRenderers.Clear();quickMaterials.Clear();quickMeshes.Clear();Array.Clear(quickCaptions,0,4);quickCenterCaption=null;quickFailed=false;}
 }
}










