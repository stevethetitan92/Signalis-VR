$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'ProdSurface.cs') -Raw
$source=$source.Substring(0,$source.IndexOf(' public sealed partial class Tracking'))+'}'
$stub=@'
namespace UnityEngine {
 public struct Vector3 {
  public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}
  public float sqrMagnitude{get{return x*x+y*y+z*z;}}
  public static Vector3 operator +(Vector3 a,Vector3 b){return new Vector3(a.x+b.x,a.y+b.y,a.z+b.z);}
  public static Vector3 operator -(Vector3 a,Vector3 b){return new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);}
  public static Vector3 operator *(Vector3 a,float b){return new Vector3(a.x*b,a.y*b,a.z*b);}
  public static float Dot(Vector3 a,Vector3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
  public static Vector3 Cross(Vector3 a,Vector3 b){return new Vector3(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);}
 }
}
public static class SurfaceTest {
 public static void Run(){
  foreach(float scale in new[]{1f,5f}){
   var a=new UnityEngine.Vector3(-1,-1,.2f)*scale;var b=new UnityEngine.Vector3(1,-1,.2f)*scale;var c=new UnityEngine.Vector3(0,1,.2f)*scale;
   var start=new UnityEngine.Vector3(0,0,0);var end=new UnityEngine.Vector3(0,0,.4f)*scale;
   if(System.Math.Abs(SignalisVrTracking.ProdSurfaceGeometry.Segment(start,end,a,b,c)-.5f)>.00001f)throw new System.Exception("Missed surface");
   if(System.Math.Abs(SignalisVrTracking.ProdSurfaceGeometry.Segment(start,end,c,b,a)-.5f)>.00001f)throw new System.Exception("Winding dependent");
   var shortTip=new UnityEngine.Vector3(0,0,.1f)*scale;
   if(SignalisVrTracking.ProdSurfaceGeometry.Segment(start,shortTip,a,b,c)!=1)throw new System.Exception("Stopped before body");
   if((SignalisVrTracking.ProdSurfaceGeometry.Closest(shortTip,a,b,c)-shortTip).sqrMagnitude<.0099f*scale*scale)throw new System.Exception("Remote stun");
   var contact=new UnityEngine.Vector3(0,0,.1995f)*scale;
   if((SignalisVrTracking.ProdSurfaceGeometry.Closest(contact,a,b,c)-contact).sqrMagnitude>.000001f*scale*scale)throw new System.Exception("Tip contact missed");
   var outside=new UnityEngine.Vector3(3,3,.2f)*scale;
   if((SignalisVrTracking.ProdSurfaceGeometry.Closest(outside,a,b,c)-outside).sqrMagnitude<scale*scale)throw new System.Exception("Outside triangle");
  }
 }
}
'@
Add-Type -TypeDefinition ($source+$stub)
[SurfaceTest]::Run()
Add-Type -Path (Join-Path $PSScriptRoot 'ManualReloadPolicy.cs')
foreach($pull in @(-.03,0,.003,.005,.007,.015,.03)){
 $p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.MinimumPull=.006;$p.MaximumPull=.03;$p.BeginRack(0)
 $p.Tick(.1,$true,$true,$false,$false,$false,$pull)|Out-Null
 if($p.Tick(.2,$true,$false,$false,$false,$false,0) -ne ($pull -ge .006)){throw 'Half-travel acceptance failed'}
}
foreach($empty in $true,$false){
 $p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.PressB(0,$false,$true,$empty)|Out-Null
 $p.Tick(.1,$true,$true,$true,$false)|Out-Null;$p.Tick(.2,$true,$true,$false,$true)|Out-Null
 if($p.Tick(.4,$true,$true,$false,$true) -ne (!$empty)){throw 'Tactical magazine requirement failed'}
}
'PASS surface geometry at two scales, winding, body gap, contact, bounds; half SMG stroke and tactical/empty magazine flow.'
