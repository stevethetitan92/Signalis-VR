$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'ControllerHands.cs') -Raw
$helper='using System;using System.Collections.Generic;namespace SignalisVrTracking {'+$source.Substring($source.IndexOf(' internal static class HandMeshSelection'))
$checks=@'
public static class HandSelectionTests {
 public static string Run() {
  int checks=0;
  for(int tracked=0;tracked<4;tracked++)for(int ready=0;ready<4;ready++) {
   int actual=SignalisVrTracking.HandMeshSelection.ReadyMask(tracked,(ready&1)!=0,(ready&2)!=0);
   if(actual!=(tracked&ready))throw new Exception("Independent hand visibility failed");
  }
  if(SignalisVrTracking.HandMeshSelection.ReadyMask(2,true,true)!=2)throw new Exception("Left tracking loss hid right hand");
  if(SignalisVrTracking.HandMeshSelection.ReadyMask(1,true,true)!=1)throw new Exception("Right tracking loss hid left hand");
  for(int mask=0;mask<16;mask++) {
   var allowed=new bool[4];for(int i=0;i<4;i++)allowed[i]=(mask&(1<<i))!=0;
   var input=new[]{0,1,2,2,3,0};var output=SignalisVrTracking.HandMeshSelection.Filter(input,allowed);
   int expected=(allowed[0]&&allowed[1]&&allowed[2]?3:0)+(allowed[2]&&allowed[3]&&allowed[0]?3:0);
   if(output.Length!=expected)throw new Exception("Triangle selection count");
   for(int i=0;i<output.Length;i++)if(!allowed[output[i]])throw new Exception("Body vertex leaked");
   if(input[0]!=0||input[5]!=0)throw new Exception("Source mutated");
   checks++;
  }
  var all=new[]{true,true,true};
  var winding=SignalisVrTracking.HandMeshSelection.Filter(new[]{2,1,0},all);
  if(winding[0]!=2||winding[1]!=1||winding[2]!=0)throw new Exception("Winding changed");
  if(SignalisVrTracking.HandMeshSelection.Filter(new[]{-1,1,2,0,1,10},all).Length!=0)throw new Exception("Invalid index accepted");
  bool threw=false;try{SignalisVrTracking.HandMeshSelection.Filter(new[]{0,1},all);}catch(ArgumentException){threw=true;}
  if(!threw)throw new Exception("Incomplete triangle accepted");
  return "PASS: 16 inclusion combinations, source preservation, winding and invalid-index rejection. Not a visual/runtime test.";
 }
}
'@
Add-Type -TypeDefinition ($helper+$checks)
[HandSelectionTests]::Run()
$main=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
if(!$main.Contains('RestoreEquippedWeaponVisual(); RestoreControllerHands();')){throw 'Missing eye-scope hand restoration'}
if(!$source.Contains('UnityEngine.Object.Instantiate(source)')){throw 'Hand mesh must be private'}
if($source.Contains('BakeMesh(')){throw 'Unexpected per-frame mesh baking'}
'PASS: integration guards; original skeleton and native firing still require runtime regression test.'
