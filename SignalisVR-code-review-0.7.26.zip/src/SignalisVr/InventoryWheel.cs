using System;
using System.Text;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;
namespace SignalisVrTracking {
 public static class InventoryWheelPolicy {
  public static bool Allowed(string id){switch(id){case "Pistol":case "Revolver":case "Shotgun":case "Rifle":case "FlareGun":case "SMG":case "Taser":case "Health25":case "Health50":case "Health100":case "HealthFast":case "SignalFlare":return true;default:return false;}}
  public static void Assign(string[] slots,int slot,string id){if(slot<0||slot>=slots.Length||!Allowed(id))throw new ArgumentException();for(int i=0;i<slots.Length;i++)if(slots[i]==id)slots[i]="None";slots[slot]=id;}
  public static void Normalize(string[] slots){for(int i=0;i<slots.Length;i++){if(!Allowed(slots[i]))slots[i]="None";for(int j=0;j<i;j++)if(slots[i]!="None"&&slots[i]==slots[j])slots[i]="None";}}
 }
 public sealed partial class Tracking {
  private static Tracking inventoryWheelOwner; private bool inventoryWheelNativeClosing;
  private global::InventoryBase inventoryWheelView;
  private global::AnItem inventoryWheelItem;
  private GameObject inventoryWheelRoot;
  private readonly Image[] inventoryWheelFrames=new Image[4],inventoryWheelIcons=new Image[4];
  private int inventoryWheelSlot;
  private bool inventoryWheelConfirmHeld,inventoryWheelCancelHeld,inventoryWheelDescriptionEnabled;
  private string inventoryWheelName;
  private readonly ModMenuInput inventoryWheelNavigation=new ModMenuInput();
  private global::InventoryBase extendedMenu;
  private Vector2 extendedFrameSize,extendedTextSize;
  private bool InventoryWheelEligible(global::InventoryBase v){return v!=null&&!global::InventoryBase.storeMode&&!v.combineMode&&v.intItem!=null&&InventoryWheelPolicy.Allowed(v.intItem._item.ToString())&&QuickCount(v.intItem)>0;}
  private void InstallInventoryWheel(){inventoryWheelOwner=this;InventoryWheelPolicy.Normalize(quickSlots);var h=new HarmonyLib.Harmony("signalis.vr.inventory.wheel");h.Patch(AccessTools.Method(typeof(global::InventoryBase),"ToggleInteractMenu"),prefix:new HarmonyMethod(typeof(Tracking),nameof(InventoryWheelToggle)),postfix:new HarmonyMethod(typeof(Tracking),nameof(InventoryWheelMenuOpened)));h.Patch(AccessTools.Method(typeof(global::InventoryBase),"InteractMenu"),prefix:new HarmonyMethod(typeof(Tracking),nameof(InventoryWheelMenu)));h.Patch(AccessTools.Method(typeof(global::InventoryBase),"Update"),prefix:new HarmonyMethod(typeof(Tracking),nameof(InventoryWheelUpdate)));h.Patch(AccessTools.Method(typeof(global::InventoryBase),"OnDisable"),prefix:new HarmonyMethod(typeof(Tracking),nameof(InventoryWheelDisabled)));}
  private bool InventoryWheelAccept(){return (questFrame.buttons&1)!=0||Input.GetKey(KeyCode.Return);}
  private bool InventoryWheelCancel(){return (questFrame.buttons&2)!=0||Input.GetKey(KeyCode.Escape);}
  private float InventoryWheelX(){return questFrame.uiX+(Input.GetKey(KeyCode.RightArrow)?1:0)-(Input.GetKey(KeyCode.LeftArrow)?1:0);}
  private float InventoryWheelY(){return questFrame.uiY+(Input.GetKey(KeyCode.UpArrow)?1:0)-(Input.GetKey(KeyCode.DownArrow)?1:0);}
  private static bool InventoryWheelToggle(global::InventoryBase __instance){var o=inventoryWheelOwner;if(o==null||o.inventoryWheelNativeClosing)return true;if(__instance.intMenuOn&&o.InventoryWheelEligible(__instance)&&__instance.intMenuChoice==3){o.OpenInventoryWheel(__instance);return false;}return true;}
  private static void InventoryWheelMenuOpened(global::InventoryBase __instance){var o=inventoryWheelOwner;if(o==null)return;if(__instance.intMenuOn&&o.InventoryWheelEligible(__instance)&&o.inventoryWheelView==null){o.RestoreInventoryActionFrame();o.extendedMenu=__instance;o.extendedFrameSize=__instance.IntMenuFrameRect.sizeDelta;o.extendedTextSize=__instance.IntMenuText.rectTransform.sizeDelta;var size=o.extendedFrameSize;size.y*=4f/3f;size.x=Math.Max(size.x,__instance.IntMenuText.fontSize*11f);__instance.IntMenuFrameRect.sizeDelta=size;__instance.IntMenuText.rectTransform.sizeDelta=size;o.DrawInventoryActions(__instance);}else o.RestoreInventoryActionFrame();}
  private void RestoreInventoryActionFrame(){if(extendedMenu!=null){extendedMenu.IntMenuFrameRect.sizeDelta=extendedFrameSize;extendedMenu.IntMenuText.rectTransform.sizeDelta=extendedTextSize;}extendedMenu=null;}
  private void DrawInventoryActions(global::InventoryBase v){var s=new StringBuilder();for(int i=0;i<4;i++){if(i>0)s.Append('\n');if(i==v.intMenuChoice)s.Append("<color=#FF6500>");s.Append(i==3?"Add To Item Wheel":v.intChoices[i]);if(i==v.intMenuChoice)s.Append("</color>");}v.IntMenuText.text=s.ToString();}
  private static bool InventoryWheelMenu(global::InventoryBase __instance){var o=inventoryWheelOwner;if(o==null||!o.InventoryWheelEligible(__instance))return true;int move=o.inventoryWheelNavigation.Navigate(o.InventoryWheelY(),Time.realtimeSinceStartup);__instance.intMenuChoice=(__instance.intMenuChoice+move+4)%4;o.DrawInventoryActions(__instance);return false;}
  private void OpenInventoryWheel(global::InventoryBase v){RestoreInventoryActionFrame();inventoryWheelView=v;inventoryWheelItem=v.intItem;inventoryWheelSlot=0;inventoryWheelConfirmHeld=InventoryWheelAccept();inventoryWheelCancelHeld=InventoryWheelCancel();inventoryWheelName=v.itemName.text;inventoryWheelDescriptionEnabled=v.itemDescription.enabled;inventoryWheelNativeClosing=true;try{v.ToggleInteractMenu();}finally{inventoryWheelNativeClosing=false;}v.itemName.text="Choose Slot";v.itemDescription.enabled=false;
   inventoryWheelRoot=new GameObject("InventoryWheelSlots");var root=inventoryWheelRoot.AddComponent<RectTransform>();root.SetParent(v.itemDescription.rectTransform,false);root.anchorMin=Vector2.zero;root.anchorMax=Vector2.one;root.offsetMin=Vector2.zero;root.offsetMax=Vector2.zero;inventoryWheelRoot.layer=v.itemDescription.gameObject.layer;
   float size=Math.Min(v.itemDescription.rectTransform.rect.width,v.itemDescription.rectTransform.rect.height)/3.3f;Vector2[] positions={new Vector2(.5f,.82f),new Vector2(.82f,.5f),new Vector2(.5f,.18f),new Vector2(.18f,.5f)};
   for(int i=0;i<4;i++){var frame=InventoryWheelImage(root,"Slot"+i,positions[i],new Vector2(size,size));inventoryWheelFrames[i]=frame;var inner=InventoryWheelImage(frame.rectTransform,"Background",new Vector2(.5f,.5f),new Vector2(size-4,size-4));inner.color=Color.black;var icon=InventoryWheelImage(inner.rectTransform,"Item",new Vector2(.5f,.5f),new Vector2(size-12,size-12));icon.preserveAspect=true;inventoryWheelIcons[i]=icon;}
   DrawInventoryWheel();
  }
  private Image InventoryWheelImage(RectTransform parent,string name,Vector2 anchor,Vector2 size){var go=new GameObject(name);go.layer=parent.gameObject.layer;go.AddComponent<RectTransform>();var im=go.AddComponent<Image>();im.raycastTarget=false;var r=im.rectTransform;r.SetParent(parent,false);r.anchorMin=r.anchorMax=anchor;r.pivot=new Vector2(.5f,.5f);r.anchoredPosition=Vector2.zero;r.sizeDelta=size;return im;}
  private void DrawInventoryWheel(){for(int i=0;i<4;i++){inventoryWheelFrames[i].color=i==inventoryWheelSlot?new Color(1,.4f,0):Color.gray;var item=QuickItem(i);inventoryWheelIcons[i].sprite=item==null?null:item.Icon;inventoryWheelIcons[i].color=Color.white;inventoryWheelIcons[i].enabled=inventoryWheelIcons[i].sprite!=null;}}
  private void CloseInventoryWheel(){if(inventoryWheelRoot!=null)UnityEngine.Object.Destroy(inventoryWheelRoot);inventoryWheelRoot=null;if(inventoryWheelView!=null){inventoryWheelView.itemName.text=inventoryWheelName;inventoryWheelView.itemDescription.enabled=inventoryWheelDescriptionEnabled;}inventoryWheelView=null;inventoryWheelItem=null;}
  private static void InventoryWheelDisabled(global::InventoryBase __instance){var o=inventoryWheelOwner;if(o==null)return;if(o.inventoryWheelView==__instance)o.CloseInventoryWheel();if(o.extendedMenu==__instance)o.RestoreInventoryActionFrame();}
  private static bool InventoryWheelUpdate(global::InventoryBase __instance){var o=inventoryWheelOwner;if(o==null)return true;if(o.extendedMenu==__instance&&!__instance.intMenuOn)o.RestoreInventoryActionFrame();if(o.inventoryWheelView!=__instance)return true;if(!__instance.inventoryOpen||o.inventoryWheelItem==null||o.QuickCount(o.inventoryWheelItem)<=0){o.CloseInventoryWheel();return true;}bool a=o.InventoryWheelAccept(),b=o.InventoryWheelCancel();bool confirm=a&&!o.inventoryWheelConfirmHeld,cancel=b&&!o.inventoryWheelCancelHeld;o.inventoryWheelConfirmHeld=a;o.inventoryWheelCancelHeld=b;int d=WheelInventoryPicker.Direction(o.InventoryWheelX(),o.InventoryWheelY());if(d>=0)o.inventoryWheelSlot=d;o.DrawInventoryWheel();if(cancel){o.CloseInventoryWheel();return false;}if(confirm){var old=(string[])o.quickSlots.Clone();try{InventoryWheelPolicy.Assign(o.quickSlots,o.inventoryWheelSlot,o.inventoryWheelItem._item.ToString());o.SaveModSettings();o.CloseInventoryWheel();}catch(Exception ex){o.quickSlots=old;__instance.itemName.text="Could not save - press A to retry";MelonLoader.MelonLogger.Warning("Inventory wheel save: "+ex.Message);}}return false;}
 }
}
