$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'SmgChargingTravel.cs'),(Join-Path $PSScriptRoot 'ManualReloadPolicy.cs')
foreach($approach in @(0,.02,.08)){
 foreach($stroke in @(0,.003,.015,.03)){
  $t=[SignalisVrTracking.SmgChargingTravel]::new();$p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.MinimumPull=.006;$p.MaximumPull=.03;$p.BeginRack(0);$t.Begin(.1)
  $p.Tick(.1,$true,$true,$false,$false,$false,$t.Pull(.1+$approach))|Out-Null
  $p.Tick(.2,$true,$true,$false,$false,$false,$t.Pull(.1+$approach-$stroke))|Out-Null
  $p.Tick(.3,$true,$true,$false,$false,$false,$t.Pull(.1+$approach))|Out-Null
  if($p.Tick(.4,$true,$false,$false,$false,$false,$t.Pull(.1+$approach)) -ne ($stroke -ge .006)){throw 'Approach then pull/return lost stroke'}
 }
}
$t=[SignalisVrTracking.SmgChargingTravel]::new();$t.Begin(.1);if(![float]::IsNaN($t.Pull(1))){throw 'Tracking teleport counted as pull'}
$s=Get-Content (Join-Path $PSScriptRoot 'AdditionalGunReload.cs') -Raw
if(!$s.Contains('rawControllerPositions[0]-rawControllerPositions[1]')){throw 'SMG travel is not relative raw tracking'}
$surf=Get-Content (Join-Path $PSScriptRoot 'ProdSurface.cs') -Raw
if($surf.Contains('copy.Source.BakeMesh') -or !$surf.Contains('Vector3[] vertices=mesh.vertices;int[] indices=mesh.triangles;') -or !$surf.Contains('bounds.Intersects(prodQueryBounds)')){throw 'Prod expensive per-vertex interop/duplicate bake regression'}
$hud=Get-Content (Join-Path $PSScriptRoot 'ModHud.cs') -Raw
if(!$hud.Contains('ProdSelected()&&!ProdHandOccupied()')){throw 'Hidden prod leaking into melee HUD'}
'PASS approach/pull/return and jitter/teleport rejection; raw-relative travel wiring; prod broad culling/managed arrays/bake reuse; occupied-hand HUD guard.'
