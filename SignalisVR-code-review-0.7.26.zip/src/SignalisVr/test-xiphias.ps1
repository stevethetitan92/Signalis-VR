$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'XiphiasData.cs') -Raw
$encoded=[regex]::Match($s,'Geometry="([^"]+)"').Groups[1].Value
$r=[IO.BinaryReader]::new([IO.MemoryStream]::new([Convert]::FromBase64String($encoded)))
$count=$r.ReadInt32();$roles=@(0,0,0,0);$tris=0
for($p=0;$p -lt $count;$p++){
 $role=$r.ReadInt32();$mat=$r.ReadInt32();$nv=$r.ReadInt32();$nt=$r.ReadInt32()
 if($role -lt 0 -or $role -gt 3 -or $mat -lt 0 -or $mat -gt 5 -or $nv -le 0 -or $nt%3){throw 'Invalid imported mesh record'}
 $roles[$role]++;$tris+=$nt/3
 for($k=0;$k -lt $nv*5;$k++){$f=$r.ReadSingle();if([float]::IsNaN($f)-or[float]::IsInfinity($f)){throw 'Nonfinite vertex/UV'}}
 for($k=0;$k -lt $nt;$k++){$index=$r.ReadInt32();if($index -lt 0 -or $index -ge $nv){throw 'Index outside imported vertex buffer'}}
}
if($roles[3] -ne 1 -or $roles[1] -ne 1 -or $roles[2] -ne 1 -or $roles[0] -lt 1 -or $tris -ne 9503 -or $r.BaseStream.Position -ne $r.BaseStream.Length){throw 'Missing/repeated moving parts or incomplete asset decode'}
$r.Dispose()
Add-Type -Path (Join-Path $PSScriptRoot 'QuestInputPolicy.cs')
# Existing stats and manual-reload fixtures exercise native fullAuto configuration,
# ammo preservation and pull-release completion separately.
'PASS: Xiphias binary geometry, finite vertices/UVs, material/index ranges, separate magazine/handle, 9503 source triangles; rendered alignment unverified.'
