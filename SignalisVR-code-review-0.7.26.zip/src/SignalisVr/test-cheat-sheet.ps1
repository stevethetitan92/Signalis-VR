$ErrorActionPreference='Stop'
$art=Get-Content (Join-Path $PSScriptRoot 'CheatSheetArtwork.cs') -Raw
$bytes=[Convert]::FromBase64String([regex]::Match($art,'Png="([^"]+)"').Groups[1].Value)
$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))
if($hash -ne '0A2A890B7A78DB8AB774FD01910A48B1E6FF065E3914928D69D4E07D0C3B4279'){throw 'Cheat sheet differs from original supplied PNG'}
$s=Get-Content (Join-Path $PSScriptRoot 'CheatSheetTab.cs') -Raw
foreach($needle in @('if(i!=7)','if(modMenuSelection==7)DrawCheatSheetImage','float fit=Math.Min(area.width/cheatSheetTexture.width,area.height/cheatSheetTexture.height)','DestroyCheatSheet()')){if(!$s.Contains($needle)){throw "Missing preview behavior: $needle"}}
$menu=Get-Content (Join-Path $PSScriptRoot 'ModMenu.cs') -Raw
$start=$menu.IndexOf('   if(modMenuCheats) {')
$end=$menu.IndexOf('   switch(index)', $start)
$method=$menu.Substring($start,$end-$start)
if($method.Contains('index==7') -or !$method.Contains('index==8') -or !$method.Contains('index==9')){throw 'Read-only sheet row activated a setting or displaced Back/Done'}
'PASS supplied PNG exact hash, read-only row routing, selection-driven preview, aspect preservation and cleanup source guards. Headset readability unverified.'


