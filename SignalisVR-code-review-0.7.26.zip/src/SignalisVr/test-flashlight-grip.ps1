$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'FlashlightPlacement.cs') -Raw
$grip=Get-Content (Join-Path $PSScriptRoot 'FlashlightGrip.cs') -Raw
$files=Get-Content (Join-Path $PSScriptRoot 'source-files.txt')
if($source.Contains('LEFT HAND') -or $source.Contains('ShowFlashlightGrip') -or $grip.Contains('FlashlightGripData') -or $files -contains 'FlashlightGripData.cs'){throw 'Left-hand flashlight remains compiled or reachable'}
if(!$source.Contains('{"OFF","HEAD","UNDER BARREL"}') -or !$source.Contains('SuppressHandFlashlight(model,holder)')){throw 'Off/head/underbarrel options missing'}
'PASS removed left flashlight mesh and entry point; off suppresses native flashlight.'
