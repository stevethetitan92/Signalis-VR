$ErrorActionPreference='Stop'
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
function AllTypes($types){foreach($t in $types){$t;AllTypes $t.NestedTypes}}
try {
 foreach($t in (AllTypes $a.MainModule.Types)) {
  foreach($f in $t.Fields){if($f.Name -eq 'infiniteStamina' -or $f.Name -eq 'InfiniteStamina'){throw 'Stamina cheat state still compiled'}}
  foreach($m in $t.Methods){
   if($m.Name -eq 'FillCheatStamina'){throw 'Stamina fill hook still compiled'}
   if(!$m.HasBody){continue}
   foreach($i in $m.Body.Instructions){
    if($i.Operand -is [Mono.Cecil.MethodReference] -and $i.Operand.DeclaringType.FullName -eq 'PlayerAttack' -and $i.Operand.Name -eq 'set_Stamina'){throw ('Compiled stamina write remains in '+$m.FullName)}
    if($i.OpCode.Name -eq 'ldstr' -and $i.Operand -eq 'Infinite Stamina'){throw 'Stamina menu label remains'}
   }
  }
 }
}finally{$a.Dispose()}
Add-Type -Path (Join-Path $PSScriptRoot 'ModSettingsFile.cs')
$dir=Join-Path $PSScriptRoot 'settings-test-data';New-Item -ItemType Directory -Force $dir | Out-Null
$path=Join-Path $dir 'legacy-stamina-removal.settings'
[IO.File]::WriteAllLines($path,@('InfiniteStamina=True','Lasers=False','InfiniteAmmo=True','MiniMap=True','AlyxWheel=True','WheelSlot0=Pistol'))
$s=[SignalisVrTracking.ModSettingsFile]::Load($path)
if($s.Lasers -or !$s.InfiniteAmmo -or !$s.MiniMap -or !$s.AlyxWheel -or $s.WheelSlots[0] -ne 'Pistol'){throw 'Legacy migration changed unrelated choices'}
$s.Save($path)
if((Get-Content $path -Raw).Contains('InfiniteStamina')){throw 'Removed setting persisted'}
'PASS compiled assembly has no stamina cheat state, fill hook, native stamina setter or menu label. Legacy InfiniteStamina=True ignored and omitted on save; unrelated settings retained.'
'Native stamina is untouched by this build. Door success and graphics still require runtime confirmation.'
