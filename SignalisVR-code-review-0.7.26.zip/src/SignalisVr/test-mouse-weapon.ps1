$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'MouseWeaponTest.cs') -Raw
$policy=$source.Substring($source.IndexOf(' internal static class MouseWeaponPolicy'))
$method=[regex]::Match($source,'(?s)private void RestoreMouseWeaponCamera\(\).*?\r?\n  \}').Value
$code=@'
using System;
public class Camera {public int cullingMask;}
public class WeaponPoseScope {public int restores; public bool fail;public void Restore(){restores++;if(fail)throw new Exception("injected");}}
namespace Test {
'@
$checks=@'
public class Cleanup {
 Camera mouseRenderCamera;WeaponPoseScope mouseRenderScope;int mouseCameraMask,hides;
 void HideRifleImpacts(){hides++;}
 METHOD
 public static void Run(){foreach(bool fail in new[]{false,true}){
  var cam=new Camera{cullingMask=1<<30};var scope=new WeaponPoseScope{fail=fail};
  var c=new Cleanup{mouseRenderCamera=cam,mouseRenderScope=scope,mouseCameraMask=23};
  try{c.RestoreMouseWeaponCamera();}catch(Exception){if(!fail)throw;}
  if(cam.cullingMask!=23||c.mouseRenderCamera!=null||c.mouseRenderScope!=null||scope.restores!=1||c.hides!=1)throw new Exception("Cleanup failed");
  c.RestoreMouseWeaponCamera();if(scope.restores!=1||c.hides!=1)throw new Exception("Repeated cleanup");
 }}
}
public static class Cases {
 public static string Run(){int eligible=0;for(int i=0;i<128;i++){
  bool actual=MouseWeaponPolicy.Ready((i&1)!=0,(i&2)!=0,(i&4)!=0,(i&8)!=0,(i&16)!=0,(i&32)!=0,(i&64)!=0);
  if(actual)eligible++;
  if(actual!=(i==93))throw new Exception("Unsafe eligibility: "+i);
 }if(eligible!=1)throw new Exception("No eligible state");Cleanup.Run();return "PASS: 128 mouse-mode gate combinations, camera-mask/pose cleanup on success/failure and repeated cleanup. Runtime remains unverified.";}
}
'@
$checks=$checks.Replace('METHOD',$method)
# The source policy includes the namespace closing brace; checks go before it.
Add-Type -TypeDefinition ($code+$checks+$policy)
[Test.Cases]::Run()
