using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private sealed class EnemyEyeCopy {public SkinnedMeshRenderer Source;public Mesh Original,Mesh;public MeshRenderer View;public Material[] Materials;public int[][] Triangles;public Color[] Colors;public int Frame=-1;}
 private readonly Dictionary<int,EnemyEyeCopy> enemyEyeCopies=new Dictionary<int,EnemyEyeCopy>();
 private readonly List<MeshRenderer> enemyEyeVisible=new List<MeshRenderer>();
 private readonly Dictionary<SkinnedMeshRenderer,bool> enemyEyeEnabled=new Dictionary<SkinnedMeshRenderer,bool>();
 private readonly Dictionary<Animator,AnimatorCullingMode> enemyAnimationModes=new Dictionary<Animator,AnimatorCullingMode>();
 private readonly Dictionary<SkinnedMeshRenderer,bool> enemyOffscreenModes=new Dictionary<SkinnedMeshRenderer,bool>();
 private global::Room eyeEnemyRoom;
 private SkinnedMeshRenderer[] eyeEnemySkins;private float nextEyeEnemyScan;
 private void InstallEnemyEyeLifecycle(){
  var h=new HarmonyLib.Harmony("signalis.vr.enemy.eye.lifecycle");
  foreach(var name in new[]{"OnEnable","Load"})h.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(global::EnemyController),name),postfix:new HarmonyLib.HarmonyMethod(typeof(Tracking),nameof(EnemyEyeActivated)));
 }
 private static void EnemyEyeActivated(){var q=questOwner;if(q!=null)q.nextEyeEnemyScan=0;}
 private void PrepareEnemyEyeMaterials(){
  if(eyeEnemySkins==null||eyeEnemyRoom!=global::PlayerState.currentRoom||Time.realtimeSinceStartup>=nextEyeEnemyScan){
   eyeEnemyRoom=global::PlayerState.currentRoom;
   var found=new List<SkinnedMeshRenderer>();
   foreach(var enemy in Resources.FindObjectsOfTypeAll<global::EnemyController>())if(enemy!=null&&!OwnsTestEnemy(enemy)&&enemy.gameObject.scene.IsValid())
   {
    foreach(var skin in enemy.GetComponentsInChildren<SkinnedMeshRenderer>(true)){if(!found.Contains(skin))found.Add(skin);}}
   eyeEnemySkins=found.ToArray();nextEyeEnemyScan=Time.realtimeSinceStartup+2f;
   var stale=new List<int>();foreach(var entry in enemyEyeCopies)if(entry.Value.Source==null)stale.Add(entry.Key);
   foreach(var key in stale){DestroyEnemyEyeCopy(enemyEyeCopies[key]);enemyEyeCopies.Remove(key);}
  }
  foreach(var renderer in eyeEnemySkins){
   if(renderer==null||!renderer.enabled||!renderer.gameObject.activeInHierarchy||renderer.sharedMesh==null)continue;
   var owner=MapOwner(renderer.transform);if(owner!=null&&global::PlayerState.currentRoom!=null&&!MapSameRoom(owner,global::PlayerState.currentRoom))continue;
   if((renderer.bounds.center-stereoPosition).sqrMagnitude>Mathf.Pow(20f*UnitsPerMetre,2))continue;
   var enemy=renderer.GetComponentInParent<global::EnemyController>();if(enemy!=null&&enemy.BurnEffect!=null&&enemy.BurnEffect.burning)continue;
   var originals=renderer.sharedMaterials;bool body=false,overlay=false;
   foreach(var m in originals)if(m!=null&&m.shader!=null){body|=TestEnemyMaterialPolicy.Body(m.shader.name,m.GetTag("RenderType",false,""),m.renderQueue,m.mainTexture!=null);overlay|=TestEnemyMaterialPolicy.Overlay(m.shader.name);}
   if(body){foreach(var m in originals)if(m==null||m.mainTexture==null){body=false;break;}}
   if(!body){if(overlay){enemyEyeEnabled[renderer]=renderer.enabled;renderer.enabled=false;}continue;}
   int id=renderer.GetInstanceID();EnemyEyeCopy c;
   if(enemyEyeCopies.TryGetValue(id,out c)&&(c.Original!=renderer.sharedMesh||c.Materials.Length!=originals.Length)){DestroyEnemyEyeCopy(c);enemyEyeCopies.Remove(id);c=null;}
   if(c==null){
    var shader=Shader.Find("Unlit/Texture");if(shader==null)continue;
    c=new EnemyEyeCopy{Source=renderer,Original=renderer.sharedMesh,Mesh=new Mesh(),Materials=new Material[originals.Length]};enemyEyeCopies[id]=c;
    var go=new GameObject("SignalisVR_EnemyBaked_"+renderer.name);go.layer=0;
    c.View=go.AddComponent<MeshRenderer>();c.View.enabled=false;c.View.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;go.AddComponent<MeshFilter>().sharedMesh=c.Mesh;
    for(int i=0;i<originals.Length;i++){var m=new Material(shader);c.Materials[i]=m;if(originals[i]!=null){m.mainTexture=originals[i].mainTexture;m.mainTextureScale=originals[i].mainTextureScale;m.mainTextureOffset=originals[i].mainTextureOffset;}}
    c.View.sharedMaterials=c.Materials;c.Triangles=new int[c.Original.subMeshCount][];
    for(int sub=0;sub<c.Triangles.Length;sub++)c.Triangles[sub]=HandSurfaceTopology.DoubleSided(c.Original.GetTriangles(sub));
    MelonLoader.MelonLogger.Msg("ENEMY BAKED EYE: "+renderer.name+" uses calibration body rendering; native AI retained.");
   }
   // Same baked, white-vertex, double-sided texture path as the calibration target.
   if(c.Frame!=Time.frameCount){c.Frame=Time.frameCount;
   for(int i=0;i<c.Materials.Length&&i<originals.Length;i++)if(originals[i]!=null){c.Materials[i].mainTexture=originals[i].mainTexture;c.Materials[i].mainTextureScale=originals[i].mainTextureScale;c.Materials[i].mainTextureOffset=originals[i].mainTextureOffset;}
   renderer.BakeMesh(c.Mesh);
   if(c.Colors==null||c.Colors.Length!=c.Mesh.vertexCount){c.Colors=new Color[c.Mesh.vertexCount];for(int i=0;i<c.Colors.Length;i++)c.Colors[i]=Color.white;}
   c.Mesh.colors=c.Colors;for(int sub=0;sub<c.Triangles.Length;sub++)c.Mesh.SetTriangles(c.Triangles[sub],sub);c.Mesh.RecalculateBounds();}
   c.View.transform.SetPositionAndRotation(renderer.transform.position,renderer.transform.rotation);c.View.transform.localScale=renderer.transform.lossyScale;
   enemyEyeEnabled[renderer]=renderer.enabled;renderer.enabled=false;enemyEyeVisible.Add(c.View);c.View.enabled=true;
  }
 }
 private void RestoreEnemyEyeMaterials(){foreach(var view in enemyEyeVisible)if(view!=null)view.enabled=false;enemyEyeVisible.Clear();foreach(var pair in enemyEyeEnabled)if(pair.Key!=null)pair.Key.enabled=pair.Value;enemyEyeEnabled.Clear();}
 private void DestroyEnemyEyeCopy(EnemyEyeCopy c){if(c.View!=null)UnityEngine.Object.Destroy(c.View.gameObject);if(c.Mesh!=null)UnityEngine.Object.Destroy(c.Mesh);foreach(var m in c.Materials)if(m!=null)UnityEngine.Object.Destroy(m);}
 private void DestroyEnemyEyeMaterials(){RestoreEnemyEyeMaterials();foreach(var pair in enemyAnimationModes)if(pair.Key!=null)pair.Key.cullingMode=pair.Value;enemyAnimationModes.Clear();foreach(var pair in enemyOffscreenModes)if(pair.Key!=null)pair.Key.updateWhenOffscreen=pair.Value;enemyOffscreenModes.Clear();foreach(var c in enemyEyeCopies.Values)DestroyEnemyEyeCopy(c);enemyEyeCopies.Clear();eyeEnemySkins=null;nextEyeEnemyScan=0;}
}}

