$ErrorActionPreference='Stop'
# Compile the actual production helper against a numerical Unity Frustum stub.
$stub=@"
namespace UnityEngine {
 public struct Matrix4x4 {
  public float m00,m02,m11,m12;
  public static Matrix4x4 Frustum(float l,float r,float b,float t,float n,float f) {
   return new Matrix4x4 {m00=2*n/(r-l),m02=(r+l)/(r-l),m11=2*n/(t-b),m12=(t+b)/(t-b)};
  }
 }
}
"@
Add-Type -TypeDefinition ($stub+[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'EyeProjection.cs')).Replace('using UnityEngine;','').Replace('Matrix4x4','UnityEngine.Matrix4x4'))
$count=0
foreach($eye in @(@(-1.27994,.90040,-1.19175,1.11061),@(-.90040,1.27994,-1.19175,1.11061),@(-1,1,-1,1),@(-.8,1.3,-.7,1.4))) {
 foreach($near in @(.01,.05,.3,1)) {
  $l,$r,$t,$b=$eye
  $m=[SignalisVrTracking.EyeProjection]::FromRaw($l,$r,$t,$b,$near,1000)
  # Independent Valve ComposeProjection x/y coefficients (depth conventions differ).
  $expected=@((2/($r-$l)),(($r+$l)/($r-$l)),(2/($b-$t)),(($b+$t)/($b-$t)))
  $actual=@($m.m00,$m.m02,$m.m11,$m.m12)
  for($i=0;$i -lt 4;$i++){if([Math]::Abs($actual[$i]-$expected[$i]) -gt .00001){throw 'OpenVR projection coefficient mismatch'}}
  # Rays on each frustum boundary must map to -1/+1; optical center must retain its asymmetry.
  if([Math]::Abs($m.m00*$l-$m.m02+1) -gt .00001 -or [Math]::Abs($m.m00*$r-$m.m02-1) -gt .00001){throw 'Horizontal boundary mapping failed'}
  if([Math]::Abs($m.m11*$t-$m.m12+1) -gt .00001 -or [Math]::Abs($m.m11*$b-$m.m12-1) -gt .00001){throw 'Vertical boundary mapping failed'}
  $count++
 }
}
# Ensure the former mirrored-center implementation would be detected by asymmetric fixtures.
$t=-1.19175;$b=1.11061
if([Math]::Abs((-$b-$t)/(-$t+$b)-($b+$t)/($b-$t)) -lt .05){throw 'Regression fixture not sensitive to former sign error'}
"PASS: $count production projection cases match Valve coefficients and boundary rays; former offset sign error detected. Numerical tests, not headset validation."
