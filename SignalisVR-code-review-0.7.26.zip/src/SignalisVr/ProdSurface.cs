using System;
using UnityEngine;
namespace SignalisVrTracking {
 public static class ProdSurfaceGeometry {
  public static float Segment(Vector3 start,Vector3 end,Vector3 a,Vector3 b,Vector3 c){
   var d=end-start;var e=b-a;var f=c-a;var h=Vector3.Cross(d,f);float det=Vector3.Dot(e,h);
   if(Math.Abs(det)<1e-12f)return 1f;
   var s=start-a;float u=Vector3.Dot(s,h)/det;if(u<0||u>1)return 1f;
   var q=Vector3.Cross(s,e);float v=Vector3.Dot(d,q)/det;if(v<0||u+v>1)return 1f;
   float t=Vector3.Dot(f,q)/det;return t>=0&&t<=1?t:1f;
  }
  public static Vector3 Closest(Vector3 p,Vector3 a,Vector3 b,Vector3 c){
   var ab=b-a;var ac=c-a;var ap=p-a;float d1=Vector3.Dot(ab,ap),d2=Vector3.Dot(ac,ap);
   if(d1<=0&&d2<=0)return a;
   var bp=p-b;float d3=Vector3.Dot(ab,bp),d4=Vector3.Dot(ac,bp);if(d3>=0&&d4<=d3)return b;
   float vc=d1*d4-d3*d2;if(vc<=0&&d1>=0&&d3<=0)return a+ab*(d1/(d1-d3));
   var cp=p-c;float d5=Vector3.Dot(ab,cp),d6=Vector3.Dot(ac,cp);if(d6>=0&&d5<=d6)return c;
   float vb=d5*d2-d1*d6;if(vb<=0&&d2>=0&&d6<=0)return a+ac*(d2/(d2-d6));
   float va=d3*d6-d5*d4;if(va<=0&&d4-d3>=0&&d5-d6>=0)return b+(c-b)*((d4-d3)/((d4-d3)+(d5-d6)));
   float denom=va+vb+vc;if(Math.Abs(denom)<1e-20f)return a;
   return a+ab*(vb/denom)+ac*(vc/denom);
  }
 }
 public sealed partial class Tracking {
  private struct ProdFace {public Vector3 a,b,c;public global::EnemyController enemy;}
  private readonly System.Collections.Generic.List<ProdFace> prodFaces=new System.Collections.Generic.List<ProdFace>();
  private Mesh prodSurfaceBake;
  private Bounds prodQueryBounds;
  private void AddProdSurface(Mesh mesh,Transform frame,global::EnemyController enemy){
   Vector3[] vertices=mesh.vertices;int[] indices=mesh.triangles;var matrix=frame.localToWorldMatrix;
   for(int i=0;i<vertices.Length;i++)vertices[i]=matrix.MultiplyPoint3x4(vertices[i]);
   for(int i=0;i+2<indices.Length;i+=3){var a=vertices[indices[i]];var b=vertices[indices[i+1]];var c=vertices[indices[i+2]];
    var bounds=new Bounds(a,Vector3.zero);bounds.Encapsulate(b);bounds.Encapsulate(c);
    if(bounds.Intersects(prodQueryBounds)&&Vector3.Cross(b-a,c-a).sqrMagnitude>1e-16f)prodFaces.Add(new ProdFace{a=a,b=b,c=c,enemy=enemy});
   }
  }
  private void GatherProdSurfaces(Vector3 position,Quaternion rotation){
   prodQueryBounds=new Bounds(position,Vector3.zero);prodQueryBounds.Encapsulate(position+rotation*Vector3.forward*(.27438f*UnitsPerMetre));
   if(prodPoseValid){prodQueryBounds.Encapsulate(prodResolved);prodQueryBounds.Encapsulate(prodResolved+prodResolvedRotation*Vector3.forward*(.27438f*UnitsPerMetre));}
   prodQueryBounds.Expand(.05f*UnitsPerMetre);
   prodFaces.Clear();var seen=new System.Collections.Generic.HashSet<IntPtr>();
   foreach(var collider in Physics.OverlapSphere(position+rotation*Vector3.forward*(.15f*UnitsPerMetre),.65f*UnitsPerMetre,-1,QueryTriggerInteraction.Collide)){
    var enemy=collider.GetComponentInParent<global::EnemyController>();if(!ProdEnemyValid(enemy)||!seen.Add(enemy.Pointer))continue;
    if(OwnsTestEnemy(enemy)){
     foreach(var copy in testBodyCopies)if(copy.Source!=null&&copy.View!=null&&copy.View.enabled){
      // Reuse the mesh already baked for the visible test body.
      AddProdSurface(copy.Mesh,copy.View.transform,enemy);
     }
    }else foreach(var skin in enemy.GetComponentsInChildren<SkinnedMeshRenderer>()){
     if(!skin.enabled||!skin.gameObject.activeInHierarchy||skin.sharedMesh==null)continue;
     bool body=false;foreach(var material in skin.sharedMaterials)if(material!=null&&material.shader!=null)
      body|=TestEnemyMaterialPolicy.Body(material.shader.name,material.GetTag("RenderType",false,""),material.renderQueue,material.mainTexture!=null);
     if(!body)continue;if(prodSurfaceBake==null)prodSurfaceBake=new Mesh();skin.BakeMesh(prodSurfaceBake);AddProdSurface(prodSurfaceBake,skin.transform,enemy);
    }
   }
  }
  private void ResolveProdSurface(ref Vector3 position,Quaternion rotation){
   // Trace each electrode from the grip to its visible tip. Broad enemy capsules
   // only collect candidates; they never stop the prod or authorize a stun.
   float fraction=1;var forward=rotation*Vector3.forward;
   foreach(float x in new[]{-.0175f,.0175f}){
    var start=position+rotation*new Vector3(x,0,0)*UnitsPerMetre;var end=start+forward*(.27438f*UnitsPerMetre);
    foreach(var face in prodFaces)fraction=Math.Min(fraction,ProdSurfaceGeometry.Segment(start,end,face.a,face.b,face.c));
   }
   if(fraction<1)position-=forward*((.27438f*(1-fraction)+.0005f)*UnitsPerMetre);
  }
  private bool ProdSurfaceTouch(global::EnemyController enemy,Vector3 tip){
   float tolerance=.002f*UnitsPerMetre;
   foreach(var face in prodFaces)if(face.enemy.Pointer==enemy.Pointer&&(ProdSurfaceGeometry.Closest(tip,face.a,face.b,face.c)-tip).sqrMagnitude<=tolerance*tolerance)return true;
   return false;
  }
 }
}
