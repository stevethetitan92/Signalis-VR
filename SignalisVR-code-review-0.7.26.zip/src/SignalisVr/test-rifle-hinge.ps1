$ErrorActionPreference='Stop'
Add-Type -Path @((Join-Path $PSScriptRoot 'RifleBarrelMotion.cs'),(Join-Path $PSScriptRoot 'RifleHingePolicy.cs'))
function Check($v,$m){if(-not $v){throw $m}}
foreach($hz in @(30,72,90,144)){
 $p=[SignalisVrTracking.RifleHingePolicy]::new()
 for($i=0;$i -lt $hz*2;$i++){$a=$p.Tick(1.0/$hz,$true,$false,0,-1,0,0);Check ($a -ge 0 -and $a -le 65) 'Hinge outside stops'}
 Check ($a -gt 64.9) 'Gravity did not open barrels'
 Check ($p.Tick(1.0/$hz,$true,$true,17,-1,0,0) -eq 17) 'Hand angle did not control hinge'
 Check ($p.Tick(1.0/$hz,$true,$true,99,-1,0,0) -eq 65) 'Hand crossed hinge stop'
 for($i=0;$i -lt $hz*2;$i++){$a=$p.Tick(1.0/$hz,$true,$false,0,1,0,0)}
 Check ($a -lt 1) 'Inverted gravity did not swing barrels back'
 $p.Tick(1.0/$hz,$true,$true,28,-1,0,0)|Out-Null
 for($i=0;$i -le [Math]::Ceiling(.24*$hz);$i++){$old=$p.Angle;$a=$p.Tick(1.0/$hz,$false,$false,0,-1,0,0);Check ($a -le $old -and $a -ge 0) 'Close was not monotonic'}
 Check ($a -eq 0) 'Did not latch closed'
 $p.Reset();Check ($p.Angle -eq 0) 'Reset failed'
}
'PASS: gravity swing, inversion, grip override, hinge limits, smooth close and reset at 30–144Hz.'
$flare=[SignalisVrTracking.RifleHingePolicy]::new()
$flare.TravelLimit=40
for($i=0;$i -lt 144;$i++){$a=$flare.Tick(1.0/72,$true,$false,0,-1,0,0)}
Check ($a -eq 40) 'Flare barrel exceeded its authored 40-degree stop'
Check ($flare.Tick(1.0/72,$true,$true,16,-1,0,0) -eq 16) 'Flare barrel did not follow hand toward closure'
Check ($flare.Tick(1.0/72,$true,$true,4,-1,0,0) -eq 4) 'Flare barrel cannot reach latch zone'
for($i=0;$i -lt 20;$i++){$a=$flare.Tick(1.0/72,$false,$false,0,-1,0,0)}
Check ($a -eq 0) 'Flare barrel did not finish closure'
'PASS: flare-specific travel, hand-driven closing and latch completion; headset contact fit unverified.'
$p=[SignalisVrTracking.RifleHingePolicy]::new()
$null=$p.Tick(.01,$true,$true,60,-1,0,0)
$null=$p.Tick(.01,$false,$false,0,-1,0,0)
$p.Reset()
for($i=0;$i -lt 30;$i++){if($p.Tick(.01,$false,$false,0,-1,0,0) -ne 0){throw 'Reset replayed previous closure'}}
'PASS reopening/reselecting cannot replay old hinge angle'
