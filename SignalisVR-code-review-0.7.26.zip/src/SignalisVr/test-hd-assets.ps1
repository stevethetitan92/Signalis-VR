$ErrorActionPreference='Stop'
$expected=@{Pistol=@(1,2,3,4);Revolver=@(2,3,4,6,10,11,12,13,14,15);Rifle=@(2,4);Shotgun=@(2,4,5);FlareGun=@(2,3,4)}
foreach($kind in $expected.Keys){
 $r=[IO.BinaryReader]::new([IO.File]::OpenRead((Join-Path $PSScriptRoot "embedded-hd/$kind-0.bin")));$count=$r.ReadInt32();$roles=@();$lo=@(1e10,1e10,1e10);$hi=@(-1e10,-1e10,-1e10)
 for($p=0;$p -lt $count;$p++){
  $roles+=$r.ReadInt32();$mat=$r.ReadInt32();$nv=$r.ReadInt32();$ni=$r.ReadInt32();if($nv -lt 3 -or $ni%3){throw "$kind invalid topology"}
  for($v=0;$v -lt $nv;$v++){for($a=0;$a -lt 3;$a++){$f=$r.ReadSingle();if([float]::IsNaN($f) -or [float]::IsInfinity($f)){throw 'Nonfinite HD vertex'};$lo[$a]=[Math]::Min($lo[$a],$f);$hi[$a]=[Math]::Max($hi[$a],$f)}}
  for($v=0;$v -lt $nv*2;$v++){$f=$r.ReadSingle();if([float]::IsNaN($f)){throw 'Invalid HD UV'}}
  for($v=0;$v -lt $ni;$v++){$i=$r.ReadInt32();if($i -lt 0 -or $i -ge $nv){throw 'Out of range triangle'}}
 }
 if($r.BaseStream.Position -ne $r.BaseStream.Length){throw 'Trailing geometry bytes'};$r.Dispose()
 foreach($role in $expected[$kind]){if($role -notin $roles){throw "$kind missing action role $role"}}
 if($hi[2]-$lo[2] -lt .1 -or $hi[2]-$lo[2] -gt 1.5){throw "$kind units/length incorrect"}
 Write-Host "PASS $kind : finite UV geometry, action roles and metre scale"
}
$poses=Get-Content (Join-Path $PSScriptRoot 'ElsterGripPoseData.cs') -Raw
$arrays=[regex]::Matches($poses,'float\[\] \w+=\{([^}]+)\}')
foreach($side in 0,1){foreach($kind in 'Handle','Trigger','Magazine','Round','Loader','Slide','ForeEnd'){if(!$poses.Contains("P${side}${kind}={")){throw "Missing grip P${side}${kind}"}}}
if(!$poses.Contains('PistolRight={')){throw 'Missing fitted pistol profile'}
foreach($a in $arrays){$v=@($a.Groups[1].Value.Split(',')|ForEach-Object{[double]$_.TrimEnd('f')});if($v.Count -ne 60){throw 'Grip missing finger joints'};for($i=0;$i -lt 60;$i+=4){$n=0;for($j=0;$j -lt 4;$j++){$n+=$v[$i+$j]*$v[$i+$j]};if([Math]::Abs($n-1) -gt .00001){throw 'Nonunit grip quaternion'}}}
$clips=Get-ChildItem (Join-Path $PSScriptRoot 'embedded-hd') -Filter '*-shot-*.pcm';if($clips.Count -ne 20){throw 'Missing HD shot variants'}
foreach($c in $clips){$b=[IO.File]::ReadAllBytes($c.FullName);if($b.Length%2 -or $b.Length -lt 1000){throw 'Invalid PCM clip'};$peak=0;for($i=0;$i -lt $b.Length;$i+=2){$peak=[Math]::Max($peak,[Math]::Abs([int][BitConverter]::ToInt16($b,$i)))};if($peak -lt 100){throw 'Silent HD clip'}}
Write-Host 'PASS bilateral 15-joint weighted-hand poses, fitted pistol profile and twenty non-silent PCM shot variants. No headset or audible playback claim.'
