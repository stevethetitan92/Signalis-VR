$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'HandSurfaceTopology.cs')
# Open square with duplicate UV-seam vertices: welding yields one perimeter.
$xyz=[float[]]@(0,0,0, 1,0,0, 1,1,0, 0,1,0, 0,0,0, 1,1,0)
$t=[int[]]@(0,1,2, 4,5,3)
$r=[SignalisVrTracking.HandSurfaceTopology]::BoundaryLoops($xyz,$t)
if($r.Count -ne 1 -or $r[0].Length -ne 4){throw 'UV seam incorrectly treated as hole'}
$d=[SignalisVrTracking.HandSurfaceTopology]::DoubleSided($t)
if($d.Length -ne 12 -or $d[7] -ne 2 -or $d[8] -ne 1){throw 'Back face winding incorrect'}
# Closed tetrahedron has no boundary and must receive no caps.
$r=[SignalisVrTracking.HandSurfaceTopology]::BoundaryLoops([float[]]@(0,0,0,1,0,0,0,1,0,0,0,1),[int[]]@(0,1,2,0,3,1,0,2,3,1,3,2))
if($r.Count -ne 0){throw 'Closed mesh capped'}
# Separate surfaces must never be bridged across the gaps between fingers.
$r=[SignalisVrTracking.HandSurfaceTopology]::BoundaryLoops([float[]]@(0,0,0,1,0,0,0,1,0,5,0,0,6,0,0,5,1,0),[int[]]@(0,1,2,3,4,5))
if($r.Count -ne 2){throw 'Separate boundaries joined'}
'PASS UV seam welding, closed-mesh preservation, disconnected boundary isolation, double-sided winding. Actual skinned rendering unverified.'
