$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ModSettingsFile.cs')
$path=Join-Path $PSScriptRoot 'flashlight-settings-test/settings.txt'
foreach($location in 0..2){$s=[SignalisVrTracking.ModSettingsFile]::new();$s.FlashlightPlacement=$location;$s.Save($path);if(([SignalisVrTracking.ModSettingsFile]::Load($path)).FlashlightPlacement -ne $location){throw 'Placement save/load failed'}}
[IO.File]::WriteAllText($path,'FlashlightPlacement=99');if(([SignalisVrTracking.ModSettingsFile]::Load($path)).FlashlightPlacement -ne 0){throw 'Invalid location accepted'}
$s.FlashlightPlacement=3;$failed=$false;try{$s.Save($path)}catch{$failed=$true};if(!$failed){throw 'Invalid placement saved'}
$q=Get-Content (Join-Path $PSScriptRoot 'QuickSelect.cs') -Raw
$choices=[regex]::Match($q,'QuickChoices=\{([^}]+)\}').Groups[1].Value
if($choices.Contains('Flashlight')){throw 'Flashlight assignable to wheel'}
$p=Get-Content (Join-Path $PSScriptRoot 'WheelInventoryPicker.cs') -Raw
if(!$p.Contains('WheelInventoryPicker.Allowed(pair.Key._item.ToString())')){throw 'Flashlight still shown in picker'}
$f=Get-Content (Join-Path $PSScriptRoot 'FlashlightPlacement.cs') -Raw
foreach($guard in @('"OFF","HEAD","UNDER BARREL"','rotation=stereoRotation','global::PlayerAttack.muzzle','pose.Transform.position=pose.Position','FlashLightHolder','GetComponentInChildren<Light>')){if(!$f.Contains($guard)){throw "Missing pose/native-light integration $guard"}}
'PASS three-location persistence, invalid-load/save, wheel exclusion/migration and scoped native-light/head/gun pose source checks. Runtime flashlight tracking unverified.'
