$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'QuickSelect.cs') -Raw
$start=$s.IndexOf('  private void ClearDepletedHealthSlot()')
$end=$s.IndexOf('  private void RestoreQuickWeapon()', $start)
$method=$s.Substring($start,$end-$start).Replace('private void ClearDepletedHealthSlot','public void ClearDepletedHealthSlot')
$motion=Get-Content (Join-Path $PSScriptRoot 'RepairSprayPose.cs') -Raw
$a=$motion.IndexOf('  public static void ClearSlots(');$b=$motion.IndexOf("`n",$a)
Add-Type -TypeDefinition (@'
using System; using MelonLoader;
namespace MelonLoader { public static class MelonLogger {public static void Warning(string s){}} }
public class Item {public string _item;}
public static class RepairSprayUseMotion {
'@+$motion.Substring($a,$b-$a)+@'
}
public class Harness {
public Item heldQuickHealth;public int count,saves;
public string[] quickSlots;
int QuickCount(Item item){return count;}void SaveModSettings(){saves++;}
'@+$method+'}')
foreach($id in @('Health25','Health50','Health100','HealthFast')){foreach($remaining in @(0,1,4)){
 $h=[Harness]::new();$h.heldQuickHealth=[Item]::new();$h.heldQuickHealth._item=$id;$h.count=$remaining;$h.quickSlots=[string[]]@('Pistol',$id,'SignalFlare','Taser');$h.ClearDepletedHealthSlot()
 if($h.quickSlots[1] -ne $(if($remaining -gt 0){$id}else{'None'})){throw "Wrong slot for $id with $remaining left"}
 if($h.saves -ne $(if($remaining -gt 0){0}else{1})){throw 'Unexpected save'}
 if($h.quickSlots[0] -ne 'Pistol' -or $h.quickSlots[2] -ne 'SignalFlare' -or $h.quickSlots[3] -ne 'Taser'){throw 'Other assignments changed'}
}}
if(!$s.Contains('ClearDepletedHealthSlot();healthUsed=false;heldQuickHealth=null;RestoreQuickWeapon();')){throw 'Completion/restoration order changed'}
if($s.Contains('if(spray||item._item==global::Items.itemlist.Health25){RepairSprayUseMotion.ClearSlots')){throw 'Unconditional clearing remains'}
'PASS actual production cleanup method for all four healing types at zero, one and multiple remaining; other slots preserved, save only at depletion, prior weapon restoration retained. Headset use animation unverified.'
