namespace SignalisVrTracking { internal static class HdRevolverData {
public static readonly string Geometry=HdAsset.Read("Revolver-0.bin");
public static readonly string[] Textures={HdAsset.Read("Revolver-1.bin"),HdAsset.Read("Revolver-2.bin"),HdAsset.Read("Revolver-3.bin"),HdAsset.Read("Revolver-4.bin")};
public static readonly float[] Colors={1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f};
public static readonly UnityEngine.Vector3 TriggerPivot=new UnityEngine.Vector3(-0.00000000f,0.02385000f,0.07158000f);
public static readonly UnityEngine.Vector3 Pivot=new UnityEngine.Vector3(-0.00589900f,0.02459400f,0.10249500f);
public static readonly UnityEngine.Vector3 Muzzle=new UnityEngine.Vector3(-0.00000000f,0.04869000f,0.14831000f);
public static readonly UnityEngine.Vector3 HammerPivot=new UnityEngine.Vector3(-0.00104600f,0.07510000f,0.01690000f);
public static readonly UnityEngine.Vector3 Support=new UnityEngine.Vector3(-0.00000000f,0.00620000f,0.00190000f);
public static readonly UnityEngine.Vector3 Chamber=new UnityEngine.Vector3(0.00005200f,0.06106500f,0.03839000f);
public static readonly UnityEngine.Vector3 LoaderCenter=new UnityEngine.Vector3(0.00005200f,0.06106500f,0.06355160f);
public static readonly UnityEngine.Vector3 OpenLoaderCenter=new UnityEngine.Vector3(-0.04237000f,0.03054500f,0.06355160f);
} }
