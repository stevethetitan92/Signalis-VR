using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public static class WheelInventoryPicker {
  public static bool Allowed(string id){return id!=null&&id!="Flashlight"&&!id.EndsWith("Ammo",StringComparison.Ordinal)&&!id.StartsWith("Ammo",StringComparison.Ordinal);}
  public static int[] Carried(int[] quantities){var result=new List<int>();for(int i=1;i<quantities.Length;i++)if(quantities[i]>0)result.Add(i);return result.ToArray();}
  public static int Direction(float x,float y){if(Math.Max(Math.Abs(x),Math.Abs(y))<.55f)return -1;return Math.Abs(y)>=Math.Abs(x)?(y>0?0:2):(x>0?1:3);}
 }
 public sealed partial class Tracking {
  private int wheelPickSlot=-1,wheelPendingChoice=-1;
  private bool wheelDirectionArmed;
  private Vector2 wheelListScroll;
  private global::AnItem[] wheelCarried=new global::AnItem[0];
  private int WheelListCount(){return wheelCarried.Length+3;}
  private global::AnItem WheelCatalogItem(int choice){if(choice>0&&choice<QuickChoices.Length&&QuickChoices[choice]=="Receiver")return ReceiverCatalog();global::Items.itemlist id;var all=global::InventoryManager.allItems;return choice>0&&choice<QuickChoices.Length&&all!=null&&Enum.TryParse(QuickChoices[choice],out id)&&all.ContainsKey(id)?all[id]:null;}
  private int WheelChoice(global::AnItem item){if(item!=null&&receiverCatalog!=null&&item.Pointer==receiverCatalog.Pointer)return Array.IndexOf(QuickChoices,"Receiver");return item==null?-1:Array.IndexOf(QuickChoices,item._item.ToString());}
  private void RefreshWheelInventory(){var list=new List<global::AnItem>();var inv=global::InventoryManager.elsterItems;if(inv!=null)foreach(var pair in inv)if(pair.Key!=null&&pair.Value>0&&WheelInventoryPicker.Allowed(pair.Key._item.ToString()))list.Add(pair.Key);if(ReceiverOwned())list.Add(ReceiverCatalog());list.Sort((a,b)=>a.sortingPriority.CompareTo(b.sortingPriority));wheelCarried=list.ToArray();modMenuSelection=Math.Min(modMenuSelection,WheelListCount()-1);}
  private void OpenWheelPicker(int slot){wheelPickSlot=-1;wheelPendingChoice=-1;wheelDirectionArmed=false;RefreshWheelInventory();modMenuSelection=0;}
  private void CloseWheelPicker(){wheelPickSlot=-1;wheelPendingChoice=-1;wheelDirectionArmed=false;}
  private void ActivateWheelPicker(int index){
   if(index<wheelCarried.Length){var item=wheelCarried[index];int choice=WheelChoice(item);if(choice<=0){modSettingsError="This item cannot be equipped or used from the wheel.";return;}if(QuickCount(item)<=0){RefreshWheelInventory();modSettingsError="That item is no longer carried.";return;}wheelPendingChoice=choice;wheelPickSlot=0;wheelDirectionArmed=false;modSettingsError=null;}
   else if(index==wheelCarried.Length){wheelPendingChoice=0;wheelPickSlot=0;wheelDirectionArmed=false;modSettingsError=null;}
   else if(index==wheelCarried.Length+1){CloseWheelPicker();SelectModSection(0);}else FinishModMenu();
  }
  private void AssignWheelBox(int slot){if(wheelPendingChoice<0)return;if(wheelPendingChoice>0&&QuickCount(WheelCatalogItem(wheelPendingChoice))<=0){modSettingsError="That item is no longer carried.";CloseWheelPicker();RefreshWheelInventory();return;}quickSlots[slot]=QuickChoices[wheelPendingChoice];CloseWheelPicker();modSettingsError=null;}
  private bool PollWheelAssignment(float x,float y){if(!modMenuWheel||wheelPendingChoice<0)return false;int d=WheelInventoryPicker.Direction(x,y);if(d<0){wheelDirectionArmed=true;return true;}if(wheelDirectionArmed)AssignWheelBox(d);return true;}
  private void DrawModItemIcon(global::AnItem item,Rect area){var icon=item==null?null:(item.Icon!=null?item.Icon:item.Image);if(icon==null||icon.texture==null)return;var tex=icon.texture;var uv=icon.textureRect;float fit=Math.Min(area.width/Math.Max(1,uv.width),area.height/Math.Max(1,uv.height));GUI.color=Color.white;GUI.DrawTextureWithTexCoords(new Rect(area.x+(area.width-uv.width*fit)/2,area.y+(area.height-uv.height*fit)/2,uv.width*fit,uv.height*fit),tex,new Rect(uv.x/tex.width,uv.y/tex.height,uv.width/tex.width,uv.height/tex.height),true);}
  private void DrawWheelBoxes(float x,float y,float width,float s){
   var cyan=new Color(.42f,.8f,.9f);var red=new Color(.88f,.12f,.055f);
   var listArea=new Rect(x,y+115*s,810*s,575*s);int rows=wheelCarried.Length+1;float row=58*s;
   wheelListScroll=GUI.BeginScrollView(listArea,wheelListScroll,new Rect(0,0,listArea.width-22*s,rows*row));
   for(int i=0;i<rows;i++){var r=new Rect(0,i*row,listArea.width-25*s,row-5*s);bool selected=i==modMenuSelection;PaintMenuRect(r,selected?cyan:new Color(.4f,.45f,.43f));PaintMenuRect(new Rect(r.x+2*s,r.y+2*s,r.width-4*s,r.height-4*s),selected?new Color(.04f,.16f,.17f):Color.black);
    var item=i<wheelCarried.Length?wheelCarried[i]:null;int choice=WheelChoice(item);DrawModItemIcon(item,new Rect(10*s,r.y+5*s,100*s,43*s));string name=item==null?"CLEAR SPACE":choice>0?QuickNames[choice]:item._name;
    MenuText(new Rect(115*s,r.y,r.width-230*s,r.height),name,Color.white,modMenuHelp);if(item!=null)MenuText(new Rect(r.width-105*s,r.y,100*s,r.height),"x"+QuickCount(item),cyan,modMenuHelp);
    if(MenuClicked(r)){modMenuSelection=i;ActivateWheelPicker(i);}
   }GUI.EndScrollView();
   MenuText(new Rect(x+860*s,y+115*s,620*s,40*s),"ITEM WHEEL",cyan,modMenuStyle);
   float[] xs={1060,1280,1060,840},ys={180,350,520,350};
   for(int i=0;i<4;i++){var r=new Rect(x+xs[i]*s,y+ys[i]*s,200*s,150*s);PaintMenuRect(r,wheelPendingChoice>=0?cyan:Color.gray);PaintMenuRect(new Rect(r.x+2*s,r.y+2*s,r.width-4*s,r.height-4*s),Color.black);DrawModItemIcon(QuickItem(i),new Rect(r.x+20*s,r.y+12*s,r.width-40*s,88*s));MenuText(new Rect(r.x,r.y+103*s,r.width,42*s),QuickName(i),Color.white,modMenuHelp);if(MenuClicked(r))AssignWheelBox(i);}
   MenuText(new Rect(x+840*s,y+690*s,640*s,55*s),wheelPendingChoice>=0?"Move LEFT STICK toward a box to assign it.":"Choose an item, then move LEFT STICK toward a box.",cyan,modMenuHelp);
   var back=new Rect(x,y+710*s,300*s,38*s);PaintMenuRect(back,modMenuSelection==wheelCarried.Length+1?cyan:Color.black);MenuText(back,"BACK",Color.white,modMenuHelp);if(MenuClicked(back))ActivateWheelPicker(wheelCarried.Length+1);
   var done=new Rect(x,y+760*s,300*s,48*s);PaintMenuRect(done,modMenuSelection==wheelCarried.Length+2?Color.gray:red);MenuText(done,"D O N E",Color.white,modMenuStyle);if(MenuClicked(done))FinishModMenu();MenuText(new Rect(x+330*s,y+760*s,1150*s,48*s),"A: Choose item   B: Cancel / Back   DONE: Save",Color.white,modMenuHelp);
   MenuText(new Rect(x,y+818*s,width,36*s),modSettingsError??"Press DONE to save choices for next launch",cyan,modMenuHelp);
  }
  private bool DrawModTabs(float x,float y,float width,float s){var names=ModMenuSections.Names;int current=CurrentModSection();for(int i=0;i<names.Length;i++){var r=new Rect(x+i*width/names.Length,y+50*s,width/names.Length-4*s,48*s);PaintMenuRect(r,i==current?new Color(.35f,.48f,.49f):new Color(.88f,.12f,.055f));MenuText(r,names[i],Color.white,modMenuHelp);if(MenuClicked(r)){SelectModSection(i);return true;}}return false;}
 }
}