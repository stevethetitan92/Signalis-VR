$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'ControllerWeapon.cs') -Raw
$start=$source.IndexOf(' internal static class WeaponAimPolicy')
$actual='namespace SignalisVrTracking {'+$source.Substring($start)
$stub=@'
using System;using UnityEngine;using N=System.Numerics;
namespace UnityEngine {
 public class GameObject { public bool activeInHierarchy; }
 public struct Vector3 {
  public N.Vector3 v;
  public Vector3(float x,float y,float z){v=new N.Vector3(x,y,z);}
  public static Vector3 operator +(Vector3 a,Vector3 b){return new Vector3{v=a.v+b.v};}
  public static Vector3 operator -(Vector3 a,Vector3 b){return new Vector3{v=a.v-b.v};}
 }
 public struct Quaternion {
  public N.Quaternion v;
  public static Quaternion Euler(float x,float y,float z){float d=(float)Math.PI/180f;return new Quaternion{v=N.Quaternion.CreateFromYawPitchRoll(y*d,x*d,z*d)};}
  public static Quaternion Inverse(Quaternion a){return new Quaternion{v=N.Quaternion.Inverse(a.v)};}
  public static Quaternion operator *(Quaternion a,Quaternion b){return new Quaternion{v=a.v*b.v};}
  public static Vector3 operator *(Quaternion a,Vector3 b){return new Vector3{v=N.Vector3.Transform(b.v,a.v)};}
 }
 public class Transform {
  public Transform parent;
  public Vector3 localPosition;
  public Quaternion localRotation=new Quaternion{v=N.Quaternion.Identity};
  public Vector3 position {get{return parent==null?localPosition:parent.position+parent.rotation*localPosition;}set{localPosition=parent==null?value:Quaternion.Inverse(parent.rotation)*(value-parent.position);}}
  public Quaternion rotation {get{return parent==null?localRotation:parent.rotation*localRotation;}set{localRotation=parent==null?value:Quaternion.Inverse(parent.rotation)*value;}}
 }
}
'@
$checks=@'
public static class WeaponScopeTests {
 static Quaternion Rot(float x,float y,float z){return new Quaternion{v=N.Quaternion.CreateFromYawPitchRoll(y,x,z)};}
 static void Vec(Vector3 a,Vector3 b,string label){if(N.Vector3.Distance(a.v,b.v)>.0001f)throw new Exception(label);}
 static void Quat(Quaternion a,Quaternion b,string label){if(Math.Abs(N.Quaternion.Dot(a.v,b.v))<.9999f)throw new Exception(label);}
 public static string Run(){
  int cases=0;
  var calibrated=SignalisVrTracking.WeaponAimPolicy.ControllerRotation(Rot(0,0,0));
  float diagonal=(float)Math.Sqrt(.5);
  Vec(calibrated*new Vector3(0,0,1),new Vector3(0,-diagonal,diagonal),"Correction must pitch down 45 degrees in controller space");
  var raised=Rot(-(float)Math.PI/4,0,0);
  Vec(SignalisVrTracking.WeaponAimPolicy.ControllerRotation(raised)*new Vector3(0,0,1),new Vector3(0,0,1),"45-degree raised grip becomes forward aim");
  for(int i=0;i<20;i++){
   var tracked=Rot(i*.13f,i*.21f,i*.17f);
   Vec(SignalisVrTracking.WeaponAimPolicy.ControllerRotation(tracked)*new Vector3(0,0,1),tracked*new Vector3(0,-diagonal,diagonal),"Correction follows controller, not world axes");
  }
  var pistol=new GameObject();var rifle=new GameObject();
  if(SignalisVrTracking.WeaponModelPolicy.Select(null,null)!=null)throw new Exception("Missing models accepted");
  for(int mask=0;mask<4;mask++){
   pistol.activeInHierarchy=(mask&1)!=0;rifle.activeInHierarchy=(mask&2)!=0;
   var expected=mask==1?pistol:mask==2?rifle:null;
   if(SignalisVrTracking.WeaponModelPolicy.Select(pistol,rifle)!=expected)throw new Exception("Weapon switch/ambiguous selection "+mask);
  }
  pistol.activeInHierarchy=true;rifle.activeInHierarchy=true;
  if(SignalisVrTracking.WeaponModelPolicy.Select(pistol,null)!=pistol||SignalisVrTracking.WeaponModelPolicy.Select(null,rifle)!=rifle)throw new Exception("Single supported model rejected");
  var guns=new GameObject[6];for(int i=0;i<6;i++)guns[i]=new GameObject();
  for(int mask=0;mask<64;mask++){
   int count=0;GameObject expected=null;
   for(int i=0;i<6;i++){guns[i].activeInHierarchy=(mask&(1<<i))!=0;if(guns[i].activeInHierarchy){count++;expected=guns[i];}}
   var actual=SignalisVrTracking.WeaponModelPolicy.Select(guns[0],guns[1],guns[2],guns[3],guns[4],guns[5]);
   if(actual!=(count==1?expected:null))throw new Exception("All-gun selection mask "+mask);
  }
  if(!SignalisVrTracking.WeaponGameplayPolicy.Ready(true,false))throw new Exception("Play state rejected");
  if(SignalisVrTracking.WeaponGameplayPolicy.Ready(true,true)||SignalisVrTracking.WeaponGameplayPolicy.Ready(false,false)||SignalisVrTracking.WeaponGameplayPolicy.Ready(false,true))throw new Exception("Menu/pause accepted");
  foreach(bool alternate in new[]{false,true})foreach(bool child in new[]{false,true})for(int n=0;n<20;n++){
   var root=new Transform{localPosition=new Vector3(19,20,-7),localRotation=Rot(.3f,.5f,-.9f)};
   var model=new Transform{parent=root,localPosition=new Vector3(1,2,3),localRotation=Rot(.1f,.9f,.2f)};
   var muzzle=new Transform{parent=child?model:root,localPosition=new Vector3(0,0,4),localRotation=Rot(.4f,.2f,-.1f)};
   var modelP=model.position;var modelR=model.rotation;var muzzleP=muzzle.position;var muzzleR=muzzle.rotation;
   var laser=new Transform{parent=model,localPosition=new Vector3(1,3,5)};
   var offset=Quaternion.Inverse(muzzleR)*((alternate?laser.position:muzzleP)-modelP);
   var hand=new Vector3(5,-6,7);var rot=SignalisVrTracking.WeaponAimPolicy.ControllerRotation(Rot(n*.19f,n*.3f,n*.11f));
   var scope=new SignalisVrTracking.WeaponPoseScope(model,muzzle,alternate?laser:null);
   scope.weaponName="test";scope.shot=true;scope.shotOrigin=muzzleP;scope.shotDirection=new Vector3(0,0,1);scope.shotRange=100;scope.shotMask=7;
   int targetRestores=0;scope.restoreTargets=delegate{targetRestores++;};
   try{
    scope.Apply(hand,rot);
    Vec(model.position,hand,"Model must move to hand");Quat(muzzle.rotation,rot,"Muzzle must point with controller");
    Vec(muzzle.position,hand+rot*offset,"Muzzle offset must rotate with hand");
    var nested=new SignalisVrTracking.WeaponPoseScope(model,muzzle,alternate?laser:null);nested.Apply(hand,rot);nested.Restore();
    Vec(model.position,hand,"Nested model");Quat(muzzle.rotation,rot,"Nested muzzle");
   }finally{scope.Restore();}
   Vec(model.position,modelP,"Restore model");Quat(model.rotation,modelR,"Restore model rotation");
   Vec(muzzle.position,muzzleP,"Restore muzzle");Quat(muzzle.rotation,muzzleR,"Restore muzzle rotation");scope.Restore();if(!scope.shot||scope.shotRange!=100||scope.shotMask!=7)throw new Exception("Shot metadata lost");Vec(scope.shotOrigin,muzzleP,"Shot origin preserved");Vec(scope.shotDirection,new Vector3(0,0,1),"Shot direction preserved");cases++;
   if(targetRestores!=1)throw new Exception("Shotgun target restoration must run exactly once");
   var fixedScope=new SignalisVrTracking.WeaponPoseScope(model,muzzle);
   fixedScope.ApplyHeld(hand,rot,Quaternion.Euler(0,25,0),offset);
   Vec(model.position,hand,"Held frame model anchor");
   Quat(model.rotation,rot*Quaternion.Euler(0,25,0),"Held frame ignores native aiming rotation");
   Vec(muzzle.position,hand+rot*offset,"Held frame shot matches visual offset");
   var imported=hand+rot*new Vector3(0,.06f,.52f);fixedScope.AlignMuzzle(imported,rot);
   Vec(muzzle.position,imported,"Imported barrel origin");Quat(muzzle.rotation,rot,"Imported barrel direction");
   fixedScope.Restore();
   Vec(model.position,modelP,"Held frame native model restored");
   Quat(muzzle.rotation,muzzleR,"Held frame native muzzle restored");
  }
  if(!SignalisVrTracking.WeaponAimPolicy.Fresh(.02f,1)||!SignalisVrTracking.WeaponAimPolicy.Fresh(.1f,3))throw new Exception("Valid poses rejected");
  foreach(float age in new[]{-.01f,.101f,float.NaN,float.PositiveInfinity})if(SignalisVrTracking.WeaponAimPolicy.Fresh(age,1))throw new Exception("Invalid age accepted");
  foreach(int frame in new[]{-1,4,100})if(SignalisVrTracking.WeaponAimPolicy.Fresh(.01f,frame))throw new Exception("Invalid frame age accepted");
  return "PASS: "+cases+" pose/offset/nesting/restoration cases and stale-pose boundaries. Game mesh alignment and hits unverified.";
 }
}
'@
Add-Type -TypeDefinition ($stub+$actual+$checks)
[WeaponScopeTests]::Run()

