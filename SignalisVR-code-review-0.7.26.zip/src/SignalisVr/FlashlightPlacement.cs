using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public static class FlashlightPlacementPolicy {public static int Next(int current,int direction){return (current+direction+3)%3;}}
 public sealed partial class Tracking {
  private int modFlashlightPlacement;
  private static readonly string[] flashlightLocations={"OFF","HEAD","UNDER BARREL"};
  private global::ElsterFlashLight placedFlashlight;
  private float nextFlashlightSearch;private Light vrFlashlightBeam;
  private readonly List<FlashlightPose> flashlightPoses=new List<FlashlightPose>();
  private sealed class FlashlightPose {public Transform Transform;public Vector3 Position;public Quaternion Rotation;}
  private bool flashlightPlacementFailed;
  private void PrepareFlashlightPlacement(){if(flashlightPlacementFailed)return;try{PrepareFlashlightPlacementCore();}catch(Exception ex){RestoreFlashlightPlacement();flashlightPlacementFailed=true;MelonLoader.MelonLogger.Warning("Flashlight placement disabled: "+ex.Message);}}
  private void PrepareFlashlightPlacementCore(){
   RestoreFlashlightPlacement();if(!ProdVrMode()||!handsScoped||!WeaponGameplayReady()||global::PlayerState.player==null)return;
   if(placedFlashlight==null&&Time.realtimeSinceStartup>=nextFlashlightSearch){nextFlashlightSearch=Time.realtimeSinceStartup+1f;foreach(var light in Resources.FindObjectsOfTypeAll<global::ElsterFlashLight>())if(light!=null&&light.gameObject.scene.IsValid()&&light.transform.root==global::PlayerState.player.transform.root){placedFlashlight=light;break;}}
   if(placedFlashlight==null||placedFlashlight.FlashLightHolder==null)return;
   bool powered=calibrationRoot!=null||(!global::ElsterFlashLight.broken&&global::ElsterFlashLight.on);
   if(!powered)return;
   var holder=placedFlashlight.FlashLightHolder.transform;var model=placedFlashlight.FlashLightModel==null?null:placedFlashlight.FlashLightModel.transform;
   if(modFlashlightPlacement==0){SuppressHandFlashlight(model,holder);foreach(var r in holder.GetComponentsInChildren<Renderer>(true))if(r.enabled){flashlightHiddenNative.Add(r);r.enabled=false;}return;}
   Vector3 position;Quaternion rotation;bool leftGrip=false;
   if(modFlashlightPlacement==2&&renderedWeapon!=null&&global::PlayerAttack.muzzle!=null){var muzzle=global::PlayerAttack.muzzle;rotation=muzzle.rotation;position=muzzle.position+rotation*(new Vector3(0,-.045f,-.07f)*UnitsPerMetre);}
   else {rotation=stereoRotation;position=stereoPosition+rotation*(new Vector3(.055f,-.025f,.04f)*UnitsPerMetre);}
   var beam=holder.GetComponentInChildren<Light>(true);var beamRotation=beam==null?Quaternion.identity:Quaternion.Inverse(holder.rotation)*beam.transform.rotation;
   var deltaRotation=(rotation*Quaternion.Inverse(beamRotation))*Quaternion.Inverse(holder.rotation);
   var origin=leftGrip&&beam!=null?beam.transform.position:holder.position;
   // Move native light/model together; never clone light scripts or change native ON/OFF.
   var root=model!=null&&holder.IsChildOf(model)?model:holder;
   flashlightPoses.Add(new FlashlightPose{Transform=root,Position=root.position,Rotation=root.rotation});
   if(model!=null&&model!=holder&&!model.IsChildOf(holder)&&!holder.IsChildOf(model))flashlightPoses.Add(new FlashlightPose{Transform=model,Position=model.position,Rotation=model.rotation});
   foreach(var pose in flashlightPoses){pose.Transform.position=position+deltaRotation*(pose.Position-origin);pose.Transform.rotation=deltaRotation*pose.Rotation;}
   // A private spotlight also works when the original uses a projected mesh instead of a Light.
   if(vrFlashlightBeam==null){var go=new GameObject("SignalisVR_PlacedFlashlightBeam");UnityEngine.Object.DontDestroyOnLoad(go);vrFlashlightBeam=go.AddComponent<Light>();vrFlashlightBeam.type=LightType.Spot;vrFlashlightBeam.spotAngle=48;vrFlashlightBeam.range=12*UnitsPerMetre;vrFlashlightBeam.intensity=2;vrFlashlightBeam.cullingMask&=~(1<<30);vrFlashlightBeam.color=Color.white;}
   vrFlashlightBeam.transform.SetPositionAndRotation(position,rotation);vrFlashlightBeam.enabled=true;
   if(beam!=null){vrFlashlightBeam.color=beam.color;if(beam.enabled){flashlightHiddenLights.Add(beam);beam.enabled=false;}}

  }
  private void RestoreFlashlightPlacement(){if(vrFlashlightBeam!=null)vrFlashlightBeam.enabled=false;HideFlashlightGrip();for(int i=flashlightPoses.Count-1;i>=0;i--){var pose=flashlightPoses[i];if(pose.Transform!=null){pose.Transform.position=pose.Position;pose.Transform.rotation=pose.Rotation;}}flashlightPoses.Clear();}
  private void ResetFlashlightPlacement(){RestoreFlashlightPlacement();DestroyFlashlightGrip();if(vrFlashlightBeam!=null)UnityEngine.Object.Destroy(vrFlashlightBeam.gameObject);vrFlashlightBeam=null;placedFlashlight=null;nextFlashlightSearch=0;flashlightPlacementFailed=false;}
 }
}

