using System;
namespace SignalisVrTracking {
 // Affine world-XY to map-XY fit. Allows reflected axes and unequal room scales.
 public sealed class RoomMapProjection {
  private double xx,xy,x0,yx,yy,y0;
  public bool Fit(double[,] pairs) {
   if(pairs==null||pairs.GetLength(1)!=4)return false;
   int n=pairs.GetLength(0);if(n<3)return false;
   for(int i=0;i<n;i++)for(int j=0;j<4;j++)if(double.IsNaN(pairs[i,j])||double.IsInfinity(pairs[i,j]))return false;
   double wx=0,wz=0,mx=0,my=0;
   for(int i=0;i<n;i++){wx+=pairs[i,0];wz+=pairs[i,1];mx+=pairs[i,2];my+=pairs[i,3];}
   wx/=n;wz/=n;mx/=n;my/=n;
   double a=0,b=0,c=0,dx=0,ex=0,dy=0,ey=0;
   for(int i=0;i<n;i++){double x=pairs[i,0]-wx,z=pairs[i,1]-wz,u=pairs[i,2]-mx,v=pairs[i,3]-my;a+=x*x;b+=x*z;c+=z*z;dx+=x*u;ex+=z*u;dy+=x*v;ey+=z*v;}
   double det=a*c-b*b;if(a*c<1e-12||det/(a*c)<1e-5)return false;
   xx=(dx*c-ex*b)/det;xy=(ex*a-dx*b)/det;yx=(dy*c-ey*b)/det;yy=(ey*a-dy*b)/det;
   if(Math.Abs(xx*yy-xy*yx)<1e-10)return false;
   x0=mx-xx*wx-xy*wz;y0=my-yx*wx-yy*wz;
   return Finite(xx)&&Finite(xy)&&Finite(x0)&&Finite(yx)&&Finite(yy)&&Finite(y0);
  }
  private static bool Finite(double value){return !double.IsNaN(value)&&!double.IsInfinity(value);}
  public void Point(double x,double z,out double u,out double v){u=xx*x+xy*z+x0;v=yx*x+yy*z+y0;}
 }
}
