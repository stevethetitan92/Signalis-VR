namespace SignalisVrTracking {
 public sealed class HingedReloadPolicy {
  public enum Step { Closed, Open, Holding, AwaitingInsert }
  public Step Stage {get;private set;}
  public bool Active {get{return Stage!=Step.Closed;}}
  private bool lastGrip;private float dwell=-1;
  public void Cancel(){Stage=Step.Closed;lastGrip=false;dwell=-1;}
  public void PressB(){Stage=Active?Step.Closed:Step.Open;dwell=-1;}
  public bool Tick(float now,bool grip,bool pouch,bool chamber,int loaded,int capacity,int reserve){
   bool down=grip&&!lastGrip;lastGrip=grip;
   if(Stage==Step.Open&&down&&pouch&&ShotgunReloadPolicy.CanTransfer(loaded,capacity,reserve)){Stage=Step.Holding;dwell=-1;}
   else if(Stage==Step.Holding){if(!grip){if(chamber&&dwell>=0){Stage=Step.AwaitingInsert;dwell=-1;return true;}Stage=Step.Open;dwell=-1;}else if(chamber){if(dwell<0)dwell=now;if(now-dwell>=.12f){Stage=Step.AwaitingInsert;dwell=-1;return true;}}else dwell=-1;}
   return false;
  }
  public void ResetInsertionDwell(){dwell=-1;}
  public void Inserted(){if(Stage==Step.AwaitingInsert)Stage=Step.Open;}
 }
 public static class ManualAmmoTransfer {
  public static int Amount(int loaded,int capacity,int reserve,bool infinite){if(loaded<0||capacity<=0||loaded>=capacity||reserve<=0&&!infinite)return 0;return 1;}
  public static int LoaderAmount(int loaded,int capacity,int reserve,bool infinite){if(loaded<0||capacity<=loaded)return 0;return System.Math.Max(0,System.Math.Min(6,System.Math.Min(capacity-loaded,infinite?capacity:System.Math.Max(0,reserve))));}
 }
}

namespace SignalisVrTracking { public static class RevolverRoundLayout { public static bool InLoader(int index,int loaded,int amount){int round=RoundForVertex(index);return round>=loaded&&round<loaded+amount&&round<6;} public static int RoundForVertex(int index){if(index<0||index>=144)return 6;if(index<120)return index/20;int[] rear={2,3,5,1,0,4};return rear[(index-120)/4];} } }
