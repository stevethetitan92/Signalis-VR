$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'MapRevealPolicy.cs')
$p=[SignalisVrTracking.MapRevealPolicy]::new()
if($p.Update($true,.9,.3,-.3,0)){throw 'Revealed without dwell'}
if(-not $p.Update($true,.9,.3,-.3,.16)){throw 'Palm-down reveal failed'}
if(-not $p.Update($true,.55,.15,-.6,.2)){throw 'Threshold jitter hides map'}
if(-not $p.Update($true,0,.3,-.3,.3)){throw 'No hide debounce'}
if($p.Update($true,0,.3,-.3,.41)){throw 'Turning back did not hide'}
$p.Update($true,.9,.3,-.3,.5)|Out-Null
if(-not $p.Update($true,.9,.3,-.3,.66)){throw 'Cannot reopen'}
$p.Update($true,.9,.05,-.3,.7)|Out-Null
if($p.Update($true,.9,.05,-.3,.81)){throw 'Retracting hand did not hide'}
$p.Update($true,.9,.3,-.3,.9)|Out-Null
$p.Update($true,.9,.3,-.3,1.06)|Out-Null
if($p.Update($false,.9,.3,-.3,1.07)){throw 'Ineligible state retained visibility'}
if($p.Update($true,.9,.3,-.3,1.1)){throw 'Reset did not require new dwell'}
$p.Update($true,.9,.3,-.3,1.26)|Out-Null
$p.Update($true,.9,.3,-.8,1.3)|Out-Null
if($p.Update($true,.9,.3,-.8,1.41)){throw 'Lowering hand did not hide'}
'PASS reveal dwell, hysteresis, return/retract/lower hide, immediate eligibility reset. Headset pose interpretation unverified.'
