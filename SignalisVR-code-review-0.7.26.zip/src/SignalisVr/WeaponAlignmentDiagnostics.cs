using System;
using System.Collections.Generic;
using System.Globalization;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly Dictionary<string,int> weaponRayCounts=new Dictionary<string,int>();
  private readonly Dictionary<string,float> weaponRayTimes=new Dictionary<string,float>();
  private bool weaponRayDiagnosticFailed;
  private static string WeaponVector(Vector3 v) {
   return string.Format(CultureInfo.InvariantCulture,"({0:F4},{1:F4},{2:F4})",v.x,v.y,v.z);
  }
  // Read-only, at most three snapshots per weapon/phase, spaced one second.
  // Hard global key cap prevents unbounded logging if names change unexpectedly.
  private void ReportWeaponRays(string phase,global::PlayerAttack attack) {
   if(weaponRayDiagnosticFailed||attack==null)return;
   try {
    var model=ActiveSupportedWeapon(rifleOwner);var muzzle=global::PlayerAttack.muzzle;
    if(model==null||muzzle==null)return;
    string key=model.name+":"+phase;int count;float last;
    weaponRayCounts.TryGetValue(key,out count);
    if(count>=3||(!weaponRayCounts.ContainsKey(key)&&weaponRayCounts.Count>=18))return;
    if(weaponRayTimes.TryGetValue(key,out last)&&Time.realtimeSinceStartup-last<1f)return;
    weaponRayCounts[key]=count+1;weaponRayTimes[key]=Time.realtimeSinceStartup;
    var t=model.transform;
    string message="WEAPON RAYS: weapon="+model.name+" phase="+phase+" frame="+Time.frameCount
     +" poseFrame="+rightWeaponFrame+" source="+(mouseWeaponTest?"mouse":"controller")
     +" modelPos="+WeaponVector(t.position)+" modelForward="+WeaponVector(t.forward)+" modelUp="+WeaponVector(t.up)
     +" muzzle="+muzzle.name+" muzzlePos="+WeaponVector(muzzle.position)+" muzzleForward="+WeaponVector(muzzle.forward)
     +" muzzleInModel="+WeaponVector(t.InverseTransformPoint(muzzle.position))
     +" muzzleForwardInModel="+WeaponVector(Quaternion.Inverse(t.rotation)*muzzle.forward);
    // Bounded sampling only; no per-frame scene search or added physics raycast.
    var lasers=model.GetComponentsInChildren<global::AimLaser>(true);
    message+=" laserCount="+lasers.Length;
    for(int i=0;i<lasers.Length&&i<4;i++) {
     var laser=lasers[i];if(laser==null)continue;var l=laser.transform;
     message+=" laser["+i+"]="+l.name+" active="+laser.gameObject.activeInHierarchy
      +" pos="+WeaponVector(l.position)+" forward="+WeaponVector(l.forward)
      +" muzzleDelta="+WeaponVector(l.position-muzzle.position)
      +" angleDeg="+Vector3.Angle(l.forward,muzzle.forward).ToString("F3",CultureInfo.InvariantCulture)
      +" nativeHit="+WeaponVector(laser.hitPos)+" hitSomething="+laser.hitSomething;
    }
    MelonLogger.Msg(message);
   }catch(Exception ex){weaponRayDiagnosticFailed=true;MelonLogger.Warning("Weapon ray diagnostics stopped; aiming unchanged: "+ex.Message);}
  }
 }
}
