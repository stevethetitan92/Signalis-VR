using UnityEngine;
using MelonLoader;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private readonly DoorCameraPolicy doorCamera=new DoorCameraPolicy();
  private bool doorAnchorValid;
  private bool doorHeadingPending;
  private int doorCameraId,doorParentId;
  private Quaternion doorWorldBasis;
  private float doorYaw;
  private bool DoorCameraEligible() {
   return active&&stereo&&!snowWalkStereo&&!questMenuScene&&camera!=null
    &&camera.transform.parent!=null&&camera.transform.parent.name=="Character Root"
    &&questFpMod!=null&&questFpPlayer!=null&&questFpYaw!=null;
  }
  private void ResetDoorCamera(){doorCamera.Reset();doorAnchorValid=false;doorHeadingPending=false;}
  private bool DoorCameraBlocked(){return DoorCameraEligible()&&doorAnchorValid&&doorCamera.Active;}
  private bool DoorNativeTraversing() {
   var player=questFpMod!=null&&questFpPlayer!=null?questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController:null;
   return (player!=null&&player.traversing)||global::PlayerState.gameState==global::PlayerState.gameStates.traversing;
  }
  private void ObserveDoorCamera() {
   if(!DoorCameraEligible()){ResetDoorCamera();return;}
   int id=camera.GetInstanceID(),parentId=camera.transform.parent.GetInstanceID();
   if(doorAnchorValid&&(id!=doorCameraId||parentId!=doorParentId))ResetDoorCamera();
   var player=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
   if(player==null){ResetDoorCamera();return;}
   bool traversing=player.traversing||global::PlayerState.gameState==global::PlayerState.gameStates.traversing;
   bool ready=player.playing&&camera.enabled&&global::PlayerState.gameState==global::PlayerState.gameStates.play
    &&!global::PlayerState.cutscene&&!global::PlayerState.suspendInput;
   bool wasActive=doorCamera.Active;
   bool blocked=doorCamera.Observe(traversing,ready,Time.realtimeSinceStartup);
   if(!doorAnchorValid)return;
   // Follow the native doorway heading instead of recovering the approach angle.
   if(!wasActive&&blocked)doorHeadingPending=true;
   if(traversing)doorYaw=(float)questFpYaw.GetValue(questFpMod);
   if((wasActive||blocked)&&!traversing)questFpYaw.SetValue(questFpMod,doorYaw);
   if(!wasActive&&blocked)
    MelonLogger.Msg("VR DOOR: begin; following native camera; camera="+FormatMarkerVector(camera.transform.position)
     +" local="+FormatMarkerVector(camera.transform.localPosition)+" player="+FormatMarkerVector(player.transform.position)+" heading="+doorYaw);
   if(wasActive&&!blocked) {
    MelonLogger.Msg("VR DOOR: destination ready; native eye offset="+FormatMarkerVector(camera.transform.localPosition)
     +" camera="+FormatMarkerVector(camera.transform.position)+" player="+FormatMarkerVector(player.transform.position)+" heading="+doorYaw);
   }
  }
  private void RememberDoorCamera(Quaternion basis) {
   if(!DoorCameraEligible()||doorCamera.Active||recovery.Paused
    ||global::PlayerState.gameState!=global::PlayerState.gameStates.play)return;
   var player=questFpPlayer.GetValue(questFpMod) as global::AlternatePlayerController;
   if(player==null||!player.playing||player.traversing)return;
   doorCameraId=camera.GetInstanceID();doorParentId=camera.transform.parent.GetInstanceID();
   doorWorldBasis=basis;doorYaw=(float)questFpYaw.GetValue(questFpMod);doorAnchorValid=true;
  }
  // The native door coroutine moves the player/camera through both door halves.
  // Follow the view heading too: freezing the origin strands the headset at
  // the source door, then teleports it when the guard releases.
  private Vector3 DoorCameraOrigin(Vector3 native){return native;}
  private Quaternion DoorCameraBasis(Quaternion native){
   if(!DoorCameraBlocked())return native;
   if(DoorNativeTraversing())doorWorldBasis=native;
   return doorWorldBasis;
  }
 }
}
