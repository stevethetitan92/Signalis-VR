$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'PauseHold.cs') -Raw
$a=$s.IndexOf(' public sealed class PauseHoldPolicy');$b=$s.IndexOf(' public sealed partial class Tracking')
Add-Type -TypeDefinition ('namespace SignalisVrTracking {'+$s.Substring($a,$b-$a)+'}')
$p=[SignalisVrTracking.PauseHoldPolicy]::new()
if($p.Update($true,$true,0) -or $p.Update($true,$true,2.99)){throw 'Opened too early'}
if(!$p.Update($true,$true,3) -or !$p.Consuming){throw 'Did not open at 3 seconds'}
if($p.Update($false,$true,5) -or !$p.Consuming -or $p.Update($true,$true,10)){throw 'Held button retriggered/was not consumed'}
$p.Update($true,$false,11)|Out-Null
if($p.Consuming){throw 'Did not release'}
$p.Update($true,$true,12)|Out-Null;$p.Update($true,$false,14)|Out-Null
if($p.Update($true,$true,15) -or $p.Update($true,$true,17.99) -or !$p.Update($true,$true,18)){throw 'Short tap/repress timer incorrect'}
$p=[SignalisVrTracking.PauseHoldPolicy]::new();$p.Update($true,$true,0)|Out-Null;$p.Update($false,$true,1)|Out-Null
if($p.Update($true,$true,10)){throw 'Hold survived focus/menu interruption'}
$p.Update($true,$false,11)|Out-Null;$p.Update($true,$true,12)|Out-Null;if(!$p.Update($true,$true,15)){throw 'Did not rearm after release'}
if(!$s.Contains('pause.setPause(true)') -or !$s.Contains('~((1<<1)|(1<<7))')){throw 'Missing pause/cancel suppression integration'}
'PASS 3-second boundary, short taps, once-per-hold, release/repress, interruption/rearm and post-trigger consumption policy. Headset timing unverified.'
