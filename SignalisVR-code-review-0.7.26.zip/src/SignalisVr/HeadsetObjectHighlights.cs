using System;
using UnityEngine;
namespace SignalisVrTracking
{
    public sealed partial class Tracking
    {
        private Color[] markerColors = new Color[0];
        private bool[] markerRenderVetoes = new bool[0];
        private float nextObjectHighlightLog;
        private float nextBookGateLog;
        private sealed class HighlightContext {
            internal global::interactionPopup popup;
            internal global::Interaction interaction;
            internal global::BookScreen book;
            internal global::ItemPickup pickup;
            internal global::Room room;
            internal bool travel,supported;
            internal BookBracket bracket;
            internal int sightFrame=-1;
            internal bool clearSight;
        }
        private readonly System.Collections.Generic.Dictionary<int,HighlightContext> highlightContexts=new System.Collections.Generic.Dictionary<int,HighlightContext>();
        private HighlightContext GetHighlightContext(SpriteRenderer sr) {
            int id=sr.GetInstanceID(); HighlightContext c;
            if(highlightContexts.TryGetValue(id,out c))return c;
            c=new HighlightContext(); c.popup=sr.GetComponentInParent<global::interactionPopup>();
            if(c.popup==null)markerOwners.TryGetValue(id,out c.popup);
            c.interaction=c.popup==null?null:c.popup.inter;
            if(c.interaction==null)extraMarkerOwners.TryGetValue(id,out c.interaction);
            var interaction=c.interaction;
            if(interaction!=null) {
                c.travel=IsTravelOrCombatInteraction(interaction);c.supported=IsSupportedItemInteraction(interaction);
                c.book=interaction.GetComponent<global::BookScreen>();
                c.pickup=interaction.GetComponent<global::ItemPickup>();
                c.room=MapOwner(interaction.transform);
                foreach(var point in mapObjects)if(point.Inter==interaction){if(c.book==null)c.book=point.Source.TryCast<global::BookScreen>();if(c.pickup==null)c.pickup=point.Pickup;if(c.room==null)c.room=point.Room;}
                bool cryoKey=c.pickup!=null&&interaction.gameObject.name=="ItemPickup_BrokenKey"&&interaction.GetComponentInParent<global::PEN_Cryo>()!=null;
                c.bracket=c.book!=null||cryoKey?FindBookBracket(sr,interaction):FindCryoKeypadBracket(sr,interaction);
            }
            highlightContexts[id]=c;return c;
        }

        private void ShowObjectBracketForVr(SpriteRenderer sr, int index)
        {
            if (sr == null || sr.sprite == null) return;
            if(!HighlightPolicy.IsBracket(sr.sprite.name)&&sr.sprite.name!="Interaction_inspect"){sr.enabled=false;return;}
            
            var context=GetHighlightContext(sr);
            var interaction=context.interaction;
            if(interaction==null||!context.supported){sr.enabled=false;return;}
            if(sr.sprite.name=="Interaction_inspect"&&itemBracketArtwork!=null)sr.sprite=itemBracketArtwork;
            // Do not turn travel prompts into new object brackets.
            bool travel=context.travel;
            var book=context.book;var pickup=context.pickup;var room=context.room;
            bool sameRoom = room == null || global::PlayerState.currentRoom == null || MapSameRoom(room,global::PlayerState.currentRoom);
            bool consumed = pickup != null && (pickup.triggered || pickup.fadingOut);
            bool reading = book != null && (book.open || book.opening);
            var bookBracket=context.bracket;
            if(!interaction.gameObject.activeInHierarchy||!interaction.enabled||consumed||reading||!sameRoom||travel){sr.enabled=false;return;}
            Bounds objectBounds;
            if(bookBracket==null&&!ItemObjectBounds(interaction,out objectBounds)&&interaction.pointOfInterest==null){sr.enabled=false;return;}
            Vector3 rangeOrigin = bookBracket != null ? BracketOrigin(bookBracket) : ItemObjectBounds(interaction,out objectBounds)?objectBounds.center:interaction.pointOfInterest!=null?interaction.pointOfInterest.position:interaction.transform.position;
            Vector3 delta = rangeOrigin - camera.transform.position;
            bool visible = HighlightPolicy.Visible(interaction.gameObject.activeInHierarchy,
                interaction.enabled, consumed, reading, sameRoom, travel, delta.x * delta.x + delta.y * delta.y, delta.z);
            if(visible){
                if(context.sightFrame<0||Time.frameCount-context.sightFrame>=6){
                    context.sightFrame=Time.frameCount;
                    context.clearSight=ObjectMarkerClearSight(interaction,rangeOrigin);
                }
                visible=context.clearSight;
            }
            if (book != null && Time.realtimeSinceStartup >= nextBookGateLog)
            {
                nextBookGateLog = Time.realtimeSinceStartup + 5f;
                MelonLoader.MelonLogger.Msg("BOOK VISIBILITY: object=" + interaction.gameObject.name
                    + " visible=" + visible + " active=" + interaction.gameObject.activeInHierarchy
                    + " spriteActive=" + sr.gameObject.activeInHierarchy + " enabled=" + interaction.enabled
                    + " consumed=" + consumed + " reading=" + reading + " sameRoom=" + sameRoom + " travel=" + travel
                    + " origin=" + FormatMarkerVector(rangeOrigin) + " camera=" + FormatMarkerVector(camera.transform.position)
                    + " model=" + (bookBracket == null ? "none" : bookBracket.paper != null ? bookBracket.paper.name : bookBracket.model.name)
                    + " worldSize=" + (bookBracket == null ? "none" : bookBracket.paper != null ? FormatMarkerVector(bookBracket.paper.bounds.size) : FormatMarkerVector(bookBracket.model.GetComponent<MeshRenderer>().bounds.size)));
            }
            if (!visible || interaction.gameObject.name == "StompZone") {sr.enabled=false;return;}
            // The game's popup animation can collapse its Y scale, fade alpha and
            // disable SR based on the flat-camera/player-facing interaction state.
            // Override only while each VR eye renders; restore ALL fields in finally.
            sr.enabled = true;
            sr.forceRenderingOff = false;
            var tint = markerColors[index];
            // An invisible/black animation sample is not the desired white artwork.
            if (tint.a < 0.1f || Math.Max(tint.r, Math.Max(tint.g, tint.b)) < 0.1f) tint = Color.white;
            tint.a = 1f;
            sr.color = tint;
            var scale = markerScales[index];
            scale.y = 1f;
            sr.transform.localScale = scale;
            if (bookBracket != null) {PlaceBookBracket(bookBracket);var proxy=bookBracket.proxy;ShowItemHologram(sr,proxy.transform.position,proxy.transform.rotation,proxy.transform.lossyScale);proxy.enabled=false;}
            else PlaceObjectHologram(sr,interaction);
            if (Time.realtimeSinceStartup >= nextObjectHighlightLog)
            {
                nextObjectHighlightLog = Time.realtimeSinceStartup + 5f;
                MelonLoader.MelonLogger.Msg("HEADSET OBJECT BRACKET: object=" + interaction.gameObject.name
                    + " sprite=" + sr.sprite.name + " originalEnabled=" + markerEnabled[index]
                    + " originalAlpha=" + markerColors[index].a + " originalScaleY=" + markerScales[index].y
                    + " position=" + FormatMarkerVector(markerPositions[index])
                    + " bookAnchor=" + (bookBracket == null ? "none" : FormatMarkerVector(bookBracket.proxy.transform.position)));
            }
        }
    }
}

