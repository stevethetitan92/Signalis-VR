using System;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private string lastHandVisibility;
  private int handVisibilityReports;
  private void ObserveHandVisibility(Camera eye,int eyeIndex) {
   if(eyeIndex!=0||handVisibilityReports>=80)return;
   try {
    int rendered=0,tracked=0;
    for(int h=0;h<2;h++) {
     if(handsRenderers[h]!=null&&handsRenderers[h].enabled&&handsRenderers[h].gameObject.activeInHierarchy&&!handsRenderers[h].forceRenderingOff)rendered|=1<<h;
     if(controllerBodies[h]!=null&&(controllerBodies[h].enabled||(handPreparedMask&(1<<h))!=0))tracked|=1<<h;
    }
    string state="prepared="+handPreparedMask+" rendered="+rendered+" tracked="+tracked+" failed="+handsFailed
     +" game="+global::PlayerState.gameState+" paused="+global::PlayerState.paused+" event="+global::PlayerState.eventScreen
     +" menu="+pauseMenuVisible+" book="+bookScreenVisible+" dialogue="+dialogueScreenVisible;
    if(state==lastHandVisibility)return;
    lastHandVisibility=state;handVisibilityReports++;
    MelonLogger.Msg("HAND VISIBILITY: frame="+Time.frameCount+" "+state+" cameraNear="+eye.nearClipPlane+" projection="+eye.projectionMatrix.m22+","+eye.projectionMatrix.m23);
    for(int h=0;h<2;h++)if(handsRenderers[h]!=null) {
     var r=handsRenderers[h];var center=eye.worldToCameraMatrix.MultiplyPoint3x4(r.bounds.center);
     MelonLogger.Msg("HAND VISIBILITY DETAIL: hand="+h+" boundsEye="+WeaponVector(center)+" dynamicOcclusion="+r.allowOcclusionWhenDynamic+" cameraOcclusion="+eye.useOcclusionCulling+" boundsSize="+WeaponVector(r.bounds.size)+" wristScale="+WeaponVector(handsObjects[h].transform.lossyScale));
    }
   }catch(Exception ex){handVisibilityReports=80;MelonLogger.Warning("Hand visibility diagnostics stopped: "+ex.Message);}
  }
  private int handViewReports;
  private float nextHandViewReport;
  private void ObserveHandTrackingView(Camera eye,int eyeIndex) {
   if(!handsScoped||eyeIndex!=0||handViewReports>=30||Time.realtimeSinceStartup<nextHandViewReport)return;
   nextHandViewReport=Time.realtimeSinceStartup+1f;handViewReports++;
   try {
    for(int h=0;h<2;h++) {
     var tracked=controllerMarkers[h].transform.position;
     var rawExpected=Quaternion.Inverse(headComfortPose)*((rawControllerPositions[h]-trackedHeadPosition)*UnitsPerMetre);
     var gripDelta=HandPlacement.CalibrateGrip(Vector3.zero,controllerMarkers[h].transform.rotation,UnitsPerMetre,controllerGripOffsets[h]);
     var expected=rawExpected+Quaternion.Inverse(stereoRotation)*gripDelta;
     var mapped=Quaternion.Inverse(stereoRotation)*(tracked-stereoPosition);
     var hand=handsObjects[h].transform.TransformPoint(handPalmCenters[h]);
     MelonLogger.Msg("HAND VIEW: frame="+Time.frameCount+" pose="+stereoTraceId+" hand="+h
      +" rawHead="+WeaponVector(trackedHeadPosition)+" rawController="+WeaponVector(rawControllerPositions[h])
      +" gripDeltaWorld="+WeaponVector(gripDelta)+" controllerForward="+WeaponVector(controllerMarkers[h].transform.forward)+" controllerUp="+WeaponVector(controllerMarkers[h].transform.up)+" rawExpectedHeadLocal="+WeaponVector(rawExpected)+" expectedHeadLocal="+WeaponVector(expected)+" mappedHeadLocal="+WeaponVector(mapped)
      +" mappingDelta="+WeaponVector(mapped-expected)+" handMinusController="+WeaponVector(hand-tracked)
      +" controllerEye="+WeaponVector(eye.worldToCameraMatrix.MultiplyPoint3x4(tracked))
      +" handEye="+WeaponVector(eye.worldToCameraMatrix.MultiplyPoint3x4(hand)));
    }
   }catch(Exception ex){handViewReports=30;MelonLogger.Warning("Hand view diagnostics stopped: "+ex.Message);}
  }
 }
}


