using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private string stereoRouteReason="not sampled";
 private bool nativeEventContext;
 private Camera stereoReturnCamera;
 private bool fastStereoReturn;
 private bool FastStereoReturnEligible(bool eligible){
  if(!eligible){
   // Eligibility still gates books, event cameras, cinematics, death and loading.
   // Once those clear, a retained gameplay camera needs no artificial dwell.
   if(!recovery.Paused){stereoReturnCamera=camera;fastStereoReturn=camera!=null;}
   else if(camera!=stereoReturnCamera)fastStereoReturn=false;
   return false;
  }
  return recovery.Paused&&fastStereoReturn&&camera==stereoReturnCamera;
 }
 private string StereoGameplayBlocker(){
  var state=global::PlayerState.gameState;
  // An event-camera interaction can temporarily report dialogue/itemView while
  // its room camera stays enabled but does not show the active scene. Retain
  // native capture through that dialogue, until a different native state wins.
  if(state==global::PlayerState.gameStates.eventScreen)nativeEventContext=true;
  else if(state!=global::PlayerState.gameStates.dialogue&&!global::BlackSleekGuiSubs.itemView)nativeEventContext=false;
  if(global::PlayerState.hp<=0||global::PlayerState.gameOver)return "death";
  // Legacy menu flags can remain set during playable first person. Use the
  // current game state and visible screens, as WeaponGameplayReady already does.
  if(pauseMenuVisible)return "visible pause menu";
  if(bookScreenVisible)return "open book";
  if(StorageStereoActive())return null;
  // Item inspection reuses the cutscene flag; its panel belongs over the world.
  if(perspectiveCutsceneReturn!=null||ModHudCinematicVisible())return "native cinematic camera";
  if(state==global::PlayerState.gameStates.menu||state==global::PlayerState.gameStates.paused||state==global::PlayerState.gameStates.inventory||state==global::PlayerState.gameStates.book||state==global::PlayerState.gameStates.loading)return "screen state: "+state;
  if(nativeEventContext)return "native event camera";
  if(global::BlackSleekGuiSubs.itemView)return null;
  if(global::PlayerState.cutscene&&state!=global::PlayerState.gameStates.dialogue)return "cutscene";
  if(state==global::PlayerState.gameStates.play||state==global::PlayerState.gameStates.dialogue||state==global::PlayerState.gameStates.traversing)return null;
  return "non-gameplay state: "+state;
 }
 private bool StereoGameplayState(){return StereoGameplayBlocker()==null;}
 private bool ObserveStereoEligibility(){
  string reason=StereoGameplayBlocker();
  // Native close-up interactions disable the room camera and may hide its
  // geometry. Manually rendering that camera is not a valid world fallback.
  if(reason==null&&(camera==null||!camera.gameObject.activeInHierarchy||(!camera.enabled&&!StorageStereoActive())))reason="inactive gameplay camera";
  string route=reason??"world stereo";
  if(stereoRouteReason!=route){stereoRouteReason=route;MelonLoader.MelonLogger.Msg("STEREO ROUTE: "+route+" legacyMenu="+global::PlayerState.menu+" legacyPause="+global::PlayerState.pauseMenu);}
  return reason==null;
 }
 private void DarkenPistolTexture(Texture2D texture){
  var pixels=texture.GetPixels32();
  for(int i=0;i<pixels.Length;i++){var c=pixels[i];c.r=(byte)(c.r*.40f);c.g=(byte)(c.g*.40f);c.b=(byte)(c.b*.40f);pixels[i]=c;}
  texture.SetPixels32(pixels);texture.Apply(false,true);
 }
}}




