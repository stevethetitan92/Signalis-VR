$ErrorActionPreference='Stop'
# The two-hit HP damage feature was retired before 0.7.10 (see development log).
$s=(Get-Content "$PSScriptRoot/SwingProd.cs" -Raw)+(Get-Content "$PSScriptRoot/ProdContact.cs" -Raw)
if($s -match 'ProdDamage.AfterHit|hitbox.HP\s*=|\.TakeDamage\('){throw 'Retired prod HP damage returned'}
& "$PSScriptRoot/test-prod-contact.ps1"
'PASS current contact stun policy; retired two-hit damage is absent. Native AI behavior unverified.'
