$ErrorActionPreference = 'Stop'
$tests = @'
using System;
namespace SignalisVrTracking {
    public static class HighlightPolicyTests {
        private static int count;
        private static void Check(bool value, string message) { count++; if (!value) throw new Exception(message); }
        public static string Run() {
            Check(HighlightPolicy.IsBracket("interaction"), "Original book brackets excluded");
            Check(HighlightPolicy.IsBracket("interactionScaleable"), "Scalable brackets excluded");
            foreach (string s in new[] { "Interaction_inspect", "Door_interactions_1", "Door_interactions_15", "Door_interactions_17", "", null })
                Check(!HighlightPolicy.IsBracket(s), "Non-bracket artwork selected");
            // A nearby active unread book can render despite no game inRange flag.
            Check(HighlightPolicy.Visible(true,true,false,false,true,false,25,3), "Nearby book hidden");
            Check(!HighlightPolicy.Visible(false,true,false,false,true,false,25,3), "Inactive object revealed");
            Check(!HighlightPolicy.Visible(true,false,false,false,true,false,25,3), "Disabled interaction revealed");
            Check(!HighlightPolicy.Visible(true,true,true,false,true,false,25,3), "Consumed pickup revealed");
            Check(!HighlightPolicy.Visible(true,true,false,true,true,false,25,3), "Open book received brackets");
            Check(!HighlightPolicy.Visible(true,true,false,false,false,false,25,3), "Other-room object revealed");
            Check(!HighlightPolicy.Visible(true,true,false,false,true,true,25,3), "Travel object received brackets");
            Check(HighlightPolicy.Visible(true,true,false,false,true,false,900,11.99f), "Range edge hidden");
            Check(HighlightPolicy.Visible(true,true,false,false,true,false,900000f,3), "Visible far object hidden by distance");
            Check(HighlightPolicy.Visible(true,true,false,false,true,false,25,12), "Visible high object hidden by height");
            Check(HighlightPolicy.Visible(true,true,false,false,true,false,25,-12), "Visible low object hidden by height");
            return "PASS: " + count + " object bracket selection/state/range checks; runtime rendering unverified.";
        }
    }
}
'@
Add-Type -TypeDefinition ((Get-Content (Join-Path $PSScriptRoot 'HighlightPolicy.cs') -Raw) + $tests.Replace('using System;', ''))
[SignalisVrTracking.HighlightPolicyTests]::Run()

# Verify the emitted DLL, including finally-based restoration in the eye loop.
Add-Type -Path 'E:\SteamLibrary\steamapps\common\SIGNALIS\MelonLoader\Mono.Cecil.dll'
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $PSScriptRoot 'SignalisVrTracking.dll'))
try {
    $tracking = $assembly.MainModule.Types | Where-Object FullName -eq 'SignalisVrTracking.Tracking'
    $face = $tracking.Methods | Where-Object Name -eq 'FaceMarkersForVr'
    $searches = @($face.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.GenericInstanceMethod] -and $_.Operand.Name -eq 'FindObjectsOfTypeAll' } | ForEach-Object { $_.Operand.GenericArguments[0].FullName })
    if ($searches -contains 'UnityEngine.Sprite' -or $searches -contains 'UnityEngine.SpriteRenderer') { throw 'Global artwork scan returned to marker render path' }
    if ($searches -notcontains 'interactionPopup') { throw 'Object popup discovery missing' }
    $faceCalls = @($face.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] } | ForEach-Object { $_.Operand.Name })
    if ($faceCalls -notcontains 'Apply' -or $faceCalls -notcontains 'ShowObjectBracketForVr') { throw 'Suppression or functional brackets lost' }
    $restore = $tracking.Methods | Where-Object Name -eq 'RestoreMarkerRotations'
    $calls = @($restore.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] } | ForEach-Object { $_.Operand.Name })
    foreach ($setter in 'set_sprite','set_enabled','set_color','set_forceRenderingOff','set_rotation','set_position','set_localScale') {
        if ($calls -notcontains $setter) { throw "Missing compiled restoration: $setter" }
    }
    $render = $tracking.Methods | Where-Object Name -eq 'RenderStereo'
    $finalizers = @($render.Body.ExceptionHandlers | Where-Object HandlerType -eq 'Finally')
    $hasRestore = $false
    foreach ($handler in $finalizers) {
        $instruction = $handler.HandlerStart
        while ($instruction -and $instruction -ne $handler.HandlerEnd) {
            if ($instruction.Operand -is [Mono.Cecil.MethodReference] -and $instruction.Operand.Name -eq 'RestoreMarkerRotations') { $hasRestore = $true }
            $instruction = $instruction.Next
        }
    }
    if (-not $hasRestore) { throw 'Eye render does not restore marker state in finally' }
    'PASS: compiled DLL restores artwork, enabled, color, rendering veto and transforms in the eye-render finally path.'
} finally { $assembly.Dispose() }

