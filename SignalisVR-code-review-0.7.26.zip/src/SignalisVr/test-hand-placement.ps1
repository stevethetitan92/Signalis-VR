$ErrorActionPreference='Stop'
$stub=@'
using System;
using N=System.Numerics;
namespace UnityEngine {
 public struct Vector3 {
  public N.Vector3 v; public float x {get{return v.X;}} public float y {get{return v.Y;}} public float z {get{return v.Z;}}
  public Vector3(float x,float y,float z){v=new N.Vector3(x,y,z);}
  public static Vector3 operator +(Vector3 a,Vector3 b){return new Vector3{v=a.v+b.v};}
  public static Vector3 operator -(Vector3 a,Vector3 b){return new Vector3{v=a.v-b.v};}
  public static Vector3 Scale(Vector3 a,Vector3 b){return new Vector3{v=a.v*b.v};}
 }
 public struct Quaternion {
  public N.Quaternion q;
  public static Vector3 operator *(Quaternion a,Vector3 b){return new Vector3{v=N.Vector3.Transform(b.v,a.q)};}
 }
}
'@
$checks=@'
public static class HandPlacementTests {
 public static string Run() {
  var controller=new UnityEngine.Vector3(11,-8,17);
  var palm=new UnityEngine.Vector3(.1f,.03f,.14f);
  int count=0;
  foreach(float scale in new[]{.5f,1f,5f,-1f})for(int i=0;i<36;i++) {
   var q=new UnityEngine.Quaternion{q=N.Quaternion.CreateFromYawPitchRoll(i*.13f,i*.19f,i*.31f)};
   var s=new UnityEngine.Vector3(scale,2f,3f);
   var wrist=SignalisVrTracking.HandPlacement.PalmAnchor(controller,q,palm,s);
   var result=wrist.v+N.Vector3.Transform(palm.v*s.v,q.q);
   if(N.Vector3.Distance(result,controller.v)>.00001f)throw new Exception("Palm anchor drifts with rotation or scale");
   var nativePalm=new UnityEngine.Vector3(2,3,7);var nativeModel=new UnityEngine.Vector3(1,5,4);
   var model=SignalisVrTracking.HandPlacement.WeaponAnchor(controller,q,nativePalm,nativeModel);
   var resultingPalm=model.v+N.Vector3.Transform(nativePalm.v-nativeModel.v,q.q);
   if(N.Vector3.Distance(resultingPalm,controller.v)>.00001f)throw new Exception("Gun pivot displaces palm");
   var corrected=SignalisVrTracking.HandPlacement.TrackedPalm(controller,q,5f);
   var shift=N.Vector3.Transform(corrected.v-controller.v,N.Quaternion.Inverse(q.q));
   if(N.Vector3.Distance(shift,new N.Vector3(0,0,0))>.00001f)throw new Exception("Grip offset wrong units/basis");
   var lowered=SignalisVrTracking.HandPlacement.CalibrateGrip(controller,q,5f,new UnityEngine.Vector3(.02f,-.03f,.04f));
   var localDelta=N.Vector3.Transform(lowered.v-controller.v,N.Quaternion.Inverse(q.q));
   if(N.Vector3.Distance(localDelta,new N.Vector3(.1f,-.15f,.2f))>.00001f)throw new Exception("Grip correction fails to follow controller rotation or uses wrong scale");
   count++;
  }
  var identity=new UnityEngine.Quaternion{q=N.Quaternion.Identity};
  var raw=SignalisVrTracking.HandPlacement.CalibrateGrip(controller,identity,5f,new UnityEngine.Vector3(0,0,0));
  if(N.Vector3.Distance(raw.v,controller.v)>.00001f)throw new Exception("Missing runtime grip must retain raw origin");
  return "PASS: "+count+" rotated/scaled palm placements keep controller at palm; not a headset calibration test.";
 }
}
'@
$helper=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'HandPlacement.cs')).Replace('using UnityEngine;','').Replace('Vector3','UnityEngine.Vector3').Replace('Quaternion','UnityEngine.Quaternion')
Add-Type -TypeDefinition ($stub+$helper+$checks)
[HandPlacementTests]::Run()
$main=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
if($main.IndexOf('            PrepareControllerHands();') -gt $main.IndexOf('            PrepareControllerWeapon();')){throw 'Grip reference must be captured before weapon relocation'}
if($main.IndexOf('            AlignControllerHandGrip();') -lt $main.IndexOf('            PrepareControllerWeapon();')){throw 'Grip must follow relocated weapon'}
'PASS: grip capture/application order guard.'



