namespace SignalisVrTracking { internal static class HdShotgunData {
public static readonly string Geometry=HdAsset.Read("Shotgun-0.bin");
public static readonly string[] Textures={"",HdAsset.Read("Shotgun-1.bin"),HdAsset.Read("Shotgun-2.bin"),"",HdAsset.Read("Shotgun-3.bin"),HdAsset.Read("Shotgun-4.bin")};
public static readonly float[] Colors={1.0f,0.0f,0.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f};
public static readonly UnityEngine.Vector3 Pump=new UnityEngine.Vector3(-0.00012600f,0.05000000f,0.43400000f);
public static readonly UnityEngine.Vector3 TriggerPivot=new UnityEngine.Vector3(0.00171800f,0.04820000f,0.06280000f);
public static readonly UnityEngine.Vector3 Muzzle=new UnityEngine.Vector3(0.00000000f,0.08870000f,0.77600000f);
} }
