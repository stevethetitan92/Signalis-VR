using System;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed class RifleChamberPolicy {
  public int Mask {get;private set;}
  public int Spent {get;private set;}
  public void Reset(){Mask=Spent=0;}
  public void Ejected(){Spent=0;}
  public bool Empty(int chamber){return chamber>=0&&chamber<2&&(Mask&(1<<chamber))==0;}
  public void Sync(int count){count=Math.Max(0,Math.Min(2,count));while(Count>count){int removed=Mask&-Mask;Spent|=removed;Mask&=Mask-1;}while(Count<count){Mask|=Empty(0)?1:2;}}
  public int Count {get{return (Mask&1)+((Mask>>1)&1);}}
  public bool Insert(int chamber){if(!Empty(chamber))return false;Mask|=1<<chamber;Spent&=~(1<<chamber);return true;}
  public int Candidate(float upper,float lower){if(float.IsNaN(upper)||float.IsNaN(lower))return -1;int c=upper<=lower?0:1;return Math.Min(upper,lower)<.014f&&Empty(c)?c:-1;}
 }
 public sealed partial class Tracking {
  private readonly RifleChamberPolicy rifleChambers=new RifleChamberPolicy();
  private readonly Vector3[] rifleChamberWorld=new Vector3[2];
  private IntPtr rifleChamberWeapon;private int rifleCandidate=-1,riflePendingChamber=-1;
  private void PrepareRifleChambers(Quaternion turn,Vector3 pivot){
   var w=global::InventoryManager.EquippedWeapon;if(rifleChamberWeapon!=w.Pointer){rifleChambers.Reset();rifleChamberWeapon=w.Pointer;}rifleChambers.Sync(w.magAmmo);
   rifleChamberWorld[0]=selectedRoot.transform.TransformPoint(pivot+turn*(HdRifleData.Chamber0-pivot));
   rifleChamberWorld[1]=selectedRoot.transform.TransformPoint(pivot+turn*(HdRifleData.Chamber1-pivot));
   additionalChamber=rifleChamberWorld[rifleChambers.Empty(0)?0:1];
  }
  private bool RifleChamberContact(Vector3 tip,Vector3 direction){
   var w=global::InventoryManager.EquippedWeapon;rifleChambers.Sync(w.magAmmo);
   int candidate=rifleChambers.Candidate(Vector3.Distance(tip,rifleChamberWorld[0])/UnitsPerMetre,Vector3.Distance(tip,rifleChamberWorld[1])/UnitsPerMetre);
   if(candidate!=rifleCandidate){hingedReload.ResetInsertionDwell();rifleCandidate=candidate;}
   if(candidate<0||Vector3.Dot(direction,additionalLoadDirection)<.9f)return false;
   additionalChamber=rifleChamberWorld[candidate];return true;
  }
 }
}
