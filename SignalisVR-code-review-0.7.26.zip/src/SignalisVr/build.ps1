param([Parameter(Mandatory=$true)][string]$GamePath)
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'backup-installed.ps1') -GamePath $GamePath
$managed = Join-Path $GamePath 'MelonLoader\Managed'
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$references = @(
    (Join-Path $managed 'Assembly-CSharp.dll'),
    (Join-Path $managed 'FMODUnity.dll'),
    (Join-Path $managed 'Assembly-CSharp-firstpass.dll'),
    (Join-Path $managed 'AstarPathfindingProject.dll'),
    (Join-Path $managed 'Rewired_Core.dll'),
    (Join-Path $managed 'UnityEngine.PhysicsModule.dll'),
    (Join-Path $managed 'UnityEngine.ParticleSystemModule.dll'),
    (Join-Path $managed 'UnityEngine.AudioModule.dll'),
    (Join-Path $managed 'UnityEngine.IMGUIModule.dll'),
    (Join-Path $managed 'UnityEngine.ImageConversionModule.dll'),
    (Join-Path $managed 'UnityEngine.TextRenderingModule.dll'),
    (Join-Path $GamePath 'MelonLoader\0Harmony.dll'),
    (Join-Path $managed 'UnityEngine.UI.dll'),
    (Join-Path $managed 'UnityEngine.UIModule.dll'),
    (Join-Path $GamePath 'MelonLoader\MelonLoader.dll'),
    (Join-Path $managed 'UnityEngine.CoreModule.dll'),
    (Join-Path $managed 'UnityEngine.AnimationModule.dll'),
    (Join-Path $managed 'UnityEngine.InputLegacyModule.dll'),
    (Join-Path $managed 'UnityEngine.ScreenCaptureModule.dll'),
    (Join-Path $managed 'UnhollowerBaseLib.dll'),
    (Join-Path $managed 'Il2Cppmscorlib.dll'),
    (Join-Path $framework 'mscorlib.dll'),
    (Join-Path $framework 'System.dll'),
    (Join-Path $framework 'System.Core.dll')
)
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.dll')) | Out-Null
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.CSharp.dll')) | Out-Null
$metadata = [System.Collections.Generic.List[Microsoft.CodeAnalysis.MetadataReference]]::new()
foreach ($reference in $references) {
    $metadata.Add([Microsoft.CodeAnalysis.MetadataReference]::CreateFromFile($reference))
}
$options = [Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions]::new([Microsoft.CodeAnalysis.OutputKind]::DynamicallyLinkedLibrary).WithOptimizationLevel([Microsoft.CodeAnalysis.OptimizationLevel]::Release).WithDeterministic($true)
$trees = foreach ($relative in Get-Content (Join-Path $PSScriptRoot 'source-files.txt')) {
    if ([string]::IsNullOrWhiteSpace($relative)) { continue }
    [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText([IO.File]::ReadAllText((Join-Path $PSScriptRoot $relative)))
}
$compilation = [Microsoft.CodeAnalysis.CSharp.CSharpCompilation]::Create('SignalisVrTracking', [Microsoft.CodeAnalysis.SyntaxTree[]]$trees, $metadata, $options)
$destination = Join-Path $PSScriptRoot 'SignalisVrTracking.dll'
$temporary = Join-Path $PSScriptRoot 'SignalisVrTracking.build.tmp'
$resources = [System.Collections.Generic.List[Microsoft.CodeAnalysis.ResourceDescription]]::new()
foreach ($asset in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'embedded-hd') -File | Sort-Object Name) {
    $assetPath = $asset.FullName
    $provider = [Func[IO.Stream]]{ [IO.File]::OpenRead($assetPath) }.GetNewClosure()
    $resources.Add([Microsoft.CodeAnalysis.ResourceDescription]::new(('SignalisVR.HD.' + $asset.Name), $provider, $true))
}
$stream = [IO.File]::Create($temporary)
try { $result = $compilation.Emit($stream, $null, $null, $null, $resources, $null, [System.Threading.CancellationToken]::None) } finally { $stream.Dispose() }
$errors = @($result.Diagnostics | Where-Object Severity -eq Error)
$warnings = @($result.Diagnostics | Where-Object Severity -eq Warning)
$errors | ForEach-Object { $_.ToString() }
$warnings | ForEach-Object { $_.ToString() } | Select-Object -Unique
if (-not $result.Success) { throw 'Compilation failed; previous DLL preserved.' }
Move-Item -LiteralPath $temporary -Destination $destination -Force
Write-Output "Built SignalisVrTracking.dll (Release, deterministic; $($warnings.Count) reference/compiler warnings)."


