using System;
using MelonLoader;
namespace SignalisVrTracking {
 public static class MagazineTransferPolicy {
  public static int Amount(int loaded,int capacity,int reserve,bool infinite){return Math.Max(0,Math.Min(Math.Max(0,capacity-loaded),infinite?Math.Max(0,capacity):Math.Max(0,reserve)));}
 }
 public sealed partial class Tracking {
  private void CommitPhysicalMagazine(global::AnWeapon w){
   int before=w.magAmmo,reserve=ShotgunReserve(w),amount=MagazineTransferPolicy.Amount(before,w.MagSize,reserve,infiniteAmmo);
   if(amount>0){if(!infiniteAmmo)global::InventoryManager.SetCount(w.ammoItem,reserve-amount);
    try{w.magAmmo=before+amount;}catch{if(!infiniteAmmo)global::InventoryManager.SetCount(w.ammoItem,reserve);throw;}}
   MelonLogger.Msg("PHYSICAL MAGAZINE: "+w.parentItem._item+" loaded="+w.magAmmo+" transferred="+amount+" reserve="+ShotgunReserve(w));
  }
 }
}
