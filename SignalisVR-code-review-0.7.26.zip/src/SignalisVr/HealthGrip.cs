using System;
using System.Collections.Generic;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Transform healthGripFrame,healthTriggerPivot;
  private Quaternion healthTriggerRest=Quaternion.identity;
  private readonly List<Mesh> healthPrivateMeshes=new List<Mesh>();
  private readonly List<Renderer> healthTriggerParts=new List<Renderer>();
  private float healthFinishTime=-100f;
  private bool healthUsed;
  private void SplitHealthTrigger(Mesh source,GameObject geometry,MeshRenderer body) {
   if(!source.isReadable||(source.name!="HealthSpray"&&source.name!="HealthSprayPlus")||(source.vertexCount!=892&&source.vertexCount!=894)||source.subMeshCount!=1)return;
   var triangles=source.GetTriangles(0);if(triangles.Length!=1512)return;
   var fixedFaces=new List<int>();var leverFaces=new List<int>();
   for(int t=0;t<triangles.Length/3;t++)for(int i=0;i<3;i++)(t>=401&&t<=418?leverFaces:fixedFaces).Add(triangles[t*3+i]);
   var fixedMesh=UnityEngine.Object.Instantiate(source);fixedMesh.name=source.name+"_TriggerSeparated";fixedMesh.SetTriangles(fixedFaces.ToArray(),0);healthPrivateMeshes.Add(fixedMesh);geometry.GetComponent<MeshFilter>().sharedMesh=fixedMesh;
   var lever=UnityEngine.Object.Instantiate(source);lever.name=source.name+"_MovingLever";lever.SetTriangles(leverFaces.ToArray(),0);healthPrivateMeshes.Add(lever);
   var p=new Vector3(-.077f,.4076f,-.01f);var v=lever.vertices;for(int i=0;i<v.Length;i++)v[i]-=p;lever.vertices=v;lever.RecalculateBounds();
   var go=new GameObject("SignalisVR_HealthTrigger");go.layer=30;go.transform.SetParent(geometry.transform,false);go.transform.localPosition=p;healthTriggerPivot=go.transform;go.AddComponent<MeshFilter>().sharedMesh=lever;var r=go.AddComponent<MeshRenderer>();r.sharedMaterials=body.sharedMaterials;r.enabled=false;healthTriggerParts.Add(r);healthGripFrame=geometry.transform;
  }
  private void FitHealthGrip() {
   if(healthGripFrame==null||handsObjects[1]==null)return;
   healthGripFrame.rotation=rightWeaponRotation*Quaternion.Euler(0,90,0);
   var palm=controllerMarkers[1].transform.position-rightWeaponRotation*Vector3.right*(.010f*UnitsPerMetre);
   quickHealthRoot.transform.position+=palm-healthGripFrame.TransformPoint(new Vector3(.40f,-.36f,.285f));
   float squeeze=RepairSprayUseMotion.Amount(Time.realtimeSinceStartup-healthSqueezeTime);
   if(healthTriggerPivot!=null)healthTriggerPivot.localRotation=healthTriggerRest*Quaternion.Euler(0,0,16*squeeze);
   // Fingers are animated on the Elster rig.

   foreach(var r in healthTriggerParts)if(r!=null)r.enabled=true;
  }
  private void ClearHealthGrip(){ClearRepairHand();healthGripFrame=null;healthTriggerPivot=null;healthTriggerParts.Clear();foreach(var m in healthPrivateMeshes)if(m!=null)UnityEngine.Object.Destroy(m);healthPrivateMeshes.Clear();}
 }
}
