$ErrorActionPreference='Stop'
$root=$PSScriptRoot
foreach($f in @('CalibrationRoom.cs','TestMenuActions.cs','HeldModules.cs','source-files.txt','ControlsTab.cs')){
 $s=Get-Content (Join-Path $root $f) -Raw
 if($s -match 'CreateCalibrationSignal|CreateCalibrationPedestal|CalibrationButtonTrigger|CalibrationSignal.cs|CalibrationPedestal.cs|121.000|receiverCalibrationDisplay'){throw "Signal test reference remains in $f"}
}
'PASS receiver test audio, pedestal, interaction hook and display removed from active build.'
