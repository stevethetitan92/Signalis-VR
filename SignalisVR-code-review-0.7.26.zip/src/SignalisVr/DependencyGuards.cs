using System;
using HarmonyLib;
using UnityEngine;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private void InstallDependencyGuards(){
  InstallOptionalModSwitches();
  try{
   var type=AccessTools.TypeByName("MyFlashlightModTest.FlashlightModTest");
   if(type==null)return;
   var method=AccessTools.DeclaredMethod(type,"OnSceneWasLoaded",new[]{typeof(int),typeof(string)});
   if(method==null)return;
   new HarmonyLib.Harmony("signalis.vr.flashlight.scene.guard").Patch(method,prefix:new HarmonyMethod(typeof(Tracking),nameof(FlashlightSceneReady)));
   MelonLoader.MelonLogger.Msg("FLASHLIGHT GUARD: skip scene setup when native flashlight hierarchy is absent.");
  }catch(Exception ex){MelonLoader.MelonLogger.Warning("Flashlight scene guard unavailable: "+ex.Message);}
 }
 private static bool FlashlightSceneReady(){
  // The installed flashlight dependency dereferences this exact hierarchy without null checks.
  // Let its original setup run unchanged whenever that hierarchy is available.
  var root=GameObject.Find("__Prerequisites__");if(root==null)return false;
  var flashlight=root.transform.Find("Character Origin/Character Root/Ellie_Default/FlashLightHolder/FlashLight");
  return flashlight!=null&&flashlight.childCount>1;
 }
}}
