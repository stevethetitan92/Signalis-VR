using UnityEngine;
using UnityEngine.SceneManagement;
namespace SignalisVrTracking {public sealed partial class Tracking {
 private Camera redPitEntryCamera;
 private bool redPitEntryFinished;
 private Camera FindRedPitArrivalSource(){
  if(SceneManager.GetActiveScene().name!="PEN_Hole"||redPitEntryFinished)return null;
  foreach(var c in Camera.allCameras)if(c!=null&&c.isActiveAndEnabled&&c.orthographic&&c.name=="Main Camera"&&c.transform.parent!=null&&c.transform.parent.name=="HoleCameras")return c;
  return null;
 }
 private Camera RedPitEntryView(){
  if(!immersiveRequested||!active||!stereo||stopping)return null;
  var source=FindRedPitArrivalSource();if(source==null)return null;
  var root=GameObject.Find("__Prerequisites__/Character Origin/Character Root");if(root==null)return null;
  if(redPitEntryCamera==null){var go=new GameObject("SignalisVR_RedPitArrival");redPitEntryCamera=go.AddComponent<Camera>();redPitEntryCamera.enabled=false;}
  var entry=redPitEntryCamera;entry.CopyFrom(source);entry.enabled=false;entry.orthographic=false;entry.fieldOfView=75;
  entry.transform.SetParent(root.transform,false);
  // The inspected perspective mod uses this exact local eye location and orientation.
  entry.transform.localPosition=new Vector3(.3f,8.4f,2.1f);entry.transform.localRotation=Quaternion.identity;entry.transform.localScale=Vector3.one;
  return entry;
 }
 private void UpdateRedPitEntry(){
  if(SceneManager.GetActiveScene().name!="PEN_Hole"){
   redPitEntryFinished=false;if(redPitEntryCamera!=null){UnityEngine.Object.Destroy(redPitEntryCamera.gameObject);redPitEntryCamera=null;}return;
  }
  if(redPitEntryCamera!=null&&camera==redPitEntryCamera&&!questMenuScene&&FindRedPitArrivalSource()==null){
   redPitEntryFinished=true;questMenuScene=true;sceneRecoveryRequest=false;sceneRecoveryDraining=true;sceneStableSince=-1;
   MelonLoader.MelonLogger.Msg("RED PIT ENTRY: arrival camera ended; automatically acquiring normal first-person camera. Native inspection/jump cameras remain untouched.");
  }
 }
}}
