using System;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed class EjectorStroke {
  private bool previous,fired;private float origin;
  public bool Held {get;private set;}public float Pull {get;private set;}
  public void Reset(){Held=previous=fired=false;Pull=0;}
  public bool Tick(bool ready,bool grip,bool near,float position){
   bool down=grip&&!previous;previous=grip;
   if(!ready||!grip||float.IsNaN(position)||float.IsInfinity(position)){Held=false;Pull=0;return false;}
   if(!Held&&down&&near){Held=true;origin=position;fired=false;}
   if(!Held)return false;
   if(Math.Abs(position-origin)>.15f){Held=false;Pull=0;return false;}
   Pull=Math.Max(0,Math.Min(.025f,origin-position));
   if(!fired&&Pull>=.012f){fired=true;return true;}return false;
  }
 }
 public sealed partial class Tracking {
  private readonly EjectorStroke revolverRod=new EjectorStroke();
  private readonly GripTravel revolverRodTravel=new GripTravel();
  private bool revolverEjectPending;private int revolverRodFrame=-1,revolverLastAmmo=-1,revolverSpent;
  private IntPtr revolverAmmoWeapon;private Vector3 revolverRodContact;
  private readonly MeshRenderer[] revolverEjected=new MeshRenderer[6];
  private readonly Vector3[] revolverEjectedOrigins=new Vector3[6];
  private readonly Quaternion[] revolverEjectedRotations=new Quaternion[6];
  private readonly System.Collections.Generic.Dictionary<Mesh,Mesh> revolverCaseMeshes=new System.Collections.Generic.Dictionary<Mesh,Mesh>();
  private Mesh RevolverCaseMesh(Mesh source){
   Mesh cached;if(revolverCaseMeshes.TryGetValue(source,out cached))return cached;
   // The imported round's case mouth is the authored ring at Z=.070895.
   // Preserve case texture/vertices; remove the projectile above that ring.
   var v=source.vertices;var indices=source.triangles;var kept=new System.Collections.Generic.List<int>();
   float mouth=source.bounds.min.z+.032505f;
   for(int i=0;i<indices.Length;i+=3)if(v[indices[i]].z<=mouth+.00001f&&v[indices[i+1]].z<=mouth+.00001f&&v[indices[i+2]].z<=mouth+.00001f){kept.Add(indices[i]);kept.Add(indices[i+1]);kept.Add(indices[i+2]);}
   cached=UnityEngine.Object.Instantiate(source);cached.name="HD revolver spent case";cached.triangles=kept.ToArray();
   var bounds=source.bounds;bounds.SetMinMax(bounds.min,new Vector3(bounds.max.x,bounds.max.y,mouth));cached.bounds=bounds;
   revolverCaseMeshes.Add(source,cached);return cached;
  }
  private void DestroyRevolverCases(){foreach(var m in revolverCaseMeshes.Values)if(m!=null)UnityEngine.Object.Destroy(m);revolverCaseMeshes.Clear();}
  private Vector3 revolverEjectVelocity;private float revolverEjectTime=-100;
  private void HideRevolverEjected(){foreach(var r in revolverEjected)if(r!=null)r.enabled=false;}
  private void StartRevolverEjection(int loaded){
   revolverEjectTime=Time.realtimeSinceStartup;revolverEjectVelocity=rightWeaponRotation*Vector3.back*(.65f*UnitsPerMetre);
   for(int i=0;i<selectedParts.Count;i++){
    int slot=selectedRoles[i]-10;if(slot<0||slot>=6)continue;
    if(slot>=loaded&&(revolverSpent&(1<<slot))==0){if(revolverEjected[slot]!=null)UnityEngine.Object.Destroy(revolverEjected[slot].gameObject);revolverEjected[slot]=null;continue;}
    var source=selectedParts[i];var r=revolverEjected[slot];
    var mesh=(revolverSpent&(1<<slot))!=0?RevolverCaseMesh(selectedMeshes[i]):selectedMeshes[i];
    if(r==null)r=revolverEjected[slot]=CreateControllerPart(selectedRoot,mesh,source.sharedMaterial,"Ejected cylinder round "+slot,Vector3.zero,Vector3.one);
    r.GetComponent<MeshFilter>().sharedMesh=mesh;
    revolverEjectedOrigins[slot]=source.transform.position;revolverEjectedRotations[slot]=source.transform.rotation;
   }
  }
  private void ShowRevolverEjected(){
   float age=Time.realtimeSinceStartup-revolverEjectTime;if(age<0||age>1.5f)return;
   var gravity=controllerTrackingToWorld*Vector3.down*(4.905f*age*age*UnitsPerMetre);
   for(int i=0;i<6;i++){var r=revolverEjected[i];if(r==null)continue;
    r.transform.SetPositionAndRotation(revolverEjectedOrigins[i]+revolverEjectVelocity*age+gravity,revolverEjectedRotations[i]);r.enabled=true;
   }
  }
  // The user removed the plunger. Reloading never requires an ejector gesture.
  private void PollRevolverEjector(){revolverRod.Reset();revolverEjectPending=false;}
  private void PrepareRevolverEjector(Quaternion swing){
   revolverRod.Reset();revolverSpent=0;
  }
 }
}
