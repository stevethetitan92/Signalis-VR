$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'ControlsTab.cs') -Raw
$policy=$s.Substring($s.IndexOf(' public static class ModMenuSections'))
$policy=$policy.Substring(0,$policy.IndexOf(' public sealed partial class Tracking'))
$start=$s.IndexOf('  private int CurrentModSection()')
$end=$s.IndexOf('  private void DrawControlsTab(')
$methods=$s.Substring($start,$end-$start).Replace('private int CurrentModSection','public int CurrentModSection').Replace('private void SelectModSection','public void SelectModSection')
Add-Type -TypeDefinition ('using System; namespace SignalisVrTracking {'+$policy+@'
public class PageHarness {
 public int wheelPickSlot=2,modMenuSelection=4,wheelPendingChoice=-1; public void OpenWheelPicker(int slot){}
 public bool modMenuControls,modMenuWheel,modMenuCheats,modMenuTest;
'@+$methods+'}}')
$names=[SignalisVrTracking.ModMenuSections]::Names
if(($names -join '|') -ne 'SETTINGS|CHEATS|TEST'){throw 'Tab order incorrect'}
$h=[SignalisVrTracking.PageHarness]::new()
foreach($page in 0..2){$h.SelectModSection($page);if($h.CurrentModSection() -ne $page -or $h.wheelPickSlot -ne -1 -or $h.modMenuSelection -ne 0){throw 'Page selection/picker reset failed'}}
foreach($page in 0..2){foreach($d in @(-1,1)){$next=[SignalisVrTracking.ModMenuSections]::Next($page,$d);if($next -ne [Math]::Clamp($page+$d,0,2)){throw 'Section movement wrong'}}}
$art=Get-Content (Join-Path $PSScriptRoot 'ControlsArtwork.cs') -Raw
$encoded=[regex]::Match($art,'Png="([^"]+)"').Groups[1].Value
$bytes=[Convert]::FromBase64String($encoded)
$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))
if($sha -ne '82AB7188B724C402235D2FE2C0F648CCCCFAF6229AA0438010135FED9B5A2C75'){throw 'Embedded diagram differs from approved v5 image'}
$width=$bytes[16]*16777216+$bytes[17]*65536+$bytes[18]*256+$bytes[19]
$height=$bytes[20]*16777216+$bytes[21]*65536+$bytes[22]*256+$bytes[23]
if($width -ne 1672 -or $height -ne 941){throw 'Image size differs from hit coordinates'}
$menu=Get-Content (Join-Path $PSScriptRoot 'ModMenu.cs') -Raw
foreach($needle in @('if(modMenuTest){ActivateTestMenu(index);return;}','if(modMenuControls){DrawControlsTab(x,y,width,scale);return;}','SelectModSection(ModMenuSections.Next(CurrentModSection(),section))')){if(!$menu.Contains($needle)){throw "Missing controls routing: $needle"}}
if(!$s.Contains('FinishModMenu();return;') -or !$s.Contains('DestroyControlsTab()') -or !$s.Contains('FilterMode.Point')){throw 'Missing save/cleanup/pixel filtering'}
'PASS actual three-section selection/navigation and picker reset; exact approved PNG/hash/dimensions; Done/save/pixel/cleanup source integration. Live menu rendering unverified.'
