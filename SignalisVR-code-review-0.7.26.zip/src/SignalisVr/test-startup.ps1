$ErrorActionPreference='Stop'
$main=Get-Content (Join-Path $PSScriptRoot 'SignalisVrTracking.cs') -Raw
$scene=Get-Content (Join-Path $PSScriptRoot 'SceneRecovery.cs') -Raw
$cleanup=[regex]::Match($main,'bool requestedBeforeLoad = immersiveRequested;[\s\S]*?immersiveRequested = requestedBeforeLoad && !questInputStopped;').Value
if(!$cleanup){throw 'Scene cleanup block absent'}
$start=$scene.IndexOf('  private static bool SceneRecoveryKey(')
$end=$scene.IndexOf('  // PEN_Hole walking',$start)
$key=$scene.Substring($start,$end-$start)
$edge=Get-Content (Join-Path $PSScriptRoot 'HotkeyEdge.cs') -Raw
$stub=@'
using System;
using SignalisVrTracking;
enum KeyCode {F1,Other}
static class Input {public static bool GetKeyDown(KeyCode k){return false;}}
public class StartupCheck {
static StartupCheck questOwner;
HotkeyEdge perspectiveKey=new HotkeyEdge();
bool immersiveRequested=true,questInputStopped,sceneRecoveryRequest,eligible=true;
static bool down;
static short GetAsyncKeyState(int k){return down?unchecked((short)0x8000):(short)0;}
bool CanRecoverScene(){return eligible;} bool NeedsScenePerspective(){return needsPerspective;} bool needsPerspective=true;
void Stop(){immersiveRequested=false;}
void Load(){
'@
$tail=@'
public static void Test(){
var q=new StartupCheck();questOwner=q;
q.Load();q.Load();if(!q.immersiveRequested)throw new Exception("Opening loads lost auto-start");
q.immersiveRequested=false;q.Load();if(q.immersiveRequested)throw new Exception("Stop overridden");
q.immersiveRequested=true;q.questInputStopped=true;q.Load();if(q.immersiveRequested)throw new Exception("Manual input stop overridden");
down=true;if(!SceneRecoveryKey(KeyCode.F1))throw new Exception("Unfocused F1 missing");
if(SceneRecoveryKey(KeyCode.F1))throw new Exception("Held F1 repeated");
down=false;SceneRecoveryKey(KeyCode.F1);down=true;if(!SceneRecoveryKey(KeyCode.F1))throw new Exception("Second F1 missing");
down=false;SceneRecoveryKey(KeyCode.F1);q.sceneRecoveryRequest=true;if(!SceneRecoveryKey(KeyCode.F1)||q.sceneRecoveryRequest)throw new Exception("Auto request not consumed");
q.needsPerspective=false;q.sceneRecoveryRequest=true;if(SceneRecoveryKey(KeyCode.F1))throw new Exception("Already converted camera toggled");q.needsPerspective=true;
q.eligible=false;q.sceneRecoveryRequest=true;if(SceneRecoveryKey(KeyCode.F1))throw new Exception("Ineligible automatic camera");
}}
'@
Add-Type ($stub+$cleanup+'}'+$key+$tail+$edge)
[StartupCheck]::Test()
'PASS: opening-load request, manual stop, unfocused F1 edges and eligibility. Runtime unverified.'
