$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ProdContactPolicy.cs')
foreach($hz in @(30,72,90,120)){
 $p=[SignalisVrTracking.ProdContactPolicy]::new();$count=0
 for($i=0;$i -lt 30*$hz;$i++) { $now=$i/[double]$hz;if($p.Touch($true,$now -lt .01 -or $now -ge 4,$now)){$count++} }
 if($count -ne 1){throw "Held contact spent $count charges at $hz Hz"}
 $p.Touch($false,$false,31)|Out-Null
 if(!$p.Touch($true,$true,31.1)){throw 'Withdraw/retouch did not rearm'}
 if($p.Touch($true,$true,40)){throw 'Second held contact repeated'}
}
$p=[SignalisVrTracking.ProdContactPolicy]::new()
if(!$p.Touch($true,$true,0)){throw 'Initial contact rejected'}
$p.Touch($false,$false,5)|Out-Null
if($p.Touch($true,$true,5.01)){throw 'One-frame gap spent another charge'}
$p.Touch($false,$false,6)|Out-Null
if($p.Touch($true,$false,6.1)){throw 'Invalid target spent charge'}
if($p.Touch($true,$true,10)){throw 'Invalid-to-valid held contact retriggered'}
$p.Touch($false,$false,11)|Out-Null
if(!$p.Touch($true,$true,11.1)){throw 'Valid fresh touch failed'}
if($p.Touch($true,$true,[double]::NaN)){throw 'Invalid time spent charge'}
'PASS one charge per contact at30/72/90/120Hz, 30-second hold, withdraw/recontact, collision jitter, invalid-target transition and invalid time. Headset contact accuracy unverified.'
