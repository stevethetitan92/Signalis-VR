using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace SignalisVrTracking { public sealed partial class Tracking {
 private sealed class BurnJoint {internal Transform Bone;internal string Kind;internal float Side;internal Quaternion Base,Applied;internal bool Set;}
 private readonly Dictionary<IntPtr,List<BurnJoint>> burnJoints=new Dictionary<IntPtr,List<BurnJoint>>();
 private void PrepareBurnReaction(EnemyFire fire){
  var joints=new List<BurnJoint>();var seen=new HashSet<IntPtr>();
  foreach(var skin in fire.Enemy.GetComponentsInChildren<SkinnedMeshRenderer>(true).ToArray())foreach(var bone in skin.bones.ToArray()){
   if(bone==null||!seen.Add(bone.Pointer))continue;var name=bone.name.ToLowerInvariant();string kind=null;
   if(name.Contains("head")||name.Contains("neck"))kind="head";
   else if(name.Contains("spine")||name.Contains("chest"))kind="torso";
   else if(name.Contains("forearm")||name.Contains("lowerarm")||name.Contains("lower_arm"))kind="elbow";
   else if(name.Contains("upperarm")||name.Contains("upper_arm"))kind="arm";
   else if(name.Contains("hand")&&!name.Contains("finger"))kind="hand";
   if(kind!=null)joints.Add(new BurnJoint{Bone=bone,Kind=kind,Side=name.Contains("left")||name.EndsWith(".l")||name.EndsWith("_l")?-1:1});
  }
  burnJoints[fire.Id]=joints;
  foreach(var joint in joints){if(joint.Kind=="torso")fire.Torso=joint.Bone;if(joint.Kind=="head")fire.Head=joint.Bone;}
 }
 private void RestoreBurnJoints(List<BurnJoint> joints){foreach(var joint in joints){try{if(joint.Set&&joint.Bone!=null&&Quaternion.Angle(joint.Bone.localRotation,joint.Applied)<.01f)joint.Bone.localRotation=joint.Base;}catch{}joint.Set=false;}}
 private void RestoreBurnReactions(){foreach(var joints in burnJoints.Values)RestoreBurnJoints(joints);}
 private void EndBurnReaction(IntPtr id){List<BurnJoint> joints;if(burnJoints.TryGetValue(id,out joints)){RestoreBurnJoints(joints);burnJoints.Remove(id);}}
 private void SolveBurnArm(List<BurnJoint> joints,float side,Vector3 target,Vector3 pole,float weight){
  var upper=joints.Find(j=>j.Kind=="arm"&&j.Side==side);var lower=joints.Find(j=>j.Kind=="elbow"&&j.Side==side);var wrist=joints.Find(j=>j.Kind=="hand"&&j.Side==side);
  if(upper==null||lower==null||wrist==null||upper.Bone==null||lower.Bone==null||wrist.Bone==null)return;
  var a=upper.Bone.position;float l1=(lower.Bone.position-a).magnitude,l2=(wrist.Bone.position-lower.Bone.position).magnitude;if(l1<.001f||l2<.001f)return;
  var direction=target-a;float distance=Mathf.Sqrt(l1*l1+l2*l2);direction=direction.normalized;
  var bend=Vector3.ProjectOnPlane(pole-a,direction).normalized;if(bend.sqrMagnitude<.1f)return;
  float along=(l1*l1-l2*l2+distance*distance)/(2*distance);var elbow=a+direction*along+bend*Mathf.Sqrt(Mathf.Max(0,l1*l1-along*along));
  upper.Base=upper.Bone.localRotation;var desired=Quaternion.FromToRotation(lower.Bone.position-a,elbow-a)*upper.Bone.rotation;upper.Bone.rotation=Quaternion.Slerp(upper.Bone.rotation,desired,weight);upper.Applied=upper.Bone.localRotation;upper.Set=true;
  lower.Base=lower.Bone.localRotation;desired=Quaternion.FromToRotation(wrist.Bone.position-lower.Bone.position,a+direction*distance-lower.Bone.position)*lower.Bone.rotation;lower.Bone.rotation=Quaternion.Slerp(lower.Bone.rotation,desired,weight);lower.Applied=lower.Bone.localRotation;lower.Set=true;
 }
 private void ApplyBurnReactions(){
  if(global::PlayerState.paused||global::PlayerState.menu||pauseMenuVisible||modMenuOpen||!ProdVrMode())return;
  foreach(var fire in enemyFires)try{
   if(!ProdEnemyValid(fire.Enemy))continue;
   bool stunned=false;foreach(var frozen in prodFrozen)if(frozen.enemy==fire.Enemy){stunned=true;break;}if(stunned)continue;
   List<BurnJoint> joints;if(!burnJoints.TryGetValue(fire.Id,out joints))continue;
   float t=fire.Age,weight=Mathf.Clamp01(t/.25f)*Mathf.Clamp01((6-t)/.7f);
   foreach(var joint in joints){if(joint.Bone==null||joint.Kind=="arm"||joint.Kind=="elbow")continue;float side=joint.Side;Vector3 turn;
    if(joint.Kind=="torso")turn=new Vector3(15*Mathf.Sin(t*10.4f)+7*Mathf.Sin(t*18.08f+.4f),0,9*Mathf.Sin(t*11.36f)+4*Mathf.Sin(t*20.32f))/Math.Max(1,joints.Count(j=>j.Kind=="torso"));
    else if(joint.Kind=="head")turn=Vector3.zero;
    else if(joint.Kind=="arm")turn=new Vector3(48+14*Mathf.Sin(t*9+side*1.7f),side*12,side*(40+12*Mathf.Sin(t*8.3f+side)));
    else if(joint.Kind=="hand")turn=Vector3.zero;
    else turn=new Vector3(95+18*Mathf.Sin(t*9+side*1.7f),0,0);
    joint.Base=joint.Bone.localRotation;var bodyUp=controllerTrackingToWorld*Vector3.up;var bodyFront=Vector3.ProjectOnPlane(fire.Enemy.transform.forward,bodyUp).normalized;var bodyRight=Vector3.Cross(bodyUp,bodyFront).normalized;joint.Bone.rotation=Quaternion.AngleAxis(turn.z*weight,bodyFront)*Quaternion.AngleAxis(turn.x*weight,bodyRight)*joint.Bone.rotation;joint.Applied=joint.Bone.localRotation;joint.Set=true;
   }
   if(fire.Head!=null){var up=controllerTrackingToWorld*Vector3.up;var front=Vector3.ProjectOnPlane(fire.Enemy.transform.forward,up).normalized;var right=Vector3.Cross(up,front).normalized;
    foreach(float side in new[]{-1f,1f}){var target=fire.Head.position+right*side*.28f*UnitsPerMetre+front*.2f*UnitsPerMetre;var pole=fire.Head.position+right*side*.5f*UnitsPerMetre-up*.35f*UnitsPerMetre+front*.15f*UnitsPerMetre;SolveBurnArm(joints,side,target,pole,weight);}
   }
   for(int i=0;i<48;i++){var anchor=i%4==0?fire.Head:fire.Torso;if(anchor!=null&&fire.Anchored[i]&&fire.Sprites[i]!=null)fire.Sprites[i].transform.position=anchor.TransformPoint(fire.Local[i])+fire.Drift[i];}
  }catch(Exception ex){MelonLoader.MelonLogger.Warning("Burn reaction skipped: "+ex.Message);}
 }
} }

