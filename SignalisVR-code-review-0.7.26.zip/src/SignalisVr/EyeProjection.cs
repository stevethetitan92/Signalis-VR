using UnityEngine;
namespace SignalisVrTracking {
 public static class EyeProjection {
  public static Matrix4x4 FromRaw(float left,float right,float top,float bottom,float near,float far) {
   // OpenVR ComposeProjection: m12=(bottom+top)/(bottom-top).
   // Raw names are historical: pass top as Unity's lower extent, bottom as upper.
   // Texture orientation is handled separately by existing submission bounds.
   return Matrix4x4.Frustum(left*near,right*near,top*near,bottom*near,near,far);
  }
 }
}
