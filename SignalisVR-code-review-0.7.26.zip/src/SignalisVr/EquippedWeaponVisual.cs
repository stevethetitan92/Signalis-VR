using System;
using System.Collections.Generic;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public sealed partial class Tracking {
  private Transform equippedVisualModel;
  private GameObject equippedVisualRoot;
  private MeshRenderer[] equippedOriginals,equippedCopies;
  private bool[] equippedOriginalEnabled;
  private bool equippedVisualScoped;
  private global::PistolSlide equippedPistolSlide;
  private float rackHandBlend;private int rackHandFrame=-1;
  private readonly PistolSlideVisualPolicy pistolSlideVisual=new PistolSlideVisualPolicy();
  // Geometry-only copies: never activate the native weapon hierarchy or clone
  // firing scripts. Holstering by the game must not hide the VR held model.
  private void PrepareEquippedWeaponVisual() {
   RestoreEquippedWeaponVisual();
   if(!handsScoped||renderedWeapon==null||handGripModel==null)return;
   try {
    if(equippedVisualModel!=handGripModel||equippedVisualRoot==null) {
     DestroyEquippedWeaponVisual(true);
     equippedVisualRoot=new GameObject("SignalisVR_EquippedWeaponVisual");
     UnityEngine.Object.DontDestroyOnLoad(equippedVisualRoot);
     var originals=new List<MeshRenderer>();var copies=new List<MeshRenderer>();
     foreach(var r in handGripModel.GetComponentsInChildren<MeshRenderer>(true)) {
      var filter=r.GetComponent<MeshFilter>();if(filter==null||filter.sharedMesh==null)continue;
      if(originals.Count>=64)throw new InvalidOperationException("Unexpected weapon renderer count");
      var child=new GameObject("SignalisVR_"+r.name);child.layer=30;child.transform.SetParent(equippedVisualRoot.transform,false);
      child.AddComponent<MeshFilter>().sharedMesh=CreateOpenGunGuard(filter.sharedMesh,child.transform);
      var copy=child.AddComponent<MeshRenderer>();copy.enabled=false;copy.sharedMaterials=r.sharedMaterials;
      copy.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;copy.receiveShadows=false;
      originals.Add(r);copies.Add(copy);
     }
     equippedOriginals=originals.ToArray();equippedCopies=copies.ToArray();equippedOriginalEnabled=new bool[originals.Count];
     equippedVisualModel=handGripModel;
     var slides=handGripModel.GetComponentsInChildren<global::PistolSlide>(true);
     if(slides.Length==1)equippedPistolSlide=slides[0];
    }
    if(equippedOriginals.Length==0)return;
    for(int i=0;i<equippedOriginals.Length;i++)if(equippedOriginals[i]!=null)equippedOriginalEnabled[i]=equippedOriginals[i].enabled;
    equippedVisualScoped=true;
    for(int i=0;i<equippedOriginals.Length;i++) {
     var original=equippedOriginals[i];var copy=equippedCopies[i];if(original==null||copy==null)continue;
     bool childActive=true;
     for(var t=original.transform;t!=null&&t!=equippedVisualModel;t=t.parent)if(!t.gameObject.activeSelf){childActive=false;break;}
     copy.transform.position=original.transform.position;copy.transform.rotation=original.transform.rotation;copy.transform.localScale=original.transform.lossyScale;
     copy.enabled=childActive&&equippedOriginalEnabled[i];original.enabled=false;
    }
    PrepareXiphias();PrepareSelected();ApplyManualPistolSlide();PrepareAllGunMechanisms();PrepareImportedTriggers();if(!IsXiphias()&&selectedRoot==null)PrepareGunTrigger();
   }catch(Exception ex){DestroyEquippedWeaponVisual();handsFailed=true;MelonLogger.Warning("Equipped weapon visual disabled: "+ex.Message);}
  }
  // Only position the geometry copies. Native slide scripts, coroutines and
  // transforms continue unchanged; the authored travel is along parent-local X.
  private void ApplyManualPistolSlide() {
   bool eligible=ManualPistolEligible();
   var stage=manualReload.Stage;
   bool gripping=stage==ManualReloadPolicy.Step.RackHolding;
   bool hold=manualReload.RequiresRack&&(stage==ManualReloadPolicy.Step.Ejected||stage==ManualReloadPolicy.Step.Holding||stage==ManualReloadPolicy.Step.Inserted||gripping);
   float rackAge=Time.realtimeSinceStartup-manualRackStarted;
   bool rack=eligible&&manualRackWeapon==global::InventoryManager.EquippedWeapon.Pointer&&rackAge>=0&&rackAge<.18f;
   if(eligible&&!rack&&stage==ManualReloadPolicy.Step.Idle&&global::InventoryManager.EquippedWeapon.magAmmo==0)hold=true;
   pistolSlideVisual.Update(Time.realtimeSinceStartup,eligible,hold,manualReload.Active||rack);
   if(rackHandFrame!=Time.frameCount){rackHandFrame=Time.frameCount;float target=gripping?1f:rack?PistolSlideVisualPolicy.RackReleaseWeight(rackAge):0f;rackHandBlend+=(target-rackHandBlend)*TriggerMotion.Blend(Time.unscaledDeltaTime);}
   if(equippedPistolSlide==null||equippedPistolSlide.slide==null)return;
   if(!pistolSlideVisual.Override){if(eligible&&rackHandBlend>.001f)ApplyLeftRackHand(equippedPistolSlide.slide,Vector3.zero,rackHandBlend);return;}
   var slide=equippedPistolSlide.slide;var parent=slide.parent;
   float travel=equippedPistolSlide.distance;
   if(parent==null||float.IsNaN(travel)||float.IsInfinity(travel)||Math.Abs(travel)>2f)return;
   float pull=gripping?PistolSlideVisualPolicy.PullExtension(manualReload.RackPull):0f;
   var position=parent.TransformPoint(new Vector3(travel*(pistolSlideVisual.Amount+pull),0f,0f));
   var delta=position-slide.position;
   for(int i=0;i<equippedOriginals.Length;i++) {
    var r=equippedOriginals[i];if(r==null||equippedCopies[i]==null)continue;
    if(r.transform==slide||r.transform.IsChildOf(slide))equippedCopies[i].transform.position=r.transform.position+delta;
   }
   if(rackHandBlend>0)ApplyLeftRackHand(slide,delta,rackHandBlend);
  }
  private void ApplyLeftRackHand(Transform slide,Vector3 delta,float weight) {
   if(weight<=0||!handsScoped||handsObjects[0]==null||leftRackRotations==null)return;
   Vector3 contact=ManualSlideRear(slide.position+delta);
   var t=handsObjects[0].transform;
   for(int i=0;i<handSourceBones[0].Length;i++)if(handSourceBones[0][i]!=null&&handSourceBones[0][i]!=handsWrists[0])
    handCopyBones[0][i].localRotation=Quaternion.Slerp(handNeutralRotations[0][i],leftRackRotations[i],weight);
   if(leftPinchThumb==null||leftPinchIndex==null)return;
   // Align the opposing thumb/index contact points across the rear serrations.
   // Fingers point toward the muzzle; palm remains behind the contact point.
   var forward=rightWeaponRotation*Vector3.forward;
   var roof=controllerTrackingToWorld*Vector3.up;
   var dorsal=Vector3.ProjectOnPlane(roof,forward);
   if(dorsal.sqrMagnitude<.01f)dorsal=rightWeaponRotation*Vector3.up;
   // Anatomical +Y is the back-of-hand axis used by the palm-down map gesture.
   // Keep it roof-facing while the fingers follow the slide; retain pinch pivot.
   var rot=Quaternion.LookRotation(forward,dorsal)*handsCorrections[0];
   t.rotation=Quaternion.Slerp(t.rotation,rot,weight);
   var pinch=(leftPinchThumb.position+leftPinchIndex.position)*.5f;
   t.position+= (contact-pinch)*weight;
  }
  private Vector3 ManualSlideRear(Vector3 fallback) {
   if(SelectedActive("Pistol"))return SelectedSlideContact();
   if(equippedPistolSlide==null||equippedPistolSlide.slide==null||equippedOriginals==null)return fallback;
   for(int i=0;i<equippedOriginals.Length;i++)if(equippedOriginals[i]!=null&&equippedOriginals[i].transform==equippedPistolSlide.slide&&equippedCopies[i]!=null) {
    var mesh=equippedCopies[i].GetComponent<MeshFilter>().sharedMesh;
    var bounds=mesh.bounds;var t=equippedCopies[i].transform;
    // Use mesh-local bounds, not world AABB: the target must remain at the
    // rear when the gun rolls or points in a different world direction.
    var forward=rightWeaponRotation*Vector3.forward;
    var x=t.TransformVector(new Vector3(bounds.extents.x,0,0));
    var y=t.TransformVector(new Vector3(0,bounds.extents.y,0));
    var z=t.TransformVector(new Vector3(0,0,bounds.extents.z));
    var axis=x;
    if(Math.Abs(Vector3.Dot(y,forward))>Math.Abs(Vector3.Dot(axis,forward)))axis=y;
    if(Math.Abs(Vector3.Dot(z,forward))>Math.Abs(Vector3.Dot(axis,forward)))axis=z;
    if(Vector3.Dot(axis,forward)<0)axis=-axis;
    return t.TransformPoint(bounds.center)-axis*.78f;
   }
   return fallback;
  }
  private void RestoreEquippedWeaponVisual() {
   HideXiphias();HideSelected();
   if(equippedCopies!=null)for(int i=0;i<equippedCopies.Length;i++)if(equippedCopies[i]!=null)equippedCopies[i].enabled=false;
   if(equippedVisualScoped&&equippedOriginals!=null)for(int i=0;i<equippedOriginals.Length;i++)if(equippedOriginals[i]!=null)equippedOriginals[i].enabled=equippedOriginalEnabled[i];
   foreach(var r in heldTriggerRenderers)if(r!=null)r.enabled=false;
   equippedVisualScoped=false;
  }
  private void DestroyEquippedWeaponVisual(bool keepModels=false) {
   RestoreEquippedWeaponVisual();

   if(equippedVisualRoot!=null)UnityEngine.Object.Destroy(equippedVisualRoot);
   DestroyGunTriggers();DestroyCylinderRounds();DestroyXiphias();if(keepModels)CacheSelected();else DestroySelected();
   equippedVisualRoot=null;equippedVisualModel=null;equippedOriginals=null;equippedCopies=null;equippedOriginalEnabled=null;
   rackHandBlend=0;rackHandFrame=-1;equippedPistolSlide=null;pistolSlideVisual.Reset();
  }
 }
}

