$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ManualReloadPolicy.cs')
foreach($limit in @(.055,.060)){
 $p=[SignalisVrTracking.ManualReloadPolicy]::new();$p.MaximumPull=$limit
 $p.PressB(0,$false,$true)|Out-Null
 $p.Tick(.1,$true,$true,$true,$false)|Out-Null
 $p.Tick(.2,$true,$true,$false,$true)|Out-Null
 $p.Tick(.4,$true,$true,$false,$true)|Out-Null
 $p.Tick(.5,$true,$true,$false,$false,$true,0)|Out-Null
 $p.Tick(.6,$true,$true,$false,$false,$true,.09)|Out-Null
 if([Math]::Abs($p.RackPull-$limit) -gt .000001){throw 'Wrong maximum pull'}
 $p.Tick(.7,$true,$true,$false,$false,$true,.03)|Out-Null
 if([Math]::Abs($p.RackPull-.03) -gt .000001){throw 'Handle did not follow forward'}
 if(-not $p.Tick(.8,$true,$false,$false,$false,$true,.03)){throw 'Rack release failed'}
}
'PASS pistol55mm and SMG60mm limits; forward tracking and release completion'
