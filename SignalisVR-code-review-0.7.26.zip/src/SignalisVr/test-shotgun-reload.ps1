$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'ShotgunReloadPolicy.cs')
function Check($v,$msg){if(-not $v){throw $msg}}
$p=[SignalisVrTracking.ShotgunReloadPolicy]::new()
Check (-not $p.Active) 'Idle blocks normal firing'
$p.Tick(0,$true,$true,$false,$false,0,2,5,3)|Out-Null
Check ($p.Stage -eq 'Holding') 'Hip grip without B did not grab shell'
$p.Tick(.1,$true,$false,$true,$false,0,2,5,3)|Out-Null
Check ($p.Tick(.23,$true,$false,$true,$false,0,2,5,3)) 'Dwell did not insert'
Check (-not $p.Tick(.3,$true,$true,$true,$false,0,2,5,3)) 'Pending transfer repeated'
$p.Inserted(3,5,2)
Check (-not $p.Active) 'Topping off requires finish button'
$p.Tick(.4,$true,$true,$false,$false,0,3,5,2)|Out-Null
Check (-not $p.Active) 'Held grip re-grabbed shell'
$p.Tick(.5,$false,$true,$false,$false,0,3,5,2)|Out-Null
$p.Tick(.6,$true,$true,$false,$false,0,3,5,2)|Out-Null
Check ($p.Stage -eq 'Holding') 'Next shell not available without B'
Check (-not $p.Tick(.7,$false,$false,$true,$false,0,3,5,2)) 'Released shell inserted'
Check (-not $p.Active) 'Drop failed to return to normal firing'
$p.Cancel()
$p.Tick(1,$true,$true,$false,$false,0,0,5,3)|Out-Null
$p.Tick(1.1,$true,$false,$true,$false,0,0,5,3)|Out-Null
Check ($p.Tick(1.23,$true,$false,$true,$false,0,0,5,3)) 'Empty load failed'
$p.Inserted(1,5,2)
Check ($p.Stage -eq 'PumpReady') 'Empty reload bypassed pump'
$p.Tick(1.3,$false,$true,$false,$false,0,1,5,2)|Out-Null
$p.Tick(1.4,$true,$true,$false,$false,0,1,5,2)|Out-Null
Check ($p.Stage -eq 'Holding') 'Cannot add more shells before pump'
$p.Tick(1.5,$false,$false,$false,$false,0,1,5,2)|Out-Null
Check ($p.Stage -eq 'PumpReady') 'Drop lost chamber requirement'
$p.Tick(2,$true,$false,$false,$true,0,1,5,2)|Out-Null
$p.Tick(2.1,$true,$false,$false,$true,.08,1,5,2)|Out-Null
$p.Tick(2.2,$false,$false,$false,$true,.08,1,5,2)|Out-Null
Check ($p.Stage -eq 'PumpReady') 'Early release chambered shell'
$p.Tick(2.3,$true,$false,$false,$true,0,1,5,2)|Out-Null
$p.Tick(2.4,$true,$false,$false,$true,.08,1,5,2)|Out-Null
$p.Tick(2.5,$true,$false,$false,$true,.01,1,5,2)|Out-Null
Check (-not $p.Active) 'Pump failed to finish'
$p.Tick(2.6,$true,$true,$false,$false,0,1,5,2)|Out-Null
Check (-not $p.Active) 'Held pump grip re-grabbed shell'
$p.Cancel();$p.Tick(3,$true,$true,$false,$false,0,5,5,2)|Out-Null
Check (-not $p.Active) 'Full magazine grabs shell'
$p.Cancel();$p.Tick(3,$true,$true,$false,$false,0,0,5,0)|Out-Null
Check (-not $p.Active) 'No reserve grabs shell'
Check (-not [SignalisVrTracking.ShotgunReloadPolicy]::CanTransfer(5,5,2)) 'Overflow allowed'
Check ([SignalisVrTracking.ShotgunReloadPolicy]::CanTransfer(4,5,1)) 'Last round denied'
$p.Cancel();$p.Fired()
Check ($p.NeedsPump -and $p.Active -and $p.Pull -eq 0) 'Shot did not lock firing with pump forward'
$p.Interrupt()
Check ($p.NeedsPump -and $p.Active) 'Menu or swap bypassed cocking'
$p.Tick(4,$true,$true,$false,$false,0,3,5,2)|Out-Null
$p.Tick(4.1,$true,$false,$true,$false,0,3,5,2)|Out-Null
Check ($p.Tick(4.23,$true,$false,$true,$false,0,3,5,2)) 'Post-shot topoff denied'
$p.Inserted(4,5,1)
Check ($p.NeedsPump) 'Topoff bypassed post-shot cocking'
$p.Tick(4.3,$false,$false,$false,$false,0,4,5,1)|Out-Null
$p.Tick(4.4,$true,$false,$false,$true,0,4,5,1)|Out-Null
$p.Tick(4.5,$true,$false,$false,$false,.04,4,5,1)|Out-Null
$p.Tick(4.6,$true,$false,$false,$false,0,4,5,1)|Out-Null
Check ($p.NeedsPump) 'Short stroke chambered a round'
$p.Tick(4.7,$true,$false,$false,$false,.08,4,5,1)|Out-Null
$p.Tick(4.8,$true,$false,$false,$false,0,4,5,1)|Out-Null
Check (-not $p.Active) 'Full pump did not chamber'
$p.Fired();$p.Interrupt()
$p.Tick(5,$true,$false,$false,$true,0,0,5,1)|Out-Null
$p.Tick(5.1,$true,$false,$false,$false,.08,0,5,1)|Out-Null
$p.Tick(5.2,$true,$false,$false,$false,0,0,5,1)|Out-Null
Check ($p.NeedsPump) 'Empty pump created chambered round'
$p.Interrupt();$p.Tick(6,$true,$false,$false,$true,0,1,5,1)|Out-Null
$p.Tick(6.1,$true,$false,$false,$false,1,1,5,1)|Out-Null
Check ($p.Stage -eq 'PumpReady' -and $p.Pull -eq 0) 'Tracking jump completed pump'
'PASS no-B start/repeat/finish, idle attack availability, no duplicate insertion, drops, empty pump and limits'

$p.Cancel();$p.Fired()
$p.Tick(7,$true,$false,$false,$true,0,2,5,1)|Out-Null
$p.Tick(7.1,$true,$false,$false,$true,.08,2,5,1)|Out-Null
$p.Tick(7.2,$true,$false,$false,$true,0,2,5,1)|Out-Null
$p.Fired()
$p.Tick(7.3,$true,$false,$false,$true,0,1,5,1)|Out-Null
Check ($p.Stage -eq 'Pumping') 'Continuous support grip cannot pump next shot'
'PASS: keep gripping through a shot and start the next pump without releasing grip.'
$p.Cancel();$start=$p.EjectionCount
$p.Tick(8,$true,$false,$false,$true,0,3,5,2)|Out-Null
Check ($p.Stage -eq 'Pumping') 'Cannot rack a loaded idle shotgun'
$p.Tick(8.1,$true,$false,$false,$false,.04,3,5,2)|Out-Null
Check ($p.EjectionCount -eq $start) 'Short stroke ejected live round'
$p.Tick(8.2,$true,$false,$false,$false,.08,3,5,2)|Out-Null
Check ($p.EjectionCount -eq $start+1 -and $p.LastEjectionLive) 'Live round not ejected at rear stop'
foreach($pos in .075,.08,.09,.03){$p.Tick(8.3,$true,$false,$false,$false,$pos,2,5,2)|Out-Null}
Check ($p.EjectionCount -eq $start+1) 'Rear-stop jitter duplicated ejection'
$p.Tick(8.4,$true,$false,$false,$true,0,2,5,2)|Out-Null
Check (-not $p.Active) 'Forward stroke did not chamber remaining round'
$p.Tick(8.5,$true,$false,$false,$true,0,2,5,2)|Out-Null
Check (-not $p.Active) 'Retained support grip blocked firing'
$p.Fired();$p.Tick(9,$true,$false,$false,$true,0,1,5,2)|Out-Null
$p.Tick(9.1,$true,$false,$false,$false,.08,1,5,2)|Out-Null
Check ($p.EjectionCount -eq $start+2 -and -not $p.LastEjectionLive) 'Spent ejection consumes another live round'
$p.Tick(9.2,$false,$false,$false,$false,.08,1,5,2)|Out-Null
$p.Tick(9.3,$true,$false,$false,$true,0,1,5,2)|Out-Null
$p.Tick(9.4,$true,$false,$false,$false,.08,1,5,2)|Out-Null
Check ($p.EjectionCount -eq $start+2) 'Release/regrab ejected the same spent case twice'
'PASS: live versus spent pump ejection, short-stroke rejection, single ejection across jitter and regrab, retained grip firing.'
