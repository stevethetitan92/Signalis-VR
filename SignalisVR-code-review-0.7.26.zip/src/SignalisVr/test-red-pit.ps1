$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'SceneRecovery.cs') -Raw
$a=$s.IndexOf('  private static bool PerspectiveSceneAllowed')
$b=$s.IndexOf('  private static bool SceneRecoveryKey')
$methods=$s.Substring($a,$b-$a).Replace('private static bool PerspectiveSceneAllowed','public static bool PerspectiveSceneAllowed')
$stub=@'
using System;
static class PlayerState {public enum gameStates {play,eventScreen,cutscene,paused}public static gameStates gameState;public static bool cutscene,suspendInput;public static GameObject player=new GameObject();}
class Transform {public static bool cameraPresent=true;public Transform Find(string path){return cameraPresent?this:null;}}
class GameObject {public static bool rootPresent=true;public Transform transform=new Transform();public AlternatePlayerController control=new AlternatePlayerController();public static GameObject Find(string path){return rootPresent?new GameObject():null;}public T GetComponent<T>() where T:class{return control as T;}}
class AlternatePlayerController {public bool playing=true,traversing;}
public class PitGate {private void RememberRedPitCamera(){}static PitGate questOwner=new PitGate();public bool immersiveRequested=true,active=true,stereo=true,stopping;
'@
$tail=@'
public static void Test(){
if(!PerspectiveSceneAllowed("Other","PEN_Hole"))throw new Exception("normal scene");
if(PerspectiveSceneAllowed("PEN_Hole","PEN_Hole"))throw new Exception("Native pit exclusion overridden");
}}
'@
Add-Type ($stub+$methods+$tail) -IgnoreWarnings -WarningAction SilentlyContinue
[PitGate]::Test()
Add-Type -Path 'E:/SteamLibrary/steamapps/common/SIGNALIS/MelonLoader/Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly('E:/SteamLibrary/steamapps/common/SIGNALIS/Mods/CameraPerspectiveSolid.dll')
try {
 $t=$a.MainModule.Types|Where-Object FullName -eq 'Camera_Perspective_Mod.PerspectiveChange'
 $m=$t.Methods|Where-Object Name -eq OnUpdate
 $hits=@($m.Body.Instructions|Where-Object {$_.OpCode.Name -eq 'ldstr' -and $_.Operand -eq 'PEN_Hole'})
 if($hits.Count -ne 1 -or $hits[0].Next.Operand.Name -ne 'op_Inequality'){throw 'Installed perspective scene gate layout changed'}
}finally{$a.Dispose()}
'PASS actual red pit gate and installed perspective scene-exclusion layout. Runtime/headset unverified.'
