$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'SceneRecovery.cs') -Raw
# The later native-camera rollback supersedes the old forced snow-camera feature.
if(!$s.Contains('private bool IsSnowWalkCamera(Camera candidate) { return false; }') -or !$s.Contains('private Camera FindSnowWalkCamera() { return null; }')){throw 'Retired snow camera override returned'}
& "$PSScriptRoot/test-scene-recovery.ps1"
'PASS native snow/pit camera exclusion and actual scene recovery guards. Runtime unverified.'
