$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'DiagnosticFlow.cs')
function Assert-Diagnostic($condition, $message) { if (-not $condition) { throw $message } }
$f = [SignalisVrTracking.DiagnosticFlow]::new()
Assert-Diagnostic (-not $f.CanSubmit) 'Startup can submit'
Assert-Diagnostic (-not $f.BeginSubmit(0)) 'Skipped both prerequisites'
$f.RenderReady()
Assert-Diagnostic ($f.Stage -eq 0) 'Skipped connection stage'
$f.Connected()
Assert-Diagnostic ($f.Stage -eq 1 -and -not $f.CanSubmit) 'Connection submits'
Assert-Diagnostic (-not $f.BeginSubmit(1)) 'Skipped local rendering'
$f.RenderReady()
Assert-Diagnostic ($f.Stage -eq 2 -and -not $f.CanSubmit) 'Local rendering submits'
Assert-Diagnostic ($f.BeginSubmit(30)) 'Submission did not arm'
Assert-Diagnostic ($f.CanSubmit -and -not $f.Expired(929.99)) 'Window ended early'
Assert-Diagnostic (-not $f.BeginSubmit(929)) 'Repeated F10 rearmed submission'
Assert-Diagnostic (-not $f.Expired(930) -and $f.CanSubmit) 'Stopped at old cutoff'
$f.Stop()
Assert-Diagnostic ($f.Stage -eq 0 -and -not $f.CanSubmit) 'Stop leaves submission enabled'
foreach ($stage in @(1,2,3)) {
    $f.Connected()
    if ($stage -ge 2) { $f.RenderReady() }
    if ($stage -ge 3) { [void]$f.BeginSubmit(0) }
    $f.Stop()
    Assert-Diagnostic (-not $f.CanSubmit -and $f.Stage -eq 0) 'Stage cancellation failed'
}
'PASS: prerequisite gating, no submission in stages A/B, continuous stage C, repeated-key protection, cancellation at every stage.'

foreach ($time in @(900,901,3600,86400)) {
    $f.Connected(); $f.RenderReady(); [void]$f.BeginSubmit(0)
    Assert-Diagnostic (-not $f.Expired($time) -and $f.CanSubmit) 'Elapsed time stopped continuous submission'
    $f.Stop()
}
