$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot 'GrantWeaponsCheat.cs') -Raw
$harness=@"
namespace MelonLoader { public static class MelonLogger { public static void Msg(string s){} public static void Warning(string s){} } }
public static class Items {public enum itemlist {Pistol,Revolver,Shotgun,Rifle,FlareGun,SMG,Machete,PistolAmmo,RevolverAmmo,ShotgunAmmo,RifleAmmo,FlareGunAmmo,SmgAmmo}}
public class AnItem {public Items.itemlist id;}
public static class InventoryManager {
 public static System.Collections.Generic.Dictionary<Items.itemlist,AnItem> allItems=new System.Collections.Generic.Dictionary<Items.itemlist,AnItem>();
 public static System.Collections.Generic.Dictionary<AnItem,int> boxItems=new System.Collections.Generic.Dictionary<AnItem,int>();
 public static bool boxContainsItem(AnItem i){return boxItems.ContainsKey(i);}
 public static void boxItem(AnItem i,int n){if(boxItems.ContainsKey(i))boxItems[i]+=n;else boxItems[i]=n;}
}
namespace SignalisVrTracking { public sealed partial class Tracking {
 private string modSettingsError;private static bool CheatPlayerReady(){return true;}
 public static void Test(){var t=new Tracking();allWeapons=true;grantWeaponsPending=true;t.PollGrantWeapons();if(InventoryManager.boxItems.Count!=0||!grantWeaponsPending)throw new Exception("Missing catalog mutated storage");
 foreach(Items.itemlist id in Enum.GetValues(typeof(Items.itemlist)))InventoryManager.allItems[id]=new AnItem{id=id};
 t.PollGrantWeapons();for(int i=0;i<1000;i++)t.PollGrantWeapons();
 foreach(var id in StorageWeapons)if(InventoryManager.boxItems[InventoryManager.allItems[id]]!=1)throw new Exception("Weapon duplicated/missing");
 foreach(var id in StorageAmmo)if(InventoryManager.boxItems[InventoryManager.allItems[id]]!=4)throw new Exception("Ammo count wrong");
 allWeapons=false;t.PollGrantWeapons();if(InventoryManager.boxItems.Count!=12)throw new Exception("OFF removed items");
 allWeapons=true;grantWeaponsPending=true;t.PollGrantWeapons();
 foreach(var id in StorageWeapons)if(InventoryManager.boxItems[InventoryManager.allItems[id]]!=1)throw new Exception("Reactivation duplicated weapon");
 foreach(var id in StorageAmmo)if(InventoryManager.boxItems[InventoryManager.allItems[id]]!=8)throw new Exception("Reactivation ammo wrong");
 }
}}
"@
Add-Type -TypeDefinition ($source+[Environment]::NewLine+$harness) -IgnoreWarnings -WarningAction SilentlyContinue
[SignalisVrTracking.Tracking]::Test()
'PASS actual storage grant source with controlled catalog/box: missing catalog, six weapons; machete excluded, four rounds, no frame duplication, OFF and reactivation.'
