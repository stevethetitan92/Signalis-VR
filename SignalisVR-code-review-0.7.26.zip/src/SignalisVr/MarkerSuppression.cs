using System;
using System.Collections.Generic;
using UnityEngine;

namespace SignalisVrTracking
{
    // Camera-wide rendering veto: never change an interaction component, collider,
    // active state, Renderer.enabled, sprite, transform, or shared material.
    internal static class MarkerSuppression
    {
        private static readonly List<Renderer> targets = new List<Renderer>();
        private static readonly HashSet<int> targetIds = new HashSet<int>();
        private static int scannedFrame = -1;
        private static readonly List<global::DoorInteractionPopup> doors = new List<global::DoorInteractionPopup>();
        private static readonly List<global::Ladder> ladders = new List<global::Ladder>();
        private static readonly HashSet<int> doorIds = new HashSet<int>(), ladderIds = new HashSet<int>();
        private static bool registryEnabled;
        private static float nextRegistryScan;
        private static float nextWarning;
        private static Camera.CameraCallback preCull;
        internal static Action<int,long> TimingObserver=null;
        internal static void EnableRegistry(bool enabled) { registryEnabled=enabled; Reset(); }
        internal static void RegisterDoor(global::DoorInteractionPopup door) {
            if(door!=null && doorIds.Add(door.GetInstanceID())) {doors.Add(door);scannedFrame=-1;}
        }
        internal static void RegisterLadder(global::Ladder ladder) {
            if(ladder!=null && ladderIds.Add(ladder.GetInstanceID())) {ladders.Add(ladder);scannedFrame=-1;}
        }

        internal static void Install()
        {
            if (preCull != null) return;
            preCull = (Action<Camera>)BeforeCamera;
            Camera.onPreCull += preCull;
        }

        internal static void Reset()
        {
            scannedFrame = -1;
            targets.Clear();
            targetIds.Clear();
            doors.Clear(); ladders.Clear(); doorIds.Clear(); ladderIds.Clear(); nextRegistryScan=0f;
        }

        private static void BeforeCamera(Camera unused) { Apply(); }

        internal static void Apply()
        {
            long started=System.Diagnostics.Stopwatch.GetTimestamp();
            try
            {
                // Lifecycle hooks discover new active controllers; a full scan includes
                // inactive objects and refreshes/prunes the registry once per second.
                // If hooks were unavailable, retain the original per-frame discovery.
                // Hierarchy/artwork discovery is still once per frame, then enforce EVERY eye.
                // No VR stage, proximity, sprite-name, layer or enabled-state gate.
                if (scannedFrame != Time.frameCount)
                {
                    long discoveryStarted=System.Diagnostics.Stopwatch.GetTimestamp();
                    targets.Clear();
                    targetIds.Clear();
                    if(!registryEnabled || Time.realtimeSinceStartup >= nextRegistryScan) {
                        var foundDoors = Resources.FindObjectsOfTypeAll<global::DoorInteractionPopup>();
                        var foundLadders = Resources.FindObjectsOfTypeAll<global::Ladder>();
                        doors.Clear(); ladders.Clear(); doorIds.Clear(); ladderIds.Clear();
                        for(int i=0;i<foundDoors.Length;i++)RegisterDoor(foundDoors[i]);
                        for(int i=0;i<foundLadders.Length;i++)RegisterLadder(foundLadders[i]);
                        nextRegistryScan=Time.realtimeSinceStartup+1f;
                        if(TimingObserver!=null)TimingObserver(28,discoveryStarted);
                    }
                    long hierarchyStarted=System.Diagnostics.Stopwatch.GetTimestamp();
                    for (int i = 0; i < doors.Count; i++)
                    {
                        var door = doors[i];
                        if (door == null) continue;
                        Add(door.block);
                        Add(door.bar);
                        // This is the popup hierarchy, NOT door.door or door geometry.
                        AddArtwork(door.transform);
                    }
                    for (int i = 0; i < ladders.Count; i++)
                    {
                        var ladder = ladders[i];
                        if (ladder == null) continue;
                        // Game-owned icon/label references also cover renamed roots.
                        Add(ladder.block);
                        Add(ladder.bar);
                        var children = ladder.GetComponentsInChildren<Transform>(true);
                        for (int j = 0; j < children.Length; j++)
                            if (children[j] != null && children[j].name == "Ladder Icon")
                                AddArtwork(children[j]);
                    }
                    scannedFrame = Time.frameCount;
                    if(TimingObserver!=null)TimingObserver(36,hierarchyStarted);
                    if(TimingObserver!=null)TimingObserver(26,discoveryStarted);
                }
                for (int i = 0; i < targets.Count; i++)
                    if (targets[i] != null) targets[i].forceRenderingOff = true;
            }
            catch (Exception ex)
            {
                if (Time.realtimeSinceStartup >= nextWarning)
                {
                    nextWarning = Time.realtimeSinceStartup + 10f;
                    MelonLoader.MelonLogger.Warning("Door/ladder artwork suppression failed: " + ex.Message);
                }
            }
            finally {if(TimingObserver!=null)TimingObserver(25,started);}
        }

        private static void AddArtwork(Transform root)
        {
            var artwork = root.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < artwork.Length; i++) Add(artwork[i]);
        }

        private static void Add(Renderer renderer)
        {
            if (renderer != null && targetIds.Add(renderer.GetInstanceID())) targets.Add(renderer);
        }
    }
}
