param([string]$GamePath='E:/SteamLibrary/steamapps/common/SIGNALIS',[string]$AudioSourcePath='')
$ErrorActionPreference='Stop'
$scratch=Join-Path $PSScriptRoot 'hd-audio-harness'
New-Item -ItemType Directory -Force $scratch | Out-Null
foreach($name in '0Harmony.dll','MonoMod.RuntimeDetour.dll','MonoMod.Utils.dll','Mono.Cecil.dll'){
 Copy-Item (Join-Path "$GamePath/MelonLoader" $name) $scratch -Force
}
if(!$AudioSourcePath){$AudioSourcePath=Join-Path $PSScriptRoot 'SmgShotAudio.cs'}
$source=Get-Content $AudioSourcePath -Raw
$hd=Get-Content (Join-Path $PSScriptRoot 'HdGunAudio.cs') -Raw
$a=$hd.IndexOf(' private static bool ReplaceHdShotAudio');$b=$hd.IndexOf(' private void DestroyHdGunAudio')
$source+='namespace SignalisVrTracking { public sealed partial class Tracking {'+$hd.Substring($a,$b-$a)+'}}'

$stub=@'
namespace UnityEngine {public struct Vector3 {public static Vector3 zero;public static Vector3 operator+(Vector3 a,Vector3 b){return a;}public static Vector3 operator*(Vector3 a,float b){return a;}} public struct Quaternion{public static Vector3 operator*(Quaternion q,Vector3 v){return v;}}public class Transform{public Vector3 position;}public class GameObject{public Transform transform=new Transform();}public class AudioClip{} public class AudioSource{public static int Calls;public static bool Fail;public void PlayOneShot(AudioClip c,float v){if(Fail)throw new System.Exception();Calls++;}}}
namespace FMODUnity {public static class RuntimeManager {public static int Calls;[System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)] public static void PlayOneShot(string s,UnityEngine.Vector3 p){Calls++;} [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)] public static void PlayOneShotAttached(string s,UnityEngine.GameObject p){Calls++;}}}
namespace MelonLoader {public static class MelonLogger {public static void Warning(string s){}}}
public static class InventoryManager{public static AnWeapon EquippedWeapon;}
public class Items {public enum itemlist {SMG,Pistol}}
public class AnItem {public Items.itemlist _item;}
public class AnWeapon {public AnItem parentItem=new AnItem();public int magAmmo=40;public string shotMod="native";}
public class PlayerAttack {
 public AnWeapon weapon=new AnWeapon();public bool Fail;
 [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)] public void RaycastShot(){if(Fail)throw new System.InvalidOperationException("native failure");if(weapon.magAmmo>0)weapon.magAmmo--;}
 [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)] public void ReadyForAttack(){RaycastShot();}
}
namespace SignalisVrTracking {internal sealed class PackAudio {internal static int Calls;internal static bool Fail;internal void Play(float v,bool loop){if(Fail)throw new System.Exception();Calls++;}} public sealed partial class Tracking {
 private static Tracking weaponOwner=new Tracking();private bool ControllerWeaponReady(){return true;}
 private UnityEngine.GameObject hdGunAudioRoot=new UnityEngine.GameObject();private UnityEngine.AudioSource hdGunAudio=new UnityEngine.AudioSource();private bool hdAudioFailed;private int hdSoundIndex;private UnityEngine.Vector3 rightWeaponPosition;private UnityEngine.Quaternion rightWeaponRotation;private const float UnitsPerMetre=1;
 private System.Collections.Generic.Dictionary<string,PackAudio[]> hdShotClips=new System.Collections.Generic.Dictionary<string,PackAudio[]>{{"SMG",new[]{new PackAudio(),new PackAudio()}}};
 private bool EnsureHdGunAudio(string kind){return !hdAudioFailed&&hdShotClips.ContainsKey(kind);}private bool ImportedMuzzle(out UnityEngine.Vector3 v){v=new UnityEngine.Vector3();return true;}
 private sealed class WeaponPoseScope {internal bool restored;}
 private static int Restores;
 private static void ControllerShotBegin(out WeaponPoseScope __state){__state=new WeaponPoseScope();}
 private static System.Exception ControllerShotEnd(System.Exception __exception,WeaponPoseScope __state){if(__state==null||__state.restored)throw new System.Exception("Pose scope corrupted");__state.restored=true;Restores++;return __exception;}
 public static void Main(){
  var h=new HarmonyLib.Harmony("signalis.shot-composition-test");
  h.Patch(HarmonyLib.AccessTools.DeclaredMethod(typeof(PlayerAttack),"RaycastShot"),prefix:new HarmonyLib.HarmonyMethod(typeof(Tracking),"ControllerShotBegin"),finalizer:new HarmonyLib.HarmonyMethod(typeof(Tracking),"ControllerShotEnd"));
  weaponOwner.InstallSmgShotAudio(h);
  var a=new PlayerAttack();a.ReadyForAttack();if(a.weapon.magAmmo!=39||Restores!=1||FMODUnity.RuntimeManager.Calls!=0)throw new System.Exception("First shot composition failed");
  for(int i=0;i<39;i++)a.RaycastShot();if(a.weapon.magAmmo!=0||Restores!=40||FMODUnity.RuntimeManager.Calls!=39)throw new System.Exception("Automatic shot composition failed");
  a.weapon.parentItem._item=Items.itemlist.Pistol;a.weapon.magAmmo=10;a.ReadyForAttack();if(a.weapon.magAmmo!=9||Restores!=41||FMODUnity.RuntimeManager.Calls!=39)throw new System.Exception("Pistol firing blocked");
  a.Fail=true;try{a.ReadyForAttack();throw new System.Exception("Failure not reached");}catch(System.InvalidOperationException){}if(Restores!=42||smgReadyDepth!=0)throw new System.Exception("Exception scope stuck");
  InventoryManager.EquippedWeapon=a.weapon;weaponOwner.InstallHdGunAudio(h);a.Fail=false;a.weapon.parentItem._item=Items.itemlist.SMG;a.weapon.magAmmo=40;int native=FMODUnity.RuntimeManager.Calls;for(int i=0;i<40;i++)a.RaycastShot();if(a.weapon.magAmmo!=0||PackAudio.Calls!=40||FMODUnity.RuntimeManager.Calls!=native)throw new System.Exception("HD automatic audio replacement/ammo failed");FMODUnity.RuntimeManager.PlayOneShotAttached("native",new UnityEngine.GameObject());if(PackAudio.Calls!=41)throw new System.Exception("Attached shot not replaced");FMODUnity.RuntimeManager.PlayOneShot("unrelated",UnityEngine.Vector3.zero);if(FMODUnity.RuntimeManager.Calls!=native+1)throw new System.Exception("Unrelated sound suppressed");PackAudio.Fail=true;FMODUnity.RuntimeManager.PlayOneShot("native",UnityEngine.Vector3.zero);if(FMODUnity.RuntimeManager.Calls!=native+2)throw new System.Exception("Native fallback lost");
  System.Console.WriteLine("PASS HD audio replacement, forty automatic shots, attached events, unrelated events and failure fallback; installed Harmony engine: actual audio hook registration composed with reference-type pose state; first/39 automatic/other-gun shots and exception restoration.");
 }
}}
'@
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.dll')) | Out-Null
[System.Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.CSharp.dll')) | Out-Null
$framework=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319'
$refs=[System.Collections.Generic.List[Microsoft.CodeAnalysis.MetadataReference]]::new()
foreach($path in @("$scratch/0Harmony.dll","$framework/mscorlib.dll","$framework/System.dll","$framework/System.Core.dll")){$refs.Add([Microsoft.CodeAnalysis.MetadataReference]::CreateFromFile($path))}
$options=[Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions]::new([Microsoft.CodeAnalysis.OutputKind]::ConsoleApplication)
$trees=[Microsoft.CodeAnalysis.SyntaxTree[]]@([Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($source+$stub))
$c=[Microsoft.CodeAnalysis.CSharp.CSharpCompilation]::Create('HdAudioHarness',$trees,$refs,$options)
$exe=Join-Path $scratch 'HdAudioHarness.exe';$stream=[IO.File]::Create($exe)
try{$result=$c.Emit($stream)}finally{$stream.Dispose()}
if(!$result.Success){$result.Diagnostics | ForEach-Object ToString;throw 'Shot hook harness compile failed'}
& $exe
if($LASTEXITCODE -ne 0){throw 'Actual Harmony hook composition failed'}


