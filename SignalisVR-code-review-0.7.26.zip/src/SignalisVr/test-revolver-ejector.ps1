$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'RevolverEjector.cs') -Raw
$start=$s.IndexOf(' public sealed class EjectorStroke');$end=$s.IndexOf(' public sealed partial class Tracking')
Add-Type -TypeDefinition ('using System;namespace SignalisVrTracking {'+$s.Substring($start,$end-$start)+'}')
foreach($hz in 30,72,90,120){
 $p=[SignalisVrTracking.EjectorStroke]::new();$events=0
 for($i=0;$i -le $hz;$i++){if($p.Tick($true,$true,($i -eq 0),(-.025*$i/$hz))){$events++}}
 if($events -ne 1 -or !$p.Held -or [Math]::Abs($p.Pull-.025) -gt .00001){throw "Ejector stroke failed at $hz Hz"}
 if($p.Tick($true,$false,$true,0) -or $p.Held -or $p.Pull -ne 0){throw 'Ejector failed to release'}
 if($p.Tick($true,$true,$true,0)){throw 'Grab alone ejected'}
 if($p.Tick($true,$true,$true,.025)){throw 'Forward movement ejected'}
 if(!$p.Tick($true,$true,$false,-.013)){throw 'Second rearward stroke rejected'}
}
foreach($invalid in [float]::NaN,[float]::PositiveInfinity,.25){
 $p=[SignalisVrTracking.EjectorStroke]::new();$p.Tick($true,$true,$true,0)|Out-Null
 if($p.Tick($true,$true,$true,$invalid) -or $p.Held){throw 'Invalid tracking retained ejector'}
}
$p=[SignalisVrTracking.EjectorStroke]::new()
if($p.Tick($false,$true,$true,0) -or $p.Tick($true,$true,$true,-.03) -or $p.Held){throw 'Closed cylinder or held grip acquired ejector'}
$p.Reset();$p.Tick($true,$true,$false,0)|Out-Null
if($p.Tick($true,$true,$true,-.03) -or $p.Held){throw 'Remote held grip acquired ejector'}
'PASS physical ejector: fresh nearby grab, rearward stroke, single event, release, closed-cylinder rejection and invalid tracking at four rates. Headset contact not verified.'
