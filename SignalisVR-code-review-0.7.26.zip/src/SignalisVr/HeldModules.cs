using System;
using System.Collections.Generic;
using HarmonyLib;
using MelonLoader;
using UnityEngine;
namespace SignalisVrTracking {
 public static class ReceiverTuning {
  public static float Turn(float value,float degrees,float minimum,float maximum){if(float.IsNaN(degrees)||float.IsInfinity(degrees)||Math.Abs(degrees)>70)return value;return Math.Max(minimum,Math.Min(maximum,(float)Math.Round((value+degrees/15f)*10)/10));}
 }
 public sealed partial class Tracking {
  private bool heldReceiver,heldEidetic,receiverKnobHeld,receiverArrowArmed;
  private float receiverKnobAngle,receiverPressTime=-100f,receiverGripAmount;
  private int receiverArrowDirection;
  private global::AnItem receiverCatalog;
  private GameObject receiverRoot,eideticRoot;
  private Transform receiverKnob,receiverLeftArrow,receiverRightArrow;
  private readonly List<Renderer> moduleRenderers=new List<Renderer>();
  private readonly List<Material> moduleMaterials=new List<Material>();
  private readonly List<Mesh> moduleMeshes=new List<Mesh>();
  private Mesh receiverDisplay;private string receiverCaption;
  private readonly QuickUsePolicy eideticUse=new QuickUsePolicy();
  private bool snapshotQueued;
  private float nextSnapshot;
  private global::AnItem ReceiverCatalog(){if(receiverCatalog!=null)return receiverCatalog;receiverCatalog=ScriptableObject.CreateInstance<global::AnItem>();receiverCatalog.name="SignalisVR_ReceiverWheel";receiverCatalog._name="Receiver";receiverCatalog.sortingPriority=999;var tex=new Texture2D(32,32,TextureFormat.RGBA32,false);tex.filterMode=FilterMode.Point;var pixels=new Color[1024];for(int y=0;y<32;y++)for(int x=0;x<32;x++){bool body=x>=3&&x<=27&&y>=3&&y<=23;bool screen=x>=7&&x<=23&&y>=15&&y<=19;bool aerial=x>=25&&x<=27&&y>=23;pixels[y*32+x]=screen?new Color(.4f,.85f,1f):body?new Color(.15f,.17f,.18f):aerial?Color.gray:Color.clear;}tex.SetPixels(pixels);tex.Apply();receiverCatalog.Icon=Sprite.Create(tex,new Rect(0,0,32,32),new Vector2(.5f,.5f));return receiverCatalog;}
  private bool ReceiverOwned(){var radio=global::RadioManager.instance;return radio!=null&&global::RadioManager.moduleInstalled;}
  private bool EideticOwned(){var all=global::InventoryManager.allItems;return all!=null&&all.ContainsKey(global::Items.itemlist.PhotoModule)&&QuickCount(all[global::Items.itemlist.PhotoModule])>0;}
  private void ClearHeldModules(){heldReceiver=heldEidetic=receiverKnobHeld=false;receiverGripAmount=0;eideticUse.Reset();snapshotQueued=false;HideHeldModules();}
  private bool EquipHeldModule(string id,bool wheelSelection=false) {
   if(id!="Receiver"&&id!="PhotoModule")return false;
   if((id=="Receiver"&&!ReceiverOwned())||(id=="PhotoModule"&&!EideticOwned())){quickStatus="Not carried";return true;}
   if(quickInventory==null||!PrepareProdHand(quickInventory)){quickStatus="Cannot holster now";return true;}
   heldQuickHealth=null;healthUsed=false;quickPreviousWeapon=null;global::InventoryManager.EquippedTool=null;
   ClearHeldModules();heldReceiver=id=="Receiver";heldEidetic=id=="PhotoModule";if(heldReceiver){global::RadioManager.tuner=true;global::RadioManager.audible=true;}quickStatus=heldReceiver?"Receiver":"Eidetic Module";if(wheelSelection)PlayWheelItemEquip(id);return true;
  }
  private void PollHeldModules(bool available,QuestSample left,QuestSample right) {
   if(!heldReceiver&&!heldEidetic)return;
   bool ready=available&&ProdVrMode()&&questPolicy.LeftArmed&&questPolicy.RightArmed&&ModHudGameplayReady()&&!modMenuOpen&&!global::PlayerState.reloading&&!global::PlayerState.animating&&!global::PlayerState.grappled&&!global::PlayerState.hurt&&manualReload.Stage==ManualReloadPolicy.Step.Idle&&!shotgunReload.Active&&!AdditionalReloadActive();
   if((heldReceiver&&!ReceiverOwned())||(heldEidetic&&!EideticOwned())||global::InventoryManager.EquippedWeapon!=null){ClearHeldModules();return;}
   questFrame.buttons&=~((1<<5)|(1<<6)|(1<<7));
   if(heldEidetic){if(eideticUse.Update(ready,right.trigger>.55f||right.Button(33))&&Time.realtimeSinceStartup>=nextSnapshot){snapshotQueued=true;nextSnapshot=Time.realtimeSinceStartup+.6f;healthSqueezeTime=Time.realtimeSinceStartup;}return;}
   var radio=global::RadioManager.instance;if(radio==null||receiverRoot==null||controllerMarkers[1]==null){receiverKnobHeld=false;return;}
   bool grip=right.grip>.55f||right.Button(2);
   var local=receiverRoot.transform.InverseTransformPoint(controllerMarkers[1].transform.position);
   bool near=Vector3.Distance(local,new Vector3(.072f,.015f,-.043f))<.085f;
   var up=receiverRoot.transform.InverseTransformDirection(controllerMarkers[1].transform.up);float angle=Mathf.Atan2(up.y,up.x)*(180f/(float)Math.PI);
   if(ready&&grip&&(near||receiverKnobHeld)){if(receiverKnobHeld)radio._frequency=ReceiverTuning.Turn(radio._frequency,Mathf.DeltaAngle(receiverKnobAngle,angle),radio.range.x,radio.range.y);receiverKnobHeld=true;receiverKnobAngle=angle;}else receiverKnobHeld=false;
   float x=left.x;
   if(!ready){receiverArrowArmed=false;receiverKnobHeld=false;return;}
   // The thumb contact is animated from the left controller's directional input.
   if(Math.Abs(x)<.25f)receiverArrowArmed=true;
   if(receiverArrowArmed&&Math.Abs(x)>.65f){receiverArrowArmed=false;receiverArrowDirection=x>0?1:-1;receiverPressTime=Time.realtimeSinceStartup;radio._frequency=ReceiverTuning.Turn(radio._frequency,receiverArrowDirection*1.5f,radio.range.x,radio.range.y);}
   questFrame.moveX=questFrame.moveY=questFrame.uiX=questFrame.uiY=0;manualLeftGrip=false;
  }
  private Renderer ModulePart(GameObject parent,PrimitiveType type,Vector3 position,Vector3 size,Color color) {
   var go=GameObject.CreatePrimitive(type);go.layer=30;UnityEngine.Object.Destroy(go.GetComponent<Collider>());go.transform.SetParent(parent.transform,false);go.transform.localPosition=position;go.transform.localScale=size;
   var material=new Material(Shader.Find("Unlit/Color"));material.color=color;moduleMaterials.Add(material);var r=go.GetComponent<Renderer>();r.sharedMaterial=material;r.enabled=false;moduleRenderers.Add(r);return r;
  }
  private void EnsureReceiver() {
   if(receiverRoot!=null)return;receiverRoot=new GameObject("SignalisVR_HandheldReceiver");UnityEngine.Object.DontDestroyOnLoad(receiverRoot);Color dark=new Color(.08f,.09f,.10f),grey=new Color(.24f,.26f,.27f),orange=new Color(.95f,.25f,.035f);
   ModulePart(receiverRoot,PrimitiveType.Cube,Vector3.zero,new Vector3(.21f,.16f,.055f),dark);
   ModulePart(receiverRoot,PrimitiveType.Cube,new Vector3(0,.065f,-.029f),new Vector3(.20f,.009f,.004f),orange);
   ModulePart(receiverRoot,PrimitiveType.Cube,new Vector3(-.025f,.035f,-.030f),new Vector3(.13f,.045f,.004f),Color.black);
   for(int i=0;i<10;i++)ModulePart(receiverRoot,PrimitiveType.Cube,new Vector3(-.080f+i*.011f,-.036f,-.030f),new Vector3(.005f,.051f,.004f),grey);
   ModulePart(receiverRoot,PrimitiveType.Cube,new Vector3(.087f,.145f,0),new Vector3(.006f,.19f,.006f),grey);
   receiverKnob=ModulePart(receiverRoot,PrimitiveType.Cylinder,new Vector3(.072f,.015f,-.043f),new Vector3(.038f,.014f,.038f),grey).transform;receiverKnob.localRotation=Quaternion.Euler(90,0,0);
   receiverLeftArrow=ModulePart(receiverRoot,PrimitiveType.Cube,new Vector3(.037f,-.045f,-.034f),new Vector3(.023f,.020f,.010f),orange).transform;
   receiverRightArrow=ModulePart(receiverRoot,PrimitiveType.Cube,new Vector3(.076f,-.045f,-.034f),new Vector3(.023f,.020f,.010f),orange).transform;
   var labels=new[]{new Vector3(-.025f,.035f,-.034f),new Vector3(.037f,-.045f,-.040f),new Vector3(.076f,-.045f,-.040f),new Vector3(-.01f,-.003f,-.034f)};
   for(int i=0;i<3;i++){var go=new GameObject("ReceiverReadout");go.layer=30;go.transform.SetParent(receiverRoot.transform,false);go.transform.localPosition=labels[i];go.transform.localScale=Vector3.one*(i==0?.5f:.45f);var mesh=new Mesh();moduleMeshes.Add(mesh);go.AddComponent<MeshFilter>().sharedMesh=mesh;EnsureGlyphAtlas();var mat=new Material(Shader.Find("Sprites/Default"));mat.mainTexture=modGlyphAtlas;mat.color=new Color(.4f,.85f,1f);moduleMaterials.Add(mat);var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=mat;r.enabled=false;moduleRenderers.Add(r);if(i==0)receiverDisplay=mesh;else{string previous=null;UpdateModHudText(mesh,i==1?"<":">",ref previous);}}
  }
  private void EnsureEidetic(){if(eideticRoot!=null)return;eideticRoot=new GameObject("SignalisVR_HandheldEidetic");UnityEngine.Object.DontDestroyOnLoad(eideticRoot);ModulePart(eideticRoot,PrimitiveType.Sphere,Vector3.zero,new Vector3(.09f,.09f,.09f),new Color(.82f,.84f,.85f));ModulePart(eideticRoot,PrimitiveType.Sphere,new Vector3(0,0,.040f),new Vector3(.045f,.045f,.022f),Color.black);ModulePart(eideticRoot,PrimitiveType.Sphere,new Vector3(0,0,.051f),new Vector3(.023f,.023f,.009f),new Color(.025f,.50f,.8f));ModulePart(eideticRoot,PrimitiveType.Cube,new Vector3(.038f,0,0),new Vector3(.007f,.065f,.060f),new Color(.5f,.045f,.05f));}
  private void PrepareHeldModules() {
   HideHeldModules();if((!heldReceiver&&!heldEidetic)||!handsScoped||!ModHudGameplayReady())return;
   if(heldReceiver){EnsureReceiver();var left=controllerMarkers[0].transform;receiverRoot.transform.position=HandPlacement.TrackedPalm(left.position,left.rotation,UnitsPerMetre)+left.forward*.045f*UnitsPerMetre;receiverRoot.transform.rotation=left.rotation;receiverRoot.transform.localScale=Vector3.one*UnitsPerMetre;FitHandAroundBox(0,receiverRoot.transform,Vector3.zero,new Vector3(.21f,.16f,.055f));
    float press=TriggerMotion.Amount(Time.realtimeSinceStartup-receiverPressTime);var arrow=receiverArrowDirection<0?receiverLeftArrow:receiverRightArrow;receiverLeftArrow.localPosition=new Vector3(.037f,-.045f,-.034f);receiverRightArrow.localPosition=new Vector3(.076f,-.045f,-.034f);arrow.localPosition+=Vector3.forward*(.006f*press);
    FitFingerToContact(0,"thumb",receiverRoot.transform.TransformPoint(new Vector3(receiverArrowDirection<0?.037f:.076f,-.045f,-.055f+.008f*press)),8);
    receiverGripAmount=Mathf.MoveTowards(receiverGripAmount,receiverKnobHeld?1:0,Time.unscaledDeltaTime*8);if(receiverGripAmount>0){var knob=receiverKnob.position;FitFingerToContact(1,"thumb",knob-receiverRoot.transform.right*.022f,8);FitFingerToContact(1,"index",knob+receiverRoot.transform.right*.022f,8);}
    var radio=global::RadioManager.instance;if(radio!=null){receiverKnob.localRotation=Quaternion.Euler(90,0,radio._frequency*15);UpdateModHudText(receiverDisplay,radio._frequency.ToString("F3",System.Globalization.CultureInfo.InvariantCulture),ref receiverCaption);}}
   if(heldEidetic){EnsureEidetic();var right=controllerMarkers[1].transform;eideticRoot.transform.position=HandPlacement.TrackedPalm(right.position,right.rotation,UnitsPerMetre)+right.forward*.035f*UnitsPerMetre;eideticRoot.transform.rotation=right.rotation;eideticRoot.transform.localScale=Vector3.one*UnitsPerMetre;FitHandAroundBox(1,eideticRoot.transform,Vector3.zero,new Vector3(.078f,.078f,.078f));}
   foreach(var r in moduleRenderers)if(r!=null)r.enabled=(heldReceiver&&r.transform.IsChildOf(receiverRoot.transform))||(heldEidetic&&r.transform.IsChildOf(eideticRoot.transform));
  }
  private void HideHeldModules(){foreach(var r in moduleRenderers)if(r!=null)r.enabled=false;}
  private void DestroyHeldModules(){ClearHeldModules();if(receiverRoot!=null)UnityEngine.Object.Destroy(receiverRoot);if(eideticRoot!=null)UnityEngine.Object.Destroy(eideticRoot);receiverRoot=eideticRoot=null;receiverDisplay=null;receiverCaption=null;foreach(var m in moduleMaterials)UnityEngine.Object.Destroy(m);foreach(var m in moduleMeshes)UnityEngine.Object.Destroy(m);moduleMaterials.Clear();moduleMeshes.Clear();moduleRenderers.Clear();}
 }
}




