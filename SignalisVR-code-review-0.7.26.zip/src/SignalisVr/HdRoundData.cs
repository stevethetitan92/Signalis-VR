namespace SignalisVrTracking {internal static class HdRoundData {
public static readonly string Rifle=HdAsset.Read("Rifle-round.bin");
public static readonly string[] RifleTextures={HdAsset.Read("Rifle-round-tex-0.bin"),HdAsset.Read("Rifle-round-tex-1.bin")};
public static readonly float[] RifleColors={1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f,1.0f};
public static readonly string FlareGun=HdAsset.Read("FlareGun-round.bin");
public static readonly string[] FlareGunTextures={HdAsset.Read("FlareGun-round-tex-0.bin")};
public static readonly float[] FlareGunColors={1.0f,1.0f,1.0f,1.0f};
public static readonly string Shotgun=HdAsset.Read("Shotgun-round.bin");
public static readonly string[] ShotgunTextures={HdAsset.Read("Shotgun-round-tex-0.bin")};
public static readonly float[] ShotgunColors={1.0f,1.0f,1.0f,1.0f};
}}