$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'QuickSelectPolicy.cs')
function Check($v,$m){if(-not $v){throw $m}}
$p=[SignalisVrTracking.QuickSelectPolicy]::new()
Check ($p.Update($true,$true,0,1) -eq -1) 'Reconnect activated item'
$p.Update($true,$false,0,0)|Out-Null
Check ($p.Update($true,$true,0,1) -eq -1) 'Moving before touch activated item'
$p.Update($true,$true,0,0)|Out-Null
Check ($p.Update($true,$true,0,1) -eq 0) 'Up missing'
1..100|ForEach-Object {Check ($p.Update($true,$true,0,1) -eq -1) 'Held direction repeated'}
Check ($p.Update($true,$true,1,0) -eq -1) 'Direction change bypassed center'
$p.Update($true,$true,0,0)|Out-Null
Check ($p.Update($true,$true,1,1) -eq -1) 'Diagonal activated'
Check ($p.Update($true,$true,1,0) -eq 1) 'Right missing'
$p.Update($true,$true,0,0)|Out-Null
Check ($p.Update($true,$true,0,-1) -eq 2) 'Down missing'
$p.Update($true,$true,0,0)|Out-Null
Check ($p.Update($true,$true,-1,0) -eq 3) 'Left missing'
$p.Update($false,$true,0,0)|Out-Null
Check (-not $p.Open) 'Menu stayed open on tracking loss'
Check ($p.Update($true,$true,0,1) -eq -1) 'Tracking recovery used item'
$u=[SignalisVrTracking.QuickUsePolicy]::new()
Check (-not $u.Update($true,$true)) 'Selecting health while trigger held consumed it'
$u.Update($true,$false)|Out-Null
Check ($u.Update($true,$true)) 'Fresh trigger failed'
1..100|ForEach-Object {Check (-not $u.Update($true,$true)) 'Held trigger repeated healing'}
$u.Update($false,$false)|Out-Null
Check (-not $u.Update($true,$true)) 'Resume consumed health'
'PASS directional wheel edges, deadzone, diagonals, interruptions and health trigger release/repress'
