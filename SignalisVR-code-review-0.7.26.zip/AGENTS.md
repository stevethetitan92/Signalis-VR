# SIGNALIS VR no-door/ladder-marker variant

Work only in this workspace. The original project and installed game are read-only
references and must remain available as fallback. Do not install automatically.

Read and update `outputs/SignalisVrNoMarkersDevelopmentLog.md` for continuity.
Keep this variant's log separate; do not synchronize it over the original project's
development log or its shared copy. Preserve historical builds and evidence.

Hide only door/ladder marker artwork and labels, on desktop and in VR. Preserve
actual interactions, object markers, approved INSPECT placement, books, dialogue,
puzzles, inventory, controls and native rendering behavior.

Distinguish automated checks, user observations, log evidence and unverified
runtime/headset behavior. Compilation or simulated tests do not establish graphics
stability. Record version, changed files, checks, hashes and installation status.

Before a new test candidate, audit the minimap/map and enemy rendering with the
same depth as the main mod: code, logs, dependencies, lifecycle, and performance.
Map checks include live refresh, interaction-only door states, projection and
arrow/door alignment, room labels, allowed POIs, floating artifacts, save/load,
scene changes, and growing exploration. Enemy checks include activation and room
entry, animations, texture readiness/loading, material changes, death/burn
transitions, visibility restoration, and accumulated rendering costs.
Also audit camera transitions/replacement, flat-to-stereo handoffs, smoothing,
pose/texture lifecycle, visibility restoration, and transition performance.
Audit world item markers with the same depth: size and readability at the reported
distances, centering on the actual object, missing markers, and unwanted/floating
markers. Check line of sight, occlusion, activation, pickup/consumption, room and
scene changes, and desktop/VR visibility restoration. Keep world-marker behavior
separate from minimap POI filtering; removing an item category from the minimap
must not remove its approved world marker. Preserve passage-door/ladder artwork
suppression and all actual interactions.
Audit working reflections: mirrors and other supported reflective surfaces,
correct perspective in both eyes, reflected player/enemy/object visibility,
texture freshness, clipping, camera replacement and flat/stereo transitions,
resource cleanup, and rendering cost. Preserve native reflection behavior where
appropriate; automated checks alone do not establish correct headset reflections.
Fix reproducible discrepancies and rerun affected checks. Keep automated results
separate from real game/headset measurements; never infer graphics stability or
performance from compilation or simulated checks.
